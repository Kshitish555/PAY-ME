/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package cn.carbswang.android.numberpickerview.library;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int npv_AlternativeHint = 2130903251;
        public static final int npv_AlternativeTextArrayWithMeasureHint = 2130903252;
        public static final int npv_AlternativeTextArrayWithoutMeasureHint = 2130903253;
        public static final int npv_DividerColor = 2130903254;
        public static final int npv_DividerHeight = 2130903255;
        public static final int npv_DividerMarginLeft = 2130903256;
        public static final int npv_DividerMarginRight = 2130903257;
        public static final int npv_EmptyItemHint = 2130903258;
        public static final int npv_HintText = 2130903259;
        public static final int npv_ItemPaddingHorizontal = 2130903260;
        public static final int npv_ItemPaddingVertical = 2130903261;
        public static final int npv_MarginEndOfHint = 2130903262;
        public static final int npv_MarginStartOfHint = 2130903263;
        public static final int npv_MaxValue = 2130903264;
        public static final int npv_MinValue = 2130903265;
        public static final int npv_RespondChangeInMainThread = 2130903266;
        public static final int npv_RespondChangeOnDetached = 2130903267;
        public static final int npv_ShowDivider = 2130903268;
        public static final int npv_ShownCount = 2130903269;
        public static final int npv_TextArray = 2130903270;
        public static final int npv_TextColorHint = 2130903271;
        public static final int npv_TextColorNormal = 2130903272;
        public static final int npv_TextColorSelected = 2130903273;
        public static final int npv_TextEllipsize = 2130903274;
        public static final int npv_TextSizeHint = 2130903275;
        public static final int npv_TextSizeNormal = 2130903276;
        public static final int npv_TextSizeSelected = 2130903277;
        public static final int npv_WrapSelectorWheel = 2130903278;

        private attr() {
        }
    }

    public static final class styleable {
        public static final int[] NumberPickerView = new int[]{2130903251, 2130903252, 2130903253, 2130903254, 2130903255, 2130903256, 2130903257, 2130903258, 2130903259, 2130903260, 2130903261, 2130903262, 2130903263, 2130903264, 2130903265, 2130903266, 2130903267, 2130903268, 2130903269, 2130903270, 2130903271, 2130903272, 2130903273, 2130903274, 2130903275, 2130903276, 2130903277, 2130903278};
        public static final int NumberPickerView_npv_AlternativeHint = 0;
        public static final int NumberPickerView_npv_AlternativeTextArrayWithMeasureHint = 1;
        public static final int NumberPickerView_npv_AlternativeTextArrayWithoutMeasureHint = 2;
        public static final int NumberPickerView_npv_DividerColor = 3;
        public static final int NumberPickerView_npv_DividerHeight = 4;
        public static final int NumberPickerView_npv_DividerMarginLeft = 5;
        public static final int NumberPickerView_npv_DividerMarginRight = 6;
        public static final int NumberPickerView_npv_EmptyItemHint = 7;
        public static final int NumberPickerView_npv_HintText = 8;
        public static final int NumberPickerView_npv_ItemPaddingHorizontal = 9;
        public static final int NumberPickerView_npv_ItemPaddingVertical = 10;
        public static final int NumberPickerView_npv_MarginEndOfHint = 11;
        public static final int NumberPickerView_npv_MarginStartOfHint = 12;
        public static final int NumberPickerView_npv_MaxValue = 13;
        public static final int NumberPickerView_npv_MinValue = 14;
        public static final int NumberPickerView_npv_RespondChangeInMainThread = 15;
        public static final int NumberPickerView_npv_RespondChangeOnDetached = 16;
        public static final int NumberPickerView_npv_ShowDivider = 17;
        public static final int NumberPickerView_npv_ShownCount = 18;
        public static final int NumberPickerView_npv_TextArray = 19;
        public static final int NumberPickerView_npv_TextColorHint = 20;
        public static final int NumberPickerView_npv_TextColorNormal = 21;
        public static final int NumberPickerView_npv_TextColorSelected = 22;
        public static final int NumberPickerView_npv_TextEllipsize = 23;
        public static final int NumberPickerView_npv_TextSizeHint = 24;
        public static final int NumberPickerView_npv_TextSizeNormal = 25;
        public static final int NumberPickerView_npv_TextSizeSelected = 26;
        public static final int NumberPickerView_npv_WrapSelectorWheel = 27;

        private styleable() {
        }
    }

}

