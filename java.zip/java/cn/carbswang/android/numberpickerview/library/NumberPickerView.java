/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$FontMetrics
 *  android.graphics.Paint$Style
 *  android.graphics.Typeface
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.os.Message
 *  android.text.TextPaint
 *  android.text.TextUtils
 *  android.text.TextUtils$TruncateAt
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.MotionEvent
 *  android.view.VelocityTracker
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewConfiguration
 *  android.view.ViewParent
 *  android.widget.Scroller
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package cn.carbswang.android.numberpickerview.library;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.widget.Scroller;
import cn.carbswang.android.numberpickerview.library.R;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NumberPickerView
extends View {
    private static final boolean DEFAULT_CURRENT_ITEM_INDEX_EFFECT = false;
    private static final int DEFAULT_DIVIDER_COLOR = -695533;
    private static final int DEFAULT_DIVIDER_HEIGHT = 2;
    private static final int DEFAULT_DIVIDER_MARGIN_HORIZONTAL = 0;
    private static final int DEFAULT_INTERVAL_REVISE_DURATION = 300;
    private static final int DEFAULT_ITEM_PADDING_DP_H = 5;
    private static final int DEFAULT_ITEM_PADDING_DP_V = 2;
    private static final int DEFAULT_MARGIN_END_OF_HINT_DP = 8;
    private static final int DEFAULT_MARGIN_START_OF_HINT_DP = 8;
    private static final int DEFAULT_MAX_SCROLL_BY_INDEX_DURATION = 600;
    private static final int DEFAULT_MIN_SCROLL_BY_INDEX_DURATION = 300;
    private static final boolean DEFAULT_RESPOND_CHANGE_IN_MAIN_THREAD = true;
    private static final boolean DEFAULT_RESPOND_CHANGE_ON_DETACH = false;
    private static final int DEFAULT_SHOWN_COUNT = 3;
    private static final boolean DEFAULT_SHOW_DIVIDER = true;
    private static final int DEFAULT_TEXT_COLOR_NORMAL = -13421773;
    private static final int DEFAULT_TEXT_COLOR_SELECTED = -695533;
    private static final int DEFAULT_TEXT_SIZE_HINT_SP = 14;
    private static final int DEFAULT_TEXT_SIZE_NORMAL_SP = 14;
    private static final int DEFAULT_TEXT_SIZE_SELECTED_SP = 16;
    private static final boolean DEFAULT_WRAP_SELECTOR_WHEEL = true;
    private static final int HANDLER_INTERVAL_REFRESH = 32;
    private static final int HANDLER_WHAT_LISTENER_VALUE_CHANGED = 2;
    private static final int HANDLER_WHAT_REFRESH = 1;
    private static final int HANDLER_WHAT_REQUEST_LAYOUT = 3;
    private static final String TEXT_ELLIPSIZE_END = "end";
    private static final String TEXT_ELLIPSIZE_MIDDLE = "middle";
    private static final String TEXT_ELLIPSIZE_START = "start";
    private float currY = 0.0f;
    private float dividerY0;
    private float dividerY1;
    private float downY = 0.0f;
    private float downYGlobal = 0.0f;
    private String mAlterHint;
    private CharSequence[] mAlterTextArrayWithMeasureHint;
    private CharSequence[] mAlterTextArrayWithoutMeasureHint;
    private int mCurrDrawFirstItemIndex = 0;
    private int mCurrDrawFirstItemY = 0;
    private int mCurrDrawGlobalY = 0;
    private boolean mCurrentItemIndexEffect = false;
    private String[] mDisplayedValues;
    private int mDividerColor = -695533;
    private int mDividerHeight = 2;
    private int mDividerIndex0 = 0;
    private int mDividerIndex1 = 0;
    private int mDividerMarginL = 0;
    private int mDividerMarginR = 0;
    private String mEmptyItemHint;
    private boolean mFlagMayPress = false;
    private float mFriction = 1.0f;
    private Handler mHandlerInMainThread;
    private Handler mHandlerInNewThread;
    private HandlerThread mHandlerThread;
    private boolean mHasInit = false;
    private String mHintText;
    private int mInScrollingPickedNewValue;
    private int mInScrollingPickedOldValue;
    private int mItemHeight;
    private int mItemPaddingHorizontal = 0;
    private int mItemPaddingVertical = 0;
    private int mMarginEndOfHint = 0;
    private int mMarginStartOfHint = 0;
    private int mMaxHeightOfDisplayedValues = 0;
    private int mMaxShowIndex = -1;
    private int mMaxValue = 0;
    private int mMaxWidthOfAlterArrayWithMeasureHint = 0;
    private int mMaxWidthOfAlterArrayWithoutMeasureHint = 0;
    private int mMaxWidthOfDisplayedValues = 0;
    private int mMinShowIndex = -1;
    private int mMinValue = 0;
    private int mMiniVelocityFling = 150;
    private int mNotWrapLimitYBottom;
    private int mNotWrapLimitYTop;
    private OnScrollListener mOnScrollListener;
    private OnValueChangeListener mOnValueChangeListener;
    private OnValueChangeListenerInScrolling mOnValueChangeListenerInScrolling;
    private OnValueChangeListenerRelativeToRaw mOnValueChangeListenerRaw;
    private Paint mPaintDivider = new Paint();
    private Paint mPaintHint = new Paint();
    private TextPaint mPaintText = new TextPaint();
    private boolean mPendingWrapToLinear = false;
    private int mPrevPickedIndex = 0;
    private boolean mRespondChangeInMainThread = true;
    private boolean mRespondChangeOnDetach = false;
    private int mScaledTouchSlop = 8;
    private int mScrollState = 0;
    private Scroller mScroller;
    private boolean mShowDivider = true;
    private int mShownCount = 3;
    private int mSpecModeH = 0;
    private int mSpecModeW = 0;
    private int mTextColorHint = -695533;
    private int mTextColorNormal = -13421773;
    private int mTextColorSelected = -695533;
    private String mTextEllipsize;
    private int mTextSizeHint = 0;
    private float mTextSizeHintCenterYOffset = 0.0f;
    private int mTextSizeNormal = 0;
    private float mTextSizeNormalCenterYOffset = 0.0f;
    private int mTextSizeSelected = 0;
    private float mTextSizeSelectedCenterYOffset = 0.0f;
    private Map<String, Integer> mTextWidthCache = new ConcurrentHashMap();
    private VelocityTracker mVelocityTracker;
    private float mViewCenterX;
    private int mViewHeight;
    private int mViewWidth;
    private int mWidthOfAlterHint = 0;
    private int mWidthOfHintText = 0;
    private boolean mWrapSelectorWheel = true;
    private boolean mWrapSelectorWheelCheck = true;

    public NumberPickerView(Context context) {
        super(context);
        this.init(context);
    }

    public NumberPickerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.initAttr(context, attributeSet);
        this.init(context);
    }

    public NumberPickerView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.initAttr(context, attributeSet);
        this.init(context);
    }

    private void calculateFirstItemParameterByGlobalY() {
        this.mCurrDrawFirstItemIndex = (int)Math.floor((double)((float)this.mCurrDrawGlobalY / (float)this.mItemHeight));
        int n = this.mCurrDrawGlobalY;
        int n2 = this.mCurrDrawFirstItemIndex;
        int n3 = this.mItemHeight;
        this.mCurrDrawFirstItemY = -(n - n2 * n3);
        if (this.mOnValueChangeListenerInScrolling != null) {
            int n4;
            int n5;
            this.mInScrollingPickedNewValue = -this.mCurrDrawFirstItemY > n3 / 2 ? n2 + 1 + this.mShownCount / 2 : n2 + this.mShownCount / 2;
            this.mInScrollingPickedNewValue %= this.getOneRecycleSize();
            int n6 = this.mInScrollingPickedNewValue;
            if (n6 < 0) {
                this.mInScrollingPickedNewValue = n6 + this.getOneRecycleSize();
            }
            if ((n4 = this.mInScrollingPickedOldValue) != (n5 = this.mInScrollingPickedNewValue)) {
                int n7 = this.mMinValue;
                this.respondPickedValueChangedInScrolling(n4 + n7, n5 + n7);
            }
            this.mInScrollingPickedOldValue = this.mInScrollingPickedNewValue;
        }
    }

    private void click(MotionEvent motionEvent) {
        float f = motionEvent.getY();
        for (int i = 0; i < this.mShownCount; ++i) {
            int n = this.mItemHeight;
            if (!((float)(n * i) <= f) || !(f < (float)(n * (i + 1)))) continue;
            this.clickItem(i);
            return;
        }
    }

    private void clickItem(int n) {
        int n2;
        if (n >= 0 && n < (n2 = this.mShownCount)) {
            this.scrollByIndexSmoothly(n - n2 / 2);
        }
    }

    private String[] convertCharSequenceArrayToStringArray(CharSequence[] arrcharSequence) {
        if (arrcharSequence == null) {
            return null;
        }
        String[] arrstring = new String[arrcharSequence.length];
        for (int i = 0; i < arrcharSequence.length; ++i) {
            arrstring[i] = arrcharSequence[i].toString();
        }
        return arrstring;
    }

    private void correctPositionByDefaultValue(int n, boolean bl) {
        this.mCurrDrawFirstItemIndex = n - (this.mShownCount - 1) / 2;
        this.mCurrDrawFirstItemIndex = this.getIndexByRawIndex(this.mCurrDrawFirstItemIndex, this.getOneRecycleSize(), bl);
        int n2 = this.mItemHeight;
        if (n2 == 0) {
            this.mCurrentItemIndexEffect = true;
            return;
        }
        int n3 = this.mCurrDrawFirstItemIndex;
        this.mCurrDrawGlobalY = n2 * n3;
        this.mInScrollingPickedOldValue = n3 + this.mShownCount / 2;
        this.mInScrollingPickedOldValue %= this.getOneRecycleSize();
        int n4 = this.mInScrollingPickedOldValue;
        if (n4 < 0) {
            this.mInScrollingPickedOldValue = n4 + this.getOneRecycleSize();
        }
        this.mInScrollingPickedNewValue = this.mInScrollingPickedOldValue;
        this.calculateFirstItemParameterByGlobalY();
    }

    private int dp2px(Context context, float f) {
        return (int)(0.5f + f * context.getResources().getDisplayMetrics().density);
    }

    private void drawContent(Canvas canvas) {
        float f = 0.0f;
        for (int i = 0; i < 1 + this.mShownCount; ++i) {
            float f2;
            float f3;
            int n;
            float f4;
            float f5 = this.mCurrDrawFirstItemY + i * this.mItemHeight;
            int n2 = i + this.mCurrDrawFirstItemIndex;
            int n3 = this.getOneRecycleSize();
            boolean bl = this.mWrapSelectorWheel && this.mWrapSelectorWheelCheck;
            int n4 = this.getIndexByRawIndex(n2, n3, bl);
            int n5 = this.mShownCount;
            if (i == n5 / 2) {
                int n6 = this.mItemHeight;
                f3 = (float)(n6 + this.mCurrDrawFirstItemY) / (float)n6;
                n = this.getEvaluateColor(f3, this.mTextColorNormal, this.mTextColorSelected);
                f4 = this.getEvaluateSize(f3, this.mTextSizeNormal, this.mTextSizeSelected);
                f2 = this.getEvaluateSize(f3, this.mTextSizeNormalCenterYOffset, this.mTextSizeSelectedCenterYOffset);
            } else if (i == 1 + n5 / 2) {
                float f6 = 1.0f - f;
                int n7 = this.getEvaluateColor(f6, this.mTextColorNormal, this.mTextColorSelected);
                float f7 = this.getEvaluateSize(f6, this.mTextSizeNormal, this.mTextSizeSelected);
                float f8 = this.getEvaluateSize(f6, this.mTextSizeNormalCenterYOffset, this.mTextSizeSelectedCenterYOffset);
                f3 = f;
                n = n7;
                f4 = f7;
                f2 = f8;
            } else {
                int n8 = this.mTextColorNormal;
                f4 = this.mTextSizeNormal;
                f2 = this.mTextSizeNormalCenterYOffset;
                f3 = f;
                n = n8;
            }
            this.mPaintText.setColor(n);
            this.mPaintText.setTextSize(f4);
            if (n4 >= 0 && n4 < this.getOneRecycleSize()) {
                String string2 = this.mDisplayedValues[n4 + this.mMinShowIndex];
                if (this.mTextEllipsize != null) {
                    string2 = TextUtils.ellipsize((CharSequence)string2, (TextPaint)this.mPaintText, (float)(this.getWidth() - 2 * this.mItemPaddingHorizontal), (TextUtils.TruncateAt)this.getEllipsizeType());
                }
                int n9 = this.mPaintText.getTextAlign() == Paint.Align.RIGHT ? this.mViewWidth - this.mItemPaddingHorizontal : this.mItemPaddingHorizontal;
                float f9 = n9;
                canvas.drawText(string2.toString(), f9, f2 + (f5 + (float)(this.mItemHeight / 2)), (Paint)this.mPaintText);
            } else if (!TextUtils.isEmpty((CharSequence)this.mEmptyItemHint)) {
                canvas.drawText(this.mEmptyItemHint, this.mViewCenterX, f2 + (f5 + (float)(this.mItemHeight / 2)), (Paint)this.mPaintText);
            }
            f = f3;
        }
    }

    private void drawHint(Canvas canvas) {
        if (TextUtils.isEmpty((CharSequence)this.mHintText)) {
            return;
        }
        canvas.drawText(this.mHintText, this.mViewCenterX + (float)((this.mMaxWidthOfDisplayedValues + this.mWidthOfHintText) / 2) + (float)this.mMarginStartOfHint, (this.dividerY0 + this.dividerY1) / 2.0f + this.mTextSizeHintCenterYOffset, this.mPaintHint);
    }

    private void drawLine(Canvas canvas) {
        if (this.mShowDivider) {
            canvas.drawLine((float)(this.getPaddingLeft() + this.mDividerMarginL), this.dividerY0, (float)(this.mViewWidth - this.getPaddingRight() - this.mDividerMarginR), this.dividerY0, this.mPaintDivider);
            canvas.drawLine((float)(this.getPaddingLeft() + this.mDividerMarginL), this.dividerY1, (float)(this.mViewWidth - this.getPaddingRight() - this.mDividerMarginR), this.dividerY1, this.mPaintDivider);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private TextUtils.TruncateAt getEllipsizeType() {
        block4 : {
            block2 : {
                block3 : {
                    var1_1 = this.mTextEllipsize;
                    var2_2 = var1_1.hashCode();
                    if (var2_2 == -1074341483) break block2;
                    if (var2_2 == 100571) break block3;
                    if (var2_2 != 109757538 || !var1_1.equals((Object)"start")) ** GOTO lbl-1000
                    var3_3 = 0;
                    break block4;
                }
                if (!var1_1.equals((Object)"end")) ** GOTO lbl-1000
                var3_3 = 2;
                break block4;
            }
            if (var1_1.equals((Object)"middle")) {
                var3_3 = 1;
            } else lbl-1000: // 3 sources:
            {
                var3_3 = -1;
            }
        }
        if (var3_3 == 0) return TextUtils.TruncateAt.START;
        if (var3_3 == 1) return TextUtils.TruncateAt.MIDDLE;
        if (var3_3 != 2) throw new IllegalArgumentException("Illegal text ellipsize type.");
        return TextUtils.TruncateAt.END;
    }

    private int getEvaluateColor(float f, int n, int n2) {
        int n3 = (n & -16777216) >>> 24;
        int n4 = (n & 16711680) >>> 16;
        int n5 = (n & 65280) >>> 8;
        int n6 = (n & 255) >>> 0;
        int n7 = (-16777216 & n2) >>> 24;
        int n8 = (16711680 & n2) >>> 16;
        int n9 = (65280 & n2) >>> 8;
        int n10 = (n2 & 255) >>> 0;
        int n11 = (int)((float)n3 + f * (float)(n7 - n3));
        int n12 = (int)((float)n4 + f * (float)(n8 - n4));
        int n13 = (int)((float)n5 + f * (float)(n9 - n5));
        return (int)((float)n6 + f * (float)(n10 - n6)) | (n11 << 24 | n12 << 16 | n13 << 8);
    }

    private float getEvaluateSize(float f, float f2, float f3) {
        return f2 + f * (f3 - f2);
    }

    private int getIndexByRawIndex(int n, int n2, boolean bl) {
        if (n2 <= 0) {
            return 0;
        }
        if (bl && (n %= n2) < 0) {
            n += n2;
        }
        return n;
    }

    private int getMaxWidthOfTextArray(CharSequence[] arrcharSequence, Paint paint) {
        if (arrcharSequence == null) {
            return 0;
        }
        int n = arrcharSequence.length;
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            CharSequence charSequence = arrcharSequence[i];
            if (charSequence == null) continue;
            n2 = Math.max((int)this.getTextWidth(charSequence, paint), (int)n2);
        }
        return n2;
    }

    private Message getMsg(int n) {
        return this.getMsg(n, 0, 0, null);
    }

    private Message getMsg(int n, int n2, int n3, Object object) {
        Message message = Message.obtain();
        message.what = n;
        message.arg1 = n2;
        message.arg2 = n3;
        message.obj = object;
        return message;
    }

    private float getTextCenterYOffset(Paint.FontMetrics fontMetrics) {
        if (fontMetrics == null) {
            return 0.0f;
        }
        return Math.abs((float)(fontMetrics.top + fontMetrics.bottom)) / 2.0f;
    }

    private int getTextWidth(CharSequence charSequence, Paint paint) {
        Integer n;
        if (TextUtils.isEmpty((CharSequence)charSequence)) {
            return 0;
        }
        String string2 = charSequence.toString();
        if (this.mTextWidthCache.containsKey((Object)string2) && (n = (Integer)this.mTextWidthCache.get((Object)string2)) != null) {
            return n;
        }
        int n2 = (int)(0.5f + paint.measureText(string2));
        this.mTextWidthCache.put((Object)string2, (Object)n2);
        return n2;
    }

    private int getWillPickIndexByGlobalY(int n) {
        int n2;
        int n3 = this.mItemHeight;
        if (n3 == 0) {
            return 0;
        }
        int n4 = n / n3 + this.mShownCount / 2;
        int n5 = this.getOneRecycleSize();
        boolean bl = this.mWrapSelectorWheel;
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = this.mWrapSelectorWheelCheck;
            bl2 = false;
            if (bl3) {
                bl2 = true;
            }
        }
        if ((n2 = this.getIndexByRawIndex(n4, n5, bl2)) >= 0 && n2 < this.getOneRecycleSize()) {
            return n2 + this.mMinShowIndex;
        }
        return this.getOneRecycleSize() - 1;
    }

    private void inflateDisplayedValuesIfNull() {
        if (this.mDisplayedValues == null) {
            this.mDisplayedValues = new String[1];
            this.mDisplayedValues[0] = "";
        }
    }

    private void init(Context context) {
        this.mScroller = new Scroller(context);
        this.mMiniVelocityFling = ViewConfiguration.get((Context)this.getContext()).getScaledMinimumFlingVelocity();
        this.mScaledTouchSlop = ViewConfiguration.get((Context)this.getContext()).getScaledTouchSlop();
        if (this.mTextSizeNormal == 0) {
            this.mTextSizeNormal = this.sp2px(context, 14.0f);
        }
        if (this.mTextSizeSelected == 0) {
            this.mTextSizeSelected = this.sp2px(context, 16.0f);
        }
        if (this.mTextSizeHint == 0) {
            this.mTextSizeHint = this.sp2px(context, 14.0f);
        }
        if (this.mMarginStartOfHint == 0) {
            this.mMarginStartOfHint = this.dp2px(context, 8.0f);
        }
        if (this.mMarginEndOfHint == 0) {
            this.mMarginEndOfHint = this.dp2px(context, 8.0f);
        }
        this.mPaintDivider.setColor(this.mDividerColor);
        this.mPaintDivider.setAntiAlias(true);
        this.mPaintDivider.setStyle(Paint.Style.STROKE);
        this.mPaintDivider.setStrokeWidth((float)this.mDividerHeight);
        this.mPaintText.setColor(this.mTextColorNormal);
        this.mPaintText.setAntiAlias(true);
        this.mPaintText.setTextAlign(Paint.Align.RIGHT);
        this.mPaintHint.setColor(this.mTextColorHint);
        this.mPaintHint.setAntiAlias(true);
        this.mPaintHint.setTextAlign(Paint.Align.CENTER);
        this.mPaintHint.setTextSize((float)this.mTextSizeHint);
        int n = this.mShownCount;
        if (n % 2 == 0) {
            this.mShownCount = n + 1;
        }
        if (this.mMinShowIndex == -1 || this.mMaxShowIndex == -1) {
            this.updateValueForInit();
        }
        this.initHandler();
    }

    private void initAttr(Context context, AttributeSet attributeSet) {
        if (attributeSet == null) {
            return;
        }
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, R.styleable.NumberPickerView);
        int n = typedArray.getIndexCount();
        for (int i = 0; i < n; ++i) {
            int n2 = typedArray.getIndex(i);
            if (n2 == R.styleable.NumberPickerView_npv_ShownCount) {
                this.mShownCount = typedArray.getInt(n2, 3);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_DividerColor) {
                this.mDividerColor = typedArray.getColor(n2, -695533);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_DividerHeight) {
                this.mDividerHeight = typedArray.getDimensionPixelSize(n2, 2);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_DividerMarginLeft) {
                this.mDividerMarginL = typedArray.getDimensionPixelSize(n2, 0);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_DividerMarginRight) {
                this.mDividerMarginR = typedArray.getDimensionPixelSize(n2, 0);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_TextArray) {
                this.mDisplayedValues = this.convertCharSequenceArrayToStringArray(typedArray.getTextArray(n2));
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_TextColorNormal) {
                this.mTextColorNormal = typedArray.getColor(n2, -13421773);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_TextColorSelected) {
                this.mTextColorSelected = typedArray.getColor(n2, -695533);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_TextColorHint) {
                this.mTextColorHint = typedArray.getColor(n2, -695533);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_TextSizeNormal) {
                this.mTextSizeNormal = typedArray.getDimensionPixelSize(n2, this.sp2px(context, 14.0f));
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_TextSizeSelected) {
                this.mTextSizeSelected = typedArray.getDimensionPixelSize(n2, this.sp2px(context, 16.0f));
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_TextSizeHint) {
                this.mTextSizeHint = typedArray.getDimensionPixelSize(n2, this.sp2px(context, 14.0f));
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_MinValue) {
                this.mMinShowIndex = typedArray.getInteger(n2, 0);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_MaxValue) {
                this.mMaxShowIndex = typedArray.getInteger(n2, 0);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_WrapSelectorWheel) {
                this.mWrapSelectorWheel = typedArray.getBoolean(n2, true);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_ShowDivider) {
                this.mShowDivider = typedArray.getBoolean(n2, true);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_HintText) {
                this.mHintText = typedArray.getString(n2);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_AlternativeHint) {
                this.mAlterHint = typedArray.getString(n2);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_EmptyItemHint) {
                this.mEmptyItemHint = typedArray.getString(n2);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_MarginStartOfHint) {
                this.mMarginStartOfHint = typedArray.getDimensionPixelSize(n2, this.dp2px(context, 8.0f));
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_MarginEndOfHint) {
                this.mMarginEndOfHint = typedArray.getDimensionPixelSize(n2, this.dp2px(context, 8.0f));
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_ItemPaddingVertical) {
                this.mItemPaddingVertical = typedArray.getDimensionPixelSize(n2, this.dp2px(context, 2.0f));
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_ItemPaddingHorizontal) {
                this.mItemPaddingHorizontal = typedArray.getDimensionPixelSize(n2, this.dp2px(context, 5.0f));
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_AlternativeTextArrayWithMeasureHint) {
                this.mAlterTextArrayWithMeasureHint = typedArray.getTextArray(n2);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_AlternativeTextArrayWithoutMeasureHint) {
                this.mAlterTextArrayWithoutMeasureHint = typedArray.getTextArray(n2);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_RespondChangeOnDetached) {
                this.mRespondChangeOnDetach = typedArray.getBoolean(n2, false);
                continue;
            }
            if (n2 == R.styleable.NumberPickerView_npv_RespondChangeInMainThread) {
                this.mRespondChangeInMainThread = typedArray.getBoolean(n2, true);
                continue;
            }
            if (n2 != R.styleable.NumberPickerView_npv_TextEllipsize) continue;
            this.mTextEllipsize = typedArray.getString(n2);
        }
        typedArray.recycle();
    }

    private void initHandler() {
        this.mHandlerThread = new HandlerThread("HandlerThread-For-Refreshing");
        this.mHandlerThread.start();
        this.mHandlerInNewThread = new Handler(this.mHandlerThread.getLooper()){

            public void handleMessage(Message message) {
                int n;
                int n2 = message.what;
                if (n2 != 1) {
                    if (n2 != 2) {
                        return;
                    }
                    NumberPickerView.this.respondPickedValueChanged(message.arg1, message.arg2, message.obj);
                    return;
                }
                boolean bl = NumberPickerView.this.mScroller.isFinished();
                int n3 = 0;
                if (!bl) {
                    if (NumberPickerView.this.mScrollState == 0) {
                        NumberPickerView.this.onScrollStateChange(1);
                    }
                    NumberPickerView.this.mHandlerInNewThread.sendMessageDelayed(NumberPickerView.this.getMsg(1, 0, 0, message.obj), 32L);
                    return;
                }
                if (NumberPickerView.this.mCurrDrawFirstItemY != 0) {
                    int n4;
                    if (NumberPickerView.this.mScrollState == 0) {
                        NumberPickerView.this.onScrollStateChange(1);
                    }
                    if (NumberPickerView.this.mCurrDrawFirstItemY < -NumberPickerView.this.mItemHeight / 2) {
                        n4 = (int)(300.0f * (float)(NumberPickerView.this.mItemHeight + NumberPickerView.this.mCurrDrawFirstItemY) / (float)NumberPickerView.this.mItemHeight);
                        NumberPickerView.this.mScroller.startScroll(0, NumberPickerView.this.mCurrDrawGlobalY, 0, NumberPickerView.this.mItemHeight + NumberPickerView.this.mCurrDrawFirstItemY, n4 * 3);
                        NumberPickerView numberPickerView = NumberPickerView.this;
                        n = numberPickerView.getWillPickIndexByGlobalY(numberPickerView.mCurrDrawGlobalY + NumberPickerView.this.mItemHeight + NumberPickerView.this.mCurrDrawFirstItemY);
                    } else {
                        n4 = (int)(300.0f * (float)(-NumberPickerView.this.mCurrDrawFirstItemY) / (float)NumberPickerView.this.mItemHeight);
                        NumberPickerView.this.mScroller.startScroll(0, NumberPickerView.this.mCurrDrawGlobalY, 0, NumberPickerView.this.mCurrDrawFirstItemY, n4 * 3);
                        NumberPickerView numberPickerView = NumberPickerView.this;
                        n = numberPickerView.getWillPickIndexByGlobalY(numberPickerView.mCurrDrawGlobalY + NumberPickerView.this.mCurrDrawFirstItemY);
                    }
                    n3 = n4;
                    NumberPickerView.this.postInvalidate();
                } else {
                    NumberPickerView.this.onScrollStateChange(0);
                    NumberPickerView numberPickerView = NumberPickerView.this;
                    n = numberPickerView.getWillPickIndexByGlobalY(numberPickerView.mCurrDrawGlobalY);
                }
                NumberPickerView numberPickerView = NumberPickerView.this;
                Message message2 = numberPickerView.getMsg(2, numberPickerView.mPrevPickedIndex, n, message.obj);
                if (NumberPickerView.this.mRespondChangeInMainThread) {
                    NumberPickerView.this.mHandlerInMainThread.sendMessageDelayed(message2, (long)(n3 * 2));
                    return;
                }
                NumberPickerView.this.mHandlerInNewThread.sendMessageDelayed(message2, (long)(n3 * 2));
            }
        };
        this.mHandlerInMainThread = new Handler(){

            public void handleMessage(Message message) {
                super.handleMessage(message);
                int n = message.what;
                if (n != 2) {
                    if (n != 3) {
                        return;
                    }
                    NumberPickerView.this.requestLayout();
                    return;
                }
                NumberPickerView.this.respondPickedValueChanged(message.arg1, message.arg2, message.obj);
            }
        };
    }

    private void initHandlerIfDead() {
        if (!this.mHandlerThread.isAlive()) {
            this.initHandler();
        }
    }

    private void internalSetWrapToLinear() {
        this.correctPositionByDefaultValue(this.getPickedIndexRelativeToRaw() - this.mMinShowIndex, false);
        this.mWrapSelectorWheel = false;
        this.postInvalidate();
    }

    private boolean isStringEqual(String string2, String string3) {
        if (string2 == null) {
            return string3 == null;
        }
        return string2.equals((Object)string3);
    }

    private int limitY(int n) {
        if (this.mWrapSelectorWheel && this.mWrapSelectorWheelCheck) {
            return n;
        }
        int n2 = this.mNotWrapLimitYBottom;
        if (n < n2) {
            return n2;
        }
        int n3 = this.mNotWrapLimitYTop;
        if (n > n3) {
            return n3;
        }
        return n;
    }

    private int measureHeight(int n) {
        int n2;
        this.mSpecModeH = n2 = View.MeasureSpec.getMode((int)n);
        int n3 = View.MeasureSpec.getSize((int)n);
        if (n2 == 1073741824) {
            return n3;
        }
        int n4 = this.mShownCount * (this.mMaxHeightOfDisplayedValues + 2 * this.mItemPaddingVertical) + (this.getPaddingTop() + this.getPaddingBottom());
        if (n2 == Integer.MIN_VALUE) {
            return Math.min((int)n4, (int)n3);
        }
        return n4;
    }

    private int measureWidth(int n) {
        int n2;
        this.mSpecModeW = n2 = View.MeasureSpec.getMode((int)n);
        int n3 = View.MeasureSpec.getSize((int)n);
        if (n2 == 1073741824) {
            return n3;
        }
        int n4 = Math.max((int)this.mWidthOfHintText, (int)this.mWidthOfAlterHint) == 0 ? 0 : this.mMarginEndOfHint;
        int n5 = Math.max((int)this.mWidthOfHintText, (int)this.mWidthOfAlterHint) == 0 ? 0 : this.mMarginStartOfHint;
        int n6 = Math.max((int)this.mMaxWidthOfAlterArrayWithMeasureHint, (int)(Math.max((int)this.mMaxWidthOfDisplayedValues, (int)this.mMaxWidthOfAlterArrayWithoutMeasureHint) + 2 * (n4 + (n5 + Math.max((int)this.mWidthOfHintText, (int)this.mWidthOfAlterHint)) + 2 * this.mItemPaddingHorizontal))) + (this.getPaddingLeft() + this.getPaddingRight());
        if (n2 == Integer.MIN_VALUE) {
            return Math.min((int)n6, (int)n3);
        }
        return n6;
    }

    private void onScrollStateChange(int n) {
        if (this.mScrollState == n) {
            return;
        }
        this.mScrollState = n;
        OnScrollListener onScrollListener = this.mOnScrollListener;
        if (onScrollListener != null) {
            onScrollListener.onScrollStateChange(this, n);
        }
    }

    private int refineValueByLimit(int n, int n2, int n3, boolean bl) {
        if (bl) {
            if (n > n3) {
                return -1 + (n2 + (n - n3) % this.getOneRecycleSize());
            }
            if (n < n2) {
                n = 1 + (n3 + (n - n2) % this.getOneRecycleSize());
            }
            return n;
        }
        if (n > n3) {
            return n3;
        }
        if (n < n2) {
            n = n2;
        }
        return n;
    }

    private void releaseVelocityTracker() {
        VelocityTracker velocityTracker = this.mVelocityTracker;
        if (velocityTracker != null) {
            velocityTracker.clear();
            this.mVelocityTracker.recycle();
            this.mVelocityTracker = null;
        }
    }

    private void respondPickedValueChanged(int n, int n2, Object object) {
        this.onScrollStateChange(0);
        if (n != n2) {
            if (object == null || !(object instanceof Boolean) || ((Boolean)object).booleanValue()) {
                OnValueChangeListenerRelativeToRaw onValueChangeListenerRelativeToRaw;
                OnValueChangeListener onValueChangeListener = this.mOnValueChangeListener;
                if (onValueChangeListener != null) {
                    int n3 = this.mMinValue;
                    onValueChangeListener.onValueChange(this, n + n3, n3 + n2);
                }
                if ((onValueChangeListenerRelativeToRaw = this.mOnValueChangeListenerRaw) != null) {
                    onValueChangeListenerRelativeToRaw.onValueChangeRelativeToRaw(this, n, n2, this.mDisplayedValues);
                }
            }
            this.mPrevPickedIndex = n2;
        }
        if (this.mPendingWrapToLinear) {
            this.mPendingWrapToLinear = false;
            this.internalSetWrapToLinear();
        }
    }

    private void respondPickedValueChangedInScrolling(int n, int n2) {
        this.mOnValueChangeListenerInScrolling.onValueChangeInScrolling(this, n, n2);
    }

    private void scrollByIndexSmoothly(int n) {
        this.scrollByIndexSmoothly(n, true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void scrollByIndexSmoothly(int n, boolean bl) {
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        this.initHandlerIfDead();
        if (!(this.mWrapSelectorWheel && this.mWrapSelectorWheelCheck || (n2 = (n5 = this.getPickedIndexRelativeToRaw()) + n) <= (n4 = this.mMaxShowIndex) && n2 >= (n4 = this.mMinShowIndex))) {
            n = n4 - n5;
        }
        if ((n6 = this.mCurrDrawFirstItemY) < -(n3 = this.mItemHeight) / 2) {
            int n8 = n3 + n6;
            int n9 = (int)(300.0f * (float)(n6 + n3) / (float)n3);
            int n10 = n < 0 ? -n9 - n * 300 : n9 + n * 300;
            n7 = n10;
            n6 = n8;
        } else {
            int n11 = (int)(300.0f * (float)(-n6) / (float)n3);
            n7 = n < 0 ? n11 - n * 300 : n11 + n * 300;
        }
        int n12 = n6 + n * this.mItemHeight;
        int n13 = 300;
        if (n7 >= n13) {
            n13 = n7;
        }
        if (n13 > 600) {
            n13 = 600;
        }
        this.mScroller.startScroll(0, this.mCurrDrawGlobalY, 0, n12, n13);
        if (bl) {
            this.mHandlerInNewThread.sendMessageDelayed(this.getMsg(1), (long)(n13 / 4));
        } else {
            this.mHandlerInNewThread.sendMessageDelayed(this.getMsg(1, 0, 0, (Object)new Boolean(bl)), (long)(n13 / 4));
        }
        this.postInvalidate();
    }

    private int sp2px(Context context, float f) {
        return (int)(0.5f + f * context.getResources().getDisplayMetrics().scaledDensity);
    }

    private void stopRefreshing() {
        Handler handler = this.mHandlerInNewThread;
        if (handler != null) {
            handler.removeMessages(1);
        }
    }

    private void updateContent(String[] arrstring) {
        this.mDisplayedValues = arrstring;
        this.updateWrapStateByContent();
    }

    private void updateContentAndIndex(String[] arrstring) {
        this.mMinShowIndex = 0;
        this.mMaxShowIndex = -1 + arrstring.length;
        this.mDisplayedValues = arrstring;
        this.updateWrapStateByContent();
    }

    private void updateDividerAttr() {
        int n = this.mShownCount;
        int n2 = this.mDividerIndex0 = n / 2;
        this.mDividerIndex1 = n2 + 1;
        int n3 = this.mViewHeight;
        this.dividerY0 = n2 * n3 / n;
        this.dividerY1 = n3 * this.mDividerIndex1 / n;
        if (this.mDividerMarginL < 0) {
            this.mDividerMarginL = 0;
        }
        if (this.mDividerMarginR < 0) {
            this.mDividerMarginR = 0;
        }
        if (this.mDividerMarginL + this.mDividerMarginR == 0) {
            return;
        }
        if (this.getPaddingLeft() + this.mDividerMarginL >= this.mViewWidth - this.getPaddingRight() - this.mDividerMarginR) {
            int n4 = this.getPaddingLeft() + this.mDividerMarginL + this.getPaddingRight();
            int n5 = this.mDividerMarginR;
            int n6 = n4 + n5 - this.mViewWidth;
            int n7 = this.mDividerMarginL;
            float f = n7;
            float f2 = n6;
            this.mDividerMarginL = (int)(f - f2 * (float)n7 / (float)(n7 + n5));
            this.mDividerMarginR = (int)((float)n5 - f2 * (float)n5 / (float)(n5 + this.mDividerMarginL));
        }
    }

    private void updateFontAttr() {
        int n;
        Paint paint;
        int n2;
        int n3 = this.mTextSizeNormal;
        int n4 = this.mItemHeight;
        if (n3 > n4) {
            this.mTextSizeNormal = n4;
        }
        if ((n2 = this.mTextSizeSelected) > (n = this.mItemHeight)) {
            this.mTextSizeSelected = n;
        }
        if ((paint = this.mPaintHint) != null) {
            paint.setTextSize((float)this.mTextSizeHint);
            this.mTextSizeHintCenterYOffset = this.getTextCenterYOffset(this.mPaintHint.getFontMetrics());
            this.mWidthOfHintText = this.getTextWidth(this.mHintText, this.mPaintHint);
            TextPaint textPaint = this.mPaintText;
            if (textPaint != null) {
                textPaint.setTextSize((float)this.mTextSizeSelected);
                this.mTextSizeSelectedCenterYOffset = this.getTextCenterYOffset(this.mPaintText.getFontMetrics());
                this.mPaintText.setTextSize((float)this.mTextSizeNormal);
                this.mTextSizeNormalCenterYOffset = this.getTextCenterYOffset(this.mPaintText.getFontMetrics());
                return;
            }
            throw new IllegalArgumentException("mPaintText should not be null.");
        }
        throw new IllegalArgumentException("mPaintHint should not be null.");
    }

    private void updateMaxHeightOfDisplayedValues() {
        float f = this.mPaintText.getTextSize();
        this.mPaintText.setTextSize((float)this.mTextSizeSelected);
        double d = this.mPaintText.getFontMetrics().bottom - this.mPaintText.getFontMetrics().top;
        Double.isNaN((double)d);
        this.mMaxHeightOfDisplayedValues = (int)(d + 0.5);
        this.mPaintText.setTextSize(f);
    }

    private void updateMaxWHOfDisplayedValues(boolean bl) {
        this.updateMaxWidthOfDisplayedValues();
        this.updateMaxHeightOfDisplayedValues();
        if (bl && (this.mSpecModeW == Integer.MIN_VALUE || this.mSpecModeH == Integer.MIN_VALUE)) {
            this.mHandlerInMainThread.sendEmptyMessage(3);
        }
    }

    private void updateMaxWidthOfDisplayedValues() {
        float f = this.mPaintText.getTextSize();
        this.mPaintText.setTextSize((float)this.mTextSizeSelected);
        this.mMaxWidthOfDisplayedValues = this.getMaxWidthOfTextArray(this.mDisplayedValues, (Paint)this.mPaintText);
        this.mMaxWidthOfAlterArrayWithMeasureHint = this.getMaxWidthOfTextArray(this.mAlterTextArrayWithMeasureHint, (Paint)this.mPaintText);
        this.mMaxWidthOfAlterArrayWithoutMeasureHint = this.getMaxWidthOfTextArray(this.mAlterTextArrayWithoutMeasureHint, (Paint)this.mPaintText);
        this.mPaintText.setTextSize((float)this.mTextSizeHint);
        this.mWidthOfAlterHint = this.getTextWidth(this.mAlterHint, (Paint)this.mPaintText);
        this.mPaintText.setTextSize(f);
    }

    private void updateNotWrapYLimit() {
        this.mNotWrapLimitYTop = 0;
        this.mNotWrapLimitYBottom = -this.mShownCount * this.mItemHeight;
        if (this.mDisplayedValues != null) {
            int n = this.getOneRecycleSize();
            int n2 = this.mShownCount;
            int n3 = -1 + (n - n2 / 2);
            int n4 = this.mItemHeight;
            this.mNotWrapLimitYTop = n3 * n4;
            this.mNotWrapLimitYBottom = n4 * -(n2 / 2);
        }
    }

    private void updateValue() {
        this.inflateDisplayedValuesIfNull();
        this.updateWrapStateByContent();
        this.mMinShowIndex = 0;
        this.mMaxShowIndex = -1 + this.mDisplayedValues.length;
    }

    private void updateValueForInit() {
        this.inflateDisplayedValuesIfNull();
        this.updateWrapStateByContent();
        if (this.mMinShowIndex == -1) {
            this.mMinShowIndex = 0;
        }
        if (this.mMaxShowIndex == -1) {
            this.mMaxShowIndex = -1 + this.mDisplayedValues.length;
        }
        this.setMinAndMaxShowIndex(this.mMinShowIndex, this.mMaxShowIndex, false);
    }

    private void updateWrapStateByContent() {
        boolean bl = this.mDisplayedValues.length > this.mShownCount;
        this.mWrapSelectorWheelCheck = bl;
    }

    public void computeScroll() {
        if (this.mItemHeight == 0) {
            return;
        }
        if (this.mScroller.computeScrollOffset()) {
            this.mCurrDrawGlobalY = this.mScroller.getCurrY();
            this.calculateFirstItemParameterByGlobalY();
            this.postInvalidate();
        }
    }

    public String getContentByCurrValue() {
        return this.mDisplayedValues[this.getValue() - this.mMinValue];
    }

    public String[] getDisplayedValues() {
        return this.mDisplayedValues;
    }

    public int getMaxValue() {
        return this.mMaxValue;
    }

    public int getMinValue() {
        return this.mMinValue;
    }

    public int getOneRecycleSize() {
        return 1 + (this.mMaxShowIndex - this.mMinShowIndex);
    }

    public int getPickedIndexRelativeToRaw() {
        int n = this.mCurrDrawFirstItemY;
        if (n != 0) {
            int n2 = this.mItemHeight;
            if (n < -n2 / 2) {
                return this.getWillPickIndexByGlobalY(n + (n2 + this.mCurrDrawGlobalY));
            }
            return this.getWillPickIndexByGlobalY(n + this.mCurrDrawGlobalY);
        }
        return this.getWillPickIndexByGlobalY(this.mCurrDrawGlobalY);
    }

    public int getRawContentSize() {
        String[] arrstring = this.mDisplayedValues;
        if (arrstring != null) {
            return arrstring.length;
        }
        return 0;
    }

    public int getValue() {
        return this.getPickedIndexRelativeToRaw() + this.mMinValue;
    }

    public boolean getWrapSelectorWheel() {
        return this.mWrapSelectorWheel;
    }

    public boolean getWrapSelectorWheelAbsolutely() {
        return this.mWrapSelectorWheel && this.mWrapSelectorWheelCheck;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        HandlerThread handlerThread = this.mHandlerThread;
        if (handlerThread == null || !handlerThread.isAlive()) {
            this.initHandler();
        }
    }

    protected void onDetachedFromWindow() {
        int n;
        int n2;
        super.onDetachedFromWindow();
        this.mHandlerThread.quit();
        if (this.mItemHeight == 0) {
            return;
        }
        if (!this.mScroller.isFinished()) {
            this.mScroller.abortAnimation();
            this.mCurrDrawGlobalY = this.mScroller.getCurrY();
            this.calculateFirstItemParameterByGlobalY();
            int n3 = this.mCurrDrawFirstItemY;
            if (n3 != 0) {
                int n4 = this.mItemHeight;
                this.mCurrDrawGlobalY = n3 < -n4 / 2 ? n3 + (n4 + this.mCurrDrawGlobalY) : n3 + this.mCurrDrawGlobalY;
                this.calculateFirstItemParameterByGlobalY();
            }
            this.onScrollStateChange(0);
        }
        if ((n = this.getWillPickIndexByGlobalY(this.mCurrDrawGlobalY)) != (n2 = this.mPrevPickedIndex) && this.mRespondChangeOnDetach) {
            try {
                if (this.mOnValueChangeListener != null) {
                    this.mOnValueChangeListener.onValueChange(this, n2 + this.mMinValue, n + this.mMinValue);
                }
                if (this.mOnValueChangeListenerRaw != null) {
                    this.mOnValueChangeListenerRaw.onValueChangeRelativeToRaw(this, this.mPrevPickedIndex, n, this.mDisplayedValues);
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        this.mPrevPickedIndex = n;
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.drawContent(canvas);
        this.drawLine(canvas);
        this.drawHint(canvas);
    }

    protected void onMeasure(int n, int n2) {
        super.onMeasure(n, n2);
        this.updateMaxWHOfDisplayedValues(false);
        this.setMeasuredDimension(this.measureWidth(n), this.measureHeight(n2));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void onSizeChanged(int var1_1, int var2_2, int var3_3, int var4_4) {
        super.onSizeChanged(var1_1, var2_2, var3_3, var4_4);
        this.mViewWidth = var1_1;
        this.mViewHeight = var2_2;
        this.mItemHeight = this.mViewHeight / this.mShownCount;
        this.mViewCenterX = (float)(this.mViewWidth + this.getPaddingLeft() - this.getPaddingRight()) / 2.0f;
        if (this.getOneRecycleSize() <= 1) ** GOTO lbl-1000
        if (this.mHasInit) {
            var5_5 = this.getValue() - this.mMinValue;
        } else if (this.mCurrentItemIndexEffect) {
            var5_5 = this.mCurrDrawFirstItemIndex + (this.mShownCount - 1) / 2;
        } else lbl-1000: // 2 sources:
        {
            var5_5 = 0;
        }
        var6_6 = this.mWrapSelectorWheel;
        var7_7 = false;
        if (var6_6) {
            var8_8 = this.mWrapSelectorWheelCheck;
            var7_7 = false;
            if (var8_8) {
                var7_7 = true;
            }
        }
        this.correctPositionByDefaultValue(var5_5, var7_7);
        this.updateFontAttr();
        this.updateNotWrapYLimit();
        this.updateDividerAttr();
        this.mHasInit = true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        this.initHandlerIfDead();
        if (this.mItemHeight == 0) {
            return true;
        }
        if (this.mVelocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
        }
        this.mVelocityTracker.addMovement(motionEvent);
        this.currY = motionEvent.getY();
        int n = motionEvent.getAction();
        if (n != 0) {
            if (n != 1) {
                int n2;
                if (n != 2) {
                    if (n != 3) {
                        return true;
                    }
                    this.downYGlobal = this.mCurrDrawGlobalY;
                    this.stopScrolling();
                    this.mHandlerInNewThread.sendMessageDelayed(this.getMsg(1), 0L);
                    return true;
                }
                float f = this.downY - this.currY;
                if (!(this.mFlagMayPress && (float)(-(n2 = this.mScaledTouchSlop)) < f && f < (float)n2)) {
                    this.mFlagMayPress = false;
                    this.mCurrDrawGlobalY = this.limitY((int)(f + this.downYGlobal));
                    this.calculateFirstItemParameterByGlobalY();
                    this.invalidate();
                }
                this.onScrollStateChange(1);
                return true;
            }
            if (this.mFlagMayPress) {
                this.click(motionEvent);
                return true;
            }
            VelocityTracker velocityTracker = this.mVelocityTracker;
            velocityTracker.computeCurrentVelocity(1000);
            int n3 = (int)(velocityTracker.getYVelocity() * this.mFriction);
            if (Math.abs((int)n3) > this.mMiniVelocityFling) {
                this.mScroller.fling(0, this.mCurrDrawGlobalY, 0, -n3, Integer.MIN_VALUE, Integer.MAX_VALUE, this.limitY(Integer.MIN_VALUE), this.limitY(Integer.MAX_VALUE));
                this.invalidate();
                this.onScrollStateChange(2);
            }
            this.mHandlerInNewThread.sendMessageDelayed(this.getMsg(1), 0L);
            this.releaseVelocityTracker();
            return true;
        }
        this.mFlagMayPress = true;
        this.mHandlerInNewThread.removeMessages(1);
        this.stopScrolling();
        this.downY = this.currY;
        this.downYGlobal = this.mCurrDrawGlobalY;
        this.onScrollStateChange(0);
        this.getParent().requestDisallowInterceptTouchEvent(true);
        return true;
    }

    public void refreshByNewDisplayedValues(String[] arrstring) {
        int n;
        int n2 = -1 + arrstring.length;
        int n3 = this.getMinValue();
        if (1 + (n2 - n3) > (n = 1 + (this.getMaxValue() - n3))) {
            this.setDisplayedValues(arrstring);
            this.setMaxValue(n2);
            return;
        }
        this.setMaxValue(n2);
        this.setDisplayedValues(arrstring);
    }

    public void setContentTextTypeface(Typeface typeface) {
        this.mPaintText.setTypeface(typeface);
    }

    public void setDisplayedValues(String[] arrstring) {
        this.stopRefreshing();
        this.stopScrolling();
        if (arrstring != null) {
            int n = this.mMaxValue - this.mMinValue;
            boolean bl = true;
            if (n + bl <= arrstring.length) {
                this.updateContent(arrstring);
                this.updateMaxWHOfDisplayedValues(bl);
                this.mPrevPickedIndex = 0 + this.mMinShowIndex;
                if (!this.mWrapSelectorWheel || !this.mWrapSelectorWheelCheck) {
                    bl = false;
                }
                this.correctPositionByDefaultValue(0, bl);
                this.postInvalidate();
                this.mHandlerInMainThread.sendEmptyMessage(3);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("mMaxValue - mMinValue + 1 should not be greater than mDisplayedValues.length, now ((mMaxValue - mMinValue + 1) is ");
            stringBuilder.append(bl + (this.mMaxValue - this.mMinValue));
            stringBuilder.append(" newDisplayedValues.length is ");
            stringBuilder.append(arrstring.length);
            stringBuilder.append(", you need to set MaxValue and MinValue before setDisplayedValues(String[])");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        throw new IllegalArgumentException("newDisplayedValues should not be null.");
    }

    public void setDisplayedValues(String[] arrstring, boolean bl) {
        this.setDisplayedValuesAndPickedIndex(arrstring, 0, bl);
    }

    public void setDisplayedValuesAndPickedIndex(String[] arrstring, int n, boolean bl) {
        this.stopScrolling();
        if (arrstring != null) {
            if (n >= 0) {
                this.updateContent(arrstring);
                this.updateMaxWHOfDisplayedValues(true);
                this.updateNotWrapYLimit();
                this.updateValue();
                this.mPrevPickedIndex = n + this.mMinShowIndex;
                boolean bl2 = this.mWrapSelectorWheel && this.mWrapSelectorWheelCheck;
                this.correctPositionByDefaultValue(n, bl2);
                if (bl) {
                    this.initHandlerIfDead();
                    this.mHandlerInNewThread.sendMessageDelayed(this.getMsg(1), 0L);
                    this.postInvalidate();
                }
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("pickedIndex should not be negative, now pickedIndex is ");
            stringBuilder.append(n);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        throw new IllegalArgumentException("newDisplayedValues should not be null.");
    }

    public void setDividerColor(int n) {
        if (this.mDividerColor == n) {
            return;
        }
        this.mDividerColor = n;
        this.mPaintDivider.setColor(this.mDividerColor);
        this.postInvalidate();
    }

    public void setFriction(float f) {
        if (!(f <= 0.0f)) {
            ViewConfiguration.get((Context)this.getContext());
            this.mFriction = ViewConfiguration.getScrollFriction() / f;
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("you should set a a positive float friction, now friction is ");
        stringBuilder.append(f);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public void setHintText(String string2) {
        if (this.isStringEqual(this.mHintText, string2)) {
            return;
        }
        this.mHintText = string2;
        this.mTextSizeHintCenterYOffset = this.getTextCenterYOffset(this.mPaintHint.getFontMetrics());
        this.mWidthOfHintText = this.getTextWidth(this.mHintText, this.mPaintHint);
        this.mHandlerInMainThread.sendEmptyMessage(3);
    }

    public void setHintTextColor(int n) {
        if (this.mTextColorHint == n) {
            return;
        }
        this.mTextColorHint = n;
        this.mPaintHint.setColor(this.mTextColorHint);
        this.postInvalidate();
    }

    public void setHintTextTypeface(Typeface typeface) {
        this.mPaintHint.setTypeface(typeface);
    }

    public void setMaxValue(int n) {
        String[] arrstring = this.mDisplayedValues;
        if (arrstring != null) {
            int n2 = this.mMinValue;
            if (1 + (n - n2) <= arrstring.length) {
                this.mMaxValue = n;
                int n3 = this.mMaxValue - n2;
                int n4 = this.mMinShowIndex;
                this.mMaxShowIndex = n3 + n4;
                this.setMinAndMaxShowIndex(n4, this.mMaxShowIndex);
                this.updateNotWrapYLimit();
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("(maxValue - mMinValue + 1) should not be greater than mDisplayedValues.length now  (maxValue - mMinValue + 1) is ");
            stringBuilder.append(1 + (n - this.mMinValue));
            stringBuilder.append(" and mDisplayedValues.length is ");
            stringBuilder.append(this.mDisplayedValues.length);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        throw new NullPointerException("mDisplayedValues should not be null");
    }

    public void setMinAndMaxShowIndex(int n, int n2) {
        this.setMinAndMaxShowIndex(n, n2, true);
    }

    public void setMinAndMaxShowIndex(int n, int n2, boolean bl) {
        if (n <= n2) {
            String[] arrstring = this.mDisplayedValues;
            if (arrstring != null) {
                if (n >= 0) {
                    int n3 = arrstring.length;
                    boolean bl2 = true;
                    if (n <= n3 - bl2) {
                        if (n2 >= 0) {
                            if (n2 <= arrstring.length - bl2) {
                                this.mMinShowIndex = n;
                                this.mMaxShowIndex = n2;
                                if (bl) {
                                    this.mPrevPickedIndex = 0 + this.mMinShowIndex;
                                    if (!this.mWrapSelectorWheel || !this.mWrapSelectorWheelCheck) {
                                        bl2 = false;
                                    }
                                    this.correctPositionByDefaultValue(0, bl2);
                                    this.postInvalidate();
                                }
                                return;
                            }
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("maxShowIndex should not be greater than (mDisplayedValues.length - 1), now (mDisplayedValues.length - 1) is ");
                            stringBuilder.append(this.mDisplayedValues.length - bl2);
                            stringBuilder.append(" maxShowIndex is ");
                            stringBuilder.append(n2);
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("maxShowIndex should not be less than 0, now maxShowIndex is ");
                        stringBuilder.append(n2);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("minShowIndex should not be greater than (mDisplayedValues.length - 1), now (mDisplayedValues.length - 1) is ");
                    stringBuilder.append(this.mDisplayedValues.length - bl2);
                    stringBuilder.append(" minShowIndex is ");
                    stringBuilder.append(n);
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("minShowIndex should not be less than 0, now minShowIndex is ");
                stringBuilder.append(n);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            throw new IllegalArgumentException("mDisplayedValues should not be null, you need to set mDisplayedValues first.");
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("minShowIndex should be less than maxShowIndex, minShowIndex is ");
        stringBuilder.append(n);
        stringBuilder.append(", maxShowIndex is ");
        stringBuilder.append(n2);
        stringBuilder.append(".");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public void setMinValue(int n) {
        this.mMinValue = n;
        this.mMinShowIndex = 0;
        this.updateNotWrapYLimit();
    }

    public void setNormalTextColor(int n) {
        if (this.mTextColorNormal == n) {
            return;
        }
        this.mTextColorNormal = n;
        this.postInvalidate();
    }

    public void setOnScrollListener(OnScrollListener onScrollListener) {
        this.mOnScrollListener = onScrollListener;
    }

    public void setOnValueChangeListenerInScrolling(OnValueChangeListenerInScrolling onValueChangeListenerInScrolling) {
        this.mOnValueChangeListenerInScrolling = onValueChangeListenerInScrolling;
    }

    public void setOnValueChangedListener(OnValueChangeListener onValueChangeListener) {
        this.mOnValueChangeListener = onValueChangeListener;
    }

    public void setOnValueChangedListenerRelativeToRaw(OnValueChangeListenerRelativeToRaw onValueChangeListenerRelativeToRaw) {
        this.mOnValueChangeListenerRaw = onValueChangeListenerRelativeToRaw;
    }

    public void setPickedIndexRelativeToMin(int n) {
        if (n >= 0 && n < this.getOneRecycleSize()) {
            this.mPrevPickedIndex = n + this.mMinShowIndex;
            boolean bl = this.mWrapSelectorWheel && this.mWrapSelectorWheelCheck;
            this.correctPositionByDefaultValue(n, bl);
            this.postInvalidate();
        }
    }

    public void setPickedIndexRelativeToRaw(int n) {
        int n2 = this.mMinShowIndex;
        if (n2 > -1 && n2 <= n && n <= this.mMaxShowIndex) {
            this.mPrevPickedIndex = n;
            int n3 = n - n2;
            boolean bl = this.mWrapSelectorWheel && this.mWrapSelectorWheelCheck;
            this.correctPositionByDefaultValue(n3, bl);
            this.postInvalidate();
        }
    }

    public void setSelectedTextColor(int n) {
        if (this.mTextColorSelected == n) {
            return;
        }
        this.mTextColorSelected = n;
        this.postInvalidate();
    }

    public void setShownCount(int n) {
        this.mShownCount = n;
    }

    public void setTextAlign(Paint.Align align) {
        this.mPaintText.setTextAlign(align);
    }

    public void setValue(int n) {
        int n2 = this.mMinValue;
        if (n >= n2) {
            if (n <= this.mMaxValue) {
                this.setPickedIndexRelativeToRaw(n - n2);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("should not set a value greater than mMaxValue, value is ");
            stringBuilder.append(n);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("should not set a value less than mMinValue, value is ");
        stringBuilder.append(n);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public void setWrapSelectorWheel(boolean bl) {
        if (this.mWrapSelectorWheel != bl) {
            if (!bl) {
                if (this.mScrollState == 0) {
                    this.internalSetWrapToLinear();
                    return;
                }
                this.mPendingWrapToLinear = true;
                return;
            }
            this.mWrapSelectorWheel = bl;
            this.updateWrapStateByContent();
            this.postInvalidate();
        }
    }

    public void smoothScrollToValue(int n) {
        this.smoothScrollToValue(this.getValue(), n, true);
    }

    public void smoothScrollToValue(int n, int n2) {
        this.smoothScrollToValue(n, n2, true);
    }

    public void smoothScrollToValue(int n, int n2, boolean bl) {
        int n3;
        int n4 = this.mMinValue;
        int n5 = this.mMaxValue;
        boolean bl2 = this.mWrapSelectorWheel;
        boolean bl3 = true;
        boolean bl4 = bl2 && this.mWrapSelectorWheelCheck;
        int n6 = this.refineValueByLimit(n, n4, n5, bl4);
        int n7 = this.mMinValue;
        int n8 = this.mMaxValue;
        if (!this.mWrapSelectorWheel || !this.mWrapSelectorWheelCheck) {
            bl3 = false;
        }
        int n9 = this.refineValueByLimit(n2, n7, n8, bl3);
        if (this.mWrapSelectorWheel && this.mWrapSelectorWheelCheck) {
            n3 = n9 - n6;
            int n10 = this.getOneRecycleSize() / 2;
            if (n3 < -n10 || n10 < n3) {
                int n11 = this.getOneRecycleSize();
                n3 = n3 > 0 ? (n3 -= n11) : (n3 += n11);
            }
        } else {
            n3 = n9 - n6;
        }
        this.setValue(n6);
        if (n6 == n9) {
            return;
        }
        this.scrollByIndexSmoothly(n3, bl);
    }

    public void smoothScrollToValue(int n, boolean bl) {
        this.smoothScrollToValue(this.getValue(), n, bl);
    }

    public void stopScrolling() {
        Scroller scroller = this.mScroller;
        if (scroller != null && !scroller.isFinished()) {
            Scroller scroller2 = this.mScroller;
            scroller2.startScroll(0, scroller2.getCurrY(), 0, 0, 1);
            this.mScroller.abortAnimation();
            this.postInvalidate();
        }
    }

    public void stopScrollingAndCorrectPosition() {
        this.stopScrolling();
        if (this.mHandlerInNewThread != null) {
            this.initHandlerIfDead();
            this.mHandlerInNewThread.sendMessageDelayed(this.getMsg(1), 0L);
        }
    }

    public static interface OnScrollListener {
        public static final int SCROLL_STATE_FLING = 2;
        public static final int SCROLL_STATE_IDLE = 0;
        public static final int SCROLL_STATE_TOUCH_SCROLL = 1;

        public void onScrollStateChange(NumberPickerView var1, int var2);
    }

    public static interface OnValueChangeListener {
        public void onValueChange(NumberPickerView var1, int var2, int var3);
    }

    public static interface OnValueChangeListenerInScrolling {
        public void onValueChangeInScrolling(NumberPickerView var1, int var2, int var3);
    }

    public static interface OnValueChangeListenerRelativeToRaw {
        public void onValueChangeRelativeToRaw(NumberPickerView var1, int var2, int var3, String[] var4);
    }

}

