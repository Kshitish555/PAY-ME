/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.net.Uri
 *  android.os.Parcelable
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableMap
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.clipsub.rnbottomsheet;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Parcelable;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import java.util.ArrayList;

public class RNBottomSheet
extends ReactContextBaseJavaModule {
    private boolean isOpened;
    private Callback shareFailureCallback;
    private Callback shareSuccessCallback;

    public RNBottomSheet(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
    }

    static /* synthetic */ boolean access$002(RNBottomSheet rNBottomSheet, boolean bl) {
        rNBottomSheet.isOpened = bl;
        return bl;
    }

    public String getName() {
        return "RNBottomSheet";
    }

    /*
     * Exception decompiling
     */
    @ReactMethod
    public void showBottomSheetWithOptions(ReadableMap var1, Callback var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    @ReactMethod
    public void showShareBottomSheetWithOptions(ReadableMap readableMap, Callback callback, Callback callback2) {
        String string = readableMap.getString("url");
        String string2 = readableMap.getString("message");
        String string3 = readableMap.getString("subject");
        ArrayList arrayList = new ArrayList();
        if (string2 != null && !string2.isEmpty()) {
            arrayList.add((Object)string2);
        }
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        Uri uri = Uri.parse((String)string);
        if (uri != null) {
            if (uri.getScheme() != null && "data".equals((Object)uri.getScheme().toLowerCase())) {
                intent.setType("*/*");
                intent.putExtra("android.intent.extra.STREAM", (Parcelable)uri);
            } else {
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.EMAIL", string);
                intent.putExtra("android.intent.extra.SUBJECT", string3);
                intent.putExtra("android.intent.extra.TEXT", string2);
            }
        }
        this.shareSuccessCallback = callback2;
        this.shareFailureCallback = callback;
        if (intent.resolveActivity(this.getCurrentActivity().getPackageManager()) != null) {
            this.getCurrentActivity().startActivity(Intent.createChooser((Intent)intent, (CharSequence)"Share To"));
            return;
        }
        Object[] arrobject = new Object[]{new Exception("The app you want to share is not installed.")};
        callback.invoke(arrobject);
    }
}

