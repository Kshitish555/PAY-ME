/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  com.facebook.react.bridge.Promise
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.reactnativecommunity.netinfo.BroadcastReceiverConnectivityReceiver
 *  com.reactnativecommunity.netinfo.ConnectivityReceiver
 *  com.reactnativecommunity.netinfo.NetworkCallbackConnectivityReceiver
 *  java.lang.String
 */
package com.reactnativecommunity.netinfo;

import android.os.Build;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.reactnativecommunity.netinfo.BroadcastReceiverConnectivityReceiver;
import com.reactnativecommunity.netinfo.ConnectivityReceiver;
import com.reactnativecommunity.netinfo.NetworkCallbackConnectivityReceiver;

public class NetInfoModule
extends ReactContextBaseJavaModule {
    public static final String NAME = "RNCNetInfo";
    private final ConnectivityReceiver mConnectivityReceiver;

    public NetInfoModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        if (Build.VERSION.SDK_INT >= 24) {
            this.mConnectivityReceiver = new NetworkCallbackConnectivityReceiver(reactApplicationContext);
            return;
        }
        this.mConnectivityReceiver = new BroadcastReceiverConnectivityReceiver(reactApplicationContext);
    }

    @ReactMethod
    public void getCurrentState(Promise promise) {
        this.mConnectivityReceiver.getCurrentState(promise);
    }

    public String getName() {
        return NAME;
    }

    public void initialize() {
        this.mConnectivityReceiver.register();
    }

    public void onCatalystInstanceDestroy() {
        this.mConnectivityReceiver.unregister();
    }
}

