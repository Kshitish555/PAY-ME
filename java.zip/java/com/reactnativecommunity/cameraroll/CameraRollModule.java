/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.res.AssetFileDescriptor
 *  android.database.Cursor
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.media.MediaMetadataRetriever
 *  android.net.Uri
 *  android.os.AsyncTask
 *  com.facebook.common.logging.FLog
 *  com.facebook.react.bridge.Promise
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.bridge.WritableNativeArray
 *  com.facebook.react.bridge.WritableNativeMap
 *  com.facebook.react.module.annotations.ReactModule
 *  com.reactnativecommunity.cameraroll.CameraRollModule$1
 *  com.reactnativecommunity.cameraroll.CameraRollModule$DeletePhotos
 *  com.reactnativecommunity.cameraroll.CameraRollModule$GetMediaTask
 *  com.reactnativecommunity.cameraroll.CameraRollModule$SaveToCameraRoll
 *  java.io.File
 *  java.io.FileDescriptor
 *  java.io.IOException
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.util.concurrent.Executor
 */
package com.reactnativecommunity.cameraroll;

import android.content.ContentResolver;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import com.facebook.common.logging.FLog;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeArray;
import com.facebook.react.bridge.WritableNativeMap;
import com.facebook.react.module.annotations.ReactModule;
import com.reactnativecommunity.cameraroll.CameraRollModule;
import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.util.concurrent.Executor;

/*
 * Exception performing whole class analysis.
 */
@ReactModule(name="RNCCameraRoll")
public class CameraRollModule
extends ReactContextBaseJavaModule {
    private static final String ASSET_TYPE_ALL = "All";
    private static final String ASSET_TYPE_PHOTOS = "Photos";
    private static final String ASSET_TYPE_VIDEOS = "Videos";
    private static final String ERROR_UNABLE_TO_DELETE = "E_UNABLE_TO_DELETE";
    private static final String ERROR_UNABLE_TO_FILTER = "E_UNABLE_TO_FILTER";
    private static final String ERROR_UNABLE_TO_LOAD = "E_UNABLE_TO_LOAD";
    private static final String ERROR_UNABLE_TO_LOAD_PERMISSION = "E_UNABLE_TO_LOAD_PERMISSION";
    private static final String ERROR_UNABLE_TO_SAVE = "E_UNABLE_TO_SAVE";
    public static final String NAME = "RNCCameraRoll";
    private static final String[] PROJECTION;
    private static final String SELECTION_BUCKET = "bucket_display_name = ?";
    private static final String SELECTION_DATE_TAKEN = "datetaken < ?";

    static {
        PROJECTION = new String[]{"_id", "mime_type", "bucket_display_name", "datetaken", "width", "height", "longitude", "latitude", "_data"};
    }

    public CameraRollModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
    }

    static /* synthetic */ String[] access$200() {
        return PROJECTION;
    }

    static /* synthetic */ void access$300(ContentResolver contentResolver, Cursor cursor, WritableMap writableMap, int n) {
        CameraRollModule.putEdges(contentResolver, cursor, writableMap, n);
    }

    static /* synthetic */ void access$400(Cursor cursor, WritableMap writableMap, int n, int n2) {
        CameraRollModule.putPageInfo(cursor, writableMap, n, n2);
    }

    private static void putBasicNodeInfo(Cursor cursor, WritableMap writableMap, int n, int n2, int n3) {
        writableMap.putString("type", cursor.getString(n));
        writableMap.putString("group_name", cursor.getString(n2));
        double d = cursor.getLong(n3);
        Double.isNaN((double)d);
        writableMap.putDouble("timestamp", d / 1000.0);
    }

    private static void putEdges(ContentResolver contentResolver, Cursor cursor, WritableMap writableMap, int n) {
        WritableNativeArray writableNativeArray = new WritableNativeArray();
        cursor.moveToFirst();
        int n2 = cursor.getColumnIndex("_id");
        int n3 = cursor.getColumnIndex("mime_type");
        int n4 = cursor.getColumnIndex("bucket_display_name");
        int n5 = cursor.getColumnIndex("datetaken");
        int n6 = cursor.getColumnIndex("width");
        int n7 = cursor.getColumnIndex("height");
        int n8 = cursor.getColumnIndex("longitude");
        int n9 = cursor.getColumnIndex("latitude");
        int n10 = cursor.getColumnIndex("_data");
        int n11 = n;
        int n12 = 0;
        while (n12 < n11 && !cursor.isAfterLast()) {
            WritableNativeArray writableNativeArray2;
            WritableNativeMap writableNativeMap = new WritableNativeMap();
            WritableNativeMap writableNativeMap2 = new WritableNativeMap();
            WritableNativeArray writableNativeArray3 = writableNativeArray;
            int n13 = n2;
            int n14 = n12;
            int n15 = n6;
            int n16 = n2;
            int n17 = n9;
            int n18 = n6;
            int n19 = n8;
            if (CameraRollModule.putImageInfo(contentResolver, cursor, (WritableMap)writableNativeMap2, n13, n15, n7, n10, n3)) {
                CameraRollModule.putBasicNodeInfo(cursor, (WritableMap)writableNativeMap2, n3, n4, n5);
                CameraRollModule.putLocationInfo(cursor, (WritableMap)writableNativeMap2, n19, n17);
                writableNativeMap.putMap("node", (ReadableMap)writableNativeMap2);
                writableNativeArray2 = writableNativeArray3;
                writableNativeArray2.pushMap((ReadableMap)writableNativeMap);
            } else {
                writableNativeArray2 = writableNativeArray3;
                --n14;
            }
            cursor.moveToNext();
            n12 = n14 + 1;
            n11 = n;
            writableNativeArray = writableNativeArray2;
            n9 = n17;
            n8 = n19;
            n2 = n16;
            n6 = n18;
        }
        writableMap.putArray("edges", (ReadableArray)writableNativeArray);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static boolean putImageInfo(ContentResolver var0, Cursor var1_1, WritableMap var2_2, int var3_3, int var4_4, int var5_5, int var6_6, int var7_7) {
        block11 : {
            var8_8 = new WritableNativeMap();
            var9_9 = new StringBuilder();
            var9_9.append("file://");
            var9_9.append(var1_1.getString(var6_6));
            var12_10 = Uri.parse((String)var9_9.toString());
            var13_11 = new File(var1_1.getString(var6_6)).getName();
            var8_8.putString("uri", var12_10.toString());
            var8_8.putString("filename", var13_11);
            var14_12 = var1_1.getInt(var4_4);
            var15_13 = var1_1.getInt(var5_5);
            var16_14 = var1_1.getString(var7_7);
            if (var16_14 == null || !var16_14.startsWith("video")) break block11;
            var30_15 = var0.openAssetFileDescriptor(var12_10, "r");
            var31_16 = new MediaMetadataRetriever();
            var31_16.setDataSource(var30_15.getFileDescriptor());
            {
                catch (Exception var26_20) {
                    var27_21 = new StringBuilder();
                    var27_21.append("Could not get video metadata for ");
                    var27_21.append(var12_10.toString());
                    FLog.e((String)"ReactNative", (String)var27_21.toString(), (Throwable)var26_20);
                    return false;
                }
            }
            if (!(var14_12 <= 0.0f) && !(var15_13 <= 0.0f)) ** GOTO lbl27
            var14_12 = Integer.parseInt((String)var31_16.extractMetadata(18));
            var15_13 = Integer.parseInt((String)var31_16.extractMetadata(19));
lbl27: // 2 sources:
            var8_8.putInt("playableDuration", Integer.parseInt((String)var31_16.extractMetadata(9)) / 1000);
            var31_16.release();
            var30_15.close();
        }
        if (var14_12 <= 0.0f || var15_13 <= 0.0f) {
            var21_22 = var0.openAssetFileDescriptor(var12_10, "r");
            var22_23 = new BitmapFactory.Options();
            var22_23.inJustDecodeBounds = true;
            BitmapFactory.decodeFileDescriptor((FileDescriptor)var21_22.getFileDescriptor(), null, (BitmapFactory.Options)var22_23);
            var24_24 = var22_23.outWidth;
            var25_25 = var22_23.outHeight;
            var21_22.close();
            var15_13 = var25_25;
            var14_12 = var24_24;
        }
        var8_8.putDouble("width", (double)var14_12);
        var8_8.putDouble("height", (double)var15_13);
        var2_2.putMap("image", (ReadableMap)var8_8);
        return true;
        catch (IOException var17_26) {
            var18_27 = new StringBuilder();
            var18_27.append("Could not get width/height for ");
            var18_27.append(var12_10.toString());
            FLog.e((String)"ReactNative", (String)var18_27.toString(), (Throwable)var17_26);
            return false;
        }
        {
            catch (Throwable var36_17) {
                ** GOTO lbl64
            }
            catch (NumberFormatException var32_18) {}
            {
                var33_19 = new StringBuilder();
                var33_19.append("Number format exception occurred while trying to fetch video metadata for ");
                var33_19.append(var12_10.toString());
                FLog.e((String)"ReactNative", (String)var33_19.toString(), (Throwable)var32_18);
            }
            var31_16.release();
            var30_15.close();
            return false;
lbl64: // 1 sources:
            var31_16.release();
            var30_15.close();
            throw var36_17;
        }
    }

    private static void putLocationInfo(Cursor cursor, WritableMap writableMap, int n, int n2) {
        double d = cursor.getDouble(n);
        double d2 = cursor.getDouble(n2);
        if (d > 0.0 || d2 > 0.0) {
            WritableNativeMap writableNativeMap = new WritableNativeMap();
            writableNativeMap.putDouble("longitude", d);
            writableNativeMap.putDouble("latitude", d2);
            writableMap.putMap("location", (ReadableMap)writableNativeMap);
        }
    }

    private static void putPageInfo(Cursor cursor, WritableMap writableMap, int n, int n2) {
        WritableNativeMap writableNativeMap = new WritableNativeMap();
        boolean bl = n < cursor.getCount();
        writableNativeMap.putBoolean("has_next_page", bl);
        if (n < cursor.getCount()) {
            writableNativeMap.putString("end_cursor", Integer.toString((int)(n2 + n)));
        }
        writableMap.putMap("page_info", (ReadableMap)writableNativeMap);
    }

    @ReactMethod
    public void deletePhotos(ReadableArray readableArray, Promise promise) {
        if (readableArray.size() == 0) {
            promise.reject(ERROR_UNABLE_TO_DELETE, "Need at least one URI to delete");
            return;
        }
        new /* Unavailable Anonymous Inner Class!! */.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
    }

    public String getName() {
        return NAME;
    }

    @ReactMethod
    public void getPhotos(ReadableMap readableMap, Promise promise) {
        int n = readableMap.getInt("first");
        String string = readableMap.hasKey("after") ? readableMap.getString("after") : null;
        String string2 = readableMap.hasKey("groupName") ? readableMap.getString("groupName") : null;
        String string3 = readableMap.hasKey("assetType") ? readableMap.getString("assetType") : ASSET_TYPE_PHOTOS;
        String string4 = string3;
        long l = readableMap.hasKey("fromTime") ? (long)readableMap.getDouble("fromTime") : 0L;
        long l2 = readableMap.hasKey("toTime") ? (long)readableMap.getDouble("toTime") : 0L;
        ReadableArray readableArray = readableMap.hasKey("mimeTypes") ? readableMap.getArray("mimeTypes") : null;
        GetMediaTask getMediaTask = new /* Unavailable Anonymous Inner Class!! */;
        getMediaTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
    }

    @ReactMethod
    public void saveToCameraRoll(String string, ReadableMap readableMap, Promise promise) {
        new /* Unavailable Anonymous Inner Class!! */.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
    }
}

