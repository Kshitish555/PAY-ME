/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.AsyncTask
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.module.annotations.ReactModule
 *  com.facebook.react.modules.common.ModuleDataCleaner
 *  com.facebook.react.modules.common.ModuleDataCleaner$Cleanable
 *  com.reactnativecommunity.asyncstorage.AsyncStorageErrorUtil
 *  com.reactnativecommunity.asyncstorage.AsyncStorageModule$1
 *  com.reactnativecommunity.asyncstorage.AsyncStorageModule$2
 *  com.reactnativecommunity.asyncstorage.AsyncStorageModule$3
 *  com.reactnativecommunity.asyncstorage.AsyncStorageModule$4
 *  com.reactnativecommunity.asyncstorage.AsyncStorageModule$5
 *  com.reactnativecommunity.asyncstorage.AsyncStorageModule$6
 *  com.reactnativecommunity.asyncstorage.AsyncStorageModule$SerialExecutor
 *  com.reactnativecommunity.asyncstorage.ReactDatabaseSupplier
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.concurrent.Executor
 */
package com.reactnativecommunity.asyncstorage;

import android.content.Context;
import android.os.AsyncTask;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.module.annotations.ReactModule;
import com.facebook.react.modules.common.ModuleDataCleaner;
import com.reactnativecommunity.asyncstorage.AsyncStorageErrorUtil;
import com.reactnativecommunity.asyncstorage.AsyncStorageModule;
import com.reactnativecommunity.asyncstorage.ReactDatabaseSupplier;
import java.util.concurrent.Executor;

/*
 * Exception performing whole class analysis.
 */
@ReactModule(name="RNC_AsyncSQLiteDBStorage")
public final class AsyncStorageModule
extends ReactContextBaseJavaModule
implements ModuleDataCleaner.Cleanable {
    private static final int MAX_SQL_KEYS = 999;
    public static final String NAME = "RNC_AsyncSQLiteDBStorage";
    private final SerialExecutor executor;
    private ReactDatabaseSupplier mReactDatabaseSupplier;
    private boolean mShuttingDown;

    public AsyncStorageModule(ReactApplicationContext reactApplicationContext) {
        this(reactApplicationContext, AsyncTask.THREAD_POOL_EXECUTOR);
    }

    AsyncStorageModule(ReactApplicationContext reactApplicationContext, Executor executor) {
        super(reactApplicationContext);
        this.mShuttingDown = false;
        this.executor = new /* Unavailable Anonymous Inner Class!! */;
        this.mReactDatabaseSupplier = ReactDatabaseSupplier.getInstance((Context)reactApplicationContext);
    }

    static /* synthetic */ boolean access$000(AsyncStorageModule asyncStorageModule) {
        return asyncStorageModule.ensureDatabase();
    }

    static /* synthetic */ ReactDatabaseSupplier access$100(AsyncStorageModule asyncStorageModule) {
        return asyncStorageModule.mReactDatabaseSupplier;
    }

    private boolean ensureDatabase() {
        return !this.mShuttingDown && this.mReactDatabaseSupplier.ensureDatabase();
    }

    @ReactMethod
    public void clear(Callback callback) {
        new 5(this, (ReactContext)this.getReactApplicationContext(), callback).executeOnExecutor((Executor)this.executor, (Object[])new Void[0]);
    }

    public void clearSensitiveData() {
        this.mReactDatabaseSupplier.clearAndCloseDatabase();
    }

    @ReactMethod
    public void getAllKeys(Callback callback) {
        new 6(this, (ReactContext)this.getReactApplicationContext(), callback).executeOnExecutor((Executor)this.executor, (Object[])new Void[0]);
    }

    public String getName() {
        return NAME;
    }

    public void initialize() {
        super.initialize();
        this.mShuttingDown = false;
    }

    @ReactMethod
    public void multiGet(ReadableArray readableArray, Callback callback) {
        if (readableArray == null) {
            Object[] arrobject = new Object[]{AsyncStorageErrorUtil.getInvalidKeyError(null), null};
            callback.invoke(arrobject);
            return;
        }
        new 1(this, (ReactContext)this.getReactApplicationContext(), callback, readableArray).executeOnExecutor((Executor)this.executor, (Object[])new Void[0]);
    }

    @ReactMethod
    public void multiMerge(ReadableArray readableArray, Callback callback) {
        new 4(this, (ReactContext)this.getReactApplicationContext(), callback, readableArray).executeOnExecutor((Executor)this.executor, (Object[])new Void[0]);
    }

    @ReactMethod
    public void multiRemove(ReadableArray readableArray, Callback callback) {
        if (readableArray.size() == 0) {
            callback.invoke(new Object[0]);
            return;
        }
        new 3(this, (ReactContext)this.getReactApplicationContext(), callback, readableArray).executeOnExecutor((Executor)this.executor, (Object[])new Void[0]);
    }

    @ReactMethod
    public void multiSet(ReadableArray readableArray, Callback callback) {
        if (readableArray.size() == 0) {
            callback.invoke(new Object[0]);
            return;
        }
        new 2(this, (ReactContext)this.getReactApplicationContext(), callback, readableArray).executeOnExecutor((Executor)this.executor, (Object[])new Void[0]);
    }

    public void onCatalystInstanceDestroy() {
        this.mShuttingDown = true;
    }
}

