/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.WritableMap
 *  java.io.BufferedReader
 *  java.io.EOFException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.Reader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URL
 *  java.net.URLConnection
 *  java.nio.charset.Charset
 *  java.nio.charset.StandardCharsets
 *  java.security.KeyManagementException
 *  java.security.KeyStoreException
 *  java.security.NoSuchAlgorithmException
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  javax.net.ssl.HttpsURLConnection
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSocketFactory
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.payoneermobilessl.utils;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import com.payoneermobilessl.models.HttpRequest;
import com.payoneermobilessl.models.HttpResponse;
import com.payoneermobilessl.utils.SSLContextFactory;
import com.payoneermobilessl.utils.TLSSocketFactory;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import org.json.JSONException;
import org.json.JSONObject;

public class HttpUtil {
    private static final String DEFAULT_CONTENT_TYPE = "application/json";

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private String getResponseBody(InputStream inputStream) throws IOException {
        Throwable throwable2222;
        BufferedReader bufferedReader;
        block5 : {
            String string2;
            bufferedReader = new BufferedReader((Reader)new InputStreamReader(inputStream));
            StringBuilder stringBuilder = new StringBuilder();
            while ((string2 = bufferedReader.readLine()) != null) {
                stringBuilder.append(string2);
            }
            {
                catch (Throwable throwable2222) {
                    break block5;
                }
                catch (EOFException eOFException) {}
                {
                    eOFException.printStackTrace();
                }
            }
            bufferedReader.close();
            return stringBuilder.toString();
        }
        bufferedReader.close();
        throw throwable2222;
    }

    private WritableMap getResponseHeaders(HttpsURLConnection httpsURLConnection) {
        WritableMap writableMap = Arguments.createMap();
        for (Map.Entry entry : httpsURLConnection.getHeaderFields().entrySet()) {
            if (entry.getKey() == null) continue;
            writableMap.putString((String)entry.getKey(), (String)((List)entry.getValue()).get(0));
        }
        return writableMap;
    }

    private HttpsURLConnection prepareRequest(HttpRequest httpRequest) throws IOException, KeyStoreException, KeyManagementException, NoSuchAlgorithmException, JSONException {
        URL uRL = new URL(httpRequest.endpoint);
        String string2 = httpRequest.method.toUpperCase();
        HttpsURLConnection httpsURLConnection = (HttpsURLConnection)uRL.openConnection();
        if (httpRequest.rootPublicKey != null && httpRequest.commonName != null) {
            httpsURLConnection.setSSLSocketFactory((SSLSocketFactory)new TLSSocketFactory(SSLContextFactory.getInstance(httpRequest.commonName, httpRequest.rootPublicKey).getContext().getSocketFactory()));
        }
        httpsURLConnection.setRequestMethod(string2);
        HttpsURLConnection httpsURLConnection2 = this.prepareRequestHeaders(httpsURLConnection, httpRequest.headers);
        httpsURLConnection2.setRequestProperty("Accept-Charset", "UTF-8");
        httpsURLConnection2.setAllowUserInteraction(false);
        httpsURLConnection2.setConnectTimeout(httpRequest.timeout);
        httpsURLConnection2.setReadTimeout(httpRequest.timeout);
        if (httpRequest.body != null && (string2.equals((Object)"POST") || string2.equals((Object)"PUT") || string2.equals((Object)"DELETE"))) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(httpRequest.body.getBytes().length);
            stringBuilder.append("");
            httpsURLConnection2.setRequestProperty("Content-length", stringBuilder.toString());
            httpsURLConnection2.setDoInput(true);
            httpsURLConnection2.setDoOutput(true);
            httpsURLConnection2.setUseCaches(false);
            OutputStream outputStream = httpsURLConnection2.getOutputStream();
            outputStream.write(httpRequest.body.getBytes(StandardCharsets.UTF_8));
            outputStream.close();
        }
        return httpsURLConnection2;
    }

    private HttpsURLConnection prepareRequestHeaders(HttpsURLConnection httpsURLConnection, JSONObject jSONObject) throws JSONException {
        httpsURLConnection.setRequestProperty("Content-Type", DEFAULT_CONTENT_TYPE);
        httpsURLConnection.setRequestProperty("Accept", DEFAULT_CONTENT_TYPE);
        if (jSONObject != null) {
            Iterator iterator = jSONObject.keys();
            while (iterator.hasNext()) {
                String string2 = (String)iterator.next();
                httpsURLConnection.setRequestProperty(string2, jSONObject.get(string2).toString());
            }
        }
        return httpsURLConnection;
    }

    private InputStream prepareResponseStream(HttpsURLConnection httpsURLConnection) {
        try {
            InputStream inputStream = httpsURLConnection.getInputStream();
            return inputStream;
        }
        catch (IOException iOException) {
            return httpsURLConnection.getErrorStream();
        }
    }

    /*
     * Exception decompiling
     */
    public HttpResponse sendHttpRequest(HttpRequest var1) throws IOException, KeyStoreException, KeyManagementException, NoSuchAlgorithmException, JSONException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl55 : ALOAD_3 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }
}

