/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.KeyManagementException
 *  java.security.KeyStore
 *  java.security.KeyStoreException
 *  java.security.NoSuchAlgorithmException
 *  java.security.SecureRandom
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  javax.net.ssl.KeyManager
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.TrustManagerFactory
 *  javax.net.ssl.X509TrustManager
 *  okhttp3.TlsVersion
 */
package com.payoneermobilessl.utils;

import com.payoneermobilessl.utils.CompositeX509TrustManager;
import com.payoneermobilessl.utils.PayoneerTrustManager;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import okhttp3.TlsVersion;

public class SSLContextFactory {
    private static HashMap<String, SSLContextFactory> instances = new HashMap();
    private SSLContext sslContext = SSLContext.getInstance((String)TlsVersion.TLS_1_2.javaName());

    private SSLContextFactory(String string2, String string3) throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance((String)TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init((KeyStore)null);
        ArrayList arrayList = new ArrayList();
        for (TrustManager trustManager : trustManagerFactory.getTrustManagers()) {
            if (!(trustManager instanceof X509TrustManager)) continue;
            arrayList.add((Object)((X509TrustManager)trustManager));
            break;
        }
        arrayList.add((Object)new PayoneerTrustManager(string2, string3));
        SSLContext sSLContext = this.sslContext;
        TrustManager[] arrtrustManager = new TrustManager[]{new CompositeX509TrustManager((List<X509TrustManager>)arrayList)};
        sSLContext.init(null, arrtrustManager, new SecureRandom());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static SSLContextFactory getInstance(String string2, String string3) throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        Class<SSLContextFactory> class_ = SSLContextFactory.class;
        synchronized (SSLContextFactory.class) {
            if (string2 != null && string3 != null) {
                HashMap<String, SSLContextFactory> hashMap = instances;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string2);
                stringBuilder.append(string3);
                if (hashMap.get((Object)stringBuilder.toString()) == null) {
                    HashMap<String, SSLContextFactory> hashMap2 = instances;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(string2);
                    stringBuilder2.append(string3);
                    hashMap2.put((Object)stringBuilder2.toString(), (Object)new SSLContextFactory(string2, string3));
                }
            }
            HashMap<String, SSLContextFactory> hashMap = instances;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(string3);
            return (SSLContextFactory)hashMap.get((Object)stringBuilder.toString());
        }
    }

    public SSLContext getContext() {
        return this.sslContext;
    }
}

