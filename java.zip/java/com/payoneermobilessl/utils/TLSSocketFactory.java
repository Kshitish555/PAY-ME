/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.String
 *  java.net.InetAddress
 *  java.net.Socket
 *  javax.net.ssl.SSLSocket
 *  javax.net.ssl.SSLSocketFactory
 *  okhttp3.TlsVersion
 */
package com.payoneermobilessl.utils;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import okhttp3.TlsVersion;

public class TLSSocketFactory
extends SSLSocketFactory {
    private SSLSocketFactory internalSSLSocketFactory;

    public TLSSocketFactory(SSLSocketFactory sSLSocketFactory) {
        this.internalSSLSocketFactory = sSLSocketFactory;
    }

    private Socket enableTLSOnSocket(Socket socket) {
        if (socket != null && socket instanceof SSLSocket) {
            SSLSocket sSLSocket = (SSLSocket)socket;
            String[] arrstring = new String[]{TlsVersion.TLS_1_1.javaName(), TlsVersion.TLS_1_2.javaName()};
            sSLSocket.setEnabledProtocols(arrstring);
        }
        return socket;
    }

    public Socket createSocket() throws IOException {
        return this.enableTLSOnSocket(this.internalSSLSocketFactory.createSocket());
    }

    public Socket createSocket(String string2, int n2) throws IOException {
        return this.enableTLSOnSocket(this.internalSSLSocketFactory.createSocket(string2, n2));
    }

    public Socket createSocket(String string2, int n2, InetAddress inetAddress, int n3) throws IOException {
        return this.enableTLSOnSocket(this.internalSSLSocketFactory.createSocket(string2, n2, inetAddress, n3));
    }

    public Socket createSocket(InetAddress inetAddress, int n2) throws IOException {
        return this.enableTLSOnSocket(this.internalSSLSocketFactory.createSocket(inetAddress, n2));
    }

    public Socket createSocket(InetAddress inetAddress, int n2, InetAddress inetAddress2, int n3) throws IOException {
        return this.enableTLSOnSocket(this.internalSSLSocketFactory.createSocket(inetAddress, n2, inetAddress2, n3));
    }

    public Socket createSocket(Socket socket, String string2, int n2, boolean bl) throws IOException {
        return this.enableTLSOnSocket(this.internalSSLSocketFactory.createSocket(socket, string2, n2, bl));
    }

    public String[] getDefaultCipherSuites() {
        return this.internalSSLSocketFactory.getDefaultCipherSuites();
    }

    public String[] getSupportedCipherSuites() {
        return this.internalSSLSocketFactory.getSupportedCipherSuites();
    }
}

