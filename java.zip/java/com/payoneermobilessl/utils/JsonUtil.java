/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.ReadableMapKeySetIterator
 *  com.facebook.react.bridge.ReadableType
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.payoneermobilessl.utils;

import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableMapKeySetIterator;
import com.facebook.react.bridge.ReadableType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonUtil {
    private static JSONArray convertArrayToJson(ReadableArray readableArray) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        block8 : for (int i2 = 0; i2 < readableArray.size(); ++i2) {
            switch (1.$SwitchMap$com$facebook$react$bridge$ReadableType[readableArray.getType(i2).ordinal()]) {
                default: {
                    continue block8;
                }
                case 6: {
                    jSONArray.put((Object)JsonUtil.convertArrayToJson(readableArray.getArray(i2)));
                    continue block8;
                }
                case 5: {
                    jSONArray.put((Object)JsonUtil.convertReadableMapToJson(readableArray.getMap(i2)));
                    continue block8;
                }
                case 4: {
                    jSONArray.put((Object)readableArray.getString(i2));
                    continue block8;
                }
                case 3: {
                    jSONArray.put(readableArray.getDouble(i2));
                    continue block8;
                }
                case 2: {
                    jSONArray.put(readableArray.getBoolean(i2));
                }
                case 1: 
            }
        }
        return jSONArray;
    }

    public static JSONObject convertReadableMapToJson(ReadableMap readableMap) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        ReadableMapKeySetIterator readableMapKeySetIterator = readableMap.keySetIterator();
        block8 : while (readableMapKeySetIterator.hasNextKey()) {
            String string2 = readableMapKeySetIterator.nextKey();
            switch (1.$SwitchMap$com$facebook$react$bridge$ReadableType[readableMap.getType(string2).ordinal()]) {
                default: {
                    continue block8;
                }
                case 6: {
                    jSONObject.put(string2, (Object)JsonUtil.convertArrayToJson(readableMap.getArray(string2)));
                    continue block8;
                }
                case 5: {
                    jSONObject.put(string2, (Object)JsonUtil.convertReadableMapToJson(readableMap.getMap(string2)));
                    continue block8;
                }
                case 4: {
                    jSONObject.put(string2, (Object)readableMap.getString(string2));
                    continue block8;
                }
                case 3: {
                    jSONObject.put(string2, readableMap.getDouble(string2));
                    continue block8;
                }
                case 2: {
                    jSONObject.put(string2, readableMap.getBoolean(string2));
                    continue block8;
                }
                case 1: 
            }
            jSONObject.put(string2, JSONObject.NULL);
        }
        return jSONObject;
    }

}

