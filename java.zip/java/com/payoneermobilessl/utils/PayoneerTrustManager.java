/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Base64
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.security.KeyStore
 *  java.security.KeyStoreException
 *  java.security.NoSuchAlgorithmException
 *  java.security.Principal
 *  java.security.PublicKey
 *  java.security.cert.CertificateException
 *  java.security.cert.CertificateParsingException
 *  java.security.cert.X509Certificate
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.TrustManagerFactory
 *  javax.net.ssl.X509TrustManager
 */
package com.payoneermobilessl.utils;

import android.util.Base64;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

class PayoneerTrustManager
implements X509TrustManager {
    private String commonName;
    private String rootPublicKey;
    private X509Certificate[] systemTrustedCertificates;

    PayoneerTrustManager(String string2, String string3) throws NoSuchAlgorithmException, KeyStoreException {
        this.commonName = string2;
        this.rootPublicKey = string3;
        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance((String)TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init((KeyStore)null);
        for (TrustManager trustManager : trustManagerFactory.getTrustManagers()) {
            if (!(trustManager instanceof X509TrustManager)) continue;
            this.systemTrustedCertificates = ((X509TrustManager)trustManager).getAcceptedIssuers();
            return;
        }
    }

    /*
     * Exception decompiling
     */
    private X509Certificate[] completeCertificatesChainWithRoot(X509Certificate[] var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl22 : ILOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private String getCNfromCertificate(X509Certificate x509Certificate) {
        String[] arrstring = x509Certificate.getSubjectDN().getName().split(",");
        int n2 = arrstring.length;
        String string2 = "";
        for (int i2 = 0; i2 < n2; ++i2) {
            String string3 = arrstring[i2];
            if (!string3.startsWith("CN=")) continue;
            string2 = string3.replace((CharSequence)"CN=", (CharSequence)"");
        }
        return string2;
    }

    private List<String> getCertificateCNandSANS(X509Certificate x509Certificate) throws CertificateParsingException {
        ArrayList arrayList = new ArrayList();
        Collection collection = x509Certificate.getSubjectAlternativeNames();
        if (collection != null) {
            for (List list : collection) {
                if ((Integer)list.get(0) != 2) continue;
                arrayList.add((Object)((String)list.get(1)));
            }
        }
        arrayList.add((Object)this.getCNfromCertificate(x509Certificate));
        return arrayList;
    }

    private String getCertificatePublicKey(X509Certificate x509Certificate) {
        return Base64.encodeToString((byte[])x509Certificate.getPublicKey().getEncoded(), (int)2);
    }

    public void checkClientTrusted(X509Certificate[] arrx509Certificate, String string2) {
    }

    public void checkServerTrusted(X509Certificate[] arrx509Certificate, String string2) throws CertificateException {
        X509Certificate[] arrx509Certificate2 = this.completeCertificatesChainWithRoot(arrx509Certificate);
        boolean bl = this.getCertificateCNandSANS(arrx509Certificate2[0]).contains((Object)this.commonName);
        String string3 = this.getCertificatePublicKey(arrx509Certificate2[-1 + arrx509Certificate2.length]);
        boolean bl2 = this.rootPublicKey.equals((Object)string3);
        if (bl && bl2) {
            return;
        }
        throw new CertificateException("Certificates chain validation error");
    }

    public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[0];
    }
}

