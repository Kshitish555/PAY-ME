/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.security.cert.CertificateException
 *  java.security.cert.X509Certificate
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  javax.net.ssl.X509TrustManager
 */
package com.payoneermobilessl.utils;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.X509TrustManager;

class CompositeX509TrustManager
implements X509TrustManager {
    private final List<X509TrustManager> trustManagers;

    public CompositeX509TrustManager(List<X509TrustManager> list) {
        this.trustManagers = new ArrayList(list);
    }

    public void checkClientTrusted(X509Certificate[] arrx509Certificate, String string2) throws CertificateException {
        Iterator iterator = this.trustManagers.iterator();
        while (iterator.hasNext()) {
            ((X509TrustManager)iterator.next()).checkClientTrusted(arrx509Certificate, string2);
        }
    }

    public void checkServerTrusted(X509Certificate[] arrx509Certificate, String string2) throws CertificateException {
        Iterator iterator = this.trustManagers.iterator();
        while (iterator.hasNext()) {
            ((X509TrustManager)iterator.next()).checkServerTrusted(arrx509Certificate, string2);
        }
    }

    public X509Certificate[] getAcceptedIssuers() {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.trustManagers.iterator();
        while (iterator.hasNext()) {
            arrayList.addAll((Collection)Arrays.asList((Object[])((X509TrustManager)iterator.next()).getAcceptedIssuers()));
        }
        return (X509Certificate[])arrayList.toArray((Object[])new X509Certificate[0]);
    }
}

