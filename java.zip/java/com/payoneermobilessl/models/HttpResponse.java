/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.WritableMap
 *  java.lang.Object
 *  java.lang.String
 */
package com.payoneermobilessl.models;

import com.facebook.react.bridge.WritableMap;

public class HttpResponse {
    public String bodyString;
    public WritableMap headers;
    public int statusCode;
    public String statusText;

    public HttpResponse() {
    }

    public HttpResponse(int n2, WritableMap writableMap, String string2, String string3) {
        this.statusCode = n2;
        this.headers = writableMap;
        this.bodyString = string2;
        this.statusText = string3;
    }
}

