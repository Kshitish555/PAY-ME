/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.payoneermobilessl.models;

import org.json.JSONObject;

public class HttpRequest {
    private static final int DEFAULT_TIMEOUT = 10000;
    public String body;
    public String commonName;
    public String endpoint;
    public JSONObject headers;
    public String method;
    public boolean responseCanBeIgnored = false;
    public String rootPublicKey;
    public int timeout;

    public HttpRequest() {
        this.timeout = 10000;
    }

    public HttpRequest(String string2) {
        this.endpoint = string2;
        this.timeout = 10000;
    }

    public HttpRequest(String string2, String string3, JSONObject jSONObject, String string4, int n2) {
        this.endpoint = string2;
        this.method = string3;
        this.headers = jSONObject;
        this.body = string4;
        this.timeout = n2;
    }
}

