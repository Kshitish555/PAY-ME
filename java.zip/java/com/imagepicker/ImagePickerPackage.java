/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.ReactPackage
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.uimanager.ViewManager
 *  com.imagepicker.ImagePickerModule
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 */
package com.imagepicker;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import com.imagepicker.ImagePickerModule;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ImagePickerPackage
implements ReactPackage {
    private final int dialogThemeId;

    public ImagePickerPackage() {
        this.dialogThemeId = ImagePickerModule.DEFAULT_EXPLAINING_PERMISSION_DIALIOG_THEME;
    }

    public ImagePickerPackage(int n2) {
        this.dialogThemeId = n2;
    }

    public List<Class<? extends JavaScriptModule>> createJSModules() {
        return Collections.emptyList();
    }

    public List<NativeModule> createNativeModules(ReactApplicationContext reactApplicationContext) {
        Object[] arrobject = new NativeModule[]{new ImagePickerModule(reactApplicationContext, this.dialogThemeId)};
        return Arrays.asList((Object[])arrobject);
    }

    public List<ViewManager> createViewManagers(ReactApplicationContext reactApplicationContext) {
        return Collections.emptyList();
    }
}

