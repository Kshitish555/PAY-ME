/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.ReadableNativeMap
 *  com.imagepicker.ImagePickerModule
 *  com.imagepicker.permissions.PermissionUtils$1
 *  com.imagepicker.permissions.PermissionUtils$2
 *  com.imagepicker.permissions.PermissionUtils$OnExplainingPermissionCallback
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 *  java.util.HashMap
 */
package com.imagepicker.permissions;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableNativeMap;
import com.imagepicker.ImagePickerModule;
import com.imagepicker.permissions.PermissionUtils;
import java.lang.ref.WeakReference;
import java.util.HashMap;

public class PermissionUtils {
    public static AlertDialog explainingDialog(ImagePickerModule imagePickerModule, ReadableMap readableMap, OnExplainingPermissionCallback onExplainingPermissionCallback) {
        if (imagePickerModule.getContext() == null) {
            return null;
        }
        if (!readableMap.hasKey("permissionDenied")) {
            return null;
        }
        ReadableMap readableMap2 = readableMap.getMap("permissionDenied");
        if (((ReadableNativeMap)readableMap2).toHashMap().size() == 0) {
            return null;
        }
        String string2 = readableMap2.getString("title");
        String string3 = readableMap2.getString("text");
        String string4 = readableMap2.getString("reTryTitle");
        String string5 = readableMap2.getString("okTitle");
        WeakReference weakReference = new WeakReference((Object)imagePickerModule);
        Activity activity = imagePickerModule.getActivity();
        if (activity == null) {
            return null;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)activity, imagePickerModule.getDialogThemeId());
        builder.setTitle((CharSequence)string2).setMessage((CharSequence)string3).setCancelable(false).setNegativeButton((CharSequence)string5, (DialogInterface.OnClickListener)new 2(onExplainingPermissionCallback, weakReference)).setPositiveButton((CharSequence)string4, (DialogInterface.OnClickListener)new 1(onExplainingPermissionCallback, weakReference));
        return builder.create();
    }
}

