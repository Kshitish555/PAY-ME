/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.core.content.FileProvider
 */
package com.imagepicker;

public class FileProvider
extends androidx.core.content.FileProvider {
}

