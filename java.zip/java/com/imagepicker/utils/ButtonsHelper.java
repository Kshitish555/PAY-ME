/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedList
 *  java.util.List
 */
package com.imagepicker.utils;

import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.imagepicker.utils.ReadableMapUtils;
import java.util.LinkedList;
import java.util.List;

public class ButtonsHelper {
    public final Item btnCamera;
    public final Item btnCancel;
    public final Item btnLibrary;
    public final List<Item> customButtons;

    public ButtonsHelper(Item item, Item item2, Item item3, LinkedList<Item> linkedList) {
        this.btnCamera = item;
        this.btnLibrary = item2;
        this.btnCancel = item3;
        this.customButtons = linkedList;
    }

    private static LinkedList<Item> getCustomButtons(ReadableMap readableMap) {
        LinkedList linkedList = new LinkedList();
        if (!readableMap.hasKey("customButtons")) {
            return linkedList;
        }
        ReadableArray readableArray = readableMap.getArray("customButtons");
        for (int i2 = 0; i2 < readableArray.size(); ++i2) {
            ReadableMap readableMap2 = readableArray.getMap(i2);
            linkedList.add((Object)new Item(readableMap2.getString("title"), readableMap2.getString("name")));
        }
        return linkedList;
    }

    private static Item getItemFromOption(ReadableMap readableMap, String string2, String string3) {
        if (!ReadableMapUtils.hasAndNotEmptyString(readableMap, string2)) {
            return null;
        }
        return new Item(readableMap.getString(string2), string3);
    }

    public static ButtonsHelper newInstance(ReadableMap readableMap) {
        return new ButtonsHelper(ButtonsHelper.getItemFromOption(readableMap, "takePhotoButtonTitle", "photo"), ButtonsHelper.getItemFromOption(readableMap, "chooseFromLibraryButtonTitle", "library"), ButtonsHelper.getItemFromOption(readableMap, "cancelButtonTitle", "cancel"), ButtonsHelper.getCustomButtons(readableMap));
    }

    public List<String> getActions() {
        Item item;
        LinkedList linkedList = new LinkedList();
        Item item2 = this.btnCamera;
        if (item2 != null) {
            linkedList.add((Object)item2.action);
        }
        if ((item = this.btnLibrary) != null) {
            linkedList.add((Object)item.action);
        }
        for (int i2 = 0; i2 < this.customButtons.size(); ++i2) {
            linkedList.add((Object)((Item)this.customButtons.get((int)i2)).action);
        }
        return linkedList;
    }

    public List<String> getTitles() {
        Item item;
        LinkedList linkedList = new LinkedList();
        Item item2 = this.btnCamera;
        if (item2 != null) {
            linkedList.add((Object)item2.title);
        }
        if ((item = this.btnLibrary) != null) {
            linkedList.add((Object)item.title);
        }
        for (int i2 = 0; i2 < this.customButtons.size(); ++i2) {
            linkedList.add((Object)((Item)this.customButtons.get((int)i2)).title);
        }
        return linkedList;
    }

    public static class Item {
        public final String action;
        public final String title;

        public Item(String string2, String string3) {
            this.title = string2;
            this.action = string3;
        }
    }

}

