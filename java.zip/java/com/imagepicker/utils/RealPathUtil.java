/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.provider.DocumentsContract
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Audio
 *  android.provider.MediaStore$Audio$Media
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.provider.MediaStore$Video
 *  android.provider.MediaStore$Video$Media
 *  androidx.core.content.FileProvider
 *  java.io.File
 *  java.lang.IllegalArgumentException
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.imagepicker.utils;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import androidx.core.content.FileProvider;
import java.io.File;

public class RealPathUtil {
    public static Uri compatUriFromFile(Context context, File file) {
        if (Build.VERSION.SDK_INT < 21) {
            return Uri.fromFile((File)file);
        }
        StringBuilder stringBuilder = new StringBuilder(context.getApplicationContext().getPackageName());
        stringBuilder.append(".provider");
        String string2 = stringBuilder.toString();
        try {
            Uri uri = FileProvider.getUriForFile((Context)context, (String)string2, (File)file);
            return uri;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            illegalArgumentException.printStackTrace();
            return null;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive exception aggregation
     */
    public static String getDataColumn(Context context, Uri uri, String string2, String[] arrstring) {
        void var5_9;
        Cursor cursor;
        block8 : {
            block6 : {
                String string3;
                block7 : {
                    String[] arrstring2 = new String[]{"_data"};
                    cursor = context.getContentResolver().query(uri, arrstring2, string2, arrstring, null);
                    if (cursor == null) break block6;
                    try {
                        if (!cursor.moveToFirst()) break block6;
                        string3 = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
                        if (cursor == null) break block7;
                    }
                    catch (Throwable throwable) {
                        break block8;
                    }
                    cursor.close();
                }
                return string3;
            }
            if (cursor != null) {
                cursor.close();
            }
            return null;
            catch (Throwable throwable) {
                cursor = null;
            }
        }
        if (cursor != null) {
            cursor.close();
        }
        throw var5_9;
    }

    public static String getFileProviderPath(Context context, Uri uri) {
        File file = new File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), uri.getLastPathSegment());
        if (file.exists()) {
            return file.toString();
        }
        return null;
    }

    public static String getRealPathFromURI(Context context, Uri uri) {
        boolean bl = Build.VERSION.SDK_INT >= 19;
        if (bl && DocumentsContract.isDocumentUri((Context)context, (Uri)uri)) {
            if (RealPathUtil.isExternalStorageDocument(uri)) {
                String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
                if ("primary".equalsIgnoreCase(arrstring[0])) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append((Object)Environment.getExternalStorageDirectory());
                    stringBuilder.append("/");
                    stringBuilder.append(arrstring[1]);
                    return stringBuilder.toString();
                }
            } else {
                if (RealPathUtil.isDownloadsDocument(uri)) {
                    String string2 = DocumentsContract.getDocumentId((Uri)uri);
                    return RealPathUtil.getDataColumn(context, ContentUris.withAppendedId((Uri)Uri.parse((String)"content://downloads/public_downloads"), (long)Long.valueOf((String)string2)), null, null);
                }
                if (RealPathUtil.isMediaDocument(uri)) {
                    Uri uri2;
                    String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
                    String string3 = arrstring[0];
                    if ("image".equals((Object)string3)) {
                        uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    } else if ("video".equals((Object)string3)) {
                        uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    } else {
                        boolean bl2 = "audio".equals((Object)string3);
                        uri2 = null;
                        if (bl2) {
                            uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                        }
                    }
                    String[] arrstring2 = new String[]{arrstring[1]};
                    return RealPathUtil.getDataColumn(context, uri2, "_id=?", arrstring2);
                }
            }
        } else {
            if ("content".equalsIgnoreCase(uri.getScheme())) {
                if (RealPathUtil.isGooglePhotosUri(uri)) {
                    return uri.getLastPathSegment();
                }
                if (RealPathUtil.isFileProviderUri(context, uri)) {
                    return RealPathUtil.getFileProviderPath(context, uri);
                }
                return RealPathUtil.getDataColumn(context, uri, null, null);
            }
            if ("file".equalsIgnoreCase(uri.getScheme())) {
                return uri.getPath();
            }
        }
        return null;
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isFileProviderUri(Context context, Uri uri) {
        StringBuilder stringBuilder = new StringBuilder(context.getPackageName());
        stringBuilder.append(".provider");
        return stringBuilder.toString().equals((Object)uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals((Object)uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals((Object)uri.getAuthority());
    }
}

