/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  com.facebook.react.bridge.ReadableMap
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.imagepicker.utils;

import android.text.TextUtils;
import com.facebook.react.bridge.ReadableMap;

public class ReadableMapUtils {
    public static boolean hasAndNotEmpty(Class class_, ReadableMap readableMap, String string2) {
        if (!readableMap.hasKey(string2)) {
            return false;
        }
        if (readableMap.isNull(string2)) {
            return false;
        }
        if (String.class.equals((Object)class_)) {
            return true ^ TextUtils.isEmpty((CharSequence)readableMap.getString(string2));
        }
        return true;
    }

    public static boolean hasAndNotEmptyString(ReadableMap readableMap, String string2) {
        return ReadableMapUtils.hasAndNotEmpty(String.class, readableMap, string2);
    }

    public static boolean hasAndNotNullReadableMap(ReadableMap readableMap, String string2) {
        return ReadableMapUtils.hasAndNotEmpty(ReadableMap.class, readableMap, string2);
    }
}

