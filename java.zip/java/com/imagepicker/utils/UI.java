/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.DialogInterface$OnClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.ListAdapter
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  com.facebook.react.bridge.ReadableMap
 *  com.imagepicker.ImagePickerModule
 *  com.imagepicker.R
 *  com.imagepicker.R$layout
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 *  java.util.List
 */
package com.imagepicker.utils;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertDialog;
import com.facebook.react.bridge.ReadableMap;
import com.imagepicker.ImagePickerModule;
import com.imagepicker.R;
import com.imagepicker.utils.ButtonsHelper;
import com.imagepicker.utils.ReadableMapUtils;
import java.lang.ref.WeakReference;
import java.util.List;

public class UI {
    public static AlertDialog chooseDialog(ImagePickerModule imagePickerModule, ReadableMap readableMap, final OnAction onAction) {
        Activity activity = imagePickerModule.getActivity();
        if (activity == null) {
            return null;
        }
        final WeakReference weakReference = new WeakReference((Object)imagePickerModule);
        ButtonsHelper buttonsHelper = ButtonsHelper.newInstance(readableMap);
        List<String> list = buttonsHelper.getTitles();
        final List<String> list2 = buttonsHelper.getActions();
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)activity, R.layout.list_item, list);
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)activity, imagePickerModule.getDialogThemeId());
        if (ReadableMapUtils.hasAndNotEmptyString(readableMap, "title")) {
            builder.setTitle((CharSequence)readableMap.getString("title"));
        }
        builder.setAdapter((ListAdapter)arrayAdapter, new DialogInterface.OnClickListener(){

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public void onClick(DialogInterface var1_1, int var2_2) {
                block7 : {
                    block5 : {
                        block6 : {
                            var3_3 = (String)list2.get(var2_2);
                            var4_4 = var3_3.hashCode();
                            if (var4_4 == -1367724422) break block5;
                            if (var4_4 == 106642994) break block6;
                            if (var4_4 != 166208699 || !var3_3.equals((Object)"library")) ** GOTO lbl-1000
                            var5_5 = 1;
                            break block7;
                        }
                        if (!var3_3.equals((Object)"photo")) ** GOTO lbl-1000
                        var5_5 = 0;
                        break block7;
                    }
                    if (var3_3.equals((Object)"cancel")) {
                        var5_5 = 2;
                    } else lbl-1000: // 3 sources:
                    {
                        var5_5 = -1;
                    }
                }
                if (var5_5 == 0) {
                    onAction.onTakePhoto((ImagePickerModule)weakReference.get());
                    return;
                }
                if (var5_5 == 1) {
                    onAction.onUseLibrary((ImagePickerModule)weakReference.get());
                    return;
                }
                if (var5_5 != 2) {
                    onAction.onCustomButton((ImagePickerModule)weakReference.get(), var3_3);
                    return;
                }
                onAction.onCancel((ImagePickerModule)weakReference.get());
            }
        });
        builder.setNegativeButton((CharSequence)buttonsHelper.btnCancel.title, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                onAction.onCancel((ImagePickerModule)weakReference.get());
                dialogInterface.dismiss();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.setOnCancelListener(new DialogInterface.OnCancelListener(){

            public void onCancel(DialogInterface dialogInterface) {
                onAction.onCancel((ImagePickerModule)weakReference.get());
                dialogInterface.dismiss();
            }
        });
        return alertDialog;
    }

    public static interface OnAction {
        public void onCancel(ImagePickerModule var1);

        public void onCustomButton(ImagePickerModule var1, String var2);

        public void onTakePhoto(ImagePickerModule var1);

        public void onUseLibrary(ImagePickerModule var1);
    }

}

