/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Matrix
 *  android.media.ExifInterface
 *  android.media.MediaScannerConnection
 *  android.media.MediaScannerConnection$OnScanCompletedListener
 *  android.net.Uri
 *  android.os.Environment
 *  android.util.Log
 *  com.facebook.react.bridge.ReadableMap
 *  com.imagepicker.ResponseHelper
 *  com.imagepicker.media.ImageConfig
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.channels.FileChannel
 *  java.nio.channels.WritableByteChannel
 *  java.text.SimpleDateFormat
 *  java.util.Date
 *  java.util.TimeZone
 *  java.util.UUID
 */
package com.imagepicker.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import com.facebook.react.bridge.ReadableMap;
import com.imagepicker.ResponseHelper;
import com.imagepicker.media.ImageConfig;
import com.imagepicker.utils.ReadableMapUtils;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;

public class MediaUtils {
    public static File createNewFile(Context context, ReadableMap readableMap, boolean bl) {
        StringBuilder stringBuilder = new StringBuilder("image-");
        stringBuilder.append(UUID.randomUUID().toString());
        stringBuilder.append(".jpg");
        String string2 = stringBuilder.toString();
        File file = ReadableMapUtils.hasAndNotNullReadableMap(readableMap, "storageOptions") && ReadableMapUtils.hasAndNotEmptyString(readableMap.getMap("storageOptions"), "path") ? new File(Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_PICTURES), readableMap.getMap("storageOptions").getString("path")) : (!bl ? Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_PICTURES) : context.getExternalFilesDir(Environment.DIRECTORY_PICTURES));
        File file2 = new File(file, string2);
        try {
            file.mkdirs();
            file2.createNewFile();
            return file2;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return null;
        }
    }

    public static void fileScan(Context context, String string2) {
        if (context == null) {
            return;
        }
        MediaScannerConnection.scanFile((Context)context, (String[])new String[]{string2}, null, (MediaScannerConnection.OnScanCompletedListener)new MediaScannerConnection.OnScanCompletedListener(){

            public void onScanCompleted(String string2, Uri uri) {
                StringBuilder stringBuilder = new StringBuilder("Finished scanning ");
                stringBuilder.append(string2);
                Log.i((String)"TAG", (String)stringBuilder.toString());
            }
        });
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static ImageConfig getResizedImage(Context var0, ReadableMap var1_1, ImageConfig var2_2, int var3_3, int var4_4, int var5_5) {
        block26 : {
            var6_6 = new BitmapFactory.Options();
            var6_6.inScaled = false;
            var6_6.inSampleSize = 1;
            if (var2_2.maxWidth != 0 || var2_2.maxHeight != 0) break block26;
            var7_7 = var3_3;
            var8_8 = var4_4;
            ** GOTO lbl13
        }
        var7_7 = var3_3;
        var8_8 = var4_4;
        do {
            block27 : {
                if (!(var2_2.maxWidth != 0 && var7_7 <= 2 * var2_2.maxWidth || var2_2.maxHeight != 0 && var8_8 <= 2 * var2_2.maxHeight)) break block27;
lbl13: // 2 sources:
                var9_9 = BitmapFactory.decodeFile((String)var2_2.original.getAbsolutePath(), (BitmapFactory.Options)var6_6);
                if (var9_9 == null) {
                    return null;
                }
                var10_10 = var2_2.maxWidth != 0 && var2_2.maxWidth <= var7_7 ? var2_2 : var2_2.withMaxWidth(var7_7);
                if (var2_2.maxHeight == 0 || var2_2.maxWidth > var8_8) {
                    var10_10 = var10_10.withMaxHeight(var8_8);
                }
                var11_11 = var10_10;
                var12_12 = var11_11.maxWidth;
                var14_13 = var7_7;
                Double.isNaN((double)var12_12);
                Double.isNaN((double)var14_13);
                var18_14 = var12_12 / var14_13;
                var20_15 = var11_11.maxHeight;
                var22_16 = var8_8;
                Double.isNaN((double)var20_15);
                Double.isNaN((double)var22_16);
                var26_17 = var20_15 / var22_16;
                if (var18_14 < var26_17) {
                    var26_17 = var18_14;
                }
                var28_18 = new Matrix();
                var28_18.postRotate((float)var11_11.rotation);
                var30_19 = (float)var26_17;
                var28_18.postScale(var30_19, var30_19);
                try {
                    var44_20 = new ExifInterface(var11_11.original.getAbsolutePath()).getAttributeInt("Orientation", 0);
                    if (var44_20 != 3) {
                        if (var44_20 != 6) {
                            if (var44_20 == 8) {
                                var28_18.postRotate(270.0f);
                            }
                        } else {
                            var28_18.postRotate(90.0f);
                        }
                    } else {
                        var28_18.postRotate(180.0f);
                    }
                }
                catch (IOException var32_21) {
                    var32_21.printStackTrace();
                }
                var33_22 = Bitmap.createBitmap((Bitmap)var9_9, (int)0, (int)0, (int)var9_9.getWidth(), (int)var9_9.getHeight(), (Matrix)var28_18, (boolean)true);
                var34_23 = new ByteArrayOutputStream();
                var33_22.compress(Bitmap.CompressFormat.JPEG, var11_11.quality, (OutputStream)var34_23);
                var36_24 = false;
                if (var5_5 == 13001) {
                    var36_24 = true;
                }
                if ((var37_25 = MediaUtils.createNewFile(var0, var1_1, var36_24 ^ true)) == null) {
                    if (var9_9 != null) {
                        var9_9.recycle();
                    }
                    if (var33_22 == null) return var2_2;
                    var33_22.recycle();
                    return var2_2;
                }
                var38_26 = var11_11.withResizedFile(var37_25);
                var39_27 = new FileOutputStream(var38_26.resized);
                var34_23.writeTo((OutputStream)var39_27);
                var39_27.close();
                catch (Throwable var40_28) {
                    try {
                        throw var40_28;
                    }
                    catch (Throwable var41_29) {
                        try {
                            var39_27.close();
                            throw var41_29;
                        }
                        catch (Throwable var42_30) {
                            try {
                                var40_28.addSuppressed(var42_30);
                                throw var41_29;
                            }
                            catch (IOException var43_31) {
                                var43_31.printStackTrace();
                            }
                        }
                    }
                }
                if (var9_9 != null) {
                    var9_9.recycle();
                }
                if (var33_22 == null) return var38_26;
                var33_22.recycle();
                return var38_26;
            }
            var6_6.inSampleSize = 2 * var6_6.inSampleSize;
            var8_8 /= 2;
            var7_7 /= 2;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void moveFile(File var0, File var1_1) throws IOException {
        block10 : {
            var2_2 = null;
            var4_3 = new FileInputStream(var0).getChannel();
            try {
                var6_4 = new FileOutputStream(var1_1).getChannel();
            }
            catch (Throwable var3_8) {
                var2_2 = null;
                break block10;
            }
            var7_5 = var4_3.size();
            var4_3.transferTo(0L, var7_5, (WritableByteChannel)var6_4);
            var0.delete();
            if (var4_3 == null) ** GOTO lbl16
            try {
                var4_3.close();
lbl16: // 2 sources:
                if (var6_4 == null) return;
                var6_4.close();
                return;
            }
            catch (IOException var12_6) {}
            catch (Throwable var3_7) {
                var2_2 = var6_4;
            }
            break block10;
            catch (Throwable var3_9) {
                var4_3 = null;
            }
        }
        if (var4_3 == null) ** GOTO lbl29
        try {
            var4_3.close();
lbl29: // 2 sources:
            if (var2_2 == null) throw var3_10;
            var2_2.close();
            throw var3_10;
        }
        catch (IOException var5_11) {}
        var12_6.printStackTrace();
        return;
        var5_11.printStackTrace();
        throw var3_10;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static ReadExifResult readExifInterface(ResponseHelper responseHelper, ImageConfig imageConfig) {
        int n2;
        boolean bl;
        block10 : {
            block7 : {
                block11 : {
                    block8 : {
                        block9 : {
                            n2 = 0;
                            try {
                                ExifInterface exifInterface;
                                exifInterface = new ExifInterface(imageConfig.original.getAbsolutePath());
                                float[] arrf = new float[2];
                                exifInterface.getLatLong(arrf);
                                float f2 = arrf[0];
                                bl = true;
                                float f3 = arrf[bl];
                                if (f2 != 0.0f || f3 != 0.0f) {
                                    responseHelper.putDouble("latitude", (double)f2);
                                    responseHelper.putDouble("longitude", (double)f3);
                                }
                                String string2 = exifInterface.getAttribute("DateTime");
                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
                                SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                                simpleDateFormat2.setTimeZone(TimeZone.getTimeZone((String)"UTC"));
                                try {
                                    StringBuilder stringBuilder = new StringBuilder(simpleDateFormat2.format(simpleDateFormat.parse(string2)));
                                    stringBuilder.append("Z");
                                    responseHelper.putString("timestamp", stringBuilder.toString());
                                }
                                catch (Exception exception) {}
                                int n3 = exifInterface.getAttributeInt("Orientation", (int)bl);
                                if (n3 == 3) break block7;
                                if (n3 == 6) break block8;
                                if (n3 == 8) break block9;
                                n2 = 0;
                                break block10;
                            }
                            catch (IOException iOException) {
                                iOException.printStackTrace();
                                return new ReadExifResult(n2, iOException);
                            }
                        }
                        n2 = 270;
                        break block11;
                    }
                    n2 = 90;
                }
                bl = false;
                break block10;
            }
            n2 = 180;
        }
        responseHelper.putInt("originalRotation", n2);
        responseHelper.putBoolean("isVertical", bl);
        return new ReadExifResult(n2, null);
    }

    public static void removeUselessFiles(int n2, ImageConfig imageConfig) {
        if (n2 != 13001) {
            return;
        }
        if (imageConfig.original != null && imageConfig.original.exists()) {
            imageConfig.original.delete();
        }
        if (imageConfig.resized != null && imageConfig.resized.exists()) {
            imageConfig.resized.delete();
        }
    }

    public static RolloutPhotoResult rolloutPhotoFromCamera(ImageConfig imageConfig) {
        File file = imageConfig.resized == null ? imageConfig.original : imageConfig.resized;
        File file2 = new File(Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_DCIM).getPath(), file.getName());
        try {
            MediaUtils.moveFile(file, file2);
            ImageConfig imageConfig2 = imageConfig.resized != null ? imageConfig.withResizedFile(file2) : imageConfig.withOriginalFile(file2);
            RolloutPhotoResult rolloutPhotoResult = new RolloutPhotoResult(imageConfig2, null);
            return rolloutPhotoResult;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return new RolloutPhotoResult(imageConfig, iOException);
        }
    }

    public static class ReadExifResult {
        public final int currentRotation;
        public final Throwable error;

        public ReadExifResult(int n2, Throwable throwable) {
            this.currentRotation = n2;
            this.error = throwable;
        }
    }

    public static class RolloutPhotoResult {
        public final Throwable error;
        public final ImageConfig imageConfig;

        public RolloutPhotoResult(ImageConfig imageConfig, Throwable throwable) {
            this.imageConfig = imageConfig;
            this.error = throwable;
        }
    }

}

