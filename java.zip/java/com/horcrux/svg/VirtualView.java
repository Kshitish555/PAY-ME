/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$FillType
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Region
 *  android.graphics.Region$Op
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.view.ViewParent
 *  com.facebook.common.logging.FLog
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableType
 *  com.facebook.react.uimanager.DisplayMetricsHolder
 *  com.facebook.react.uimanager.OnLayoutEvent
 *  com.facebook.react.uimanager.UIManagerModule
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.facebook.react.uimanager.events.Event
 *  com.facebook.react.uimanager.events.EventDispatcher
 *  com.facebook.react.views.view.ReactViewGroup
 *  com.horcrux.svg.ClipPathView
 *  com.horcrux.svg.GlyphContext
 *  com.horcrux.svg.GroupView
 *  com.horcrux.svg.PropHelper
 *  com.horcrux.svg.RenderableView
 *  com.horcrux.svg.SVGLength
 *  com.horcrux.svg.SVGLength$UnitType
 *  com.horcrux.svg.VirtualView$1
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  javax.annotation.Nullable
 */
package com.horcrux.svg;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewParent;
import com.facebook.common.logging.FLog;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableType;
import com.facebook.react.uimanager.DisplayMetricsHolder;
import com.facebook.react.uimanager.OnLayoutEvent;
import com.facebook.react.uimanager.UIManagerModule;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.uimanager.events.Event;
import com.facebook.react.uimanager.events.EventDispatcher;
import com.facebook.react.views.view.ReactViewGroup;
import com.horcrux.svg.ClipPathView;
import com.horcrux.svg.GlyphContext;
import com.horcrux.svg.GroupView;
import com.horcrux.svg.PropHelper;
import com.horcrux.svg.RenderableView;
import com.horcrux.svg.SVGLength;
import com.horcrux.svg.SvgView;
import com.horcrux.svg.VirtualView;
import javax.annotation.Nullable;

public abstract class VirtualView
extends ReactViewGroup {
    private static final int CLIP_RULE_EVENODD = 0;
    static final int CLIP_RULE_NONZERO = 1;
    static final float MIN_OPACITY_FOR_DRAW = 0.01f;
    private static final double M_SQRT1_2l = 0.7071067811865476;
    private static final float[] sRawMatrix = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    private double canvasDiagonal = -1.0;
    private float canvasHeight = -1.0f;
    private float canvasWidth = -1.0f;
    private double fontSize = -1.0;
    private GlyphContext glyphContext;
    RectF mBox;
    Matrix mCTM = new Matrix();
    boolean mCTMInvertible = true;
    private Path mCachedClipPath;
    private RectF mClientRect;
    @Nullable
    private String mClipPath;
    Region mClipRegion;
    Path mClipRegionPath;
    int mClipRule;
    final ReactContext mContext;
    Path mFillPath;
    Matrix mInvCTM = new Matrix();
    Matrix mInvMatrix = new Matrix();
    final Matrix mInvTransform = new Matrix();
    boolean mInvertible = true;
    @Nullable
    String mMask;
    Matrix mMatrix = new Matrix();
    String mName;
    private boolean mOnLayout;
    float mOpacity = 1.0f;
    Path mPath;
    Region mRegion;
    private boolean mResponsible;
    final float mScale;
    Path mStrokePath;
    Region mStrokeRegion;
    private GroupView mTextRoot;
    Matrix mTransform = new Matrix();
    boolean mTransformInvertible = true;
    private SvgView svgView;

    VirtualView(ReactContext reactContext) {
        super((Context)reactContext);
        this.mContext = reactContext;
        this.mScale = DisplayMetricsHolder.getScreenDisplayMetrics().density;
    }

    private void clearParentCache() {
        VirtualView virtualView = this;
        ViewParent viewParent;
        while ((viewParent = virtualView.getParent()) instanceof VirtualView) {
            virtualView = (VirtualView)viewParent;
            if (virtualView.mPath == null) {
                return;
            }
            virtualView.clearCache();
        }
        return;
    }

    private double fromRelativeFast(SVGLength sVGLength) {
        double d2;
        switch (1.$SwitchMap$com$horcrux$svg$SVGLength$UnitType[sVGLength.unit.ordinal()]) {
            default: {
                d2 = 1.0;
                break;
            }
            case 7: {
                d2 = 15.0;
                break;
            }
            case 6: {
                d2 = 1.25;
                break;
            }
            case 5: {
                d2 = 90.0;
                break;
            }
            case 4: {
                d2 = 3.543307;
                break;
            }
            case 3: {
                d2 = 35.43307;
                break;
            }
            case 2: {
                d2 = this.getFontSizeFromContext() / 2.0;
                break;
            }
            case 1: {
                d2 = this.getFontSizeFromContext();
            }
        }
        double d3 = d2 * sVGLength.value;
        double d4 = this.mScale;
        Double.isNaN((double)d4);
        return d3 * d4;
    }

    private double getCanvasDiagonal() {
        double d2 = this.canvasDiagonal;
        if (d2 != -1.0) {
            return d2;
        }
        this.canvasDiagonal = 0.7071067811865476 * Math.sqrt((double)(Math.pow((double)this.getCanvasWidth(), (double)2.0) + Math.pow((double)this.getCanvasHeight(), (double)2.0)));
        return this.canvasDiagonal;
    }

    private float getCanvasHeight() {
        float f2 = this.canvasHeight;
        if (f2 != -1.0f) {
            return f2;
        }
        GroupView groupView = this.getTextRoot();
        this.canvasHeight = groupView == null ? (float)this.getSvgView().getCanvasBounds().height() : groupView.getGlyphContext().getHeight();
        return this.canvasHeight;
    }

    private float getCanvasWidth() {
        float f2 = this.canvasWidth;
        if (f2 != -1.0f) {
            return f2;
        }
        GroupView groupView = this.getTextRoot();
        this.canvasWidth = groupView == null ? (float)this.getSvgView().getCanvasBounds().width() : groupView.getGlyphContext().getWidth();
        return this.canvasWidth;
    }

    private double getFontSizeFromContext() {
        double d2 = this.fontSize;
        if (d2 != -1.0) {
            return d2;
        }
        GroupView groupView = this.getTextRoot();
        if (groupView == null) {
            return 12.0;
        }
        if (this.glyphContext == null) {
            this.glyphContext = groupView.getGlyphContext();
        }
        this.fontSize = this.glyphContext.getFontSize();
        return this.fontSize;
    }

    void clearCache() {
        this.canvasDiagonal = -1.0;
        this.canvasHeight = -1.0f;
        this.canvasWidth = -1.0f;
        this.fontSize = -1.0;
        this.mStrokeRegion = null;
        this.mRegion = null;
        this.mPath = null;
    }

    void clearChildCache() {
        this.clearCache();
        for (int i2 = 0; i2 < this.getChildCount(); ++i2) {
            View view = this.getChildAt(i2);
            if (!(view instanceof VirtualView)) continue;
            ((VirtualView)view).clearChildCache();
        }
    }

    void clip(Canvas canvas, Paint paint) {
        Path path = this.getClipPath(canvas, paint);
        if (path != null) {
            canvas.clipPath(path);
        }
    }

    abstract void draw(Canvas var1, Paint var2, float var3);

    RectF getClientRect() {
        return this.mClientRect;
    }

    @Nullable
    Path getClipPath() {
        return this.mCachedClipPath;
    }

    @Nullable
    Path getClipPath(Canvas canvas, Paint paint) {
        if (this.mClipPath != null) {
            ClipPathView clipPathView = (ClipPathView)this.getSvgView().getDefinedClipPath(this.mClipPath);
            if (clipPathView != null) {
                Path path = clipPathView.mClipRule == 0 ? clipPathView.getPath(canvas, paint) : clipPathView.getPath(canvas, paint, Region.Op.UNION);
                int n2 = clipPathView.mClipRule;
                if (n2 != 0) {
                    if (n2 != 1) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("RNSVG: clipRule: ");
                        stringBuilder.append(this.mClipRule);
                        stringBuilder.append(" unrecognized");
                        FLog.w((String)"ReactNative", (String)stringBuilder.toString());
                    }
                } else {
                    path.setFillType(Path.FillType.EVEN_ODD);
                }
                this.mCachedClipPath = path;
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("RNSVG: Undefined clipPath: ");
                stringBuilder.append(this.mClipPath);
                FLog.w((String)"ReactNative", (String)stringBuilder.toString());
            }
        }
        return this.getClipPath();
    }

    @Nullable
    GroupView getParentTextRoot() {
        ViewParent viewParent = this.getParent();
        if (!(viewParent instanceof VirtualView)) {
            return null;
        }
        return ((VirtualView)viewParent).getTextRoot();
    }

    abstract Path getPath(Canvas var1, Paint var2);

    SvgView getSvgView() {
        SvgView svgView = this.svgView;
        if (svgView != null) {
            return svgView;
        }
        ViewParent viewParent = this.getParent();
        if (viewParent == null) {
            return null;
        }
        if (viewParent instanceof SvgView) {
            this.svgView = (SvgView)viewParent;
        } else if (viewParent instanceof VirtualView) {
            this.svgView = ((VirtualView)viewParent).getSvgView();
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("RNSVG: ");
            stringBuilder.append(this.getClass().getName());
            stringBuilder.append(" should be descendant of a SvgView.");
            FLog.e((String)"ReactNative", (String)stringBuilder.toString());
        }
        return this.svgView;
    }

    @Nullable
    GroupView getTextRoot() {
        if (this.mTextRoot == null) {
            VirtualView virtualView = this;
            while (virtualView != null) {
                GroupView groupView;
                if (virtualView instanceof GroupView && (groupView = (GroupView)virtualView).getGlyphContext() != null) {
                    this.mTextRoot = groupView;
                    break;
                }
                ViewParent viewParent = virtualView.getParent();
                if (!(viewParent instanceof VirtualView)) {
                    virtualView = null;
                    continue;
                }
                virtualView = (VirtualView)viewParent;
            }
        }
        return this.mTextRoot;
    }

    abstract int hitTest(float[] var1);

    public void invalidate() {
        if (this instanceof RenderableView && this.mPath == null) {
            return;
        }
        this.clearCache();
        this.clearParentCache();
        super.invalidate();
    }

    boolean isResponsible() {
        return this.mResponsible;
    }

    protected void onLayout(boolean bl, int n2, int n3, int n4, int n5) {
        RectF rectF = this.mClientRect;
        if (rectF == null) {
            return;
        }
        if (!(this instanceof GroupView)) {
            int n6 = (int)Math.floor((double)rectF.left);
            int n7 = (int)Math.floor((double)this.mClientRect.top);
            int n8 = (int)Math.ceil((double)this.mClientRect.right);
            int n9 = (int)Math.ceil((double)this.mClientRect.bottom);
            this.setLeft(n6);
            this.setTop(n7);
            this.setRight(n8);
            this.setBottom(n9);
        }
        this.setMeasuredDimension((int)Math.ceil((double)this.mClientRect.width()), (int)Math.ceil((double)this.mClientRect.height()));
    }

    protected void onMeasure(int n2, int n3) {
        RectF rectF = this.mClientRect;
        int n4 = rectF != null ? (int)Math.ceil((double)rectF.width()) : VirtualView.getDefaultSize((int)this.getSuggestedMinimumWidth(), (int)n2);
        RectF rectF2 = this.mClientRect;
        int n5 = rectF2 != null ? (int)Math.ceil((double)rectF2.height()) : VirtualView.getDefaultSize((int)this.getSuggestedMinimumHeight(), (int)n3);
        this.setMeasuredDimension(n4, n5);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    double relativeOnHeight(SVGLength sVGLength) {
        double d2;
        double d3;
        SVGLength.UnitType unitType = sVGLength.unit;
        if (unitType == SVGLength.UnitType.NUMBER) {
            d3 = sVGLength.value;
            d2 = this.mScale;
            Double.isNaN((double)d2);
            do {
                return d3 * d2;
                break;
            } while (true);
        }
        if (unitType != SVGLength.UnitType.PERCENTAGE) return this.fromRelativeFast(sVGLength);
        d3 = sVGLength.value / 100.0;
        d2 = this.getCanvasHeight();
        Double.isNaN((double)d2);
        return d3 * d2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    double relativeOnOther(SVGLength sVGLength) {
        double d2;
        double d3;
        SVGLength.UnitType unitType = sVGLength.unit;
        if (unitType == SVGLength.UnitType.NUMBER) {
            d3 = sVGLength.value;
            d2 = this.mScale;
            Double.isNaN((double)d2);
            do {
                return d3 * d2;
                break;
            } while (true);
        }
        if (unitType != SVGLength.UnitType.PERCENTAGE) return this.fromRelativeFast(sVGLength);
        d3 = sVGLength.value / 100.0;
        d2 = this.getCanvasDiagonal();
        return d3 * d2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    double relativeOnWidth(SVGLength sVGLength) {
        double d2;
        double d3;
        SVGLength.UnitType unitType = sVGLength.unit;
        if (unitType == SVGLength.UnitType.NUMBER) {
            d3 = sVGLength.value;
            d2 = this.mScale;
            Double.isNaN((double)d2);
            do {
                return d3 * d2;
                break;
            } while (true);
        }
        if (unitType != SVGLength.UnitType.PERCENTAGE) return this.fromRelativeFast(sVGLength);
        d3 = sVGLength.value / 100.0;
        d2 = this.getCanvasWidth();
        Double.isNaN((double)d2);
        return d3 * d2;
    }

    void render(Canvas canvas, Paint paint, float f2) {
        this.draw(canvas, paint, f2);
    }

    void restoreCanvas(Canvas canvas, int n2) {
        canvas.restoreToCount(n2);
    }

    int saveAndSetupCanvas(Canvas canvas, Matrix matrix) {
        int n2 = canvas.save();
        this.mCTM.setConcat(this.mMatrix, this.mTransform);
        canvas.concat(this.mCTM);
        this.mCTM.preConcat(matrix);
        this.mCTMInvertible = this.mCTM.invert(this.mInvCTM);
        return n2;
    }

    void saveDefinition() {
        if (this.mName != null) {
            this.getSvgView().defineTemplate(this, this.mName);
        }
    }

    void setClientRect(RectF rectF) {
        RectF rectF2 = this.mClientRect;
        if (rectF2 != null && rectF2.equals((Object)rectF)) {
            return;
        }
        this.mClientRect = rectF;
        if (this.mClientRect != null) {
            if (!this.mResponsible && !this.mOnLayout) {
                return;
            }
            int n2 = (int)Math.floor((double)this.mClientRect.left);
            int n3 = (int)Math.floor((double)this.mClientRect.top);
            int n4 = (int)Math.ceil((double)this.mClientRect.width());
            int n5 = (int)Math.ceil((double)this.mClientRect.height());
            if (this.mResponsible) {
                int n6 = (int)Math.ceil((double)this.mClientRect.right);
                int n7 = (int)Math.ceil((double)this.mClientRect.bottom);
                if (!(this instanceof GroupView)) {
                    this.setLeft(n2);
                    this.setTop(n3);
                    this.setRight(n6);
                    this.setBottom(n7);
                }
                this.setMeasuredDimension(n4, n5);
            }
            if (this.mOnLayout) {
                ((UIManagerModule)this.mContext.getNativeModule(UIManagerModule.class)).getEventDispatcher().dispatchEvent((Event)OnLayoutEvent.obtain((int)this.getId(), (int)n2, (int)n3, (int)n4, (int)n5));
            }
        }
    }

    @ReactProp(name="clipPath")
    public void setClipPath(String string2) {
        this.mCachedClipPath = null;
        this.mClipPath = string2;
        this.invalidate();
    }

    @ReactProp(defaultInt=1, name="clipRule")
    public void setClipRule(int n2) {
        this.mClipRule = n2;
        this.invalidate();
    }

    @ReactProp(name="mask")
    public void setMask(String string2) {
        this.mMask = string2;
        this.invalidate();
    }

    @ReactProp(name="matrix")
    public void setMatrix(Dynamic dynamic) {
        ReadableType readableType = dynamic.getType();
        if (!dynamic.isNull() && readableType.equals((Object)ReadableType.Array)) {
            int n2 = PropHelper.toMatrixData((ReadableArray)dynamic.asArray(), (float[])sRawMatrix, (float)this.mScale);
            if (n2 == 6) {
                if (this.mMatrix == null) {
                    this.mMatrix = new Matrix();
                    this.mInvMatrix = new Matrix();
                }
                this.mMatrix.setValues(sRawMatrix);
                this.mInvertible = this.mMatrix.invert(this.mInvMatrix);
            } else if (n2 != -1) {
                FLog.w((String)"ReactNative", (String)"RNSVG: Transform matrices must be of size 6");
            }
        } else {
            this.mMatrix = null;
            this.mInvMatrix = null;
            this.mInvertible = false;
        }
        super.invalidate();
        this.clearParentCache();
    }

    @ReactProp(name="name")
    public void setName(String string2) {
        this.mName = string2;
        this.invalidate();
    }

    @ReactProp(name="onLayout")
    public void setOnLayout(boolean bl) {
        this.mOnLayout = bl;
        this.invalidate();
    }

    @ReactProp(defaultFloat=1.0f, name="opacity")
    public void setOpacity(float f2) {
        this.mOpacity = f2;
        this.invalidate();
    }

    @ReactProp(name="responsible")
    public void setResponsible(boolean bl) {
        this.mResponsible = bl;
        this.invalidate();
    }
}

