/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  com.facebook.common.logging.FLog
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.PropHelper
 *  com.horcrux.svg.SVGLength
 *  java.lang.String
 *  javax.annotation.Nullable
 */
package com.horcrux.svg;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import com.facebook.common.logging.FLog;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.Brush;
import com.horcrux.svg.GroupView;
import com.horcrux.svg.PropHelper;
import com.horcrux.svg.SVGLength;
import com.horcrux.svg.SvgView;
import javax.annotation.Nullable;

class PatternView
extends GroupView {
    private static final float[] sRawMatrix = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    String mAlign;
    private SVGLength mH;
    private Matrix mMatrix = null;
    int mMeetOrSlice;
    private float mMinX;
    private float mMinY;
    private Brush.BrushUnits mPatternContentUnits;
    private Brush.BrushUnits mPatternUnits;
    private float mVbHeight;
    private float mVbWidth;
    private SVGLength mW;
    private SVGLength mX;
    private SVGLength mY;

    public PatternView(ReactContext reactContext) {
        super(reactContext);
    }

    RectF getViewBox() {
        return new RectF(this.mMinX * this.mScale, this.mMinY * this.mScale, (this.mMinX + this.mVbWidth) * this.mScale, (this.mMinY + this.mVbHeight) * this.mScale);
    }

    @Override
    void saveDefinition() {
        if (this.mName != null) {
            SVGLength[] arrsVGLength = new SVGLength[]{this.mX, this.mY, this.mW, this.mH};
            Brush brush = new Brush(Brush.BrushType.PATTERN, arrsVGLength, this.mPatternUnits);
            brush.setContentUnits(this.mPatternContentUnits);
            brush.setPattern(this);
            Matrix matrix = this.mMatrix;
            if (matrix != null) {
                brush.setGradientTransform(matrix);
            }
            SvgView svgView = this.getSvgView();
            if (this.mPatternUnits == Brush.BrushUnits.USER_SPACE_ON_USE || this.mPatternContentUnits == Brush.BrushUnits.USER_SPACE_ON_USE) {
                brush.setUserSpaceBoundingBox(svgView.getCanvasBounds());
            }
            svgView.defineBrush(brush, this.mName);
        }
    }

    @ReactProp(name="align")
    public void setAlign(String string) {
        this.mAlign = string;
        this.invalidate();
    }

    @ReactProp(name="height")
    public void setHeight(Dynamic dynamic) {
        this.mH = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="meetOrSlice")
    public void setMeetOrSlice(int n) {
        this.mMeetOrSlice = n;
        this.invalidate();
    }

    @ReactProp(name="minX")
    public void setMinX(float f) {
        this.mMinX = f;
        this.invalidate();
    }

    @ReactProp(name="minY")
    public void setMinY(float f) {
        this.mMinY = f;
        this.invalidate();
    }

    @ReactProp(name="patternContentUnits")
    public void setPatternContentUnits(int n) {
        if (n != 0) {
            if (n == 1) {
                this.mPatternContentUnits = Brush.BrushUnits.USER_SPACE_ON_USE;
            }
        } else {
            this.mPatternContentUnits = Brush.BrushUnits.OBJECT_BOUNDING_BOX;
        }
        this.invalidate();
    }

    @ReactProp(name="patternTransform")
    public void setPatternTransform(@Nullable ReadableArray readableArray) {
        if (readableArray != null) {
            int n = PropHelper.toMatrixData((ReadableArray)readableArray, (float[])sRawMatrix, (float)this.mScale);
            if (n == 6) {
                if (this.mMatrix == null) {
                    this.mMatrix = new Matrix();
                }
                this.mMatrix.setValues(sRawMatrix);
            } else if (n != -1) {
                FLog.w((String)"ReactNative", (String)"RNSVG: Transform matrices must be of size 6");
            }
        } else {
            this.mMatrix = null;
        }
        this.invalidate();
    }

    @ReactProp(name="patternUnits")
    public void setPatternUnits(int n) {
        if (n != 0) {
            if (n == 1) {
                this.mPatternUnits = Brush.BrushUnits.USER_SPACE_ON_USE;
            }
        } else {
            this.mPatternUnits = Brush.BrushUnits.OBJECT_BOUNDING_BOX;
        }
        this.invalidate();
    }

    @ReactProp(name="vbHeight")
    public void setVbHeight(float f) {
        this.mVbHeight = f;
        this.invalidate();
    }

    @ReactProp(name="vbWidth")
    public void setVbWidth(float f) {
        this.mVbWidth = f;
        this.invalidate();
    }

    @ReactProp(name="width")
    public void setWidth(Dynamic dynamic) {
        this.mW = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="x")
    public void setX(Dynamic dynamic) {
        this.mX = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="y")
    public void setY(Dynamic dynamic) {
        this.mY = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }
}

