/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Path
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.SVGLength
 */
package com.horcrux.svg;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.RenderableView;
import com.horcrux.svg.SVGLength;

class LineView
extends RenderableView {
    private SVGLength mX1;
    private SVGLength mX2;
    private SVGLength mY1;
    private SVGLength mY2;

    public LineView(ReactContext reactContext) {
        super(reactContext);
    }

    @Override
    Path getPath(Canvas canvas, Paint paint) {
        Path path = new Path();
        double d = this.relativeOnWidth(this.mX1);
        double d2 = this.relativeOnHeight(this.mY1);
        double d3 = this.relativeOnWidth(this.mX2);
        double d4 = this.relativeOnHeight(this.mY2);
        path.moveTo((float)d, (float)d2);
        path.lineTo((float)d3, (float)d4);
        return path;
    }

    @ReactProp(name="x1")
    public void setX1(Dynamic dynamic) {
        this.mX1 = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="x2")
    public void setX2(Dynamic dynamic) {
        this.mX2 = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="y1")
    public void setY1(Dynamic dynamic) {
        this.mY1 = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="y2")
    public void setY2(Dynamic dynamic) {
        this.mY2 = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }
}

