/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Typeface
 *  android.util.Base64
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.view.ViewParent
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.uimanager.DisplayMetricsHolder
 *  com.facebook.react.uimanager.ReactCompoundView
 *  com.facebook.react.uimanager.ReactCompoundViewGroup
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.facebook.react.views.view.ReactViewGroup
 *  com.horcrux.svg.Brush
 *  com.horcrux.svg.PropHelper
 *  com.horcrux.svg.SVGLength
 *  com.horcrux.svg.SvgViewManager
 *  com.horcrux.svg.ViewBox
 *  java.io.ByteArrayOutputStream
 *  java.io.OutputStream
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  javax.annotation.Nullable
 */
package com.horcrux.svg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewParent;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.DisplayMetricsHolder;
import com.facebook.react.uimanager.ReactCompoundView;
import com.facebook.react.uimanager.ReactCompoundViewGroup;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.views.view.ReactViewGroup;
import com.horcrux.svg.Brush;
import com.horcrux.svg.PropHelper;
import com.horcrux.svg.SVGLength;
import com.horcrux.svg.SvgViewManager;
import com.horcrux.svg.ViewBox;
import com.horcrux.svg.VirtualView;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;

public class SvgView
extends ReactViewGroup
implements ReactCompoundView,
ReactCompoundViewGroup {
    private String mAlign;
    @Nullable
    private Bitmap mBitmap;
    private Canvas mCanvas;
    private final Map<String, Brush> mDefinedBrushes = new HashMap();
    private final Map<String, VirtualView> mDefinedClipPaths = new HashMap();
    private final Map<String, VirtualView> mDefinedMasks = new HashMap();
    private final Map<String, VirtualView> mDefinedTemplates = new HashMap();
    private final Matrix mInvViewBoxMatrix = new Matrix();
    private boolean mInvertible = true;
    private int mMeetOrSlice;
    private float mMinX;
    private float mMinY;
    private boolean mRendered = false;
    private boolean mResponsible = false;
    private final float mScale;
    int mTintColor = 0;
    private float mVbHeight;
    private float mVbWidth;
    private SVGLength mbbHeight;
    private SVGLength mbbWidth;
    private Runnable toDataUrlTask = null;

    public SvgView(ReactContext reactContext) {
        super((Context)reactContext);
        this.mScale = DisplayMetricsHolder.getScreenDisplayMetrics().density;
    }

    private void clearChildCache() {
        if (!this.mRendered) {
            return;
        }
        this.mRendered = false;
        for (int i2 = 0; i2 < this.getChildCount(); ++i2) {
            View view = this.getChildAt(i2);
            if (!(view instanceof VirtualView)) continue;
            ((VirtualView)view).clearChildCache();
        }
    }

    private Bitmap drawOutput() {
        boolean bl;
        this.mRendered = bl = true;
        float f2 = this.getWidth();
        float f3 = this.getHeight();
        if (!(Float.isNaN((float)f2) || Float.isNaN((float)f3) || f2 < 1.0f || f3 < 1.0f || Math.log10((double)f2) + Math.log10((double)f3) > 42.0)) {
            bl = false;
        }
        if (bl) {
            return null;
        }
        Bitmap bitmap = Bitmap.createBitmap((int)((int)f2), (int)((int)f3), (Bitmap.Config)Bitmap.Config.ARGB_8888);
        this.drawChildren(new Canvas(bitmap));
        return bitmap;
    }

    private RectF getViewBox() {
        float f2 = this.mMinX;
        float f3 = this.mScale;
        float f4 = f2 * f3;
        float f5 = this.mMinY;
        return new RectF(f4, f5 * f3, f3 * (f2 + this.mVbWidth), f3 * (f5 + this.mVbHeight));
    }

    private int hitTest(float f2, float f3) {
        if (this.mResponsible && this.mInvertible) {
            float[] arrf = new float[]{f2, f3};
            this.mInvViewBoxMatrix.mapPoints(arrf);
            int n2 = -1;
            for (int i2 = this.getChildCount() - 1; i2 >= 0; --i2) {
                View view = this.getChildAt(i2);
                if (view instanceof VirtualView) {
                    n2 = ((VirtualView)view).hitTest(arrf);
                } else if (view instanceof SvgView) {
                    n2 = ((SvgView)view).hitTest(f2, f3);
                }
                if (n2 != -1) break;
            }
            if (n2 == -1) {
                n2 = this.getId();
            }
            return n2;
        }
        return this.getId();
    }

    void defineBrush(Brush brush, String string2) {
        this.mDefinedBrushes.put((Object)string2, (Object)brush);
    }

    void defineClipPath(VirtualView virtualView, String string2) {
        this.mDefinedClipPaths.put((Object)string2, (Object)virtualView);
    }

    void defineMask(VirtualView virtualView, String string2) {
        this.mDefinedMasks.put((Object)string2, (Object)virtualView);
    }

    void defineTemplate(VirtualView virtualView, String string2) {
        this.mDefinedTemplates.put((Object)string2, (Object)virtualView);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void drawChildren(Canvas canvas) {
        SvgView svgView = this;
        synchronized (svgView) {
            int n2;
            this.mRendered = true;
            this.mCanvas = canvas;
            Matrix matrix = new Matrix();
            if (this.mAlign != null) {
                RectF rectF = this.getViewBox();
                float f2 = canvas.getWidth();
                float f3 = canvas.getHeight();
                boolean bl = this.getParent() instanceof VirtualView;
                if (bl) {
                    f2 = (float)PropHelper.fromRelative((SVGLength)this.mbbWidth, (double)f2, (double)0.0, (double)this.mScale, (double)12.0);
                    f3 = (float)PropHelper.fromRelative((SVGLength)this.mbbHeight, (double)f3, (double)0.0, (double)this.mScale, (double)12.0);
                }
                RectF rectF2 = new RectF(0.0f, 0.0f, f2, f3);
                if (bl) {
                    canvas.clipRect(rectF2);
                }
                matrix = ViewBox.getTransform((RectF)rectF, (RectF)rectF2, (String)this.mAlign, (int)this.mMeetOrSlice);
                this.mInvertible = matrix.invert(this.mInvViewBoxMatrix);
                canvas.concat(matrix);
            }
            Paint paint = new Paint();
            paint.setFlags(385);
            paint.setTypeface(Typeface.DEFAULT);
            int n3 = 0;
            do {
                int n4 = this.getChildCount();
                n2 = 0;
                if (n3 >= n4) break;
                View view = this.getChildAt(n3);
                if (view instanceof VirtualView) {
                    ((VirtualView)view).saveDefinition();
                }
                ++n3;
            } while (true);
            while (n2 < this.getChildCount()) {
                View view = this.getChildAt(n2);
                if (view instanceof VirtualView) {
                    VirtualView virtualView = (VirtualView)view;
                    int n5 = virtualView.saveAndSetupCanvas(canvas, matrix);
                    virtualView.render(canvas, paint, 1.0f);
                    virtualView.restoreCanvas(canvas, n5);
                    if (virtualView.isResponsible() && !this.mResponsible) {
                        this.mResponsible = true;
                    }
                }
                ++n2;
            }
            return;
        }
    }

    void enableTouchEvents() {
        if (!this.mResponsible) {
            this.mResponsible = true;
        }
    }

    Rect getCanvasBounds() {
        return this.mCanvas.getClipBounds();
    }

    Brush getDefinedBrush(String string2) {
        return (Brush)this.mDefinedBrushes.get((Object)string2);
    }

    VirtualView getDefinedClipPath(String string2) {
        return (VirtualView)((Object)this.mDefinedClipPaths.get((Object)string2));
    }

    VirtualView getDefinedMask(String string2) {
        return (VirtualView)((Object)this.mDefinedMasks.get((Object)string2));
    }

    VirtualView getDefinedTemplate(String string2) {
        return (VirtualView)((Object)this.mDefinedTemplates.get((Object)string2));
    }

    public boolean interceptsTouchEvent(float f2, float f3) {
        return true;
    }

    public void invalidate() {
        super.invalidate();
        ViewParent viewParent = this.getParent();
        if (viewParent instanceof VirtualView) {
            if (!this.mRendered) {
                return;
            }
            this.mRendered = false;
            ((VirtualView)viewParent).getSvgView().invalidate();
            return;
        }
        Bitmap bitmap = this.mBitmap;
        if (bitmap != null) {
            bitmap.recycle();
        }
        this.mBitmap = null;
    }

    boolean isResponsible() {
        return this.mResponsible;
    }

    boolean notRendered() {
        return true ^ this.mRendered;
    }

    protected void onDraw(Canvas canvas) {
        Bitmap bitmap;
        if (this.getParent() instanceof VirtualView) {
            return;
        }
        super.onDraw(canvas);
        if (this.mBitmap == null) {
            this.mBitmap = this.drawOutput();
        }
        if ((bitmap = this.mBitmap) != null) {
            canvas.drawBitmap(bitmap, 0.0f, 0.0f, null);
            Runnable runnable = this.toDataUrlTask;
            if (runnable != null) {
                runnable.run();
                this.toDataUrlTask = null;
            }
        }
    }

    protected void onSizeChanged(int n2, int n3, int n4, int n5) {
        super.onSizeChanged(n2, n3, n4, n5);
        this.invalidate();
    }

    public int reactTagForTouch(float f2, float f3) {
        return this.hitTest(f2, f3);
    }

    @ReactProp(name="align")
    public void setAlign(String string2) {
        this.mAlign = string2;
        this.invalidate();
        this.clearChildCache();
    }

    @ReactProp(name="bbHeight")
    public void setBbHeight(Dynamic dynamic) {
        this.mbbHeight = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
        this.clearChildCache();
    }

    @ReactProp(name="bbWidth")
    public void setBbWidth(Dynamic dynamic) {
        this.mbbWidth = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
        this.clearChildCache();
    }

    public void setId(int n2) {
        super.setId(n2);
        SvgViewManager.setSvgView((int)n2, (SvgView)this);
    }

    @ReactProp(name="meetOrSlice")
    public void setMeetOrSlice(int n2) {
        this.mMeetOrSlice = n2;
        this.invalidate();
        this.clearChildCache();
    }

    @ReactProp(name="minX")
    public void setMinX(float f2) {
        this.mMinX = f2;
        this.invalidate();
        this.clearChildCache();
    }

    @ReactProp(name="minY")
    public void setMinY(float f2) {
        this.mMinY = f2;
        this.invalidate();
        this.clearChildCache();
    }

    @ReactProp(name="tintColor")
    public void setTintColor(@Nullable Integer n2) {
        this.mTintColor = n2 == null ? 0 : n2;
        this.invalidate();
        this.clearChildCache();
    }

    void setToDataUrlTask(Runnable runnable) {
        this.toDataUrlTask = runnable;
    }

    @ReactProp(name="vbHeight")
    public void setVbHeight(float f2) {
        this.mVbHeight = f2;
        this.invalidate();
        this.clearChildCache();
    }

    @ReactProp(name="vbWidth")
    public void setVbWidth(float f2) {
        this.mVbWidth = f2;
        this.invalidate();
        this.clearChildCache();
    }

    String toDataURL() {
        Bitmap bitmap = Bitmap.createBitmap((int)this.getWidth(), (int)this.getHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
        this.clearChildCache();
        this.drawChildren(new Canvas(bitmap));
        this.clearChildCache();
        this.invalidate();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)byteArrayOutputStream);
        bitmap.recycle();
        return Base64.encodeToString((byte[])byteArrayOutputStream.toByteArray(), (int)0);
    }

    String toDataURL(int n2, int n3) {
        Bitmap bitmap = Bitmap.createBitmap((int)n2, (int)n3, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        this.clearChildCache();
        this.drawChildren(new Canvas(bitmap));
        this.clearChildCache();
        this.invalidate();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)byteArrayOutputStream);
        bitmap.recycle();
        return Base64.encodeToString((byte[])byteArrayOutputStream.toByteArray(), (int)0);
    }
}

