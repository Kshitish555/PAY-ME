/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.view.View
 *  com.facebook.react.bridge.ReactContext
 */
package com.horcrux.svg;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import com.facebook.react.bridge.ReactContext;
import com.horcrux.svg.DefinitionView;
import com.horcrux.svg.VirtualView;

class DefsView
extends DefinitionView {
    public DefsView(ReactContext reactContext) {
        super(reactContext);
    }

    @Override
    void draw(Canvas canvas, Paint paint, float f) {
    }

    @Override
    void saveDefinition() {
        for (int i = 0; i < this.getChildCount(); ++i) {
            View view = this.getChildAt(i);
            if (!(view instanceof VirtualView)) continue;
            ((VirtualView)view).saveDefinition();
        }
    }
}

