/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.ReadableType
 *  com.horcrux.svg.PropHelper
 *  com.horcrux.svg.TextProperties
 *  com.horcrux.svg.TextProperties$FontStyle
 *  com.horcrux.svg.TextProperties$FontVariantLigatures
 *  com.horcrux.svg.TextProperties$FontWeight
 *  com.horcrux.svg.TextProperties$TextAnchor
 *  com.horcrux.svg.TextProperties$TextDecoration
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.horcrux.svg;

import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableType;
import com.horcrux.svg.PropHelper;
import com.horcrux.svg.TextProperties;

class FontData {
    static final double DEFAULT_FONT_SIZE = 12.0;
    private static final double DEFAULT_KERNING = 0.0;
    private static final double DEFAULT_LETTER_SPACING = 0.0;
    private static final double DEFAULT_WORD_SPACING = 0.0;
    static final FontData Defaults = new FontData();
    private static final String FONT_DATA = "fontData";
    private static final String FONT_FEATURE_SETTINGS = "fontFeatureSettings";
    private static final String FONT_VARIANT_LIGATURES = "fontVariantLigatures";
    private static final String FONT_VARIATION_SETTINGS = "fontVariationSettings";
    private static final String KERNING = "kerning";
    private static final String LETTER_SPACING = "letterSpacing";
    private static final String TEXT_ANCHOR = "textAnchor";
    private static final String TEXT_DECORATION = "textDecoration";
    private static final String WORD_SPACING = "wordSpacing";
    int absoluteFontWeight;
    final ReadableMap fontData;
    final String fontFamily;
    final String fontFeatureSettings;
    final double fontSize;
    final TextProperties.FontStyle fontStyle;
    final TextProperties.FontVariantLigatures fontVariantLigatures;
    final String fontVariationSettings;
    TextProperties.FontWeight fontWeight;
    final double kerning;
    final double letterSpacing;
    final boolean manualKerning;
    final TextProperties.TextAnchor textAnchor;
    private final TextProperties.TextDecoration textDecoration;
    final double wordSpacing;

    private FontData() {
        this.fontData = null;
        this.fontFamily = "";
        this.fontStyle = TextProperties.FontStyle.normal;
        this.fontWeight = TextProperties.FontWeight.Normal;
        this.absoluteFontWeight = 400;
        this.fontFeatureSettings = "";
        this.fontVariationSettings = "";
        this.fontVariantLigatures = TextProperties.FontVariantLigatures.normal;
        this.textAnchor = TextProperties.TextAnchor.start;
        this.textDecoration = TextProperties.TextDecoration.None;
        this.manualKerning = false;
        this.kerning = 0.0;
        this.fontSize = 12.0;
        this.wordSpacing = 0.0;
        this.letterSpacing = 0.0;
    }

    FontData(ReadableMap readableMap, FontData fontData, double d) {
        double d2 = fontData.fontSize;
        this.fontSize = readableMap.hasKey("fontSize") ? this.toAbsolute(readableMap, "fontSize", 1.0, d2, d2) : d2;
        if (readableMap.hasKey("fontWeight")) {
            if (readableMap.getType("fontWeight") == ReadableType.Number) {
                this.handleNumericWeight(fontData, readableMap.getDouble("fontWeight"));
            } else {
                String string2 = readableMap.getString("fontWeight");
                if (TextProperties.FontWeight.hasEnum((String)string2)) {
                    this.absoluteFontWeight = AbsoluteFontWeight.from(TextProperties.FontWeight.get((String)string2), fontData);
                    this.fontWeight = AbsoluteFontWeight.nearestFontWeight(this.absoluteFontWeight);
                } else if (string2 != null) {
                    this.handleNumericWeight(fontData, Double.parseDouble((String)string2));
                } else {
                    this.setInheritedWeight(fontData);
                }
            }
        } else {
            this.setInheritedWeight(fontData);
        }
        ReadableMap readableMap2 = readableMap.hasKey(FONT_DATA) ? readableMap.getMap(FONT_DATA) : fontData.fontData;
        this.fontData = readableMap2;
        String string3 = readableMap.hasKey("fontFamily") ? readableMap.getString("fontFamily") : fontData.fontFamily;
        this.fontFamily = string3;
        TextProperties.FontStyle fontStyle = readableMap.hasKey("fontStyle") ? TextProperties.FontStyle.valueOf((String)readableMap.getString("fontStyle")) : fontData.fontStyle;
        this.fontStyle = fontStyle;
        String string4 = readableMap.hasKey(FONT_FEATURE_SETTINGS) ? readableMap.getString(FONT_FEATURE_SETTINGS) : fontData.fontFeatureSettings;
        this.fontFeatureSettings = string4;
        String string5 = readableMap.hasKey(FONT_VARIATION_SETTINGS) ? readableMap.getString(FONT_VARIATION_SETTINGS) : fontData.fontVariationSettings;
        this.fontVariationSettings = string5;
        TextProperties.FontVariantLigatures fontVariantLigatures = readableMap.hasKey(FONT_VARIANT_LIGATURES) ? TextProperties.FontVariantLigatures.valueOf((String)readableMap.getString(FONT_VARIANT_LIGATURES)) : fontData.fontVariantLigatures;
        this.fontVariantLigatures = fontVariantLigatures;
        TextProperties.TextAnchor textAnchor = readableMap.hasKey(TEXT_ANCHOR) ? TextProperties.TextAnchor.valueOf((String)readableMap.getString(TEXT_ANCHOR)) : fontData.textAnchor;
        this.textAnchor = textAnchor;
        TextProperties.TextDecoration textDecoration = readableMap.hasKey(TEXT_DECORATION) ? TextProperties.TextDecoration.getEnum((String)readableMap.getString(TEXT_DECORATION)) : fontData.textDecoration;
        this.textDecoration = textDecoration;
        boolean bl = readableMap.hasKey(KERNING);
        boolean bl2 = bl || fontData.manualKerning;
        this.manualKerning = bl2;
        double d3 = bl ? this.toAbsolute(readableMap, KERNING, d, this.fontSize, 0.0) : fontData.kerning;
        this.kerning = d3;
        double d4 = readableMap.hasKey(WORD_SPACING) ? this.toAbsolute(readableMap, WORD_SPACING, d, this.fontSize, 0.0) : fontData.wordSpacing;
        this.wordSpacing = d4;
        double d5 = readableMap.hasKey(LETTER_SPACING) ? this.toAbsolute(readableMap, LETTER_SPACING, d, this.fontSize, 0.0) : fontData.letterSpacing;
        this.letterSpacing = d5;
    }

    private void handleNumericWeight(FontData fontData, double d) {
        long l = Math.round((double)d);
        if (l >= 1L && l <= 1000L) {
            this.absoluteFontWeight = (int)l;
            this.fontWeight = AbsoluteFontWeight.nearestFontWeight(this.absoluteFontWeight);
            return;
        }
        this.setInheritedWeight(fontData);
    }

    private void setInheritedWeight(FontData fontData) {
        this.absoluteFontWeight = fontData.absoluteFontWeight;
        this.fontWeight = fontData.fontWeight;
    }

    private double toAbsolute(ReadableMap readableMap, String string2, double d, double d2, double d3) {
        if (readableMap.getType(string2) == ReadableType.Number) {
            return readableMap.getDouble(string2);
        }
        return PropHelper.fromRelative((String)readableMap.getString(string2), (double)d3, (double)d, (double)d2);
    }

    static class AbsoluteFontWeight {
        private static final TextProperties.FontWeight[] WEIGHTS;
        private static final int[] absoluteFontWeights;
        static final int normal = 400;

        static {
            TextProperties.FontWeight[] arrfontWeight = new TextProperties.FontWeight[]{TextProperties.FontWeight.w100, TextProperties.FontWeight.w100, TextProperties.FontWeight.w200, TextProperties.FontWeight.w300, TextProperties.FontWeight.Normal, TextProperties.FontWeight.w500, TextProperties.FontWeight.w600, TextProperties.FontWeight.Bold, TextProperties.FontWeight.w800, TextProperties.FontWeight.w900, TextProperties.FontWeight.w900};
            WEIGHTS = arrfontWeight;
            absoluteFontWeights = new int[]{400, 700, 100, 200, 300, 400, 500, 600, 700, 800, 900};
        }

        AbsoluteFontWeight() {
        }

        private static int bolder(int n) {
            if (n < 350) {
                return 400;
            }
            if (n < 550) {
                return 700;
            }
            if (n < 900) {
                return 900;
            }
            return n;
        }

        static int from(TextProperties.FontWeight fontWeight, FontData fontData) {
            if (fontWeight == TextProperties.FontWeight.Bolder) {
                return AbsoluteFontWeight.bolder(fontData.absoluteFontWeight);
            }
            if (fontWeight == TextProperties.FontWeight.Lighter) {
                return AbsoluteFontWeight.lighter(fontData.absoluteFontWeight);
            }
            return absoluteFontWeights[fontWeight.ordinal()];
        }

        private static int lighter(int n) {
            if (n < 100) {
                return n;
            }
            if (n < 550) {
                return 100;
            }
            if (n < 750) {
                return 400;
            }
            return 700;
        }

        static TextProperties.FontWeight nearestFontWeight(int n) {
            return WEIGHTS[Math.round((float)((float)n / 100.0f))];
        }
    }

}

