/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.ReactPackage
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.uimanager.ViewManager
 *  com.horcrux.svg.RenderableViewManager
 *  com.horcrux.svg.RenderableViewManager$CircleViewManager
 *  com.horcrux.svg.RenderableViewManager$ClipPathViewManager
 *  com.horcrux.svg.RenderableViewManager$DefsViewManager
 *  com.horcrux.svg.RenderableViewManager$EllipseViewManager
 *  com.horcrux.svg.RenderableViewManager$GroupViewManager
 *  com.horcrux.svg.RenderableViewManager$ImageViewManager
 *  com.horcrux.svg.RenderableViewManager$LineViewManager
 *  com.horcrux.svg.RenderableViewManager$LinearGradientManager
 *  com.horcrux.svg.RenderableViewManager$MaskManager
 *  com.horcrux.svg.RenderableViewManager$PathViewManager
 *  com.horcrux.svg.RenderableViewManager$PatternManager
 *  com.horcrux.svg.RenderableViewManager$RadialGradientManager
 *  com.horcrux.svg.RenderableViewManager$RectViewManager
 *  com.horcrux.svg.RenderableViewManager$SymbolManager
 *  com.horcrux.svg.RenderableViewManager$TSpanViewManager
 *  com.horcrux.svg.RenderableViewManager$TextPathViewManager
 *  com.horcrux.svg.RenderableViewManager$TextViewManager
 *  com.horcrux.svg.RenderableViewManager$UseViewManager
 *  com.horcrux.svg.SvgViewManager
 *  com.horcrux.svg.SvgViewModule
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 *  javax.annotation.Nonnull
 */
package com.horcrux.svg;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import com.horcrux.svg.RenderableViewManager;
import com.horcrux.svg.SvgViewManager;
import com.horcrux.svg.SvgViewModule;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nonnull;

public class SvgPackage
implements ReactPackage {
    public List<Class<? extends JavaScriptModule>> createJSModules() {
        return Collections.emptyList();
    }

    @Nonnull
    public List<NativeModule> createNativeModules(@Nonnull ReactApplicationContext reactApplicationContext) {
        return Collections.singletonList((Object)new SvgViewModule(reactApplicationContext));
    }

    @Nonnull
    public List<ViewManager> createViewManagers(@Nonnull ReactApplicationContext reactApplicationContext) {
        Object[] arrobject = new ViewManager[]{new RenderableViewManager.GroupViewManager(), new RenderableViewManager.PathViewManager(), new RenderableViewManager.CircleViewManager(), new RenderableViewManager.EllipseViewManager(), new RenderableViewManager.LineViewManager(), new RenderableViewManager.RectViewManager(), new RenderableViewManager.TextViewManager(), new RenderableViewManager.TSpanViewManager(), new RenderableViewManager.TextPathViewManager(), new RenderableViewManager.ImageViewManager(), new RenderableViewManager.ClipPathViewManager(), new RenderableViewManager.DefsViewManager(), new RenderableViewManager.UseViewManager(), new RenderableViewManager.SymbolManager(), new RenderableViewManager.LinearGradientManager(), new RenderableViewManager.RadialGradientManager(), new RenderableViewManager.PatternManager(), new RenderableViewManager.MaskManager(), new SvgViewManager()};
        return Arrays.asList((Object[])arrobject);
    }
}

