/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Path
 *  com.facebook.react.bridge.ReactContext
 */
package com.horcrux.svg;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import com.facebook.react.bridge.ReactContext;
import com.horcrux.svg.VirtualView;

class DefinitionView
extends VirtualView {
    DefinitionView(ReactContext reactContext) {
        super(reactContext);
    }

    @Override
    void draw(Canvas canvas, Paint paint, float f) {
    }

    @Override
    Path getPath(Canvas canvas, Paint paint) {
        return null;
    }

    @Override
    int hitTest(float[] arrf) {
        return -1;
    }

    @Override
    boolean isResponsible() {
        return false;
    }
}

