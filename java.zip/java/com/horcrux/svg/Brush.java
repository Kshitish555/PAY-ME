/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapShader
 *  android.graphics.Canvas
 *  android.graphics.LinearGradient
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.RadialGradient
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  com.facebook.common.logging.FLog
 *  com.facebook.react.bridge.ReadableArray
 *  com.horcrux.svg.PatternView
 *  com.horcrux.svg.PropHelper
 *  com.horcrux.svg.SVGLength
 *  com.horcrux.svg.SVGLength$UnitType
 *  com.horcrux.svg.ViewBox
 *  java.lang.Enum
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.horcrux.svg;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import com.facebook.common.logging.FLog;
import com.facebook.react.bridge.ReadableArray;
import com.horcrux.svg.PatternView;
import com.horcrux.svg.PropHelper;
import com.horcrux.svg.SVGLength;
import com.horcrux.svg.ViewBox;

class Brush {
    private ReadableArray mColors;
    private Matrix mMatrix;
    private PatternView mPattern;
    private final SVGLength[] mPoints;
    private final BrushType mType;
    private boolean mUseContentObjectBoundingBoxUnits;
    private final boolean mUseObjectBoundingBox;
    private Rect mUserSpaceBoundingBox;

    Brush(BrushType brushType, SVGLength[] arrsVGLength, BrushUnits brushUnits) {
        this.mType = brushType;
        this.mPoints = arrsVGLength;
        boolean bl = brushUnits == BrushUnits.OBJECT_BOUNDING_BOX;
        this.mUseObjectBoundingBox = bl;
    }

    private RectF getPaintRect(RectF rectF) {
        float f;
        if (!this.mUseObjectBoundingBox) {
            rectF = new RectF(this.mUserSpaceBoundingBox);
        }
        float f2 = rectF.width();
        float f3 = rectF.height();
        boolean bl = this.mUseObjectBoundingBox;
        float f4 = 0.0f;
        if (bl) {
            f4 = rectF.left;
            f = rectF.top;
        } else {
            f = 0.0f;
        }
        return new RectF(f4, f, f2 + f4, f3 + f);
    }

    private double getVal(SVGLength sVGLength, double d, float f, float f2) {
        double d2 = this.mUseObjectBoundingBox && sVGLength.unit == SVGLength.UnitType.NUMBER ? d : (double)f;
        return PropHelper.fromRelative((SVGLength)sVGLength, (double)d, (double)0.0, (double)d2, (double)f2);
    }

    private static void parseGradientStops(ReadableArray readableArray, int n, float[] arrf, int[] arrn, float f) {
        for (int i = 0; i < n; ++i) {
            int n2 = i * 2;
            arrf[i] = (float)readableArray.getDouble(n2);
            int n3 = readableArray.getInt(n2 + 1);
            arrn[i] = Math.round((float)(f * (float)(n3 >>> 24))) << 24 | n3 & 16777215;
        }
    }

    void setContentUnits(BrushUnits brushUnits) {
        boolean bl = brushUnits == BrushUnits.OBJECT_BOUNDING_BOX;
        this.mUseContentObjectBoundingBoxUnits = bl;
    }

    void setGradientColors(ReadableArray readableArray) {
        this.mColors = readableArray;
    }

    void setGradientTransform(Matrix matrix) {
        this.mMatrix = matrix;
    }

    void setPattern(PatternView patternView) {
        this.mPattern = patternView;
    }

    void setUserSpaceBoundingBox(Rect rect) {
        this.mUserSpaceBoundingBox = rect;
    }

    void setupPaint(Paint paint, RectF rectF, float f, float f2) {
        int[] arrn;
        float[] arrf;
        RectF rectF2 = this.getPaintRect(rectF);
        float f3 = rectF2.width();
        float f4 = rectF2.height();
        float f5 = rectF2.left;
        float f6 = rectF2.top;
        float f7 = paint.getTextSize();
        if (this.mType == BrushType.PATTERN) {
            SVGLength sVGLength = this.mPoints[0];
            double d = f3;
            double d2 = this.getVal(sVGLength, d, f, f7);
            SVGLength sVGLength2 = this.mPoints[1];
            double d3 = f4;
            double d4 = this.getVal(sVGLength2, d3, f, f7);
            double d5 = this.getVal(this.mPoints[2], d, f, f7);
            double d6 = this.getVal(this.mPoints[3], d3, f, f7);
            if (d5 > 1.0) {
                if (!(d6 > 1.0)) {
                    return;
                }
                Bitmap bitmap = Bitmap.createBitmap((int)((int)d5), (int)((int)d6), (Bitmap.Config)Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                RectF rectF3 = this.mPattern.getViewBox();
                if (rectF3 != null && rectF3.width() > 0.0f && rectF3.height() > 0.0f) {
                    canvas.concat(ViewBox.getTransform((RectF)rectF3, (RectF)new RectF((float)d2, (float)d4, (float)d5, (float)d6), (String)this.mPattern.mAlign, (int)this.mPattern.mMeetOrSlice));
                }
                if (this.mUseContentObjectBoundingBoxUnits) {
                    canvas.scale(f3 / f, f4 / f);
                }
                this.mPattern.draw(canvas, new Paint(), f2);
                Matrix matrix = new Matrix();
                Matrix matrix2 = this.mMatrix;
                if (matrix2 != null) {
                    matrix.preConcat(matrix2);
                }
                BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
                bitmapShader.setLocalMatrix(matrix);
                paint.setShader((Shader)bitmapShader);
            }
            return;
        }
        int n = this.mColors.size() / 2;
        int[] arrn2 = new int[n];
        float[] arrf2 = new float[n];
        Brush.parseGradientStops(this.mColors, n, arrf2, arrn2, f2);
        if (arrf2.length == 1) {
            arrn = new int[]{arrn2[0], arrn2[0]};
            arrf = new float[]{arrf2[0], arrf2[0]};
            FLog.w((String)"ReactNative", (String)"Gradient contains only on stop");
        } else {
            arrn = arrn2;
            arrf = arrf2;
        }
        if (this.mType == BrushType.LINEAR_GRADIENT) {
            SVGLength sVGLength = this.mPoints[0];
            double d = f3;
            double d7 = f5;
            double d8 = f;
            double d9 = f7;
            double d10 = PropHelper.fromRelative((SVGLength)sVGLength, (double)d, (double)d7, (double)d8, (double)d9);
            SVGLength sVGLength3 = this.mPoints[1];
            double d11 = f4;
            double d12 = f6;
            double d13 = PropHelper.fromRelative((SVGLength)sVGLength3, (double)d11, (double)d12, (double)d8, (double)d9);
            double d14 = PropHelper.fromRelative((SVGLength)this.mPoints[2], (double)d, (double)d7, (double)d8, (double)d9);
            double d15 = PropHelper.fromRelative((SVGLength)this.mPoints[3], (double)d11, (double)d12, (double)d8, (double)d9);
            float f8 = (float)d10;
            float f9 = (float)d13;
            float f10 = (float)d14;
            float f11 = (float)d15;
            Shader.TileMode tileMode = Shader.TileMode.CLAMP;
            LinearGradient linearGradient = new LinearGradient(f8, f9, f10, f11, arrn, arrf, tileMode);
            if (this.mMatrix != null) {
                Matrix matrix = new Matrix();
                matrix.preConcat(this.mMatrix);
                linearGradient.setLocalMatrix(matrix);
            }
            paint.setShader((Shader)linearGradient);
            return;
        }
        if (this.mType == BrushType.RADIAL_GRADIENT) {
            SVGLength sVGLength = this.mPoints[2];
            double d = f3;
            double d16 = f;
            double d17 = f7;
            double d18 = PropHelper.fromRelative((SVGLength)sVGLength, (double)d, (double)0.0, (double)d16, (double)d17);
            SVGLength sVGLength4 = this.mPoints[3];
            double d19 = f4;
            double d20 = PropHelper.fromRelative((SVGLength)sVGLength4, (double)d19, (double)0.0, (double)d16, (double)d17);
            double d21 = PropHelper.fromRelative((SVGLength)this.mPoints[4], (double)d, (double)f5, (double)d16, (double)d17);
            double d22 = PropHelper.fromRelative((SVGLength)this.mPoints[5], (double)d19, (double)f6, (double)d16, (double)d17);
            double d23 = d20 / d18;
            double d24 = d22 / d23;
            float f12 = (float)d21;
            float f13 = (float)d24;
            float f14 = (float)d18;
            Shader.TileMode tileMode = Shader.TileMode.CLAMP;
            RadialGradient radialGradient = new RadialGradient(f12, f13, f14, arrn, arrf, tileMode);
            Matrix matrix = new Matrix();
            matrix.preScale(1.0f, (float)d23);
            Matrix matrix3 = this.mMatrix;
            if (matrix3 != null) {
                matrix.preConcat(matrix3);
            }
            radialGradient.setLocalMatrix(matrix);
            paint.setShader((Shader)radialGradient);
        }
    }

    static final class BrushType
    extends Enum<BrushType> {
        private static final /* synthetic */ BrushType[] $VALUES;
        public static final /* enum */ BrushType LINEAR_GRADIENT = new BrushType();
        public static final /* enum */ BrushType PATTERN;
        public static final /* enum */ BrushType RADIAL_GRADIENT;

        static {
            RADIAL_GRADIENT = new BrushType();
            PATTERN = new BrushType();
            BrushType[] arrbrushType = new BrushType[]{LINEAR_GRADIENT, RADIAL_GRADIENT, PATTERN};
            $VALUES = arrbrushType;
        }

        public static BrushType valueOf(String string2) {
            return (BrushType)Enum.valueOf(BrushType.class, (String)string2);
        }

        public static BrushType[] values() {
            return (BrushType[])$VALUES.clone();
        }
    }

    static final class BrushUnits
    extends Enum<BrushUnits> {
        private static final /* synthetic */ BrushUnits[] $VALUES;
        public static final /* enum */ BrushUnits OBJECT_BOUNDING_BOX = new BrushUnits();
        public static final /* enum */ BrushUnits USER_SPACE_ON_USE = new BrushUnits();

        static {
            BrushUnits[] arrbrushUnits = new BrushUnits[]{OBJECT_BOUNDING_BOX, USER_SPACE_ON_USE};
            $VALUES = arrbrushUnits;
        }

        public static BrushUnits valueOf(String string2) {
            return (BrushUnits)Enum.valueOf(BrushUnits.class, (String)string2);
        }

        public static BrushUnits[] values() {
            return (BrushUnits[])$VALUES.clone();
        }
    }

}

