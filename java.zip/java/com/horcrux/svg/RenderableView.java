/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.DashPathEffect
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Cap
 *  android.graphics.Paint$Join
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.Path$FillType
 *  android.graphics.PathEffect
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffXfermode
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Region
 *  android.graphics.Xfermode
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.JSApplicationIllegalArgumentException
 *  com.facebook.react.bridge.JavaOnlyArray
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableType
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.SVGLength
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  javax.annotation.Nullable
 */
package com.horcrux.svg;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Xfermode;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.JSApplicationIllegalArgumentException;
import com.facebook.react.bridge.JavaOnlyArray;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableType;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.Brush;
import com.horcrux.svg.MaskView;
import com.horcrux.svg.SVGLength;
import com.horcrux.svg.SvgView;
import com.horcrux.svg.VirtualView;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Nullable;

public abstract class RenderableView
extends VirtualView {
    private static final int CAP_BUTT = 0;
    static final int CAP_ROUND = 1;
    private static final int CAP_SQUARE = 2;
    private static final int FILL_RULE_EVENODD = 0;
    static final int FILL_RULE_NONZERO = 1;
    private static final int JOIN_BEVEL = 2;
    private static final int JOIN_MITER = 0;
    static final int JOIN_ROUND = 1;
    private static final int VECTOR_EFFECT_DEFAULT = 0;
    private static final int VECTOR_EFFECT_NON_SCALING_STROKE = 1;
    private static final Pattern regex = Pattern.compile((String)"[0-9.-]+");
    @Nullable
    public ReadableArray fill;
    public float fillOpacity = 1.0f;
    public Path.FillType fillRule = Path.FillType.WINDING;
    @Nullable
    private ArrayList<String> mAttributeList;
    @Nullable
    private ArrayList<String> mLastMergedList;
    @Nullable
    private ArrayList<Object> mOriginProperties;
    @Nullable
    private ArrayList<String> mPropList;
    @Nullable
    public ReadableArray stroke;
    @Nullable
    public SVGLength[] strokeDasharray;
    public float strokeDashoffset = 0.0f;
    public Paint.Cap strokeLinecap = Paint.Cap.ROUND;
    public Paint.Join strokeLinejoin = Paint.Join.ROUND;
    public float strokeMiterlimit = 4.0f;
    public float strokeOpacity = 1.0f;
    public SVGLength strokeWidth = new SVGLength(1.0);
    public int vectorEffect = 0;

    RenderableView(ReactContext reactContext) {
        super(reactContext);
    }

    private ArrayList<String> getAttributeList() {
        return this.mAttributeList;
    }

    private boolean hasOwnProperty(String string) {
        ArrayList<String> arrayList = this.mAttributeList;
        return arrayList != null && arrayList.contains((Object)string);
    }

    private static double saturate(double d) {
        if (d <= 0.0) {
            return 0.0;
        }
        if (d >= 1.0) {
            d = 1.0;
        }
        return d;
    }

    private boolean setupFillPaint(Paint paint, float f) {
        ReadableArray readableArray = this.fill;
        if (readableArray != null && readableArray.size() > 0) {
            paint.reset();
            paint.setFlags(385);
            paint.setStyle(Paint.Style.FILL);
            this.setupPaint(paint, f, this.fill);
            return true;
        }
        return false;
    }

    private void setupPaint(Paint paint, float f, ReadableArray readableArray) {
        int n = readableArray.getInt(0);
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    return;
                }
                paint.setColor(this.getSvgView().mTintColor);
                return;
            }
            Brush brush = this.getSvgView().getDefinedBrush(readableArray.getString(1));
            if (brush != null) {
                brush.setupPaint(paint, this.mBox, this.mScale, f);
                return;
            }
        } else {
            double d;
            if (readableArray.size() == 2) {
                int n2 = readableArray.getInt(1);
                paint.setColor(Math.round((float)(f * (float)(n2 >>> 24))) << 24 | n2 & 16777215);
                return;
            }
            if (readableArray.size() > 4) {
                double d2 = readableArray.getDouble(4);
                double d3 = f;
                Double.isNaN((double)d3);
                d = 255.0 * (d2 * d3);
            } else {
                d = f * 255.0f;
            }
            paint.setARGB((int)d, (int)(255.0 * readableArray.getDouble(1)), (int)(255.0 * readableArray.getDouble(2)), (int)(255.0 * readableArray.getDouble(3)));
        }
    }

    private boolean setupStrokePaint(Paint paint, float f) {
        ReadableArray readableArray;
        paint.reset();
        double d = this.relativeOnOther(this.strokeWidth);
        if (d != 0.0 && (readableArray = this.stroke) != null) {
            if (readableArray.size() == 0) {
                return false;
            }
            paint.setFlags(385);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(this.strokeLinecap);
            paint.setStrokeJoin(this.strokeLinejoin);
            paint.setStrokeMiter(this.strokeMiterlimit * this.mScale);
            paint.setStrokeWidth((float)d);
            this.setupPaint(paint, f, this.stroke);
            SVGLength[] arrsVGLength = this.strokeDasharray;
            if (arrsVGLength != null) {
                int n = arrsVGLength.length;
                float[] arrf = new float[n];
                for (int i = 0; i < n; ++i) {
                    arrf[i] = (float)this.relativeOnOther(this.strokeDasharray[i]);
                }
                paint.setPathEffect((PathEffect)new DashPathEffect(arrf, this.strokeDashoffset));
            }
            return true;
        }
        return false;
    }

    @Override
    void draw(Canvas canvas, Paint paint, float f) {
        float f2 = f * this.mOpacity;
        if (f2 > 0.01f) {
            boolean bl = this.mPath == null;
            if (bl) {
                this.mPath = this.getPath(canvas, paint);
                this.mPath.setFillType(this.fillRule);
            }
            int n = this.vectorEffect;
            boolean bl2 = false;
            if (n == 1) {
                bl2 = true;
            }
            Path path = this.mPath;
            if (bl2) {
                path = new Path();
                this.mPath.transform(this.mCTM, path);
                canvas.setMatrix(null);
            }
            if (bl || path != this.mPath) {
                this.mBox = new RectF();
                path.computeBounds(this.mBox, true);
            }
            RectF rectF = new RectF(this.mBox);
            this.mCTM.mapRect(rectF);
            this.setClientRect(rectF);
            this.clip(canvas, paint);
            if (this.setupFillPaint(paint, f2 * this.fillOpacity)) {
                if (bl) {
                    this.mFillPath = new Path();
                    paint.getFillPath(path, this.mFillPath);
                }
                canvas.drawPath(path, paint);
            }
            if (this.setupStrokePaint(paint, f2 * this.strokeOpacity)) {
                if (bl) {
                    this.mStrokePath = new Path();
                    paint.getFillPath(path, this.mStrokePath);
                }
                canvas.drawPath(path, paint);
            }
        }
    }

    @Override
    abstract Path getPath(Canvas var1, Paint var2);

    Region getRegion(Path path) {
        RectF rectF = new RectF();
        path.computeBounds(rectF, true);
        Region region = new Region();
        region.setPath(path, new Region((int)Math.floor((double)rectF.left), (int)Math.floor((double)rectF.top), (int)Math.ceil((double)rectF.right), (int)Math.ceil((double)rectF.bottom)));
        return region;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    int hitTest(float[] arrf) {
        Path path;
        if (this.mPath == null || !this.mInvertible) return -1;
        if (!this.mTransformInvertible) {
            return -1;
        }
        float[] arrf2 = new float[2];
        this.mInvMatrix.mapPoints(arrf2, arrf);
        this.mInvTransform.mapPoints(arrf2);
        int n = Math.round((float)arrf2[0]);
        int n2 = Math.round((float)arrf2[1]);
        if (this.mRegion == null && this.mFillPath != null) {
            this.mRegion = this.getRegion(this.mFillPath);
        }
        if (this.mRegion == null && this.mPath != null) {
            this.mRegion = this.getRegion(this.mPath);
        }
        if (this.mStrokeRegion == null && this.mStrokePath != null) {
            this.mStrokeRegion = this.getRegion(this.mStrokePath);
        }
        if (this.mRegion == null || !this.mRegion.contains(n, n2)) {
            if (this.mStrokeRegion == null) return -1;
            if (!this.mStrokeRegion.contains(n, n2)) {
                return -1;
            }
        }
        if ((path = this.getClipPath()) == null) return this.getId();
        if (this.mClipRegionPath != path) {
            this.mClipRegionPath = path;
            this.mClipRegion = this.getRegion(path);
        }
        if (this.mClipRegion.contains(n, n2)) return this.getId();
        return -1;
    }

    void mergeProperties(RenderableView renderableView) {
        ArrayList<String> arrayList = renderableView.getAttributeList();
        if (arrayList != null) {
            if (arrayList.size() == 0) {
                return;
            }
            this.mOriginProperties = new ArrayList();
            ArrayList<String> arrayList2 = this.mPropList;
            ArrayList arrayList3 = arrayList2 == null ? new ArrayList() : new ArrayList(arrayList2);
            this.mAttributeList = arrayList3;
            int n = arrayList.size();
            for (int i = 0; i < n; ++i) {
                try {
                    String string = (String)arrayList.get(i);
                    Field field = this.getClass().getField(string);
                    Object object = field.get((Object)((Object)renderableView));
                    this.mOriginProperties.add(field.get((Object)((Object)this)));
                    if (this.hasOwnProperty(string)) continue;
                    this.mAttributeList.add((Object)string);
                    field.set((Object)((Object)this), object);
                }
                catch (Exception exception) {
                    throw new IllegalStateException((Throwable)exception);
                }
            }
            this.mLastMergedList = arrayList;
        }
    }

    @Override
    void render(Canvas canvas, Paint paint, float f) {
        MaskView maskView = this.mMask != null ? (MaskView)this.getSvgView().getDefinedMask(this.mMask) : null;
        if (maskView != null) {
            Rect rect = canvas.getClipBounds();
            int n = rect.height();
            int n2 = rect.width();
            Bitmap bitmap = Bitmap.createBitmap((int)n2, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
            Bitmap bitmap2 = Bitmap.createBitmap((int)n2, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
            Bitmap bitmap3 = Bitmap.createBitmap((int)n2, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
            Canvas canvas2 = new Canvas(bitmap2);
            Canvas canvas3 = new Canvas(bitmap);
            Canvas canvas4 = new Canvas(bitmap3);
            canvas3.clipRect((float)this.relativeOnWidth(maskView.mX), (float)this.relativeOnWidth(maskView.mY), (float)this.relativeOnWidth(maskView.mW), (float)this.relativeOnWidth(maskView.mH));
            Paint paint2 = new Paint(1);
            maskView.draw(canvas3, paint2, 1.0f);
            int n3 = n2 * n;
            int[] arrn = new int[n3];
            bitmap.getPixels(arrn, 0, n2, 0, 0, n2, n);
            for (int i = 0; i < n3; ++i) {
                int n4 = arrn[i];
                int n5 = 255 & n4 >> 16;
                int n6 = 255 & n4 >> 8;
                int n7 = n4 & 255;
                int n8 = n4 >>> 24;
                Paint paint3 = paint2;
                int n9 = n3;
                double d = n5;
                Double.isNaN((double)d);
                double d2 = d * 0.299;
                double d3 = n6;
                Double.isNaN((double)d3);
                double d4 = d2 + d3 * 0.587;
                double d5 = n7;
                Double.isNaN((double)d5);
                double d6 = RenderableView.saturate((d4 + d5 * 0.144) / 255.0);
                double d7 = n8;
                Double.isNaN((double)d7);
                arrn[i] = (int)(d7 * d6) << 24;
                n3 = n9;
                paint2 = paint3;
            }
            Paint paint4 = paint2;
            bitmap.setPixels(arrn, 0, n2, 0, 0, n2, n);
            this.draw(canvas2, paint, f);
            paint4.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            canvas4.drawBitmap(bitmap2, 0.0f, 0.0f, null);
            canvas4.drawBitmap(bitmap, 0.0f, 0.0f, paint4);
            canvas.drawBitmap(bitmap3, 0.0f, 0.0f, paint);
            return;
        }
        this.draw(canvas, paint, f);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void resetProperties() {
        block4 : {
            ArrayList<String> arrayList = this.mLastMergedList;
            if (arrayList != null && this.mOriginProperties != null) {
                try {
                    break block4;
                }
                catch (Exception exception) {
                    throw new IllegalStateException((Throwable)exception);
                }
            }
            return;
        }
        for (int i = -1 + arrayList.size(); i >= 0; --i) {
            this.getClass().getField((String)this.mLastMergedList.get(i)).set((Object)((Object)this), this.mOriginProperties.get(i));
        }
        this.mLastMergedList = null;
        this.mOriginProperties = null;
        this.mAttributeList = this.mPropList;
    }

    @ReactProp(name="fill")
    public void setFill(@Nullable Dynamic dynamic) {
        if (dynamic != null && !dynamic.isNull()) {
            if (dynamic.getType().equals((Object)ReadableType.Array)) {
                this.fill = dynamic.asArray();
            } else {
                JavaOnlyArray javaOnlyArray = new JavaOnlyArray();
                int n = 0;
                javaOnlyArray.pushInt(0);
                Matcher matcher = regex.matcher((CharSequence)dynamic.asString());
                while (matcher.find()) {
                    double d = Double.parseDouble((String)matcher.group());
                    int n2 = n + 1;
                    if (n < 3) {
                        d /= 255.0;
                    }
                    javaOnlyArray.pushDouble(d);
                    n = n2;
                }
                this.fill = javaOnlyArray;
            }
            this.invalidate();
            return;
        }
        this.fill = null;
        this.invalidate();
    }

    @ReactProp(defaultFloat=1.0f, name="fillOpacity")
    public void setFillOpacity(float f) {
        this.fillOpacity = f;
        this.invalidate();
    }

    @ReactProp(defaultInt=1, name="fillRule")
    public void setFillRule(int n) {
        if (n != 0) {
            if (n != 1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("fillRule ");
                stringBuilder.append(n);
                stringBuilder.append(" unrecognized");
                throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
            }
        } else {
            this.fillRule = Path.FillType.EVEN_ODD;
        }
        this.invalidate();
    }

    @ReactProp(name="propList")
    public void setPropList(@Nullable ReadableArray readableArray) {
        if (readableArray != null) {
            ArrayList arrayList;
            this.mAttributeList = arrayList = new ArrayList();
            this.mPropList = arrayList;
            for (int i = 0; i < readableArray.size(); ++i) {
                this.mPropList.add((Object)readableArray.getString(i));
            }
        }
        this.invalidate();
    }

    @ReactProp(name="stroke")
    public void setStroke(@Nullable Dynamic dynamic) {
        if (dynamic != null && !dynamic.isNull()) {
            if (dynamic.getType().equals((Object)ReadableType.Array)) {
                this.stroke = dynamic.asArray();
            } else {
                JavaOnlyArray javaOnlyArray = new JavaOnlyArray();
                javaOnlyArray.pushInt(0);
                Matcher matcher = regex.matcher((CharSequence)dynamic.asString());
                while (matcher.find()) {
                    javaOnlyArray.pushDouble(Double.parseDouble((String)matcher.group()));
                }
                this.stroke = javaOnlyArray;
            }
            this.invalidate();
            return;
        }
        this.stroke = null;
        this.invalidate();
    }

    @ReactProp(name="strokeDasharray")
    public void setStrokeDasharray(@Nullable ReadableArray readableArray) {
        if (readableArray != null) {
            int n = readableArray.size();
            this.strokeDasharray = new SVGLength[n];
            for (int i = 0; i < n; ++i) {
                this.strokeDasharray[i] = SVGLength.from((Dynamic)readableArray.getDynamic(i));
            }
        } else {
            this.strokeDasharray = null;
        }
        this.invalidate();
    }

    @ReactProp(name="strokeDashoffset")
    public void setStrokeDashoffset(float f) {
        this.strokeDashoffset = f * this.mScale;
        this.invalidate();
    }

    /*
     * Enabled aggressive block sorting
     */
    @ReactProp(defaultInt=1, name="strokeLinecap")
    public void setStrokeLinecap(int n) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("strokeLinecap ");
                    stringBuilder.append(n);
                    stringBuilder.append(" unrecognized");
                    throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
                }
                this.strokeLinecap = Paint.Cap.SQUARE;
            } else {
                this.strokeLinecap = Paint.Cap.ROUND;
            }
        } else {
            this.strokeLinecap = Paint.Cap.BUTT;
        }
        this.invalidate();
    }

    /*
     * Enabled aggressive block sorting
     */
    @ReactProp(defaultInt=1, name="strokeLinejoin")
    public void setStrokeLinejoin(int n) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("strokeLinejoin ");
                    stringBuilder.append(n);
                    stringBuilder.append(" unrecognized");
                    throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
                }
                this.strokeLinejoin = Paint.Join.BEVEL;
            } else {
                this.strokeLinejoin = Paint.Join.ROUND;
            }
        } else {
            this.strokeLinejoin = Paint.Join.MITER;
        }
        this.invalidate();
    }

    @ReactProp(defaultFloat=4.0f, name="strokeMiterlimit")
    public void setStrokeMiterlimit(float f) {
        this.strokeMiterlimit = f;
        this.invalidate();
    }

    @ReactProp(defaultFloat=1.0f, name="strokeOpacity")
    public void setStrokeOpacity(float f) {
        this.strokeOpacity = f;
        this.invalidate();
    }

    @ReactProp(name="strokeWidth")
    public void setStrokeWidth(Dynamic dynamic) {
        this.strokeWidth = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="vectorEffect")
    public void setVectorEffect(int n) {
        this.vectorEffect = n;
        this.invalidate();
    }
}

