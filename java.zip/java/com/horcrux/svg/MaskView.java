/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  com.facebook.common.logging.FLog
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.PropHelper
 *  com.horcrux.svg.SVGLength
 *  java.lang.String
 *  javax.annotation.Nullable
 */
package com.horcrux.svg;

import android.graphics.Matrix;
import com.facebook.common.logging.FLog;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.Brush;
import com.horcrux.svg.GroupView;
import com.horcrux.svg.PropHelper;
import com.horcrux.svg.SVGLength;
import com.horcrux.svg.SvgView;
import com.horcrux.svg.VirtualView;
import javax.annotation.Nullable;

class MaskView
extends GroupView {
    private static final float[] sRawMatrix = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    SVGLength mH;
    private Brush.BrushUnits mMaskContentUnits;
    private Brush.BrushUnits mMaskUnits;
    private Matrix mMatrix = null;
    SVGLength mW;
    SVGLength mX;
    SVGLength mY;

    public MaskView(ReactContext reactContext) {
        super(reactContext);
    }

    @Override
    void saveDefinition() {
        if (this.mName != null) {
            this.getSvgView().defineMask(this, this.mName);
        }
    }

    @ReactProp(name="height")
    public void setHeight(Dynamic dynamic) {
        this.mH = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="maskContentUnits")
    public void setMaskContentUnits(int n) {
        if (n != 0) {
            if (n == 1) {
                this.mMaskContentUnits = Brush.BrushUnits.USER_SPACE_ON_USE;
            }
        } else {
            this.mMaskContentUnits = Brush.BrushUnits.OBJECT_BOUNDING_BOX;
        }
        this.invalidate();
    }

    @ReactProp(name="maskTransform")
    public void setMaskTransform(@Nullable ReadableArray readableArray) {
        if (readableArray != null) {
            int n = PropHelper.toMatrixData((ReadableArray)readableArray, (float[])sRawMatrix, (float)this.mScale);
            if (n == 6) {
                if (this.mMatrix == null) {
                    this.mMatrix = new Matrix();
                }
                this.mMatrix.setValues(sRawMatrix);
            } else if (n != -1) {
                FLog.w((String)"ReactNative", (String)"RNSVG: Transform matrices must be of size 6");
            }
        } else {
            this.mMatrix = null;
        }
        this.invalidate();
    }

    @ReactProp(name="maskUnits")
    public void setMaskUnits(int n) {
        if (n != 0) {
            if (n == 1) {
                this.mMaskUnits = Brush.BrushUnits.USER_SPACE_ON_USE;
            }
        } else {
            this.mMaskUnits = Brush.BrushUnits.OBJECT_BOUNDING_BOX;
        }
        this.invalidate();
    }

    @ReactProp(name="width")
    public void setWidth(Dynamic dynamic) {
        this.mW = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="x")
    public void setX(Dynamic dynamic) {
        this.mX = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="y")
    public void setY(Dynamic dynamic) {
        this.mY = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }
}

