/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$Direction
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.SVGLength
 */
package com.horcrux.svg;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.RenderableView;
import com.horcrux.svg.SVGLength;

class CircleView
extends RenderableView {
    private SVGLength mCx;
    private SVGLength mCy;
    private SVGLength mR;

    public CircleView(ReactContext reactContext) {
        super(reactContext);
    }

    @Override
    Path getPath(Canvas canvas, Paint paint) {
        Path path = new Path();
        double d = this.relativeOnWidth(this.mCx);
        double d2 = this.relativeOnHeight(this.mCy);
        double d3 = this.relativeOnOther(this.mR);
        path.addCircle((float)d, (float)d2, (float)d3, Path.Direction.CW);
        return path;
    }

    @ReactProp(name="cx")
    public void setCx(Dynamic dynamic) {
        this.mCx = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="cy")
    public void setCy(Dynamic dynamic) {
        this.mCy = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="r")
    public void setR(Dynamic dynamic) {
        this.mR = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }
}

