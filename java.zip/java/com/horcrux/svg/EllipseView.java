/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$Direction
 *  android.graphics.RectF
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.SVGLength
 */
package com.horcrux.svg;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.RenderableView;
import com.horcrux.svg.SVGLength;

class EllipseView
extends RenderableView {
    private SVGLength mCx;
    private SVGLength mCy;
    private SVGLength mRx;
    private SVGLength mRy;

    public EllipseView(ReactContext reactContext) {
        super(reactContext);
    }

    @Override
    Path getPath(Canvas canvas, Paint paint) {
        Path path = new Path();
        double d = this.relativeOnWidth(this.mCx);
        double d2 = this.relativeOnHeight(this.mCy);
        double d3 = this.relativeOnWidth(this.mRx);
        double d4 = this.relativeOnHeight(this.mRy);
        path.addOval(new RectF((float)(d - d3), (float)(d2 - d4), (float)(d + d3), (float)(d2 + d4)), Path.Direction.CW);
        return path;
    }

    @ReactProp(name="cx")
    public void setCx(Dynamic dynamic) {
        this.mCx = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="cy")
    public void setCy(Dynamic dynamic) {
        this.mCy = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="rx")
    public void setRx(Dynamic dynamic) {
        this.mRx = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="ry")
    public void setRy(Dynamic dynamic) {
        this.mRy = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }
}

