/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$Direction
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.net.Uri
 *  com.facebook.common.executors.UiThreadImmediateExecutorService
 *  com.facebook.common.logging.FLog
 *  com.facebook.common.references.CloseableReference
 *  com.facebook.datasource.DataSource
 *  com.facebook.datasource.DataSubscriber
 *  com.facebook.drawee.backends.pipeline.Fresco
 *  com.facebook.imagepipeline.core.ImagePipeline
 *  com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber
 *  com.facebook.imagepipeline.image.CloseableBitmap
 *  com.facebook.imagepipeline.image.CloseableImage
 *  com.facebook.imagepipeline.request.ImageRequest
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.facebook.react.views.imagehelper.ImageSource
 *  com.facebook.react.views.imagehelper.ResourceDrawableIdHelper
 *  com.horcrux.svg.SVGLength
 *  com.horcrux.svg.ViewBox
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.Executor
 *  java.util.concurrent.atomic.AtomicBoolean
 *  javax.annotation.Nonnull
 *  javax.annotation.Nullable
 */
package com.horcrux.svg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import com.facebook.common.executors.UiThreadImmediateExecutorService;
import com.facebook.common.logging.FLog;
import com.facebook.common.references.CloseableReference;
import com.facebook.datasource.DataSource;
import com.facebook.datasource.DataSubscriber;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.core.ImagePipeline;
import com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber;
import com.facebook.imagepipeline.image.CloseableBitmap;
import com.facebook.imagepipeline.image.CloseableImage;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.views.imagehelper.ImageSource;
import com.facebook.react.views.imagehelper.ResourceDrawableIdHelper;
import com.horcrux.svg.RenderableView;
import com.horcrux.svg.SVGLength;
import com.horcrux.svg.SvgView;
import com.horcrux.svg.ViewBox;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

class ImageView
extends RenderableView {
    private String mAlign;
    private SVGLength mH;
    private int mImageHeight;
    private int mImageWidth;
    private final AtomicBoolean mLoading = new AtomicBoolean(false);
    private int mMeetOrSlice;
    private SVGLength mW;
    private SVGLength mX;
    private SVGLength mY;
    private String uriString;

    public ImageView(ReactContext reactContext) {
        super(reactContext);
    }

    private void doRender(Canvas canvas, Paint paint, Bitmap bitmap, float f) {
        if (this.mImageWidth == 0 || this.mImageHeight == 0) {
            this.mImageWidth = bitmap.getWidth();
            this.mImageHeight = bitmap.getHeight();
        }
        RectF rectF = this.getRect();
        RectF rectF2 = new RectF(0.0f, 0.0f, (float)this.mImageWidth, (float)this.mImageHeight);
        ViewBox.getTransform((RectF)rectF2, (RectF)rectF, (String)this.mAlign, (int)this.mMeetOrSlice).mapRect(rectF2);
        canvas.clipPath(this.getPath(canvas, paint));
        Path path = this.getClipPath(canvas, paint);
        if (path != null) {
            canvas.clipPath(path);
        }
        Paint paint2 = new Paint();
        paint2.setAlpha((int)(f * 255.0f));
        canvas.drawBitmap(bitmap, null, rectF2, paint2);
        this.mCTM.mapRect(rectF2);
        this.setClientRect(rectF2);
    }

    @Nonnull
    private RectF getRect() {
        double d = this.relativeOnWidth(this.mX);
        double d2 = this.relativeOnHeight(this.mY);
        double d3 = this.relativeOnWidth(this.mW);
        double d4 = this.relativeOnHeight(this.mH);
        if (d3 == 0.0) {
            d3 = (float)this.mImageWidth * this.mScale;
        }
        if (d4 == 0.0) {
            d4 = (float)this.mImageHeight * this.mScale;
        }
        return new RectF((float)d, (float)d2, (float)(d + d3), (float)(d2 + d4));
    }

    private void loadBitmap(ImagePipeline imagePipeline, ImageRequest imageRequest) {
        this.mLoading.set(true);
        imagePipeline.fetchDecodedImage(imageRequest, (Object)this.mContext).subscribe((DataSubscriber)new BaseBitmapDataSubscriber(){

            public void onFailureImpl(DataSource dataSource) {
                ImageView.this.mLoading.set(false);
                FLog.w((String)"ReactNative", (Throwable)dataSource.getFailureCause(), (String)"RNSVG: fetchDecodedImage failed!", (Object[])new Object[0]);
            }

            public void onNewResultImpl(Bitmap bitmap) {
                ImageView.this.mLoading.set(false);
                SvgView svgView = ImageView.this.getSvgView();
                if (svgView != null) {
                    svgView.invalidate();
                }
            }
        }, (Executor)UiThreadImmediateExecutorService.getInstance());
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void tryRenderFromBitmapCache(ImagePipeline imagePipeline, ImageRequest imageRequest, Canvas canvas, Paint paint, float f) {
        DataSource dataSource;
        Throwable throwable3222;
        block18 : {
            Throwable throwable22222;
            CloseableReference closeableReference;
            block17 : {
                Bitmap bitmap;
                block16 : {
                    CloseableImage closeableImage;
                    block15 : {
                        block14 : {
                            dataSource = imagePipeline.fetchImageFromBitmapCache(imageRequest, (Object)this.mContext);
                            closeableReference = (CloseableReference)dataSource.getResult();
                            if (closeableReference != null) break block14;
                            dataSource.close();
                            return;
                        }
                        closeableImage = (CloseableImage)closeableReference.get();
                        boolean bl = closeableImage instanceof CloseableBitmap;
                        if (bl) break block15;
                        CloseableReference.closeSafely((CloseableReference)closeableReference);
                        dataSource.close();
                        return;
                    }
                    bitmap = ((CloseableBitmap)closeableImage).getUnderlyingBitmap();
                    if (bitmap != null) break block16;
                    CloseableReference.closeSafely((CloseableReference)closeableReference);
                    dataSource.close();
                    return;
                }
                this.doRender(canvas, paint, bitmap, f);
                CloseableReference.closeSafely((CloseableReference)closeableReference);
                dataSource.close();
                return;
                {
                    catch (Throwable throwable22222) {
                        break block17;
                    }
                    catch (Exception exception) {}
                    {
                        throw new IllegalStateException((Throwable)exception);
                    }
                }
            }
            try {
                CloseableReference.closeSafely((CloseableReference)closeableReference);
                throw throwable22222;
            }
            catch (Throwable throwable3222) {
                break block18;
            }
            catch (Exception exception) {
                throw new IllegalStateException((Throwable)exception);
            }
        }
        dataSource.close();
        throw throwable3222;
    }

    @Override
    void draw(Canvas canvas, Paint paint, float f) {
        if (!this.mLoading.get()) {
            ImageRequest imageRequest;
            ImagePipeline imagePipeline = Fresco.getImagePipeline();
            if (imagePipeline.isInBitmapMemoryCache(imageRequest = ImageRequest.fromUri((Uri)new ImageSource((Context)this.mContext, this.uriString).getUri()))) {
                this.tryRenderFromBitmapCache(imagePipeline, imageRequest, canvas, paint, f * this.mOpacity);
                return;
            }
            this.loadBitmap(imagePipeline, imageRequest);
        }
    }

    @Override
    Path getPath(Canvas canvas, Paint paint) {
        Path path = new Path();
        path.addRect(this.getRect(), Path.Direction.CW);
        return path;
    }

    @ReactProp(name="align")
    public void setAlign(String string) {
        this.mAlign = string;
        this.invalidate();
    }

    @ReactProp(name="height")
    public void setHeight(Dynamic dynamic) {
        this.mH = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="meetOrSlice")
    public void setMeetOrSlice(int n) {
        this.mMeetOrSlice = n;
        this.invalidate();
    }

    @ReactProp(name="src")
    public void setSrc(@Nullable ReadableMap readableMap) {
        String string;
        if (readableMap != null && (string = (this.uriString = readableMap.getString("uri"))) != null) {
            if (string.isEmpty()) {
                return;
            }
            if (readableMap.hasKey("width") && readableMap.hasKey("height")) {
                this.mImageWidth = readableMap.getInt("width");
                this.mImageHeight = readableMap.getInt("height");
            } else {
                this.mImageWidth = 0;
                this.mImageHeight = 0;
            }
            if (Uri.parse((String)this.uriString).getScheme() == null) {
                ResourceDrawableIdHelper.getInstance().getResourceDrawableUri((Context)this.mContext, this.uriString);
            }
        }
    }

    @ReactProp(name="width")
    public void setWidth(Dynamic dynamic) {
        this.mW = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="x")
    public void setX(Dynamic dynamic) {
        this.mX = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="y")
    public void setY(Dynamic dynamic) {
        this.mY = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

}

