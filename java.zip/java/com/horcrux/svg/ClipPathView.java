/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  com.facebook.common.logging.FLog
 *  com.facebook.react.bridge.ReactContext
 *  java.lang.String
 */
package com.horcrux.svg;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.facebook.common.logging.FLog;
import com.facebook.react.bridge.ReactContext;
import com.horcrux.svg.GroupView;
import com.horcrux.svg.RenderableView;
import com.horcrux.svg.SvgView;
import com.horcrux.svg.VirtualView;

class ClipPathView
extends GroupView {
    public ClipPathView(ReactContext reactContext) {
        super(reactContext);
        this.mClipRule = 1;
    }

    @Override
    void draw(Canvas canvas, Paint paint, float f) {
        FLog.w((String)"ReactNative", (String)"RNSVG: ClipPath can't be drawn, it should be defined as a child component for `Defs` ");
    }

    @Override
    int hitTest(float[] arrf) {
        return -1;
    }

    @Override
    boolean isResponsible() {
        return false;
    }

    @Override
    void mergeProperties(RenderableView renderableView) {
    }

    @Override
    void resetProperties() {
    }

    @Override
    void saveDefinition() {
        this.getSvgView().defineClipPath(this, this.mName);
    }
}

