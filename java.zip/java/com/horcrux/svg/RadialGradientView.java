/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.Rect
 *  com.facebook.common.logging.FLog
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.PropHelper
 *  com.horcrux.svg.SVGLength
 *  java.lang.String
 *  javax.annotation.Nullable
 */
package com.horcrux.svg;

import android.graphics.Matrix;
import android.graphics.Rect;
import com.facebook.common.logging.FLog;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.Brush;
import com.horcrux.svg.DefinitionView;
import com.horcrux.svg.PropHelper;
import com.horcrux.svg.SVGLength;
import com.horcrux.svg.SvgView;
import javax.annotation.Nullable;

class RadialGradientView
extends DefinitionView {
    private static final float[] sRawMatrix = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    private SVGLength mCx;
    private SVGLength mCy;
    private SVGLength mFx;
    private SVGLength mFy;
    private ReadableArray mGradient;
    private Brush.BrushUnits mGradientUnits;
    private Matrix mMatrix = null;
    private SVGLength mRx;
    private SVGLength mRy;

    public RadialGradientView(ReactContext reactContext) {
        super(reactContext);
    }

    @Override
    void saveDefinition() {
        if (this.mName != null) {
            SVGLength[] arrsVGLength = new SVGLength[]{this.mFx, this.mFy, this.mRx, this.mRy, this.mCx, this.mCy};
            Brush brush = new Brush(Brush.BrushType.RADIAL_GRADIENT, arrsVGLength, this.mGradientUnits);
            brush.setGradientColors(this.mGradient);
            Matrix matrix = this.mMatrix;
            if (matrix != null) {
                brush.setGradientTransform(matrix);
            }
            SvgView svgView = this.getSvgView();
            if (this.mGradientUnits == Brush.BrushUnits.USER_SPACE_ON_USE) {
                brush.setUserSpaceBoundingBox(svgView.getCanvasBounds());
            }
            svgView.defineBrush(brush, this.mName);
        }
    }

    @ReactProp(name="cx")
    public void setCx(Dynamic dynamic) {
        this.mCx = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="cy")
    public void setCy(Dynamic dynamic) {
        this.mCy = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="fx")
    public void setFx(Dynamic dynamic) {
        this.mFx = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="fy")
    public void setFy(Dynamic dynamic) {
        this.mFy = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="gradient")
    public void setGradient(ReadableArray readableArray) {
        this.mGradient = readableArray;
        this.invalidate();
    }

    @ReactProp(name="gradientTransform")
    public void setGradientTransform(@Nullable ReadableArray readableArray) {
        if (readableArray != null) {
            int n = PropHelper.toMatrixData((ReadableArray)readableArray, (float[])sRawMatrix, (float)this.mScale);
            if (n == 6) {
                if (this.mMatrix == null) {
                    this.mMatrix = new Matrix();
                }
                this.mMatrix.setValues(sRawMatrix);
            } else if (n != -1) {
                FLog.w((String)"ReactNative", (String)"RNSVG: Transform matrices must be of size 6");
            }
        } else {
            this.mMatrix = null;
        }
        this.invalidate();
    }

    @ReactProp(name="gradientUnits")
    public void setGradientUnits(int n) {
        if (n != 0) {
            if (n == 1) {
                this.mGradientUnits = Brush.BrushUnits.USER_SPACE_ON_USE;
            }
        } else {
            this.mGradientUnits = Brush.BrushUnits.OBJECT_BOUNDING_BOX;
        }
        this.invalidate();
    }

    @ReactProp(name="rx")
    public void setRx(Dynamic dynamic) {
        this.mRx = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="ry")
    public void setRy(Dynamic dynamic) {
        this.mRy = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }
}

