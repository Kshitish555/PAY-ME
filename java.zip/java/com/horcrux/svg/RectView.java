/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$Direction
 *  android.graphics.RectF
 *  android.os.Build
 *  android.os.Build$VERSION
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.SVGLength
 */
package com.horcrux.svg;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Build;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.RenderableView;
import com.horcrux.svg.SVGLength;

class RectView
extends RenderableView {
    private SVGLength mH;
    private SVGLength mRx;
    private SVGLength mRy;
    private SVGLength mW;
    private SVGLength mX;
    private SVGLength mY;

    public RectView(ReactContext reactContext) {
        super(reactContext);
    }

    @Override
    Path getPath(Canvas canvas, Paint paint) {
        double d;
        Path path = new Path();
        double d2 = this.relativeOnWidth(this.mX);
        double d3 = this.relativeOnHeight(this.mY);
        double d4 = this.relativeOnWidth(this.mW);
        double d5 = this.relativeOnHeight(this.mH);
        double d6 = this.relativeOnWidth(this.mRx);
        double d7 = this.relativeOnHeight(this.mRy);
        if (d6 == 0.0 && d7 == 0.0) {
            path.addRect((float)d2, (float)d3, (float)(d2 + d4), (float)(d3 + d5), Path.Direction.CW);
            path.close();
            return path;
        }
        if (d6 == 0.0) {
            d6 = d7;
        } else if (d7 == 0.0) {
            d7 = d6;
        }
        double d8 = d4 / 2.0;
        if (d6 > d8) {
            d6 = d8;
        }
        if (!(d7 > (d = d5 / 2.0))) {
            d = d7;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            path.addRoundRect((float)d2, (float)d3, (float)(d2 + d4), (float)(d3 + d5), (float)d6, (float)d, Path.Direction.CW);
            return path;
        }
        path.addRoundRect(new RectF((float)d2, (float)d3, (float)(d2 + d4), (float)(d3 + d5)), (float)d6, (float)d, Path.Direction.CW);
        return path;
    }

    @ReactProp(name="height")
    public void setHeight(Dynamic dynamic) {
        this.mH = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="rx")
    public void setRx(Dynamic dynamic) {
        this.mRx = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="ry")
    public void setRy(Dynamic dynamic) {
        this.mRy = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="width")
    public void setWidth(Dynamic dynamic) {
        this.mW = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="x")
    public void setX(Dynamic dynamic) {
        this.mX = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }

    @ReactProp(name="y")
    public void setY(Dynamic dynamic) {
        this.mY = SVGLength.from((Dynamic)dynamic);
        this.invalidate();
    }
}

