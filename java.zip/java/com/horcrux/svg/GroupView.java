/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$Op
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Region
 *  android.graphics.Region$Op
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.GlyphContext
 *  java.lang.Math
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  javax.annotation.Nullable
 */
package com.horcrux.svg;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.os.Build;
import android.view.View;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.GlyphContext;
import com.horcrux.svg.MaskView;
import com.horcrux.svg.RenderableView;
import com.horcrux.svg.SvgView;
import com.horcrux.svg.VirtualView;
import javax.annotation.Nullable;

class GroupView
extends RenderableView {
    @Nullable
    ReadableMap mFont;
    private GlyphContext mGlyphContext;

    public GroupView(ReactContext reactContext) {
        super(reactContext);
    }

    private static <T> T requireNonNull(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException();
    }

    @Override
    void draw(Canvas canvas, Paint paint, float f) {
        this.setupGlyphContext(canvas);
        if (f > 0.01f) {
            this.clip(canvas, paint);
            this.drawGroup(canvas, paint, f);
        }
    }

    void drawGroup(Canvas canvas, Paint paint, float f) {
        this.pushGlyphContext();
        SvgView svgView = this.getSvgView();
        RectF rectF = new RectF();
        for (int i = 0; i < this.getChildCount(); ++i) {
            View view = this.getChildAt(i);
            if (view instanceof MaskView) continue;
            if (view instanceof VirtualView) {
                VirtualView virtualView = (VirtualView)view;
                boolean bl = virtualView instanceof RenderableView;
                if (bl) {
                    ((RenderableView)virtualView).mergeProperties(this);
                }
                int n = virtualView.saveAndSetupCanvas(canvas, this.mCTM);
                virtualView.render(canvas, paint, f * this.mOpacity);
                RectF rectF2 = virtualView.getClientRect();
                if (rectF2 != null) {
                    rectF.union(rectF2);
                }
                virtualView.restoreCanvas(canvas, n);
                if (bl) {
                    ((RenderableView)virtualView).resetProperties();
                }
                if (!virtualView.isResponsible()) continue;
                svgView.enableTouchEvents();
                continue;
            }
            if (!(view instanceof SvgView)) continue;
            SvgView svgView2 = (SvgView)view;
            svgView2.drawChildren(canvas);
            if (!svgView2.isResponsible()) continue;
            svgView.enableTouchEvents();
        }
        this.setClientRect(rectF);
        this.popGlyphContext();
    }

    void drawPath(Canvas canvas, Paint paint, float f) {
        super.draw(canvas, paint, f);
    }

    GlyphContext getGlyphContext() {
        return this.mGlyphContext;
    }

    @Override
    Path getPath(Canvas canvas, Paint paint) {
        if (this.mPath != null) {
            return this.mPath;
        }
        this.mPath = new Path();
        for (int i = 0; i < this.getChildCount(); ++i) {
            View view = this.getChildAt(i);
            if (view instanceof MaskView || !(view instanceof VirtualView)) continue;
            VirtualView virtualView = (VirtualView)view;
            Matrix matrix = virtualView.mMatrix;
            this.mPath.addPath(virtualView.getPath(canvas, paint), matrix);
        }
        return this.mPath;
    }

    Path getPath(Canvas canvas, Paint paint, Region.Op op) {
        int n;
        Path path = new Path();
        int n2 = Build.VERSION.SDK_INT;
        if (n2 >= 19) {
            Path.Op op2 = Path.Op.valueOf((String)op.name());
            for (n = 0; n < this.getChildCount(); ++n) {
                View view = this.getChildAt(n);
                if (view instanceof MaskView || !(view instanceof VirtualView)) continue;
                VirtualView virtualView = (VirtualView)view;
                Matrix matrix = virtualView.mMatrix;
                Path path2 = virtualView instanceof GroupView ? ((GroupView)virtualView).getPath(canvas, paint, op) : virtualView.getPath(canvas, paint);
                path2.transform(matrix);
                path.op(path2, op2);
            }
        } else {
            Region region = new Region(canvas.getClipBounds());
            Region region2 = new Region();
            while (n < this.getChildCount()) {
                View view = this.getChildAt(n);
                if (!(view instanceof MaskView) && view instanceof VirtualView) {
                    VirtualView virtualView = (VirtualView)view;
                    Matrix matrix = virtualView.mMatrix;
                    Path path3 = virtualView instanceof GroupView ? ((GroupView)virtualView).getPath(canvas, paint, op) : virtualView.getPath(canvas, paint);
                    if (matrix != null) {
                        path3.transform(matrix);
                    }
                    Region region3 = new Region();
                    region3.setPath(path3, region);
                    region2.op(region3, op);
                }
                ++n;
            }
            path.addPath(region2.getBoundaryPath());
        }
        return path;
    }

    GlyphContext getTextRootGlyphContext() {
        return GroupView.requireNonNull(this.getTextRoot()).getGlyphContext();
    }

    @Override
    int hitTest(float[] arrf) {
        if (this.mInvertible) {
            if (!this.mTransformInvertible) {
                return -1;
            }
            float[] arrf2 = new float[2];
            this.mInvMatrix.mapPoints(arrf2, arrf);
            this.mInvTransform.mapPoints(arrf2);
            int n = Math.round((float)arrf2[0]);
            int n2 = Math.round((float)arrf2[1]);
            Path path = this.getClipPath();
            if (path != null) {
                if (this.mClipRegionPath != path) {
                    this.mClipRegionPath = path;
                    this.mClipRegion = this.getRegion(path);
                }
                if (!this.mClipRegion.contains(n, n2)) {
                    return -1;
                }
            }
            for (int i = this.getChildCount() - 1; i >= 0; --i) {
                int n3;
                View view = this.getChildAt(i);
                if (view instanceof VirtualView) {
                    VirtualView virtualView;
                    int n4;
                    if (view instanceof MaskView || (n4 = (virtualView = (VirtualView)view).hitTest(arrf2)) == -1) continue;
                    if (!virtualView.isResponsible()) {
                        if (n4 != view.getId()) {
                            return n4;
                        }
                        n4 = this.getId();
                    }
                    return n4;
                }
                if (!(view instanceof SvgView) || (n3 = ((SvgView)view).reactTagForTouch(arrf2[0], arrf2[1])) == view.getId()) continue;
                return n3;
            }
        }
        return -1;
    }

    void popGlyphContext() {
        this.getTextRootGlyphContext().popContext();
    }

    void pushGlyphContext() {
        this.getTextRootGlyphContext().pushContext(this, this.mFont);
    }

    @Override
    void resetProperties() {
        for (int i = 0; i < this.getChildCount(); ++i) {
            View view = this.getChildAt(i);
            if (!(view instanceof RenderableView)) continue;
            ((RenderableView)view).resetProperties();
        }
    }

    @Override
    void saveDefinition() {
        if (this.mName != null) {
            this.getSvgView().defineTemplate(this, this.mName);
        }
        for (int i = 0; i < this.getChildCount(); ++i) {
            View view = this.getChildAt(i);
            if (!(view instanceof VirtualView)) continue;
            ((VirtualView)view).saveDefinition();
        }
    }

    @ReactProp(name="font")
    public void setFont(@Nullable ReadableMap readableMap) {
        this.mFont = readableMap;
        this.invalidate();
    }

    void setupGlyphContext(Canvas canvas) {
        RectF rectF = new RectF(canvas.getClipBounds());
        if (this.mMatrix != null) {
            this.mMatrix.mapRect(rectF);
        }
        if (this.mTransform != null) {
            this.mTransform.mapRect(rectF);
        }
        this.mGlyphContext = new GlyphContext(this.mScale, rectF.width(), rectF.height());
    }
}

