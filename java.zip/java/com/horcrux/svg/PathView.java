/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Path
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.horcrux.svg.PathParser
 *  java.lang.String
 */
package com.horcrux.svg;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.horcrux.svg.PathParser;
import com.horcrux.svg.RenderableView;

class PathView
extends RenderableView {
    private Path mPath;

    public PathView(ReactContext reactContext) {
        super(reactContext);
        PathParser.mScale = this.mScale;
    }

    @Override
    Path getPath(Canvas canvas, Paint paint) {
        return this.mPath;
    }

    @ReactProp(name="d")
    public void setD(String string) {
        this.mPath = PathParser.parse((String)string);
        this.invalidate();
    }
}

