/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.ReactPackage
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.uimanager.ViewManager
 *  com.reactcommunity.rnlocalize.RNLocalizeModule
 *  java.lang.Object
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 */
package com.reactcommunity.rnlocalize;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import com.reactcommunity.rnlocalize.RNLocalizeModule;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RNLocalizePackage
implements ReactPackage {
    public List<NativeModule> createNativeModules(ReactApplicationContext reactApplicationContext) {
        Object[] arrobject = new NativeModule[]{new RNLocalizeModule(reactApplicationContext)};
        return Arrays.asList((Object[])arrobject);
    }

    public List<ViewManager> createViewManagers(ReactApplicationContext reactApplicationContext) {
        return Collections.emptyList();
    }
}

