/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.ReactPackage
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.uimanager.ViewManager
 *  com.swmansion.gesturehandler.react.RNGestureHandlerButtonViewManager
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule
 *  com.swmansion.gesturehandler.react.RNGestureHandlerRootViewManager
 *  java.lang.Object
 *  java.util.Arrays
 *  java.util.List
 */
package com.swmansion.gesturehandler.react;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import com.swmansion.gesturehandler.react.RNGestureHandlerButtonViewManager;
import com.swmansion.gesturehandler.react.RNGestureHandlerModule;
import com.swmansion.gesturehandler.react.RNGestureHandlerRootViewManager;
import java.util.Arrays;
import java.util.List;

public class RNGestureHandlerPackage
implements ReactPackage {
    public List<NativeModule> createNativeModules(ReactApplicationContext reactApplicationContext) {
        Object[] arrobject = new NativeModule[]{new RNGestureHandlerModule(reactApplicationContext)};
        return Arrays.asList((Object[])arrobject);
    }

    public List<ViewManager> createViewManagers(ReactApplicationContext reactApplicationContext) {
        Object[] arrobject = new ViewManager[]{new RNGestureHandlerRootViewManager(), new RNGestureHandlerButtonViewManager()};
        return Arrays.asList((Object[])arrobject);
    }
}

