/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.view.ViewGroup
 *  com.facebook.react.uimanager.PointerEvents
 *  com.facebook.react.uimanager.ReactPointerEventsView
 *  com.facebook.react.views.view.ReactViewGroup
 *  com.swmansion.gesturehandler.PointerEventsConfig
 *  com.swmansion.gesturehandler.ViewConfigurationHelper
 *  com.swmansion.gesturehandler.react.RNViewConfigurationHelper$1
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.gesturehandler.react;

import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import com.facebook.react.uimanager.PointerEvents;
import com.facebook.react.uimanager.ReactPointerEventsView;
import com.facebook.react.views.view.ReactViewGroup;
import com.swmansion.gesturehandler.PointerEventsConfig;
import com.swmansion.gesturehandler.ViewConfigurationHelper;
import com.swmansion.gesturehandler.react.RNViewConfigurationHelper;

public class RNViewConfigurationHelper
implements ViewConfigurationHelper {
    public View getChildInDrawingOrderAtIndex(ViewGroup viewGroup, int n) {
        if (viewGroup instanceof ReactViewGroup) {
            return viewGroup.getChildAt(((ReactViewGroup)viewGroup).getZIndexMappedChildIndex(n));
        }
        return viewGroup.getChildAt(n);
    }

    public PointerEventsConfig getPointerEventsConfigForView(View view) {
        int n;
        PointerEvents pointerEvents = view instanceof ReactPointerEventsView ? ((ReactPointerEventsView)view).getPointerEvents() : PointerEvents.AUTO;
        if (!view.isEnabled()) {
            if (pointerEvents == PointerEvents.AUTO) {
                return PointerEventsConfig.BOX_NONE;
            }
            if (pointerEvents == PointerEvents.BOX_ONLY) {
                return PointerEventsConfig.NONE;
            }
        }
        if ((n = 1.$SwitchMap$com$facebook$react$uimanager$PointerEvents[pointerEvents.ordinal()]) != 1) {
            if (n != 2) {
                if (n != 3) {
                    return PointerEventsConfig.AUTO;
                }
                return PointerEventsConfig.NONE;
            }
            return PointerEventsConfig.BOX_NONE;
        }
        return PointerEventsConfig.BOX_ONLY;
    }

    public boolean isViewClippingChildren(ViewGroup viewGroup) {
        if (Build.VERSION.SDK_INT >= 18 && !viewGroup.getClipChildren()) {
            if (viewGroup instanceof ReactViewGroup) {
                return "hidden".equals((Object)((ReactViewGroup)viewGroup).getOverflow());
            }
            return false;
        }
        return true;
    }
}

