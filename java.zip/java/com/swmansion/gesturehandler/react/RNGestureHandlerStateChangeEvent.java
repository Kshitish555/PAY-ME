/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  androidx.core.util.Pools
 *  androidx.core.util.Pools$SynchronizedPool
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.uimanager.events.Event
 *  com.facebook.react.uimanager.events.RCTEventEmitter
 *  com.swmansion.gesturehandler.GestureHandler
 *  com.swmansion.gesturehandler.react.RNGestureHandlerEventDataExtractor
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.gesturehandler.react;

import android.view.View;
import androidx.core.util.Pools;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.uimanager.events.Event;
import com.facebook.react.uimanager.events.RCTEventEmitter;
import com.swmansion.gesturehandler.GestureHandler;
import com.swmansion.gesturehandler.react.RNGestureHandlerEventDataExtractor;

public class RNGestureHandlerStateChangeEvent
extends Event<RNGestureHandlerStateChangeEvent> {
    private static final Pools.SynchronizedPool<RNGestureHandlerStateChangeEvent> EVENTS_POOL = new Pools.SynchronizedPool(7);
    public static final String EVENT_NAME = "onGestureHandlerStateChange";
    private static final int TOUCH_EVENTS_POOL_SIZE = 7;
    private WritableMap mExtraData;

    private RNGestureHandlerStateChangeEvent() {
    }

    private void init(GestureHandler gestureHandler, int n, int n2, RNGestureHandlerEventDataExtractor rNGestureHandlerEventDataExtractor) {
        super.init(gestureHandler.getView().getId());
        this.mExtraData = Arguments.createMap();
        if (rNGestureHandlerEventDataExtractor != null) {
            rNGestureHandlerEventDataExtractor.extractEventData(gestureHandler, this.mExtraData);
        }
        this.mExtraData.putInt("handlerTag", gestureHandler.getTag());
        this.mExtraData.putInt("state", n);
        this.mExtraData.putInt("oldState", n2);
    }

    public static RNGestureHandlerStateChangeEvent obtain(GestureHandler gestureHandler, int n, int n2, RNGestureHandlerEventDataExtractor rNGestureHandlerEventDataExtractor) {
        RNGestureHandlerStateChangeEvent rNGestureHandlerStateChangeEvent = (RNGestureHandlerStateChangeEvent)((Object)EVENTS_POOL.acquire());
        if (rNGestureHandlerStateChangeEvent == null) {
            rNGestureHandlerStateChangeEvent = new RNGestureHandlerStateChangeEvent();
        }
        rNGestureHandlerStateChangeEvent.init(gestureHandler, n, n2, rNGestureHandlerEventDataExtractor);
        return rNGestureHandlerStateChangeEvent;
    }

    public boolean canCoalesce() {
        return false;
    }

    public void dispatch(RCTEventEmitter rCTEventEmitter) {
        rCTEventEmitter.receiveEvent(this.getViewTag(), EVENT_NAME, this.mExtraData);
    }

    public short getCoalescingKey() {
        return 0;
    }

    public String getEventName() {
        return EVENT_NAME;
    }

    public void onDispose() {
        this.mExtraData = null;
        EVENTS_POOL.release((Object)this);
    }
}

