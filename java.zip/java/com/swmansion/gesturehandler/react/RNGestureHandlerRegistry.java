/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 *  android.view.View
 *  com.swmansion.gesturehandler.GestureHandler
 *  com.swmansion.gesturehandler.GestureHandlerRegistry
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 */
package com.swmansion.gesturehandler.react;

import android.util.SparseArray;
import android.view.View;
import com.swmansion.gesturehandler.GestureHandler;
import com.swmansion.gesturehandler.GestureHandlerRegistry;
import java.util.ArrayList;

public class RNGestureHandlerRegistry
implements GestureHandlerRegistry {
    private final SparseArray<Integer> mAttachedTo = new SparseArray();
    private final SparseArray<GestureHandler> mHandlers = new SparseArray();
    private final SparseArray<ArrayList<GestureHandler>> mHandlersForView = new SparseArray();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void detachHandler(GestureHandler gestureHandler) {
        RNGestureHandlerRegistry rNGestureHandlerRegistry = this;
        synchronized (rNGestureHandlerRegistry) {
            Integer n = (Integer)this.mAttachedTo.get(gestureHandler.getTag());
            if (n != null) {
                this.mAttachedTo.remove(gestureHandler.getTag());
                ArrayList arrayList = (ArrayList)this.mHandlersForView.get(n.intValue());
                if (arrayList != null) {
                    arrayList.remove((Object)gestureHandler);
                    if (arrayList.size() == 0) {
                        this.mHandlersForView.remove(n.intValue());
                    }
                }
            }
            if (gestureHandler.getView() != null) {
                gestureHandler.cancel();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void registerHandlerForViewWithTag(int n, GestureHandler gestureHandler) {
        RNGestureHandlerRegistry rNGestureHandlerRegistry = this;
        synchronized (rNGestureHandlerRegistry) {
            if (this.mAttachedTo.get(gestureHandler.getTag()) != null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Handler ");
                stringBuilder.append((Object)gestureHandler);
                stringBuilder.append(" already attached");
                throw new IllegalStateException(stringBuilder.toString());
            }
            this.mAttachedTo.put(gestureHandler.getTag(), (Object)n);
            ArrayList arrayList = (ArrayList)this.mHandlersForView.get(n);
            if (arrayList == null) {
                ArrayList arrayList2 = new ArrayList(1);
                arrayList2.add((Object)gestureHandler);
                this.mHandlersForView.put(n, (Object)arrayList2);
            } else {
                arrayList.add((Object)gestureHandler);
            }
            return;
        }
    }

    public boolean attachHandlerToView(int n, int n2) {
        RNGestureHandlerRegistry rNGestureHandlerRegistry = this;
        synchronized (rNGestureHandlerRegistry) {
            block4 : {
                GestureHandler gestureHandler = (GestureHandler)this.mHandlers.get(n);
                if (gestureHandler == null) break block4;
                this.detachHandler(gestureHandler);
                this.registerHandlerForViewWithTag(n2, gestureHandler);
                return true;
            }
            return false;
        }
    }

    public void dropAllHandlers() {
        RNGestureHandlerRegistry rNGestureHandlerRegistry = this;
        synchronized (rNGestureHandlerRegistry) {
            this.mHandlers.clear();
            this.mAttachedTo.clear();
            this.mHandlersForView.clear();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void dropHandler(int n) {
        RNGestureHandlerRegistry rNGestureHandlerRegistry = this;
        synchronized (rNGestureHandlerRegistry) {
            GestureHandler gestureHandler = (GestureHandler)this.mHandlers.get(n);
            if (gestureHandler != null) {
                this.detachHandler(gestureHandler);
                this.mHandlers.remove(n);
            }
            return;
        }
    }

    public GestureHandler getHandler(int n) {
        RNGestureHandlerRegistry rNGestureHandlerRegistry = this;
        synchronized (rNGestureHandlerRegistry) {
            GestureHandler gestureHandler = (GestureHandler)this.mHandlers.get(n);
            return gestureHandler;
        }
    }

    public ArrayList<GestureHandler> getHandlersForView(View view) {
        RNGestureHandlerRegistry rNGestureHandlerRegistry = this;
        synchronized (rNGestureHandlerRegistry) {
            ArrayList<GestureHandler> arrayList = this.getHandlersForViewWithTag(view.getId());
            return arrayList;
        }
    }

    public ArrayList<GestureHandler> getHandlersForViewWithTag(int n) {
        RNGestureHandlerRegistry rNGestureHandlerRegistry = this;
        synchronized (rNGestureHandlerRegistry) {
            ArrayList arrayList = (ArrayList)this.mHandlersForView.get(n);
            return arrayList;
        }
    }

    public void registerHandler(GestureHandler gestureHandler) {
        RNGestureHandlerRegistry rNGestureHandlerRegistry = this;
        synchronized (rNGestureHandlerRegistry) {
            this.mHandlers.put(gestureHandler.getTag(), (Object)gestureHandler);
            return;
        }
    }
}

