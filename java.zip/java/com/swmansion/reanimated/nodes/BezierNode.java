/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.nodes.BezierNode$CubicBezierInterpolator
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.nodes.BezierNode;
import com.swmansion.reanimated.nodes.Node;

/*
 * Exception performing whole class analysis.
 */
public class BezierNode
extends Node {
    private final int mInputID;
    private final CubicBezierInterpolator mInterpolator;

    public BezierNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mInputID = readableMap.getInt("input");
        this.mInterpolator = new /* Unavailable Anonymous Inner Class!! */;
    }

    protected Double evaluate() {
        Double d = (Double)this.mNodesManager.getNodeValue(this.mInputID);
        return this.mInterpolator.getInterpolation(d.floatValue());
    }
}

