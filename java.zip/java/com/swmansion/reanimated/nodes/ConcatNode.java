/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.Utils
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.Utils;
import com.swmansion.reanimated.nodes.Node;

public class ConcatNode
extends Node {
    private final int[] mInputIDs;

    public ConcatNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mInputIDs = Utils.processIntArray((ReadableArray)readableMap.getArray("input"));
    }

    protected String evaluate() {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < this.mInputIDs.length; ++i) {
            stringBuilder.append(this.mNodesManager.findNodeById(this.mInputIDs[i], Node.class).value());
        }
        return stringBuilder.toString();
    }
}

