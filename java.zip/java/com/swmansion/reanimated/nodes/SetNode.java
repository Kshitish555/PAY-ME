/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.nodes.Node
 *  com.swmansion.reanimated.nodes.ValueNode
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.nodes.Node;
import com.swmansion.reanimated.nodes.ValueNode;

public class SetNode
extends Node {
    private int mValueNodeID;
    private int mWhatNodeID;

    public SetNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mWhatNodeID = readableMap.getInt("what");
        this.mValueNodeID = readableMap.getInt("value");
    }

    protected Object evaluate() {
        Object object = this.mNodesManager.getNodeValue(this.mValueNodeID);
        this.mNodesManager.findNodeById(this.mWhatNodeID, ValueNode.class).setValue(object);
        return object;
    }
}

