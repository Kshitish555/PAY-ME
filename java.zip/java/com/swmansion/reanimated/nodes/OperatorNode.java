/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.JSApplicationIllegalArgumentException
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.Utils
 *  com.swmansion.reanimated.nodes.Node
 *  com.swmansion.reanimated.nodes.OperatorNode$1
 *  com.swmansion.reanimated.nodes.OperatorNode$10
 *  com.swmansion.reanimated.nodes.OperatorNode$11
 *  com.swmansion.reanimated.nodes.OperatorNode$12
 *  com.swmansion.reanimated.nodes.OperatorNode$13
 *  com.swmansion.reanimated.nodes.OperatorNode$14
 *  com.swmansion.reanimated.nodes.OperatorNode$15
 *  com.swmansion.reanimated.nodes.OperatorNode$16
 *  com.swmansion.reanimated.nodes.OperatorNode$2
 *  com.swmansion.reanimated.nodes.OperatorNode$21
 *  com.swmansion.reanimated.nodes.OperatorNode$22
 *  com.swmansion.reanimated.nodes.OperatorNode$23
 *  com.swmansion.reanimated.nodes.OperatorNode$24
 *  com.swmansion.reanimated.nodes.OperatorNode$25
 *  com.swmansion.reanimated.nodes.OperatorNode$26
 *  com.swmansion.reanimated.nodes.OperatorNode$3
 *  com.swmansion.reanimated.nodes.OperatorNode$4
 *  com.swmansion.reanimated.nodes.OperatorNode$5
 *  com.swmansion.reanimated.nodes.OperatorNode$6
 *  com.swmansion.reanimated.nodes.OperatorNode$7
 *  com.swmansion.reanimated.nodes.OperatorNode$8
 *  com.swmansion.reanimated.nodes.OperatorNode$9
 *  com.swmansion.reanimated.nodes.OperatorNode$Operator
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.JSApplicationIllegalArgumentException;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.Utils;
import com.swmansion.reanimated.nodes.Node;
import com.swmansion.reanimated.nodes.OperatorNode;

public class OperatorNode
extends Node {
    private static final Operator ACOS;
    private static final Operator ADD;
    private static final Operator AND;
    private static final Operator ASIN;
    private static final Operator ATAN;
    private static final Operator COS;
    private static final Operator DEFINED;
    private static final Operator DIVIDE;
    private static final Operator EQ;
    private static final Operator EXP;
    private static final Operator GREATER_OR_EQ;
    private static final Operator GREATER_THAN;
    private static final Operator LESS_OR_EQ;
    private static final Operator LESS_THAN;
    private static final Operator LOG;
    private static final Operator MODULO;
    private static final Operator MULTIPLY;
    private static final Operator NEQ;
    private static final Operator NOT;
    private static final Operator OR;
    private static final Operator POW;
    private static final Operator ROUND;
    private static final Operator SIN;
    private static final Operator SQRT;
    private static final Operator SUB;
    private static final Operator TAN;
    private final int[] mInputIDs;
    private final Node[] mInputNodes;
    private final Operator mOperator;

    static {
        ADD = new 1();
        SUB = new 2();
        MULTIPLY = new 3();
        DIVIDE = new 4();
        POW = new 5();
        MODULO = new 6();
        SQRT = new 7();
        LOG = new 8();
        SIN = new 9();
        COS = new 10();
        TAN = new 11();
        ACOS = new 12();
        ASIN = new 13();
        ATAN = new 14();
        EXP = new 15();
        ROUND = new 16();
        AND = new Operator(){

            public double evaluate(Node[] arrnode) {
                boolean bl = OperatorNode.truthy(arrnode[0].value());
                for (int i = 1; i < arrnode.length && bl; ++i) {
                    bl = bl && OperatorNode.truthy(arrnode[i].value());
                }
                if (bl) {
                    return 1.0;
                }
                return 0.0;
            }
        };
        OR = new Operator(){

            public double evaluate(Node[] arrnode) {
                boolean bl = OperatorNode.truthy(arrnode[0].value());
                for (int i = 1; i < arrnode.length && !bl; ++i) {
                    if (!bl && !OperatorNode.truthy(arrnode[i].value())) {
                        bl = false;
                        continue;
                    }
                    bl = true;
                }
                if (bl) {
                    return 1.0;
                }
                return 0.0;
            }
        };
        NOT = new Operator(){

            public double evaluate(Node[] arrnode) {
                if (OperatorNode.truthy(arrnode[0].value())) {
                    return 0.0;
                }
                return 1.0;
            }
        };
        DEFINED = new Operator(){

            public double evaluate(Node[] arrnode) {
                Object object = arrnode[0].value();
                if (!(object == null || object instanceof Double && ((Double)object).isNaN())) {
                    return 1.0;
                }
                return 0.0;
            }
        };
        LESS_THAN = new 21();
        EQ = new 22();
        GREATER_THAN = new 23();
        LESS_OR_EQ = new 24();
        GREATER_OR_EQ = new 25();
        NEQ = new 26();
    }

    public OperatorNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mInputIDs = Utils.processIntArray((ReadableArray)readableMap.getArray("input"));
        this.mInputNodes = new Node[this.mInputIDs.length];
        String string = readableMap.getString("op");
        if ("add".equals((Object)string)) {
            this.mOperator = ADD;
            return;
        }
        if ("sub".equals((Object)string)) {
            this.mOperator = SUB;
            return;
        }
        if ("multiply".equals((Object)string)) {
            this.mOperator = MULTIPLY;
            return;
        }
        if ("divide".equals((Object)string)) {
            this.mOperator = DIVIDE;
            return;
        }
        if ("pow".equals((Object)string)) {
            this.mOperator = POW;
            return;
        }
        if ("modulo".equals((Object)string)) {
            this.mOperator = MODULO;
            return;
        }
        if ("sqrt".equals((Object)string)) {
            this.mOperator = SQRT;
            return;
        }
        if ("log".equals((Object)string)) {
            this.mOperator = LOG;
            return;
        }
        if ("sin".equals((Object)string)) {
            this.mOperator = SIN;
            return;
        }
        if ("cos".equals((Object)string)) {
            this.mOperator = COS;
            return;
        }
        if ("tan".equals((Object)string)) {
            this.mOperator = TAN;
            return;
        }
        if ("acos".equals((Object)string)) {
            this.mOperator = ACOS;
            return;
        }
        if ("asin".equals((Object)string)) {
            this.mOperator = ASIN;
            return;
        }
        if ("atan".equals((Object)string)) {
            this.mOperator = ATAN;
            return;
        }
        if ("exp".equals((Object)string)) {
            this.mOperator = EXP;
            return;
        }
        if ("round".equals((Object)string)) {
            this.mOperator = ROUND;
            return;
        }
        if ("and".equals((Object)string)) {
            this.mOperator = AND;
            return;
        }
        if ("or".equals((Object)string)) {
            this.mOperator = OR;
            return;
        }
        if ("not".equals((Object)string)) {
            this.mOperator = NOT;
            return;
        }
        if ("defined".equals((Object)string)) {
            this.mOperator = DEFINED;
            return;
        }
        if ("lessThan".equals((Object)string)) {
            this.mOperator = LESS_THAN;
            return;
        }
        if ("eq".equals((Object)string)) {
            this.mOperator = EQ;
            return;
        }
        if ("greaterThan".equals((Object)string)) {
            this.mOperator = GREATER_THAN;
            return;
        }
        if ("lessOrEq".equals((Object)string)) {
            this.mOperator = LESS_OR_EQ;
            return;
        }
        if ("greaterOrEq".equals((Object)string)) {
            this.mOperator = GREATER_OR_EQ;
            return;
        }
        if ("neq".equals((Object)string)) {
            this.mOperator = NEQ;
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unrecognized operator ");
        stringBuilder.append(string);
        throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
    }

    private static boolean truthy(Object object) {
        return object != null && !object.equals((Object)0.0);
    }

    protected Object evaluate() {
        for (int i = 0; i < this.mInputIDs.length; ++i) {
            this.mInputNodes[i] = this.mNodesManager.findNodeById(this.mInputIDs[i], Node.class);
        }
        return this.mOperator.evaluate(this.mInputNodes);
    }

    private static abstract class CompOperator
    implements Operator {
        private CompOperator() {
        }

        public abstract boolean eval(Double var1, Double var2);

        public double evaluate(Node[] arrnode) {
            if (this.eval((Double)arrnode[0].value(), (Double)arrnode[1].value())) {
                return 1.0;
            }
            return 0.0;
        }
    }

    private static abstract class ReduceOperator
    implements Operator {
        private ReduceOperator() {
        }

        public double evaluate(Node[] arrnode) {
            double d = arrnode[0].doubleValue();
            for (int i = 1; i < arrnode.length; ++i) {
                d = this.reduce(d, arrnode[i].doubleValue());
            }
            return d;
        }

        public abstract double reduce(Double var1, Double var2);
    }

    private static abstract class SingleOperator
    implements Operator {
        private SingleOperator() {
        }

        public abstract double eval(Double var1);

        public double evaluate(Node[] arrnode) {
            return this.eval((Double)arrnode[0].value());
        }
    }

}

