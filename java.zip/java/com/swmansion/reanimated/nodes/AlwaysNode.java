/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.nodes.FinalNode
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.nodes.FinalNode;
import com.swmansion.reanimated.nodes.Node;

public class AlwaysNode
extends Node
implements FinalNode {
    private int mNodeToBeEvaluated;

    public AlwaysNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mNodeToBeEvaluated = readableMap.getInt("what");
    }

    protected Double evaluate() {
        this.mNodesManager.findNodeById(this.mNodeToBeEvaluated, Node.class).value();
        return ZERO;
    }

    public void update() {
        this.value();
    }
}

