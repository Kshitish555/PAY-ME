/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.NodesManager$OnAnimationFrame
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Double
 *  java.lang.Object
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.nodes.Node;

public class ClockNode
extends Node
implements NodesManager.OnAnimationFrame {
    public boolean isRunning;

    public ClockNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
    }

    protected Double evaluate() {
        return this.mNodesManager.currentFrameTimeMs;
    }

    public void onAnimationFrame() {
        if (this.isRunning) {
            this.markUpdated();
            this.mNodesManager.postOnAnimation(this);
        }
    }

    public void start() {
        if (this.isRunning) {
            return;
        }
        this.isRunning = true;
        this.mNodesManager.postOnAnimation(this);
    }

    public void stop() {
        this.isRunning = false;
    }
}

