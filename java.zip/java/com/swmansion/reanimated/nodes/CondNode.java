/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Double
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.nodes.Node;

public class CondNode
extends Node {
    private final int mCondID;
    private final int mElseBlockID;
    private final int mIfBlockID;

    public CondNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mCondID = readableMap.getInt("cond");
        boolean bl = readableMap.hasKey("ifBlock");
        int n2 = -1;
        int n3 = bl ? readableMap.getInt("ifBlock") : -1;
        this.mIfBlockID = n3;
        if (readableMap.hasKey("elseBlock")) {
            n2 = readableMap.getInt("elseBlock");
        }
        this.mElseBlockID = n2;
    }

    protected Object evaluate() {
        Object object = this.mNodesManager.getNodeValue(this.mCondID);
        if (object instanceof Number && ((Number)object).doubleValue() != 0.0) {
            if (this.mIfBlockID != -1) {
                return this.mNodesManager.getNodeValue(this.mIfBlockID);
            }
            return ZERO;
        }
        if (this.mElseBlockID != -1) {
            return this.mNodesManager.getNodeValue(this.mElseBlockID);
        }
        return ZERO;
    }
}

