/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.JavaOnlyMap
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.ReadableMapKeySetIterator
 *  com.facebook.react.bridge.ReadableType
 *  com.facebook.react.bridge.WritableArray
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.uimanager.ReactStylesDiffMap
 *  com.facebook.react.uimanager.UIImplementation
 *  com.swmansion.reanimated.Utils
 *  com.swmansion.reanimated.nodes.FinalNode
 *  com.swmansion.reanimated.nodes.Node
 *  com.swmansion.reanimated.nodes.PropsNode$1
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.JavaOnlyMap;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableMapKeySetIterator;
import com.facebook.react.bridge.ReadableType;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.uimanager.ReactStylesDiffMap;
import com.facebook.react.uimanager.UIImplementation;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.Utils;
import com.swmansion.reanimated.nodes.FinalNode;
import com.swmansion.reanimated.nodes.Node;
import com.swmansion.reanimated.nodes.PropsNode;
import com.swmansion.reanimated.nodes.StyleNode;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class PropsNode
extends Node
implements FinalNode {
    private int mConnectedViewTag = -1;
    private final ReactStylesDiffMap mDiffMap;
    private final Map<String, Integer> mMapping;
    private final JavaOnlyMap mPropMap;
    private final UIImplementation mUIImplementation;

    public PropsNode(int n, ReadableMap readableMap, NodesManager nodesManager, UIImplementation uIImplementation) {
        super(n, readableMap, nodesManager);
        this.mMapping = Utils.processMapping((ReadableMap)readableMap.getMap("props"));
        this.mUIImplementation = uIImplementation;
        this.mPropMap = new JavaOnlyMap();
        this.mDiffMap = new ReactStylesDiffMap((ReadableMap)this.mPropMap);
    }

    public void connectToView(int n) {
        this.mConnectedViewTag = n;
        this.dangerouslyRescheduleEvaluate();
    }

    public void disconnectFromView(int n) {
        this.mConnectedViewTag = -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected Double evaluate() {
        WritableMap writableMap = Arguments.createMap();
        WritableMap writableMap2 = Arguments.createMap();
        Iterator iterator = this.mMapping.entrySet().iterator();
        boolean bl = false;
        boolean bl2 = false;
        boolean bl3 = false;
        while (iterator.hasNext()) {
            WritableMap writableMap3;
            ReadableMapKeySetIterator readableMapKeySetIterator;
            Map.Entry entry = (Map.Entry)iterator.next();
            Node node = this.mNodesManager.findNodeById((Integer)entry.getValue(), Node.class);
            if (node instanceof StyleNode) {
                writableMap3 = (WritableMap)node.value();
                readableMapKeySetIterator = writableMap3.keySetIterator();
            } else {
                String string = (String)entry.getKey();
                if (this.mNodesManager.uiProps.contains((Object)string)) {
                    this.mPropMap.putDouble(string, node.doubleValue().doubleValue());
                    bl = true;
                    continue;
                }
                writableMap2.putDouble(string, node.doubleValue().doubleValue());
                bl2 = true;
                continue;
            }
            while (readableMapKeySetIterator.hasNextKey()) {
                JavaOnlyMap javaOnlyMap;
                boolean bl4;
                String string = readableMapKeySetIterator.nextKey();
                if (this.mNodesManager.uiProps.contains((Object)string)) {
                    javaOnlyMap = this.mPropMap;
                    bl4 = true;
                } else if (this.mNodesManager.nativeProps.contains((Object)string)) {
                    bl4 = bl;
                    bl2 = true;
                    javaOnlyMap = writableMap2;
                } else {
                    bl4 = bl;
                    bl3 = true;
                    javaOnlyMap = writableMap;
                }
                ReadableType readableType = writableMap3.getType(string);
                int n = 1.$SwitchMap$com$facebook$react$bridge$ReadableType[readableType.ordinal()];
                if (n != 1) {
                    if (n != 2) {
                        if (n != 3) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Unexpected type ");
                            stringBuilder.append((Object)readableType);
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                        javaOnlyMap.putArray(string, (ReadableArray)((WritableArray)writableMap3.getArray(string)));
                    } else {
                        javaOnlyMap.putString(string, writableMap3.getString(string));
                    }
                } else {
                    javaOnlyMap.putDouble(string, writableMap3.getDouble(string));
                }
                bl = bl4;
            }
        }
        int n = this.mConnectedViewTag;
        if (n != -1) {
            if (bl) {
                this.mUIImplementation.synchronouslyUpdateViewOnUIThread(n, this.mDiffMap);
            }
            if (bl2) {
                this.mNodesManager.enqueueUpdateViewOnNativeThread(this.mConnectedViewTag, writableMap2);
            }
            if (bl3) {
                WritableMap writableMap4 = Arguments.createMap();
                writableMap4.putInt("viewTag", this.mConnectedViewTag);
                writableMap4.putMap("props", (ReadableMap)writableMap);
                this.mNodesManager.sendEvent("onReanimatedPropsChange", writableMap4);
            }
        }
        return ZERO;
    }

    public void update() {
        if (this.mConnectedViewTag == -1) {
            return;
        }
        this.value();
    }
}

