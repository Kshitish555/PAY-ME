/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.Utils
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.Utils;
import com.swmansion.reanimated.nodes.Node;

public class BlockNode
extends Node {
    private final int[] mBlock;

    public BlockNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mBlock = Utils.processIntArray((ReadableArray)readableMap.getArray("block"));
    }

    protected Object evaluate() {
        Object object = null;
        for (int i = 0; i < this.mBlock.length; ++i) {
            object = this.mNodesManager.findNodeById(this.mBlock[i], Node.class).value();
        }
        return object;
    }
}

