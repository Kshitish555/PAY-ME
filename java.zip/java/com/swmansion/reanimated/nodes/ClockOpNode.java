/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.nodes.ClockNode;
import com.swmansion.reanimated.nodes.Node;

public abstract class ClockOpNode
extends Node {
    private int clockID;

    public ClockOpNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.clockID = readableMap.getInt("clock");
    }

    protected abstract Double eval(ClockNode var1);

    protected Double evaluate() {
        return this.eval(this.mNodesManager.findNodeById(this.clockID, ClockNode.class));
    }
}

