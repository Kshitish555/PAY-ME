/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.JavaOnlyArray
 *  com.facebook.react.bridge.JavaOnlyMap
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.ReadableType
 *  com.facebook.react.bridge.WritableArray
 *  com.swmansion.reanimated.nodes.Node
 *  com.swmansion.reanimated.nodes.TransformNode$1
 *  com.swmansion.reanimated.nodes.TransformNode$TransformConfig
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.JavaOnlyArray;
import com.facebook.react.bridge.JavaOnlyMap;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableType;
import com.facebook.react.bridge.WritableArray;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.nodes.Node;
import com.swmansion.reanimated.nodes.TransformNode;
import java.util.ArrayList;
import java.util.List;

public class TransformNode
extends Node {
    private List<TransformConfig> mTransforms;

    public TransformNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mTransforms = TransformNode.processTransforms(readableMap.getArray("transform"));
    }

    private static List<TransformConfig> processTransforms(ReadableArray readableArray) {
        ArrayList arrayList = new ArrayList(readableArray.size());
        for (int i = 0; i < readableArray.size(); ++i) {
            ReadableMap readableMap = readableArray.getMap(i);
            String string = readableMap.getString("property");
            if (readableMap.hasKey("nodeID")) {
                AnimatedTransformConfig animatedTransformConfig = new AnimatedTransformConfig();
                animatedTransformConfig.propertyName = string;
                animatedTransformConfig.nodeID = readableMap.getInt("nodeID");
                arrayList.add((Object)animatedTransformConfig);
                continue;
            }
            StaticTransformConfig staticTransformConfig = new StaticTransformConfig();
            staticTransformConfig.propertyName = string;
            String string2 = readableMap.getType("value") == ReadableType.String ? readableMap.getString("value") : Double.valueOf((double)readableMap.getDouble("value"));
            staticTransformConfig.value = string2;
            arrayList.add((Object)staticTransformConfig);
        }
        return arrayList;
    }

    protected WritableArray evaluate() {
        ArrayList arrayList = new ArrayList(this.mTransforms.size());
        for (TransformConfig transformConfig : this.mTransforms) {
            Object[] arrobject = new Object[]{transformConfig.propertyName, transformConfig.getValue(this.mNodesManager)};
            arrayList.add((Object)JavaOnlyMap.of((Object[])arrobject));
        }
        return JavaOnlyArray.from((List)arrayList);
    }

    private static class AnimatedTransformConfig
    extends TransformConfig {
        public int nodeID;

        private AnimatedTransformConfig() {
            super(null);
        }

        public Object getValue(NodesManager nodesManager) {
            return nodesManager.getNodeValue(this.nodeID);
        }
    }

    private static class StaticTransformConfig
    extends TransformConfig {
        public Object value;

        private StaticTransformConfig() {
            super(null);
        }

        public Object getValue(NodesManager nodesManager) {
            return this.value;
        }
    }

}

