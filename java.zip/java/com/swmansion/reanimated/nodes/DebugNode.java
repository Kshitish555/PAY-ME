/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.facebook.react.bridge.ReadableMap
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.reanimated.nodes;

import android.util.Log;
import com.facebook.react.bridge.ReadableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.nodes.Node;

public class DebugNode
extends Node {
    private final String mMessage;
    private final int mValueID;

    public DebugNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mMessage = readableMap.getString("message");
        this.mValueID = readableMap.getInt("value");
    }

    protected Object evaluate() {
        Object object = this.mNodesManager.findNodeById(this.mValueID, Node.class).value();
        Object[] arrobject = new Object[]{this.mMessage, object};
        Log.d((String)"REANIMATED", (String)String.format((String)"%s %s", (Object[])arrobject));
        return object;
    }
}

