/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.JavaOnlyMap
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.WritableArray
 *  com.facebook.react.bridge.WritableMap
 *  com.swmansion.reanimated.Utils
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.JavaOnlyMap;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.Utils;
import com.swmansion.reanimated.nodes.Node;
import com.swmansion.reanimated.nodes.TransformNode;
import java.util.Map;
import java.util.Set;

public class StyleNode
extends Node {
    private final Map<String, Integer> mMapping;

    public StyleNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mMapping = Utils.processMapping((ReadableMap)readableMap.getMap("style"));
    }

    protected WritableMap evaluate() {
        JavaOnlyMap javaOnlyMap = new JavaOnlyMap();
        for (Map.Entry entry : this.mMapping.entrySet()) {
            Node node = this.mNodesManager.findNodeById((Integer)entry.getValue(), Node.class);
            if (node instanceof TransformNode) {
                javaOnlyMap.putArray((String)entry.getKey(), (ReadableArray)((WritableArray)node.value()));
                continue;
            }
            Object object = node.value();
            if (object instanceof Double) {
                javaOnlyMap.putDouble((String)entry.getKey(), ((Double)object).doubleValue());
                continue;
            }
            if (object instanceof String) {
                javaOnlyMap.putString((String)entry.getKey(), (String)object);
                continue;
            }
            throw new IllegalStateException("Wrong style form");
        }
        return javaOnlyMap;
    }
}

