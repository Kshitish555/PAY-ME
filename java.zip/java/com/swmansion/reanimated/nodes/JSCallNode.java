/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.WritableArray
 *  com.facebook.react.bridge.WritableMap
 *  com.swmansion.reanimated.Utils
 *  com.swmansion.reanimated.nodes.Node
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 */
package com.swmansion.reanimated.nodes;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.Utils;
import com.swmansion.reanimated.nodes.Node;

public class JSCallNode
extends Node {
    private final int[] mInputIDs;

    public JSCallNode(int n, ReadableMap readableMap, NodesManager nodesManager) {
        super(n, readableMap, nodesManager);
        this.mInputIDs = Utils.processIntArray((ReadableArray)readableMap.getArray("input"));
    }

    protected Double evaluate() {
        WritableArray writableArray = Arguments.createArray();
        for (int i = 0; i < this.mInputIDs.length; ++i) {
            Node node = this.mNodesManager.findNodeById(this.mInputIDs[i], Node.class);
            if (node.value() == null) {
                writableArray.pushNull();
                continue;
            }
            Object object = node.value();
            if (object instanceof String) {
                writableArray.pushString((String)object);
                continue;
            }
            writableArray.pushDouble(node.doubleValue().doubleValue());
        }
        WritableMap writableMap = Arguments.createMap();
        writableMap.putInt("id", this.mNodeID);
        writableMap.putArray("args", (ReadableArray)writableArray);
        this.mNodesManager.sendEvent("onReanimatedCall", writableMap);
        return ZERO;
    }
}

