/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.ReactPackage
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.uimanager.ViewManager
 *  com.swmansion.reanimated.ReanimatedModule
 *  java.lang.Object
 *  java.util.Arrays
 *  java.util.List
 */
package com.swmansion.reanimated;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import com.swmansion.reanimated.ReanimatedModule;
import java.util.Arrays;
import java.util.List;

public class ReanimatedPackage
implements ReactPackage {
    public List<NativeModule> createNativeModules(ReactApplicationContext reactApplicationContext) {
        Object[] arrobject = new NativeModule[]{new ReanimatedModule(reactApplicationContext)};
        return Arrays.asList((Object[])arrobject);
    }

    public List<ViewManager> createViewManagers(ReactApplicationContext reactApplicationContext) {
        return Arrays.asList((Object[])new ViewManager[0]);
    }
}

