/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.GuardedRunnable
 *  com.facebook.react.bridge.JSApplicationIllegalArgumentException
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.UiThreadUtil
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.modules.core.ChoreographerCompat
 *  com.facebook.react.modules.core.ChoreographerCompat$FrameCallback
 *  com.facebook.react.modules.core.DeviceEventManagerModule
 *  com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter
 *  com.facebook.react.modules.core.ReactChoreographer
 *  com.facebook.react.modules.core.ReactChoreographer$CallbackType
 *  com.facebook.react.uimanager.GuardedFrameCallback
 *  com.facebook.react.uimanager.ReactShadowNode
 *  com.facebook.react.uimanager.UIImplementation
 *  com.facebook.react.uimanager.UIManagerModule
 *  com.facebook.react.uimanager.UIManagerModule$CustomEventNamesResolver
 *  com.facebook.react.uimanager.UIManagerReanimatedHelper
 *  com.facebook.react.uimanager.events.Event
 *  com.facebook.react.uimanager.events.EventDispatcher
 *  com.facebook.react.uimanager.events.EventDispatcherListener
 *  com.facebook.react.uimanager.events.RCTEventEmitter
 *  com.swmansion.reanimated.NodesManager$1
 *  com.swmansion.reanimated.NodesManager$NativeUpdateOperation
 *  com.swmansion.reanimated.NodesManager$OnAnimationFrame
 *  com.swmansion.reanimated.UpdateContext
 *  com.swmansion.reanimated.nodes.ClockOpNode$ClockStartNode
 *  com.swmansion.reanimated.nodes.ClockOpNode$ClockStopNode
 *  com.swmansion.reanimated.nodes.ClockOpNode$ClockTestNode
 *  com.swmansion.reanimated.nodes.EventNode
 *  com.swmansion.reanimated.nodes.Node
 *  com.swmansion.reanimated.nodes.NoopNode
 *  com.swmansion.reanimated.nodes.ValueNode
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.Map
 *  java.util.Queue
 *  java.util.Set
 *  java.util.concurrent.ConcurrentLinkedQueue
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package com.swmansion.reanimated;

import android.util.SparseArray;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.GuardedRunnable;
import com.facebook.react.bridge.JSApplicationIllegalArgumentException;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.UiThreadUtil;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.ChoreographerCompat;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.modules.core.ReactChoreographer;
import com.facebook.react.uimanager.GuardedFrameCallback;
import com.facebook.react.uimanager.ReactShadowNode;
import com.facebook.react.uimanager.UIImplementation;
import com.facebook.react.uimanager.UIManagerModule;
import com.facebook.react.uimanager.UIManagerReanimatedHelper;
import com.facebook.react.uimanager.events.Event;
import com.facebook.react.uimanager.events.EventDispatcher;
import com.facebook.react.uimanager.events.EventDispatcherListener;
import com.facebook.react.uimanager.events.RCTEventEmitter;
import com.swmansion.reanimated.NodesManager;
import com.swmansion.reanimated.UpdateContext;
import com.swmansion.reanimated.nodes.AlwaysNode;
import com.swmansion.reanimated.nodes.BezierNode;
import com.swmansion.reanimated.nodes.BlockNode;
import com.swmansion.reanimated.nodes.ClockNode;
import com.swmansion.reanimated.nodes.ClockOpNode;
import com.swmansion.reanimated.nodes.ConcatNode;
import com.swmansion.reanimated.nodes.CondNode;
import com.swmansion.reanimated.nodes.DebugNode;
import com.swmansion.reanimated.nodes.EventNode;
import com.swmansion.reanimated.nodes.JSCallNode;
import com.swmansion.reanimated.nodes.Node;
import com.swmansion.reanimated.nodes.NoopNode;
import com.swmansion.reanimated.nodes.OperatorNode;
import com.swmansion.reanimated.nodes.PropsNode;
import com.swmansion.reanimated.nodes.SetNode;
import com.swmansion.reanimated.nodes.StyleNode;
import com.swmansion.reanimated.nodes.TransformNode;
import com.swmansion.reanimated.nodes.ValueNode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * Exception performing whole class analysis.
 */
public class NodesManager
implements EventDispatcherListener {
    private static final Double ZERO;
    public double currentFrameTimeMs;
    private final SparseArray<Node> mAnimatedNodes;
    private final AtomicBoolean mCallbackPosted;
    private final GuardedFrameCallback mChoreographerCallback;
    private final ReactContext mContext;
    private final UIManagerModule.CustomEventNamesResolver mCustomEventNamesResolver;
    private final DeviceEventManagerModule.RCTDeviceEventEmitter mEventEmitter;
    private final Map<String, EventNode> mEventMapping;
    private ConcurrentLinkedQueue<Event> mEventQueue;
    private List<OnAnimationFrame> mFrameCallbacks;
    private final NoopNode mNoopNode;
    private Queue<NativeUpdateOperation> mOperationsInBatch;
    private final ReactChoreographer mReactChoreographer;
    private final UIImplementation mUIImplementation;
    private final UIManagerModule mUIManager;
    private boolean mWantRunUpdates;
    public Set<String> nativeProps;
    public Set<String> uiProps;
    public final UpdateContext updateContext;

    static {
        ZERO = 0.0;
    }

    public NodesManager(ReactContext reactContext) {
        this.mAnimatedNodes = new SparseArray();
        this.mEventMapping = new HashMap();
        this.mCallbackPosted = new AtomicBoolean();
        this.mFrameCallbacks = new ArrayList();
        this.mEventQueue = new ConcurrentLinkedQueue();
        this.uiProps = Collections.emptySet();
        this.nativeProps = Collections.emptySet();
        this.mOperationsInBatch = new LinkedList();
        this.mContext = reactContext;
        this.mUIManager = (UIManagerModule)reactContext.getNativeModule(UIManagerModule.class);
        this.updateContext = new UpdateContext();
        this.mUIImplementation = this.mUIManager.getUIImplementation();
        this.mCustomEventNamesResolver = this.mUIManager.getDirectEventNamesResolver();
        this.mUIManager.getEventDispatcher().addListener((EventDispatcherListener)this);
        this.mEventEmitter = (DeviceEventManagerModule.RCTDeviceEventEmitter)reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class);
        this.mReactChoreographer = ReactChoreographer.getInstance();
        this.mChoreographerCallback = new 1(this, reactContext);
        this.mNoopNode = new NoopNode(this);
    }

    static /* synthetic */ void access$000(NodesManager nodesManager, long l) {
        nodesManager.onAnimationFrame(l);
    }

    private void handleEvent(Event event) {
        if (!this.mEventMapping.isEmpty()) {
            String string = this.mCustomEventNamesResolver.resolveCustomEventName(event.getEventName());
            int n = event.getViewTag();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(n);
            stringBuilder.append(string);
            String string2 = stringBuilder.toString();
            EventNode eventNode = (EventNode)this.mEventMapping.get((Object)string2);
            if (eventNode != null) {
                event.dispatch((RCTEventEmitter)eventNode);
            }
        }
    }

    private void onAnimationFrame(long l) {
        double d = l;
        Double.isNaN((double)d);
        this.currentFrameTimeMs = d / 1000000.0;
        while (!this.mEventQueue.isEmpty()) {
            this.handleEvent((Event)this.mEventQueue.poll());
        }
        if (!this.mFrameCallbacks.isEmpty()) {
            List<OnAnimationFrame> list = this.mFrameCallbacks;
            this.mFrameCallbacks = new ArrayList(list.size());
            int n = list.size();
            for (int i = 0; i < n; ++i) {
                (list.get(i)).onAnimationFrame();
            }
        }
        if (this.mWantRunUpdates) {
            Node.runUpdates((UpdateContext)this.updateContext);
        }
        if (!this.mOperationsInBatch.isEmpty()) {
            final Queue<NativeUpdateOperation> queue = this.mOperationsInBatch;
            this.mOperationsInBatch = new LinkedList();
            ReactContext reactContext = this.mContext;
            reactContext.runOnNativeModulesQueueThread((Runnable)new GuardedRunnable(reactContext){

                public void runGuarded() {
                    boolean bl = UIManagerReanimatedHelper.isOperationQueueEmpty((UIImplementation)NodesManager.this.mUIImplementation);
                    while (!queue.isEmpty()) {
                        NativeUpdateOperation nativeUpdateOperation = queue.remove();
                        ReactShadowNode reactShadowNode = NodesManager.this.mUIImplementation.resolveShadowNode(nativeUpdateOperation.mViewTag);
                        if (reactShadowNode == null) continue;
                        NodesManager.this.mUIManager.updateView(nativeUpdateOperation.mViewTag, reactShadowNode.getViewClass(), (ReadableMap)nativeUpdateOperation.mNativeProps);
                    }
                    if (bl) {
                        NodesManager.this.mUIImplementation.dispatchViewUpdates(-1);
                    }
                }
            });
        }
        this.mCallbackPosted.set(false);
        this.mWantRunUpdates = false;
        if (!this.mFrameCallbacks.isEmpty() || !this.mEventQueue.isEmpty()) {
            this.startUpdatingOnAnimationFrame();
        }
    }

    private void startUpdatingOnAnimationFrame() {
        if (!this.mCallbackPosted.getAndSet(true)) {
            this.mReactChoreographer.postFrameCallback(ReactChoreographer.CallbackType.NATIVE_ANIMATED_MODULE, (ChoreographerCompat.FrameCallback)this.mChoreographerCallback);
        }
    }

    private void stopUpdatingOnAnimationFrame() {
        if (this.mCallbackPosted.getAndSet(false)) {
            this.mReactChoreographer.removeFrameCallback(ReactChoreographer.CallbackType.NATIVE_ANIMATED_MODULE, (ChoreographerCompat.FrameCallback)this.mChoreographerCallback);
        }
    }

    public void attachEvent(int n, String string, int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(n);
        stringBuilder.append(string);
        String string2 = stringBuilder.toString();
        EventNode eventNode = (EventNode)this.mAnimatedNodes.get(n2);
        if (eventNode != null) {
            if (!this.mEventMapping.containsKey((Object)string2)) {
                this.mEventMapping.put((Object)string2, (Object)eventNode);
                return;
            }
            throw new JSApplicationIllegalArgumentException("Event handler already set for the given view and event type");
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Event node ");
        stringBuilder2.append(n2);
        stringBuilder2.append(" does not exists");
        throw new JSApplicationIllegalArgumentException(stringBuilder2.toString());
    }

    public void configureProps(Set<String> set, Set<String> set2) {
        this.nativeProps = set;
        this.uiProps = set2;
    }

    public void connectNodeToView(int n, int n2) {
        Node node = (Node)this.mAnimatedNodes.get(n);
        if (node != null) {
            if (node instanceof PropsNode) {
                ((PropsNode)node).connectToView(n2);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Animated node connected to view should beof type ");
            stringBuilder.append(PropsNode.class.getName());
            throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Animated node with ID ");
        stringBuilder.append(n);
        stringBuilder.append(" does not exists");
        throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
    }

    public void connectNodes(int n, int n2) {
        Node node = (Node)this.mAnimatedNodes.get(n);
        if (node != null) {
            Node node2 = (Node)this.mAnimatedNodes.get(n2);
            if (node2 != null) {
                node.addChild(node2);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Animated node with ID ");
            stringBuilder.append(n2);
            stringBuilder.append(" does not exists");
            throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Animated node with ID ");
        stringBuilder.append(n);
        stringBuilder.append(" does not exists");
        throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
    }

    public void createNode(int n, ReadableMap readableMap) {
        block2 : {
            String string;
            block21 : {
                Node node;
                block4 : {
                    block20 : {
                        block19 : {
                            block18 : {
                                block17 : {
                                    block16 : {
                                        block15 : {
                                            block14 : {
                                                block13 : {
                                                    block12 : {
                                                        block11 : {
                                                            block10 : {
                                                                block9 : {
                                                                    block8 : {
                                                                        block7 : {
                                                                            block6 : {
                                                                                block5 : {
                                                                                    block3 : {
                                                                                        if (this.mAnimatedNodes.get(n) != null) break block2;
                                                                                        string = readableMap.getString("type");
                                                                                        if (!"props".equals((Object)string)) break block3;
                                                                                        node = new PropsNode(n, readableMap, this, this.mUIImplementation);
                                                                                        break block4;
                                                                                    }
                                                                                    if (!"style".equals((Object)string)) break block5;
                                                                                    node = new StyleNode(n, readableMap, this);
                                                                                    break block4;
                                                                                }
                                                                                if (!"transform".equals((Object)string)) break block6;
                                                                                node = new TransformNode(n, readableMap, this);
                                                                                break block4;
                                                                            }
                                                                            if (!"value".equals((Object)string)) break block7;
                                                                            node = new ValueNode(n, readableMap, this);
                                                                            break block4;
                                                                        }
                                                                        if (!"block".equals((Object)string)) break block8;
                                                                        node = new BlockNode(n, readableMap, this);
                                                                        break block4;
                                                                    }
                                                                    if (!"cond".equals((Object)string)) break block9;
                                                                    node = new CondNode(n, readableMap, this);
                                                                    break block4;
                                                                }
                                                                if (!"op".equals((Object)string)) break block10;
                                                                node = new OperatorNode(n, readableMap, this);
                                                                break block4;
                                                            }
                                                            if (!"set".equals((Object)string)) break block11;
                                                            node = new SetNode(n, readableMap, this);
                                                            break block4;
                                                        }
                                                        if (!"debug".equals((Object)string)) break block12;
                                                        node = new DebugNode(n, readableMap, this);
                                                        break block4;
                                                    }
                                                    if (!"clock".equals((Object)string)) break block13;
                                                    node = new ClockNode(n, readableMap, this);
                                                    break block4;
                                                }
                                                if (!"clockStart".equals((Object)string)) break block14;
                                                node = new ClockOpNode.ClockStartNode(n, readableMap, this);
                                                break block4;
                                            }
                                            if (!"clockStop".equals((Object)string)) break block15;
                                            node = new ClockOpNode.ClockStopNode(n, readableMap, this);
                                            break block4;
                                        }
                                        if (!"clockTest".equals((Object)string)) break block16;
                                        node = new ClockOpNode.ClockTestNode(n, readableMap, this);
                                        break block4;
                                    }
                                    if (!"call".equals((Object)string)) break block17;
                                    node = new JSCallNode(n, readableMap, this);
                                    break block4;
                                }
                                if (!"bezier".equals((Object)string)) break block18;
                                node = new BezierNode(n, readableMap, this);
                                break block4;
                            }
                            if (!"event".equals((Object)string)) break block19;
                            node = new EventNode(n, readableMap, this);
                            break block4;
                        }
                        if (!"always".equals((Object)string)) break block20;
                        node = new AlwaysNode(n, readableMap, this);
                        break block4;
                    }
                    if (!"concat".equals((Object)string)) break block21;
                    node = new ConcatNode(n, readableMap, this);
                }
                this.mAnimatedNodes.put(n, (Object)node);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unsupported node type: ");
            stringBuilder.append(string);
            throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Animated node with ID ");
        stringBuilder.append(n);
        stringBuilder.append(" already exists");
        throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
    }

    public void detachEvent(int n, String string, int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(n);
        stringBuilder.append(string);
        String string2 = stringBuilder.toString();
        this.mEventMapping.remove((Object)string2);
    }

    public void disconnectNodeFromView(int n, int n2) {
        Node node = (Node)this.mAnimatedNodes.get(n);
        if (node != null) {
            if (node instanceof PropsNode) {
                ((PropsNode)node).disconnectFromView(n2);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Animated node connected to view should beof type ");
            stringBuilder.append(PropsNode.class.getName());
            throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Animated node with ID ");
        stringBuilder.append(n);
        stringBuilder.append(" does not exists");
        throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
    }

    public void disconnectNodes(int n, int n2) {
        Node node = (Node)this.mAnimatedNodes.get(n);
        if (node != null) {
            Node node2 = (Node)this.mAnimatedNodes.get(n2);
            if (node2 != null) {
                node.removeChild(node2);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Animated node with ID ");
            stringBuilder.append(n2);
            stringBuilder.append(" does not exists");
            throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Animated node with ID ");
        stringBuilder.append(n);
        stringBuilder.append(" does not exists");
        throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
    }

    public void dropNode(int n) {
        this.mAnimatedNodes.remove(n);
    }

    public void enqueueUpdateViewOnNativeThread(int n, WritableMap writableMap) {
        this.mOperationsInBatch.add((Object)new /* Unavailable Anonymous Inner Class!! */);
    }

    public <T extends Node> T findNodeById(int n, Class<T> class_) {
        Node node = (Node)this.mAnimatedNodes.get(n);
        if (node == null) {
            if (class_ != Node.class && class_ != ValueNode.class) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Requested node with id ");
                stringBuilder.append(n);
                stringBuilder.append(" of type ");
                stringBuilder.append(class_);
                stringBuilder.append(" cannot be found");
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            return (T)this.mNoopNode;
        }
        if (class_.isInstance((Object)node)) {
            return (T)node;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Node with id ");
        stringBuilder.append(n);
        stringBuilder.append(" is of incompatible type ");
        stringBuilder.append((Object)node.getClass());
        stringBuilder.append(", requested type was ");
        stringBuilder.append(class_);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public Object getNodeValue(int n) {
        Node node = (Node)this.mAnimatedNodes.get(n);
        if (node != null) {
            return node.value();
        }
        return ZERO;
    }

    public void getValue(int n, Callback callback) {
        Object[] arrobject = new Object[]{((Node)this.mAnimatedNodes.get(n)).value()};
        callback.invoke(arrobject);
    }

    public void onEventDispatch(Event event) {
        if (UiThreadUtil.isOnUiThread()) {
            this.handleEvent(event);
            return;
        }
        this.mEventQueue.offer((Object)event);
        this.startUpdatingOnAnimationFrame();
    }

    public void onHostPause() {
        if (this.mCallbackPosted.get()) {
            this.stopUpdatingOnAnimationFrame();
            this.mCallbackPosted.set(true);
        }
    }

    public void onHostResume() {
        if (this.mCallbackPosted.getAndSet(false)) {
            this.startUpdatingOnAnimationFrame();
        }
    }

    public void postOnAnimation(OnAnimationFrame onAnimationFrame) {
        this.mFrameCallbacks.add((Object)onAnimationFrame);
        this.startUpdatingOnAnimationFrame();
    }

    public void postRunUpdatesAfterAnimation() {
        this.mWantRunUpdates = true;
        this.startUpdatingOnAnimationFrame();
    }

    public void sendEvent(String string, WritableMap writableMap) {
        this.mEventEmitter.emit(string, (Object)writableMap);
    }

}

