/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentName
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.graphics.drawable.Drawable
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.cocosw.bottomsheet;

import android.app.Activity;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import com.cocosw.bottomsheet.BottomSheet;
import com.cocosw.bottomsheet.R;
import java.util.List;

public class BottomSheetHelper {
    public static BottomSheet.Builder shareAction(final Activity activity, final Intent intent) {
        BottomSheet.Builder builder = new BottomSheet.Builder(activity).grid();
        PackageManager packageManager = activity.getPackageManager();
        final List list = packageManager.queryIntentActivities(intent, 0);
        for (int i = 0; i < list.size(); ++i) {
            builder.sheet(i, ((ResolveInfo)list.get(i)).loadIcon(packageManager), ((ResolveInfo)list.get(i)).loadLabel(packageManager));
        }
        builder.listener(new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n) {
                ActivityInfo activityInfo = ((ResolveInfo)list.get((int)n)).activityInfo;
                ComponentName componentName = new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name);
                Intent intent2 = (Intent)intent.clone();
                intent2.setFlags(270532608);
                intent2.setComponent(componentName);
                activity.startActivity(intent2);
            }
        });
        builder.limit(R.integer.bs_initial_grid_row);
        return builder;
    }

}

