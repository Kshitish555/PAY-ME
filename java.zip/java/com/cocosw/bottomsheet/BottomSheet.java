/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.DialogInterface$OnDismissListener
 *  android.content.DialogInterface$OnShowListener
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.transition.ChangeBounds
 *  android.transition.Transition
 *  android.transition.TransitionManager
 *  android.util.AttributeSet
 *  android.util.SparseArray
 *  android.util.SparseIntArray
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.MenuItem$OnMenuItemClickListener
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.BaseAdapter
 *  android.widget.GridView
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.ListAdapter
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.util.ArrayList
 */
package com.cocosw.bottomsheet;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.transition.ChangeBounds;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import com.cocosw.bottomsheet.ActionMenu;
import com.cocosw.bottomsheet.ActionMenuItem;
import com.cocosw.bottomsheet.BottomSheet;
import com.cocosw.bottomsheet.ClosableSlidingLayout;
import com.cocosw.bottomsheet.R;
import com.cocosw.bottomsheet.SimpleSectionedGridAdapter;
import com.cocosw.bottomsheet.TranslucentHelper;
import java.lang.reflect.Field;
import java.util.ArrayList;

public class BottomSheet
extends Dialog
implements DialogInterface {
    private ActionMenu actions;
    private SimpleSectionedGridAdapter adapter;
    private Builder builder;
    private boolean cancelOnSwipeDown;
    private boolean cancelOnTouchOutside;
    private Drawable close;
    private boolean collapseListIcons;
    private DialogInterface.OnDismissListener dismissListener;
    private ActionMenu fullMenuItem;
    private TranslucentHelper helper;
    private final SparseIntArray hidden;
    private ImageView icon;
    private int limit;
    private GridView list;
    private int mGridItemLayoutId;
    private int mHeaderLayoutId;
    private int mListItemLayoutId;
    private ActionMenu menuItem;
    private Drawable more;
    private String moreText;
    private DialogInterface.OnShowListener showListener;

    BottomSheet(Context context) {
        super(context, R.style.BottomSheet_Dialog);
        this.hidden = new SparseIntArray();
        this.limit = -1;
        this.cancelOnTouchOutside = true;
        this.cancelOnSwipeDown = true;
    }

    BottomSheet(Context context, int n) {
        TypedArray typedArray;
        block3 : {
            super(context, n);
            this.hidden = new SparseIntArray();
            this.limit = -1;
            this.cancelOnTouchOutside = true;
            this.cancelOnSwipeDown = true;
            typedArray = this.getContext().obtainStyledAttributes(null, R.styleable.BottomSheet, R.attr.bs_bottomSheetStyle, 0);
            this.more = typedArray.getDrawable(R.styleable.BottomSheet_bs_moreDrawable);
            this.close = typedArray.getDrawable(R.styleable.BottomSheet_bs_closeDrawable);
            this.moreText = typedArray.getString(R.styleable.BottomSheet_bs_moreText);
            this.collapseListIcons = typedArray.getBoolean(R.styleable.BottomSheet_bs_collapseListIcons, true);
            this.mHeaderLayoutId = typedArray.getResourceId(R.styleable.BottomSheet_bs_headerLayout, R.layout.bs_header);
            this.mListItemLayoutId = typedArray.getResourceId(R.styleable.BottomSheet_bs_listItemLayout, R.layout.bs_list_entry);
            this.mGridItemLayoutId = typedArray.getResourceId(R.styleable.BottomSheet_bs_gridItemLayout, R.layout.bs_grid_entry);
            if (Build.VERSION.SDK_INT < 19) break block3;
            this.helper = new TranslucentHelper(this, context);
        }
        return;
        finally {
            typedArray.recycle();
        }
    }

    private int getNumColumns() {
        int n;
        n = 1;
        try {
            Field field = GridView.class.getDeclaredField("mRequestedNumColumns");
            field.setAccessible((boolean)n);
            n = field.getInt((Object)this.list);
        }
        catch (Exception exception) {}
        return n;
    }

    private boolean hasDivider() {
        return this.adapter.mSections.size() > 0;
    }

    private void init(Context context) {
        SimpleSectionedGridAdapter simpleSectionedGridAdapter;
        this.setCanceledOnTouchOutside(this.cancelOnTouchOutside);
        final ClosableSlidingLayout closableSlidingLayout = (ClosableSlidingLayout)View.inflate((Context)context, (int)R.layout.bottom_sheet_dialog, null);
        ((LinearLayout)closableSlidingLayout.findViewById(R.id.bs_main)).addView(View.inflate((Context)context, (int)this.mHeaderLayoutId, null), 0);
        this.setContentView((View)closableSlidingLayout);
        boolean bl = this.cancelOnSwipeDown;
        if (!bl) {
            closableSlidingLayout.swipeable = bl;
        }
        closableSlidingLayout.setSlideListener(new ClosableSlidingLayout.SlideListener(this){
            final /* synthetic */ BottomSheet this$0;
            {
                this.this$0 = bottomSheet;
            }

            public void onClosed() {
                this.this$0.dismiss();
            }

            public void onOpened() {
                BottomSheet.access$000(this.this$0);
            }
        });
        super.setOnShowListener(new DialogInterface.OnShowListener(){

            public void onShow(DialogInterface dialogInterface) {
                if (BottomSheet.this.showListener != null) {
                    BottomSheet.this.showListener.onShow(dialogInterface);
                }
                BottomSheet.this.list.setAdapter((ListAdapter)BottomSheet.this.adapter);
                BottomSheet.this.list.startLayoutAnimation();
                if (BottomSheet.this.builder.icon == null) {
                    BottomSheet.this.icon.setVisibility(8);
                    return;
                }
                BottomSheet.this.icon.setVisibility(0);
                BottomSheet.this.icon.setImageDrawable(BottomSheet.this.builder.icon);
            }
        });
        int[] arrn = new int[2];
        closableSlidingLayout.getLocationOnScreen(arrn);
        if (Build.VERSION.SDK_INT >= 19) {
            int n = arrn[0] == 0 ? this.helper.mStatusBarHeight : 0;
            closableSlidingLayout.setPadding(0, n, 0, 0);
            View view = closableSlidingLayout.getChildAt(0);
            int n2 = this.helper.mNavBarAvailable ? this.helper.getNavigationBarHeight(this.getContext()) + closableSlidingLayout.getPaddingBottom() : 0;
            view.setPadding(0, 0, 0, n2);
        }
        TextView textView = (TextView)closableSlidingLayout.findViewById(R.id.bottom_sheet_title);
        if (this.builder.title != null) {
            textView.setVisibility(0);
            textView.setText(this.builder.title);
        }
        this.icon = (ImageView)closableSlidingLayout.findViewById(R.id.bottom_sheet_title_image);
        this.list = (GridView)closableSlidingLayout.findViewById(R.id.bottom_sheet_gridview);
        closableSlidingLayout.mTarget = this.list;
        if (!this.builder.grid) {
            this.list.setNumColumns(1);
        }
        if (this.builder.grid) {
            for (int i = 0; i < this.getMenu().size(); ++i) {
                if (this.getMenu().getItem(i).getIcon() != null) {
                    continue;
                }
                throw new IllegalArgumentException("You must set icon for each items in grid style");
            }
        }
        this.limit = this.builder.limit > 0 ? this.builder.limit * this.getNumColumns() : Integer.MAX_VALUE;
        closableSlidingLayout.setCollapsible(false);
        this.menuItem = this.actions = this.builder.menu;
        if (this.getMenu().size() > this.limit) {
            this.fullMenuItem = this.builder.menu;
            this.menuItem = this.builder.menu.clone(this.limit - 1);
            ActionMenuItem actionMenuItem = new ActionMenuItem(context, 0, R.id.bs_more, 0, -1 + this.limit, this.moreText);
            actionMenuItem.setIcon(this.more);
            this.menuItem.add(actionMenuItem);
            this.actions = this.menuItem;
            closableSlidingLayout.setCollapsible(true);
        }
        BaseAdapter baseAdapter = new BaseAdapter(){

            public boolean areAllItemsEnabled() {
                return false;
            }

            public int getCount() {
                return BottomSheet.this.actions.size() - BottomSheet.this.hidden.size();
            }

            public MenuItem getItem(int n) {
                return BottomSheet.this.actions.getItem(n);
            }

            public long getItemId(int n) {
                return n;
            }

            public View getView(int n, View view, ViewGroup viewGroup) {
                ViewHolder viewHolder;
                if (view == null) {
                    LayoutInflater layoutInflater = (LayoutInflater)BottomSheet.this.getContext().getSystemService("layout_inflater");
                    view = BottomSheet.this.builder.grid ? layoutInflater.inflate(BottomSheet.this.mGridItemLayoutId, viewGroup, false) : layoutInflater.inflate(BottomSheet.this.mListItemLayoutId, viewGroup, false);
                    viewHolder = new ViewHolder();
                    viewHolder.title = (TextView)view.findViewById(R.id.bs_list_title);
                    viewHolder.image = (ImageView)view.findViewById(R.id.bs_list_image);
                    view.setTag((Object)viewHolder);
                } else {
                    viewHolder = (ViewHolder)view.getTag();
                }
                int n2 = n;
                for (int i = 0; i < BottomSheet.this.hidden.size(); ++i) {
                    if (BottomSheet.this.hidden.valueAt(i) > n2) continue;
                    ++n2;
                }
                MenuItem menuItem = this.getItem(n2);
                viewHolder.title.setText(menuItem.getTitle());
                if (menuItem.getIcon() == null) {
                    ImageView imageView = viewHolder.image;
                    int n3 = BottomSheet.this.collapseListIcons ? 8 : 4;
                    imageView.setVisibility(n3);
                } else {
                    viewHolder.image.setVisibility(0);
                    viewHolder.image.setImageDrawable(menuItem.getIcon());
                }
                viewHolder.image.setEnabled(menuItem.isEnabled());
                viewHolder.title.setEnabled(menuItem.isEnabled());
                return view;
            }

            public int getViewTypeCount() {
                return 1;
            }

            public boolean isEnabled(int n) {
                return this.getItem(n).isEnabled();
            }

            class ViewHolder {
                private ImageView image;
                private TextView title;

                ViewHolder() {
                }
            }

        };
        this.adapter = simpleSectionedGridAdapter = new SimpleSectionedGridAdapter(context, baseAdapter, R.layout.bs_list_divider, R.id.headerlayout, R.id.header);
        this.list.setAdapter((ListAdapter)this.adapter);
        this.adapter.setGridView(this.list);
        this.list.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
                if (((MenuItem)BottomSheet.this.adapter.getItem(n)).getItemId() == R.id.bs_more) {
                    BottomSheet.this.showFullItems();
                    closableSlidingLayout.setCollapsible(false);
                    return;
                }
                if (!((ActionMenuItem)BottomSheet.this.adapter.getItem(n)).invoke()) {
                    if (BottomSheet.this.builder.menulistener != null) {
                        BottomSheet.this.builder.menulistener.onMenuItemClick((MenuItem)BottomSheet.this.adapter.getItem(n));
                    } else if (BottomSheet.this.builder.listener != null) {
                        DialogInterface.OnClickListener onClickListener = BottomSheet.this.builder.listener;
                        BottomSheet bottomSheet = BottomSheet.this;
                        onClickListener.onClick((DialogInterface)bottomSheet, ((MenuItem)bottomSheet.adapter.getItem(n)).getItemId());
                    }
                }
                BottomSheet.this.dismiss();
            }
        });
        if (this.builder.dismissListener != null) {
            this.setOnDismissListener(this.builder.dismissListener);
        }
        this.setListLayout();
    }

    private void setListLayout() {
        if (!this.hasDivider()) {
            return;
        }
        this.list.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(){

            public void onGlobalLayout() {
                if (Build.VERSION.SDK_INT < 16) {
                    BottomSheet.this.list.getViewTreeObserver().removeGlobalOnLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
                } else {
                    BottomSheet.this.list.getViewTreeObserver().removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
                }
                View view = BottomSheet.this.list.getChildAt(-1 + BottomSheet.this.list.getChildCount());
                if (view != null) {
                    BottomSheet.this.list.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, view.getBottom() + view.getPaddingBottom() + BottomSheet.this.list.getPaddingBottom()));
                }
            }
        });
    }

    private void showFullItems() {
        if (Build.VERSION.SDK_INT >= 19) {
            ChangeBounds changeBounds = new ChangeBounds();
            changeBounds.setDuration(300L);
            TransitionManager.beginDelayedTransition((ViewGroup)this.list, (Transition)changeBounds);
        }
        this.actions = this.fullMenuItem;
        this.updateSection();
        this.adapter.notifyDataSetChanged();
        this.list.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
        this.icon.setVisibility(0);
        this.icon.setImageDrawable(this.close);
        this.icon.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                BottomSheet.this.showShortItems();
            }
        });
        this.setListLayout();
    }

    private void showShortItems() {
        this.actions = this.menuItem;
        this.updateSection();
        this.adapter.notifyDataSetChanged();
        this.setListLayout();
        if (this.builder.icon == null) {
            this.icon.setVisibility(8);
            return;
        }
        this.icon.setVisibility(0);
        this.icon.setImageDrawable(this.builder.icon);
    }

    private void updateSection() {
        this.actions.removeInvisible();
        if (!this.builder.grid && this.actions.size() > 0) {
            ActionMenu actionMenu = this.actions;
            int n = actionMenu.getItem(0).getGroupId();
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < this.actions.size(); ++i) {
                if (this.actions.getItem(i).getGroupId() == n) continue;
                n = this.actions.getItem(i).getGroupId();
                arrayList.add((Object)new SimpleSectionedGridAdapter.Section(i, null));
            }
            if (arrayList.size() > 0) {
                Object[] arrobject = new SimpleSectionedGridAdapter.Section[arrayList.size()];
                arrayList.toArray(arrobject);
                this.adapter.setSections((SimpleSectionedGridAdapter.Section[])arrobject);
                return;
            }
            this.adapter.mSections.clear();
        }
    }

    public Menu getMenu() {
        return this.builder.menu;
    }

    public void invalidate() {
        this.updateSection();
        this.adapter.notifyDataSetChanged();
        this.setListLayout();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.init(this.getContext());
        WindowManager.LayoutParams layoutParams = this.getWindow().getAttributes();
        layoutParams.height = -2;
        layoutParams.gravity = 80;
        TypedArray typedArray = this.getContext().obtainStyledAttributes(new int[]{16842996});
        layoutParams.width = typedArray.getLayoutDimension(0, -1);
        super.setOnDismissListener(new DialogInterface.OnDismissListener(){

            public void onDismiss(DialogInterface dialogInterface) {
                if (BottomSheet.this.dismissListener != null) {
                    BottomSheet.this.dismissListener.onDismiss(dialogInterface);
                }
                if (BottomSheet.this.limit != Integer.MAX_VALUE) {
                    BottomSheet.this.showShortItems();
                }
            }
        });
        this.getWindow().setAttributes(layoutParams);
        return;
        finally {
            typedArray.recycle();
        }
    }

    protected void onStart() {
        super.onStart();
        this.showShortItems();
    }

    public void setCanceledOnSwipeDown(boolean bl) {
        this.cancelOnSwipeDown = bl;
    }

    public void setCanceledOnTouchOutside(boolean bl) {
        super.setCanceledOnTouchOutside(bl);
        this.cancelOnTouchOutside = bl;
    }

    public void setOnDismissListener(DialogInterface.OnDismissListener onDismissListener) {
        this.dismissListener = onDismissListener;
    }

    public void setOnShowListener(DialogInterface.OnShowListener onShowListener) {
        this.showListener = onShowListener;
    }

    public static class Builder {
        private final Context context;
        private DialogInterface.OnDismissListener dismissListener;
        private boolean grid;
        private Drawable icon;
        private int limit = -1;
        private DialogInterface.OnClickListener listener;
        private final ActionMenu menu;
        private MenuItem.OnMenuItemClickListener menulistener;
        private int theme;
        private CharSequence title;

        public Builder(Activity activity) {
            this((Context)activity, R.style.BottomSheet_Dialog);
            Resources.Theme theme = activity.getTheme();
            int[] arrn = new int[]{R.attr.bs_bottomSheetStyle};
            TypedArray typedArray = theme.obtainStyledAttributes(arrn);
            try {
                this.theme = typedArray.getResourceId(0, R.style.BottomSheet_Dialog);
                return;
            }
            finally {
                typedArray.recycle();
            }
        }

        public Builder(Context context, int n) {
            this.context = context;
            this.theme = n;
            this.menu = new ActionMenu(context);
        }

        public BottomSheet build() {
            BottomSheet bottomSheet = new BottomSheet(this.context, this.theme);
            bottomSheet.builder = this;
            return bottomSheet;
        }

        public Builder darkTheme() {
            this.theme = R.style.BottomSheet_Dialog_Dark;
            return this;
        }

        public Builder grid() {
            this.grid = true;
            return this;
        }

        public Builder icon(int n) {
            this.icon = this.context.getResources().getDrawable(n);
            return this;
        }

        public Builder icon(Drawable drawable2) {
            this.icon = drawable2;
            return this;
        }

        public Builder limit(int n) {
            this.limit = this.context.getResources().getInteger(n);
            return this;
        }

        public Builder listener(DialogInterface.OnClickListener onClickListener) {
            this.listener = onClickListener;
            return this;
        }

        public Builder listener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
            this.menulistener = onMenuItemClickListener;
            return this;
        }

        @Deprecated
        public Builder remove(int n) {
            this.menu.removeItem(n);
            return this;
        }

        public Builder setOnDismissListener(DialogInterface.OnDismissListener onDismissListener) {
            this.dismissListener = onDismissListener;
            return this;
        }

        public Builder sheet(int n) {
            new MenuInflater(this.context).inflate(n, (Menu)this.menu);
            return this;
        }

        public Builder sheet(int n, int n2) {
            this.menu.add(0, n, 0, n2);
            return this;
        }

        public Builder sheet(int n, int n2, int n3) {
            Context context = this.context;
            ActionMenuItem actionMenuItem = new ActionMenuItem(context, 0, n, 0, 0, context.getText(n3));
            actionMenuItem.setIcon(n2);
            this.menu.add(actionMenuItem);
            return this;
        }

        public Builder sheet(int n, Drawable drawable2, CharSequence charSequence) {
            ActionMenuItem actionMenuItem = new ActionMenuItem(this.context, 0, n, 0, 0, charSequence);
            actionMenuItem.setIcon(drawable2);
            this.menu.add(actionMenuItem);
            return this;
        }

        public Builder sheet(int n, CharSequence charSequence) {
            this.menu.add(0, n, 0, charSequence);
            return this;
        }

        public BottomSheet show() {
            BottomSheet bottomSheet = this.build();
            bottomSheet.show();
            return bottomSheet;
        }

        public Builder title(int n) {
            this.title = this.context.getText(n);
            return this;
        }

        public Builder title(CharSequence charSequence) {
            this.title = charSequence;
            return this;
        }
    }

}

