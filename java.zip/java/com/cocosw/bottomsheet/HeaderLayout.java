/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.widget.FrameLayout
 */
package com.cocosw.bottomsheet;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

class HeaderLayout
extends FrameLayout {
    private int mHeaderWidth = 1;

    public HeaderLayout(Context context) {
        super(context);
    }

    public HeaderLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public HeaderLayout(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
    }

    protected void onMeasure(int n, int n2) {
        int n3 = this.mHeaderWidth;
        if (n3 != 1) {
            n = View.MeasureSpec.makeMeasureSpec((int)n3, (int)View.MeasureSpec.getMode((int)n));
        }
        super.onMeasure(n, n2);
    }

    public void setHeaderWidth(int n) {
        this.mHeaderWidth = n;
    }
}

