/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.view.KeyEvent
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.SubMenu
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 */
package com.cocosw.bottomsheet;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import com.cocosw.bottomsheet.ActionMenuItem;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

class ActionMenu
implements Menu {
    private static final int CATEGORY_MASK = -65536;
    private static final int CATEGORY_SHIFT = 16;
    private static final int USER_MASK = 65535;
    private static final int USER_SHIFT;
    private static final int[] sCategoryToOrder;
    private Context mContext;
    private boolean mIsQwerty;
    private ArrayList<ActionMenuItem> mItems;

    static {
        sCategoryToOrder = new int[]{1, 4, 5, 3, 2, 0};
    }

    ActionMenu(Context context) {
        this.mContext = context;
        this.mItems = new ArrayList();
    }

    private static int findInsertIndex(ArrayList<ActionMenuItem> arrayList, int n) {
        for (int i = -1 + arrayList.size(); i >= 0; --i) {
            if (((ActionMenuItem)arrayList.get(i)).getOrder() > n) continue;
            return i + 1;
        }
        return 0;
    }

    private int findItemIndex(int n) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n2 = arrayList.size();
        for (int i = 0; i < n2; ++i) {
            if (((ActionMenuItem)arrayList.get(i)).getItemId() != n) continue;
            return i;
        }
        return -1;
    }

    private ActionMenuItem findItemWithShortcut(int n, KeyEvent keyEvent) {
        boolean bl = this.mIsQwerty;
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n2 = arrayList.size();
        for (int i = 0; i < n2; ++i) {
            ActionMenuItem actionMenuItem = (ActionMenuItem)arrayList.get(i);
            char c = bl ? actionMenuItem.getAlphabeticShortcut() : actionMenuItem.getNumericShortcut();
            if (n != c) continue;
            return actionMenuItem;
        }
        return null;
    }

    private static int getOrdering(int n) {
        int[] arrn;
        int n2 = (-65536 & n) >> 16;
        if (n2 >= 0 && n2 < (arrn = sCategoryToOrder).length) {
            return arrn[n2] << 16 | n & 65535;
        }
        throw new IllegalArgumentException("order does not contain a valid category.");
    }

    public MenuItem add(int n) {
        return this.add(0, 0, 0, n);
    }

    public MenuItem add(int n, int n2, int n3, int n4) {
        return this.add(n, n2, n3, this.mContext.getResources().getString(n4));
    }

    public MenuItem add(int n, int n2, int n3, CharSequence charSequence) {
        ActionMenuItem actionMenuItem = new ActionMenuItem(this.getContext(), n, n2, 0, n3, charSequence);
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        arrayList.add(ActionMenu.findInsertIndex(arrayList, ActionMenu.getOrdering(n3)), (Object)actionMenuItem);
        return actionMenuItem;
    }

    MenuItem add(ActionMenuItem actionMenuItem) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        arrayList.add(ActionMenu.findInsertIndex(arrayList, ActionMenu.getOrdering(actionMenuItem.getOrder())), (Object)actionMenuItem);
        return actionMenuItem;
    }

    public MenuItem add(CharSequence charSequence) {
        return this.add(0, 0, 0, charSequence);
    }

    public int addIntentOptions(int n, int n2, int n3, ComponentName componentName, Intent[] arrintent, Intent intent, int n4, MenuItem[] arrmenuItem) {
        PackageManager packageManager = this.mContext.getPackageManager();
        List list = packageManager.queryIntentActivityOptions(componentName, arrintent, intent, 0);
        int n5 = list != null ? list.size() : 0;
        int n6 = n4 & 1;
        int n7 = 0;
        if (n6 == 0) {
            this.removeGroup(n);
        }
        while (n7 < n5) {
            ResolveInfo resolveInfo = (ResolveInfo)list.get(n7);
            Intent intent2 = resolveInfo.specificIndex < 0 ? intent : arrintent[resolveInfo.specificIndex];
            Intent intent3 = new Intent(intent2);
            intent3.setComponent(new ComponentName(resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.name));
            MenuItem menuItem = this.add(n, n2, n3, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent3);
            if (arrmenuItem != null && resolveInfo.specificIndex >= 0) {
                arrmenuItem[resolveInfo.specificIndex] = menuItem;
            }
            ++n7;
        }
        return n5;
    }

    public SubMenu addSubMenu(int n) {
        return null;
    }

    public SubMenu addSubMenu(int n, int n2, int n3, int n4) {
        return null;
    }

    public SubMenu addSubMenu(int n, int n2, int n3, CharSequence charSequence) {
        return null;
    }

    public SubMenu addSubMenu(CharSequence charSequence) {
        return null;
    }

    public void clear() {
        this.mItems.clear();
    }

    ActionMenu clone(int n) {
        ActionMenu actionMenu = new ActionMenu(this.getContext());
        actionMenu.mItems = new ArrayList((Collection)this.mItems.subList(0, n));
        return actionMenu;
    }

    public void close() {
    }

    public MenuItem findItem(int n) {
        int n2 = this.findItemIndex(n);
        if (n2 < 0) {
            return null;
        }
        return (MenuItem)this.mItems.get(n2);
    }

    public Context getContext() {
        return this.mContext;
    }

    public MenuItem getItem(int n) {
        return (MenuItem)this.mItems.get(n);
    }

    public boolean hasVisibleItems() {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n = arrayList.size();
        for (int i = 0; i < n; ++i) {
            if (!((ActionMenuItem)arrayList.get(i)).isVisible()) continue;
            return true;
        }
        return false;
    }

    public boolean isShortcutKey(int n, KeyEvent keyEvent) {
        return this.findItemWithShortcut(n, keyEvent) != null;
    }

    public boolean performIdentifierAction(int n, int n2) {
        int n3 = this.findItemIndex(n);
        if (n3 < 0) {
            return false;
        }
        return ((ActionMenuItem)this.mItems.get(n3)).invoke();
    }

    public boolean performShortcut(int n, KeyEvent keyEvent, int n2) {
        ActionMenuItem actionMenuItem = this.findItemWithShortcut(n, keyEvent);
        if (actionMenuItem == null) {
            return false;
        }
        return actionMenuItem.invoke();
    }

    public void removeGroup(int n) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n2 = arrayList.size();
        int n3 = 0;
        while (n3 < n2) {
            if (((ActionMenuItem)arrayList.get(n3)).getGroupId() == n) {
                arrayList.remove(n3);
                --n2;
                continue;
            }
            ++n3;
        }
    }

    void removeInvisible() {
        Iterator iterator = this.mItems.iterator();
        while (iterator.hasNext()) {
            if (((ActionMenuItem)iterator.next()).isVisible()) continue;
            iterator.remove();
        }
    }

    public void removeItem(int n) {
        int n2 = this.findItemIndex(n);
        if (n2 < 0) {
            return;
        }
        this.mItems.remove(n2);
    }

    public void setGroupCheckable(int n, boolean bl, boolean bl2) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n2 = arrayList.size();
        for (int i = 0; i < n2; ++i) {
            ActionMenuItem actionMenuItem = (ActionMenuItem)arrayList.get(i);
            if (actionMenuItem.getGroupId() != n) continue;
            actionMenuItem.setCheckable(bl);
            actionMenuItem.setExclusiveCheckable(bl2);
        }
    }

    public void setGroupEnabled(int n, boolean bl) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n2 = arrayList.size();
        for (int i = 0; i < n2; ++i) {
            ActionMenuItem actionMenuItem = (ActionMenuItem)arrayList.get(i);
            if (actionMenuItem.getGroupId() != n) continue;
            actionMenuItem.setEnabled(bl);
        }
    }

    public void setGroupVisible(int n, boolean bl) {
        ArrayList<ActionMenuItem> arrayList = this.mItems;
        int n2 = arrayList.size();
        for (int i = 0; i < n2; ++i) {
            ActionMenuItem actionMenuItem = (ActionMenuItem)arrayList.get(i);
            if (actionMenuItem.getGroupId() != n) continue;
            actionMenuItem.setVisible(bl);
        }
    }

    public void setQwertyMode(boolean bl) {
        this.mIsQwerty = bl;
    }

    public int size() {
        return this.mItems.size();
    }
}

