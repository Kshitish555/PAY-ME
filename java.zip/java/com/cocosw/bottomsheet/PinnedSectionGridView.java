/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.widget.GridView
 */
package com.cocosw.bottomsheet;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.GridView;

class PinnedSectionGridView
extends GridView {
    private int mAvailableWidth;
    private int mColumnWidth;
    private int mHorizontalSpacing;
    private int mNumColumns;

    public PinnedSectionGridView(Context context) {
        super(context);
    }

    public PinnedSectionGridView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public PinnedSectionGridView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
    }

    public int getAvailableWidth() {
        int n = this.mAvailableWidth;
        if (n != 0) {
            return n;
        }
        return this.getWidth();
    }

    public int getColumnWidth() {
        return this.mColumnWidth;
    }

    public int getHorizontalSpacing() {
        return this.mHorizontalSpacing;
    }

    public int getNumColumns() {
        return this.mNumColumns;
    }

    public void setColumnWidth(int n) {
        this.mColumnWidth = n;
        super.setColumnWidth(n);
    }

    public void setHorizontalSpacing(int n) {
        this.mHorizontalSpacing = n;
        super.setHorizontalSpacing(n);
    }

    public void setNumColumns(int n) {
        this.mNumColumns = n;
        super.setNumColumns(n);
    }
}

