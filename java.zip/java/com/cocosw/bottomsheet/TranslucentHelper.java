/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.DisplayMetrics
 *  android.view.Display
 *  android.view.ViewConfiguration
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.cocosw.bottomsheet;

import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.ViewConfiguration;
import android.view.Window;
import android.view.WindowManager;

class TranslucentHelper {
    private static final String NAV_BAR_HEIGHT_LANDSCAPE_RES_NAME = "navigation_bar_height_landscape";
    private static final String NAV_BAR_HEIGHT_RES_NAME = "navigation_bar_height";
    private static final String SHOW_NAV_BAR_RES_NAME = "config_showNavigationBar";
    private static final String STATUS_BAR_HEIGHT_RES_NAME = "status_bar_height";
    private final Dialog dialog;
    private boolean mInPortrait;
    boolean mNavBarAvailable;
    private float mSmallestWidthDp;
    int mStatusBarHeight;
    private String sNavBarOverride;

    /*
     * Exception decompiling
     */
    TranslucentHelper(Dialog var1, Context var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl55 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private int getInternalDimensionSize(Resources resources, String string2) {
        int n = resources.getIdentifier(string2, "dimen", "android");
        if (n > 0) {
            return resources.getDimensionPixelSize(n);
        }
        return 0;
    }

    private float getSmallestWidthDp(WindowManager windowManager) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= 16) {
            windowManager.getDefaultDisplay().getRealMetrics(displayMetrics);
        } else {
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        return Math.min((float)((float)displayMetrics.widthPixels / displayMetrics.density), (float)((float)displayMetrics.heightPixels / displayMetrics.density));
    }

    private boolean hasNavBar(Context context) {
        Resources resources = context.getResources();
        int n = resources.getIdentifier(SHOW_NAV_BAR_RES_NAME, "bool", "android");
        if (n != 0) {
            boolean bl = resources.getBoolean(n);
            if ("1".equals((Object)this.sNavBarOverride)) {
                return false;
            }
            if ("0".equals((Object)this.sNavBarOverride)) {
                return true;
            }
            return bl;
        }
        return true ^ ViewConfiguration.get((Context)context).hasPermanentMenuKey();
    }

    private boolean isNavigationAtBottom() {
        return this.mSmallestWidthDp >= 600.0f || this.mInPortrait;
        {
        }
    }

    private void setTranslucentStatus(boolean bl) {
        Window window = this.dialog.getWindow();
        WindowManager.LayoutParams layoutParams = window.getAttributes();
        layoutParams.flags = bl ? 67108864 | layoutParams.flags : -67108865 & layoutParams.flags;
        window.setAttributes(layoutParams);
        window.setFlags(134217728, 134217728);
    }

    int getNavigationBarHeight(Context context) {
        Resources resources = context.getResources();
        if (Build.VERSION.SDK_INT >= 14 && this.hasNavBar(context)) {
            String string2;
            if (this.mInPortrait) {
                string2 = NAV_BAR_HEIGHT_RES_NAME;
            } else {
                if (!this.isNavigationAtBottom()) {
                    return 0;
                }
                string2 = NAV_BAR_HEIGHT_LANDSCAPE_RES_NAME;
            }
            return this.getInternalDimensionSize(resources, string2);
        }
        return 0;
    }
}

