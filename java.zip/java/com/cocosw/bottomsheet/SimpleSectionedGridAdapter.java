/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.DataSetObserver
 *  android.text.TextUtils
 *  android.util.SparseArray
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.BaseAdapter
 *  android.widget.GridView
 *  android.widget.ListAdapter
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Comparator
 */
package com.cocosw.bottomsheet;

import android.content.Context;
import android.database.DataSetObserver;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.TextView;
import com.cocosw.bottomsheet.FillerView;
import com.cocosw.bottomsheet.HeaderLayout;
import com.cocosw.bottomsheet.PinnedSectionGridView;
import java.util.Arrays;
import java.util.Comparator;

class SimpleSectionedGridAdapter
extends BaseAdapter {
    protected static final int TYPE_FILLER = 0;
    protected static final int TYPE_HEADER = 1;
    protected static final int TYPE_HEADER_FILLER = 2;
    private ListAdapter mBaseAdapter;
    private int mColumnWidth;
    private Context mContext;
    private GridView mGridView;
    private int mHeaderLayoutResId;
    private int mHeaderTextViewResId;
    private int mHeaderWidth;
    private int mHorizontalSpacing;
    private Section[] mInitialSections = new Section[0];
    private View mLastViewSeen;
    private LayoutInflater mLayoutInflater;
    private int mNumColumns;
    private int mSectionResourceId;
    SparseArray<Section> mSections = new SparseArray();
    private int mStrechMode;
    private boolean mValid = true;
    private int mWidth;
    private int requestedColumnWidth;
    private int requestedHorizontalSpacing;

    public SimpleSectionedGridAdapter(Context context, BaseAdapter baseAdapter, int n, int n2, int n3) {
        this.mLayoutInflater = (LayoutInflater)context.getSystemService("layout_inflater");
        this.mSectionResourceId = n;
        this.mHeaderLayoutResId = n2;
        this.mHeaderTextViewResId = n3;
        this.mBaseAdapter = baseAdapter;
        this.mContext = context;
        this.mBaseAdapter.registerDataSetObserver(new DataSetObserver(){

            public void onChanged() {
                SimpleSectionedGridAdapter simpleSectionedGridAdapter = SimpleSectionedGridAdapter.this;
                simpleSectionedGridAdapter.mValid = true ^ simpleSectionedGridAdapter.mBaseAdapter.isEmpty();
                SimpleSectionedGridAdapter.this.notifyDataSetChanged();
            }

            public void onInvalidated() {
                SimpleSectionedGridAdapter.this.mValid = false;
                SimpleSectionedGridAdapter.this.notifyDataSetInvalidated();
            }
        });
    }

    private FillerView getFillerView(View view) {
        FillerView fillerView = new FillerView(this.mContext);
        fillerView.setMeasureTarget(view);
        return fillerView;
    }

    private int getHeaderSize() {
        int n = this.mHeaderWidth;
        if (n > 0) {
            return n;
        }
        if (this.mWidth != this.mGridView.getWidth()) {
            this.mStrechMode = this.mGridView.getStretchMode();
            this.mWidth = ((PinnedSectionGridView)this.mGridView).getAvailableWidth() - (this.mGridView.getPaddingLeft() + this.mGridView.getPaddingRight());
            this.mNumColumns = ((PinnedSectionGridView)this.mGridView).getNumColumns();
            this.requestedColumnWidth = ((PinnedSectionGridView)this.mGridView).getColumnWidth();
            this.requestedHorizontalSpacing = ((PinnedSectionGridView)this.mGridView).getHorizontalSpacing();
        }
        int n2 = this.mWidth;
        int n3 = this.mNumColumns;
        int n4 = this.requestedColumnWidth;
        int n5 = n2 - n3 * n4;
        int n6 = n3 - 1;
        int n7 = this.requestedHorizontalSpacing;
        int n8 = n5 - n6 * n7;
        int n9 = this.mStrechMode;
        if (n9 != 0) {
            if (n9 != 1) {
                if (n9 != 2) {
                    if (n9 == 3) {
                        this.mColumnWidth = n4;
                        this.mHorizontalSpacing = n7;
                        this.mWidth = n2 - n8 + 2 * this.mHorizontalSpacing;
                    }
                } else {
                    this.mColumnWidth = n4 + n8 / n3;
                    this.mHorizontalSpacing = n7;
                }
            } else {
                this.mColumnWidth = n4;
                this.mHorizontalSpacing = n3 > 1 ? n7 + n8 / (n3 - 1) : n7 + n8;
            }
        } else {
            this.mWidth = n2 - n8;
            this.mColumnWidth = n4;
            this.mHorizontalSpacing = n7;
        }
        this.mHeaderWidth = this.mWidth + (this.mNumColumns - 1) * (this.mColumnWidth + this.mHorizontalSpacing);
        return this.mHeaderWidth;
    }

    public boolean areAllItemsEnabled() {
        return this.mBaseAdapter.areAllItemsEnabled();
    }

    public int getCount() {
        if (this.mValid) {
            return this.mBaseAdapter.getCount() + this.mSections.size();
        }
        return 0;
    }

    public int getHeaderLayoutResId() {
        return this.mHeaderLayoutResId;
    }

    public Object getItem(int n) {
        if (this.isSectionHeaderPosition(n)) {
            return this.mSections.get(n);
        }
        return this.mBaseAdapter.getItem(this.sectionedPositionToPosition(n));
    }

    public long getItemId(int n) {
        if (this.isSectionHeaderPosition(n)) {
            return Integer.MAX_VALUE - this.mSections.indexOfKey(n);
        }
        return this.mBaseAdapter.getItemId(this.sectionedPositionToPosition(n));
    }

    public int getItemViewType(int n) {
        if (this.isSectionHeaderPosition(n)) {
            return -1 + this.getViewTypeCount();
        }
        return this.mBaseAdapter.getItemViewType(this.sectionedPositionToPosition(n));
    }

    public View getView(int n, View view, ViewGroup viewGroup) {
        View view2;
        if (this.isSectionHeaderPosition(n)) {
            if (view == null) {
                view = this.mLayoutInflater.inflate(this.mSectionResourceId, viewGroup, false);
            } else if (view.findViewById(this.mHeaderLayoutResId) == null) {
                view = this.mLayoutInflater.inflate(this.mSectionResourceId, viewGroup, false);
            }
            int n2 = ((Section)this.mSections.get((int)n)).type;
            if (n2 != 1) {
                if (n2 != 2) {
                    return this.getFillerView(this.mLastViewSeen);
                }
                HeaderLayout headerLayout = (HeaderLayout)view.findViewById(this.mHeaderLayoutResId);
                if (!TextUtils.isEmpty((CharSequence)((Section)this.mSections.get((int)n)).title)) {
                    ((TextView)view.findViewById(this.mHeaderTextViewResId)).setText(((Section)this.mSections.get((int)n)).title);
                }
                headerLayout.setHeaderWidth(0);
                return view;
            }
            HeaderLayout headerLayout = (HeaderLayout)view.findViewById(this.mHeaderLayoutResId);
            if (!TextUtils.isEmpty((CharSequence)((Section)this.mSections.get((int)n)).title)) {
                ((TextView)view.findViewById(this.mHeaderTextViewResId)).setText(((Section)this.mSections.get((int)n)).title);
            }
            headerLayout.setHeaderWidth(this.getHeaderSize());
            return view;
        }
        this.mLastViewSeen = view2 = this.mBaseAdapter.getView(this.sectionedPositionToPosition(n), view, viewGroup);
        return view2;
    }

    public int getViewTypeCount() {
        return 1 + this.mBaseAdapter.getViewTypeCount();
    }

    public boolean hasStableIds() {
        return this.mBaseAdapter.hasStableIds();
    }

    public boolean isEmpty() {
        return this.mBaseAdapter.isEmpty();
    }

    public boolean isEnabled(int n) {
        if (this.isSectionHeaderPosition(n)) {
            return false;
        }
        return this.mBaseAdapter.isEnabled(this.sectionedPositionToPosition(n));
    }

    public boolean isSectionHeaderPosition(int n) {
        return this.mSections.get(n) != null;
    }

    public int positionToSectionedPosition(int n) {
        int n2 = 0;
        for (int i = 0; i < this.mSections.size() && ((Section)this.mSections.valueAt((int)i)).firstPosition <= n; ++i) {
            ++n2;
        }
        return n + n2;
    }

    public int sectionedPositionToPosition(int n) {
        if (this.isSectionHeaderPosition(n)) {
            return -1;
        }
        int n2 = 0;
        for (int i = 0; i < this.mSections.size() && ((Section)this.mSections.valueAt((int)i)).sectionedPosition <= n; ++i) {
            --n2;
        }
        return n + n2;
    }

    public void setGridView(GridView gridView) {
        if (gridView instanceof PinnedSectionGridView) {
            this.mGridView = gridView;
            this.mStrechMode = gridView.getStretchMode();
            this.mWidth = gridView.getWidth() - (this.mGridView.getPaddingLeft() + this.mGridView.getPaddingRight());
            PinnedSectionGridView pinnedSectionGridView = (PinnedSectionGridView)gridView;
            this.mNumColumns = pinnedSectionGridView.getNumColumns();
            this.requestedColumnWidth = pinnedSectionGridView.getColumnWidth();
            this.requestedHorizontalSpacing = pinnedSectionGridView.getHorizontalSpacing();
            return;
        }
        throw new IllegalArgumentException("Does your grid view extends PinnedSectionGridView?");
    }

    public void setSections() {
        Section[] arrsection;
        this.mSections.clear();
        this.getHeaderSize();
        Arrays.sort((Object[])this.mInitialSections, (Comparator)new Comparator<Section>(){

            public int compare(Section section, Section section2) {
                if (section.firstPosition == section2.firstPosition) {
                    return 0;
                }
                if (section.firstPosition < section2.firstPosition) {
                    return -1;
                }
                return 1;
            }
        });
        int n = 0;
        for (int i = 0; i < (arrsection = this.mInitialSections).length; ++i) {
            int n2;
            int n3;
            int n4;
            int n5;
            Section section = arrsection[i];
            int n6 = n;
            for (int j = 0; j < this.mNumColumns - 1; ++j) {
                Section section2 = new Section(section.firstPosition, section.title);
                section2.type = 2;
                section2.sectionedPosition = n6 + section2.firstPosition;
                this.mSections.append(section2.sectionedPosition, (Object)section2);
                ++n6;
            }
            Section section3 = new Section(section.firstPosition, section.title);
            section3.type = 1;
            section3.sectionedPosition = n6 + section3.firstPosition;
            this.mSections.append(section3.sectionedPosition, (Object)section3);
            int n7 = n6 + 1;
            Section[] arrsection2 = this.mInitialSections;
            if (i < arrsection2.length - 1 && (n2 = this.mNumColumns) != (n3 = n2 - (n5 = (n4 = arrsection2[i + 1].firstPosition) - section.firstPosition) % n2)) {
                int n8 = n7;
                for (int j = 0; j < n3; ++j) {
                    Section section4 = new Section(section.firstPosition, section.title);
                    section4.type = 0;
                    section4.sectionedPosition = n4 + n8;
                    this.mSections.append(section4.sectionedPosition, (Object)section4);
                    ++n8;
                }
                n = n8;
                continue;
            }
            n = n7;
        }
        this.notifyDataSetChanged();
    }

    public /* varargs */ void setSections(Section ... arrsection) {
        this.mInitialSections = arrsection;
        this.setSections();
    }

    public static class Section {
        int firstPosition;
        int sectionedPosition;
        CharSequence title;
        int type = 0;

        public Section(int n, CharSequence charSequence) {
            this.firstPosition = n;
            this.title = charSequence;
        }

        public CharSequence getTitle() {
            return this.title;
        }
    }

    public static class ViewHolder {
        public static <T extends View> T get(View view, int n) {
            View view2;
            SparseArray sparseArray = (SparseArray)view.getTag();
            if (sparseArray == null) {
                sparseArray = new SparseArray();
                view.setTag((Object)sparseArray);
            }
            if ((view2 = (View)sparseArray.get(n)) == null) {
                view2 = view.findViewById(n);
                sparseArray.put(n, (Object)view2);
            }
            return (T)view2;
        }
    }

}

