/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.AbsListView
 *  android.widget.FrameLayout
 *  androidx.core.view.MotionEventCompat
 *  androidx.core.view.ViewCompat
 *  androidx.customview.widget.ViewDragHelper
 *  androidx.customview.widget.ViewDragHelper$Callback
 *  java.lang.Math
 *  java.lang.Object
 */
package com.cocosw.bottomsheet;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.FrameLayout;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.ViewCompat;
import androidx.customview.widget.ViewDragHelper;

class ClosableSlidingLayout
extends FrameLayout {
    private static final int INVALID_POINTER = -1;
    private final float MINVEL;
    private boolean collapsible = false;
    private int height;
    private int mActivePointerId;
    private ViewDragHelper mDragHelper = ViewDragHelper.create((ViewGroup)this, (float)0.8f, (ViewDragHelper.Callback)new ViewDragHelper.Callback(){

        public int clampViewPositionVertical(View view, int n, int n2) {
            return Math.max((int)n, (int)ClosableSlidingLayout.this.top);
        }

        public void onViewPositionChanged(View view, int n, int n2, int n3, int n4) {
            if (Build.VERSION.SDK_INT < 11) {
                ClosableSlidingLayout.this.invalidate();
            }
            if (ClosableSlidingLayout.this.height - n2 < 1 && ClosableSlidingLayout.this.mListener != null) {
                ClosableSlidingLayout.this.mDragHelper.cancel();
                ClosableSlidingLayout.this.mListener.onClosed();
                ClosableSlidingLayout.this.mDragHelper.smoothSlideViewTo(view, 0, n2);
            }
        }

        public void onViewReleased(View view, float f, float f2) {
            if (f2 > ClosableSlidingLayout.this.MINVEL) {
                ClosableSlidingLayout.this.dismiss(view, f2);
                return;
            }
            if (view.getTop() >= ClosableSlidingLayout.this.top + ClosableSlidingLayout.this.height / 2) {
                ClosableSlidingLayout.this.dismiss(view, f2);
                return;
            }
            ClosableSlidingLayout.this.mDragHelper.smoothSlideViewTo(view, 0, ClosableSlidingLayout.this.top);
            ViewCompat.postInvalidateOnAnimation((View)ClosableSlidingLayout.this);
        }

        public boolean tryCaptureView(View view, int n) {
            return true;
        }
    });
    private float mInitialMotionY;
    private boolean mIsBeingDragged;
    private SlideListener mListener;
    View mTarget;
    boolean swipeable = true;
    private int top;
    private float yDiff;

    public ClosableSlidingLayout(Context context) {
        this(context, null);
    }

    public ClosableSlidingLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ClosableSlidingLayout(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.MINVEL = 400.0f * this.getResources().getDisplayMetrics().density;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean canChildScrollUp() {
        if (Build.VERSION.SDK_INT >= 14) return ViewCompat.canScrollVertically((View)this.mTarget, (int)-1);
        View view = this.mTarget;
        boolean bl = view instanceof AbsListView;
        boolean bl2 = true;
        if (bl) {
            AbsListView absListView = (AbsListView)view;
            if (absListView.getChildCount() <= 0) return false;
            if (absListView.getFirstVisiblePosition() > 0) return bl2;
            if (absListView.getChildAt(0).getTop() >= absListView.getPaddingTop()) return false;
            return bl2;
        }
        if (view.getScrollY() <= 0) return false;
        return bl2;
    }

    private void dismiss(View view, float f) {
        this.mDragHelper.smoothSlideViewTo(view, 0, this.top + this.height);
        ViewCompat.postInvalidateOnAnimation((View)this);
    }

    private void expand(View view, float f) {
        SlideListener slideListener = this.mListener;
        if (slideListener != null) {
            slideListener.onOpened();
        }
    }

    private float getMotionEventY(MotionEvent motionEvent, int n) {
        int n2 = MotionEventCompat.findPointerIndex((MotionEvent)motionEvent, (int)n);
        if (n2 < 0) {
            return -1.0f;
        }
        return MotionEventCompat.getY((MotionEvent)motionEvent, (int)n2);
    }

    public void computeScroll() {
        if (this.mDragHelper.continueSettling(true)) {
            ViewCompat.postInvalidateOnAnimation((View)this);
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int n = MotionEventCompat.getActionMasked((MotionEvent)motionEvent);
        if (this.isEnabled()) {
            if (this.canChildScrollUp()) {
                return false;
            }
            if (n != 3 && n != 1) {
                if (n != 0) {
                    if (n == 2) {
                        int n2 = this.mActivePointerId;
                        if (n2 == -1) {
                            return false;
                        }
                        float f = this.getMotionEventY(motionEvent, n2);
                        if (f == -1.0f) {
                            return false;
                        }
                        this.yDiff = f - this.mInitialMotionY;
                        if (this.swipeable && this.yDiff > (float)this.mDragHelper.getTouchSlop() && !this.mIsBeingDragged) {
                            this.mIsBeingDragged = true;
                            this.mDragHelper.captureChildView(this.getChildAt(0), 0);
                        }
                    }
                } else {
                    this.height = this.getChildAt(0).getHeight();
                    this.top = this.getChildAt(0).getTop();
                    this.mActivePointerId = MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)0);
                    this.mIsBeingDragged = false;
                    float f = this.getMotionEventY(motionEvent, this.mActivePointerId);
                    if (f == -1.0f) {
                        return false;
                    }
                    this.mInitialMotionY = f;
                    this.yDiff = 0.0f;
                }
                this.mDragHelper.shouldInterceptTouchEvent(motionEvent);
                return this.mIsBeingDragged;
            }
            this.mActivePointerId = -1;
            this.mIsBeingDragged = false;
            if (this.collapsible && -this.yDiff > (float)this.mDragHelper.getTouchSlop()) {
                this.expand(this.mDragHelper.getCapturedView(), 0.0f);
            }
            this.mDragHelper.cancel();
        }
        return false;
    }

    /*
     * Exception decompiling
     */
    public boolean onTouchEvent(MotionEvent var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public void requestDisallowInterceptTouchEvent(boolean bl) {
    }

    void setCollapsible(boolean bl) {
        this.collapsible = bl;
    }

    void setSlideListener(SlideListener slideListener) {
        this.mListener = slideListener;
    }

    static interface SlideListener {
        public void onClosed();

        public void onOpened();
    }

}

