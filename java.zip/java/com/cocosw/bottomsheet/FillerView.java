/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.widget.LinearLayout
 */
package com.cocosw.bottomsheet;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

class FillerView
extends LinearLayout {
    private View mMeasureTarget;

    public FillerView(Context context) {
        super(context);
    }

    public FillerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    protected void onMeasure(int n, int n2) {
        View view = this.mMeasureTarget;
        if (view != null) {
            n2 = View.MeasureSpec.makeMeasureSpec((int)view.getMeasuredHeight(), (int)1073741824);
        }
        super.onMeasure(n, n2);
    }

    public void setMeasureTarget(View view) {
        this.mMeasureTarget = view;
    }
}

