/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.Drawable
 *  android.view.ActionProvider
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.MenuItem
 *  android.view.MenuItem$OnActionExpandListener
 *  android.view.MenuItem$OnMenuItemClickListener
 *  android.view.SubMenu
 *  android.view.View
 *  androidx.core.content.ContextCompat
 *  androidx.core.internal.view.SupportMenuItem
 *  androidx.core.view.ActionProvider
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 */
package com.cocosw.bottomsheet;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.core.content.ContextCompat;
import androidx.core.internal.view.SupportMenuItem;

class ActionMenuItem
implements SupportMenuItem {
    private static final int CHECKABLE = 1;
    private static final int CHECKED = 2;
    private static final int ENABLED = 16;
    private static final int EXCLUSIVE = 4;
    private static final int HIDDEN = 8;
    private static final int NO_ICON;
    private final int mCategoryOrder;
    private MenuItem.OnMenuItemClickListener mClickListener;
    private Context mContext;
    private int mFlags = 16;
    private final int mGroup;
    private Drawable mIconDrawable;
    private int mIconResId = 0;
    private final int mId;
    private Intent mIntent;
    private final int mOrdering;
    private char mShortcutAlphabeticChar;
    private char mShortcutNumericChar;
    private CharSequence mTitle;
    private CharSequence mTitleCondensed;

    public ActionMenuItem(Context context, int n2, int n3, int n4, int n5, CharSequence charSequence) {
        this.mContext = context;
        this.mId = n3;
        this.mGroup = n2;
        this.mCategoryOrder = n4;
        this.mOrdering = n5;
        this.mTitle = charSequence;
    }

    public boolean collapseActionView() {
        return false;
    }

    public boolean expandActionView() {
        return false;
    }

    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    public View getActionView() {
        return null;
    }

    public int getAlphabeticModifiers() {
        return 0;
    }

    public char getAlphabeticShortcut() {
        return this.mShortcutAlphabeticChar;
    }

    public CharSequence getContentDescription() {
        return null;
    }

    public int getGroupId() {
        return this.mGroup;
    }

    public Drawable getIcon() {
        return this.mIconDrawable;
    }

    public ColorStateList getIconTintList() {
        return null;
    }

    public PorterDuff.Mode getIconTintMode() {
        return null;
    }

    public Intent getIntent() {
        return this.mIntent;
    }

    public int getItemId() {
        return this.mId;
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    public int getNumericModifiers() {
        return 0;
    }

    public char getNumericShortcut() {
        return this.mShortcutNumericChar;
    }

    public int getOrder() {
        return this.mOrdering;
    }

    public SubMenu getSubMenu() {
        return null;
    }

    public androidx.core.view.ActionProvider getSupportActionProvider() {
        return null;
    }

    public CharSequence getTitle() {
        return this.mTitle;
    }

    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.mTitleCondensed;
        if (charSequence != null) {
            return charSequence;
        }
        return this.mTitle;
    }

    public CharSequence getTooltipText() {
        return null;
    }

    public boolean hasSubMenu() {
        return false;
    }

    public boolean invoke() {
        MenuItem.OnMenuItemClickListener onMenuItemClickListener = this.mClickListener;
        if (onMenuItemClickListener != null && onMenuItemClickListener.onMenuItemClick((MenuItem)this)) {
            return true;
        }
        Intent intent = this.mIntent;
        if (intent != null) {
            this.mContext.startActivity(intent);
            return true;
        }
        return false;
    }

    public boolean isActionViewExpanded() {
        return false;
    }

    public boolean isCheckable() {
        return (1 & this.mFlags) != 0;
    }

    public boolean isChecked() {
        return (2 & this.mFlags) != 0;
    }

    public boolean isEnabled() {
        return (16 & this.mFlags) != 0;
    }

    public boolean isVisible() {
        return (8 & this.mFlags) == 0;
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    public SupportMenuItem setActionView(int n2) {
        throw new UnsupportedOperationException();
    }

    public SupportMenuItem setActionView(View view) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setAlphabeticShortcut(char c2) {
        this.mShortcutAlphabeticChar = c2;
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c2, int n2) {
        return this;
    }

    public MenuItem setCheckable(boolean bl) {
        this.mFlags = bl | -2 & this.mFlags;
        return this;
    }

    public MenuItem setChecked(boolean bl) {
        int n2 = -3 & this.mFlags;
        int n3 = bl ? 2 : 0;
        this.mFlags = n3 | n2;
        return this;
    }

    public SupportMenuItem setContentDescription(CharSequence charSequence) {
        return this;
    }

    public MenuItem setEnabled(boolean bl) {
        int n2 = -17 & this.mFlags;
        int n3 = bl ? 16 : 0;
        this.mFlags = n3 | n2;
        return this;
    }

    public ActionMenuItem setExclusiveCheckable(boolean bl) {
        int n2 = -5 & this.mFlags;
        int n3 = bl ? 4 : 0;
        this.mFlags = n3 | n2;
        return this;
    }

    public MenuItem setIcon(int n2) {
        this.mIconResId = n2;
        if (n2 > 0) {
            this.mIconDrawable = ContextCompat.getDrawable((Context)this.mContext, (int)n2);
        }
        return this;
    }

    public MenuItem setIcon(Drawable drawable2) {
        this.mIconDrawable = drawable2;
        this.mIconResId = 0;
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        return this;
    }

    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.mIntent = intent;
        return this;
    }

    public MenuItem setNumericShortcut(char c2) {
        this.mShortcutNumericChar = c2;
        return this;
    }

    public MenuItem setNumericShortcut(char c2, int n2) {
        return this;
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.mClickListener = onMenuItemClickListener;
        return this;
    }

    public MenuItem setShortcut(char c2, char c3) {
        this.mShortcutNumericChar = c2;
        this.mShortcutAlphabeticChar = c3;
        return this;
    }

    public MenuItem setShortcut(char c2, char c3, int n2, int n3) {
        return this;
    }

    public void setShowAsAction(int n2) {
    }

    public SupportMenuItem setShowAsActionFlags(int n2) {
        this.setShowAsAction(n2);
        return this;
    }

    public SupportMenuItem setSupportActionProvider(androidx.core.view.ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setTitle(int n2) {
        this.mTitle = this.mContext.getResources().getString(n2);
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.mTitle = charSequence;
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.mTitleCondensed = charSequence;
        return this;
    }

    public SupportMenuItem setTooltipText(CharSequence charSequence) {
        return this;
    }

    public MenuItem setVisible(boolean bl) {
        int n2 = -9 & this.mFlags;
        int n3 = bl ? 0 : 8;
        this.mFlags = n3 | n2;
        return this;
    }
}

