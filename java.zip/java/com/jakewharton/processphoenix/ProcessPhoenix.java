/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningAppProcessInfo
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Process
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runtime
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 */
package com.jakewharton.processphoenix;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public final class ProcessPhoenix
extends Activity {
    private static final String KEY_RESTART_INTENTS = "phoenix_restart_intents";

    private static Intent getRestartIntent(Context context) {
        IllegalStateException illegalStateException;
        Intent intent = new Intent("android.intent.action.MAIN", null);
        intent.addFlags(268468224);
        intent.addCategory("android.intent.category.DEFAULT");
        String string2 = context.getPackageName();
        Iterator iterator = context.getPackageManager().queryIntentActivities(intent, 0).iterator();
        while (iterator.hasNext()) {
            ActivityInfo activityInfo = ((ResolveInfo)iterator.next()).activityInfo;
            if (!activityInfo.packageName.equals((Object)string2)) continue;
            intent.setComponent(new ComponentName(string2, activityInfo.name));
            return intent;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to determine default activity for ");
        stringBuilder.append(string2);
        stringBuilder.append(". Does an activity specify the DEFAULT category in its intent filter?");
        illegalStateException = new IllegalStateException(stringBuilder.toString());
        throw illegalStateException;
    }

    public static boolean isPhoenixProcess(Context context) {
        int n2 = Process.myPid();
        List list = ((ActivityManager)context.getSystemService("activity")).getRunningAppProcesses();
        if (list != null) {
            for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : list) {
                if (runningAppProcessInfo.pid != n2 || !runningAppProcessInfo.processName.endsWith(":phoenix")) continue;
                return true;
            }
        }
        return false;
    }

    public static void triggerRebirth(Context context) {
        Intent[] arrintent = new Intent[]{ProcessPhoenix.getRestartIntent(context)};
        ProcessPhoenix.triggerRebirth(context, arrintent);
    }

    public static /* varargs */ void triggerRebirth(Context context, Intent ... arrintent) {
        Intent intent = new Intent(context, ProcessPhoenix.class);
        intent.addFlags(268435456);
        intent.putParcelableArrayListExtra(KEY_RESTART_INTENTS, new ArrayList((Collection)Arrays.asList((Object[])arrintent)));
        context.startActivity(intent);
        if (context instanceof Activity) {
            ((Activity)context).finish();
        }
        Runtime.getRuntime().exit(0);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ArrayList arrayList = this.getIntent().getParcelableArrayListExtra(KEY_RESTART_INTENTS);
        this.startActivities((Intent[])arrayList.toArray((Object[])new Intent[arrayList.size()]));
        this.finish();
        Runtime.getRuntime().exit(0);
    }
}

