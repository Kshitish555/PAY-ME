/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Bundle
 *  android.util.Log
 *  androidx.core.app.NotificationManagerCompat
 *  com.facebook.react.bridge.ActivityEventListener
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.Promise
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.WritableMap
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.messaging.FirebaseMessaging
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Random
 */
package com.dieam.reactnativepushnotification.modules;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import androidx.core.app.NotificationManagerCompat;
import com.dieam.reactnativepushnotification.helpers.ApplicationBadgeHelper;
import com.dieam.reactnativepushnotification.modules.RNPushNotification;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationHelper;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationJsDelivery;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationRegistrationService;
import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class RNPushNotification
extends ReactContextBaseJavaModule
implements ActivityEventListener {
    public static final String LOG_TAG = "RNPushNotification";
    private RNPushNotificationJsDelivery mJsDelivery;
    private RNPushNotificationHelper mRNPushNotificationHelper;
    private final Random mRandomNumberGenerator = new Random(System.currentTimeMillis());

    public RNPushNotification(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        reactApplicationContext.addActivityEventListener((ActivityEventListener)this);
        this.mRNPushNotificationHelper = new RNPushNotificationHelper((Application)reactApplicationContext.getApplicationContext());
        this.mJsDelivery = new RNPushNotificationJsDelivery(reactApplicationContext);
        this.registerNotificationsRegistration();
    }

    static /* synthetic */ RNPushNotificationJsDelivery access$000(RNPushNotification rNPushNotification) {
        return rNPushNotification.mJsDelivery;
    }

    private Bundle getBundleFromIntent(Intent intent) {
        if (intent.hasExtra("notification")) {
            return intent.getBundleExtra("notification");
        }
        if (intent.hasExtra("google.message_id")) {
            return intent.getExtras();
        }
        return null;
    }

    private void registerNotificationsReceiveNotificationActions(ReadableArray readableArray) {
        IntentFilter intentFilter = new IntentFilter();
        for (int i = 0; i < readableArray.size(); ++i) {
            String string = readableArray.getString(i);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.getReactApplicationContext().getPackageName());
            stringBuilder.append(".");
            stringBuilder.append(string);
            intentFilter.addAction(stringBuilder.toString());
        }
        this.getReactApplicationContext().registerReceiver(new BroadcastReceiver(this){
            final /* synthetic */ RNPushNotification this$0;
            {
                this.this$0 = rNPushNotification;
            }

            public void onReceive(Context context, Intent intent) {
                Bundle bundle = intent.getBundleExtra("notification");
                RNPushNotification.access$000(this.this$0).notifyNotificationAction(bundle);
                ((android.app.NotificationManager)context.getSystemService("notification")).cancel(java.lang.Integer.parseInt((String)bundle.getString("id")));
            }
        }, intentFilter);
    }

    private void registerNotificationsRegistration() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getReactApplicationContext().getPackageName());
        stringBuilder.append(".RNPushNotificationRegisteredToken");
        IntentFilter intentFilter = new IntentFilter(stringBuilder.toString());
        this.getReactApplicationContext().registerReceiver(new BroadcastReceiver(this){
            final /* synthetic */ RNPushNotification this$0;
            {
                this.this$0 = rNPushNotification;
            }

            public void onReceive(Context context, Intent intent) {
                String string = intent.getStringExtra("token");
                WritableMap writableMap = Arguments.createMap();
                writableMap.putString("deviceToken", string);
                RNPushNotification.access$000(this.this$0).sendEvent("remoteNotificationsRegistered", (Object)writableMap);
            }
        }, intentFilter);
    }

    @ReactMethod
    public void cancelAllLocalNotifications() {
        this.mRNPushNotificationHelper.cancelAllScheduledNotifications();
        this.mRNPushNotificationHelper.clearNotifications();
    }

    @ReactMethod
    public void cancelLocalNotifications(ReadableMap readableMap) {
        this.mRNPushNotificationHelper.cancelScheduledNotification(readableMap);
    }

    @ReactMethod
    public void checkPermissions(Promise promise) {
        promise.resolve((Object)NotificationManagerCompat.from((Context)this.getReactApplicationContext()).areNotificationsEnabled());
    }

    @ReactMethod
    public void clearLocalNotification(int n) {
        this.mRNPushNotificationHelper.clearNotification(n);
    }

    public Map<String, Object> getConstants() {
        return new HashMap();
    }

    @ReactMethod
    public void getInitialNotification(Promise promise) {
        Bundle bundle;
        WritableMap writableMap = Arguments.createMap();
        Activity activity = this.getCurrentActivity();
        if (activity != null && (bundle = this.getBundleFromIntent(activity.getIntent())) != null) {
            bundle.putBoolean("foreground", false);
            writableMap.putString("dataJSON", this.mJsDelivery.convertJSON(bundle));
        }
        promise.resolve((Object)writableMap);
    }

    public String getName() {
        return LOG_TAG;
    }

    public void onActivityResult(int n, int n2, Intent intent) {
    }

    public void onActivityResult(Activity activity, int n, int n2, Intent intent) {
        this.onActivityResult(n, n2, intent);
    }

    public void onNewIntent(Intent intent) {
        Bundle bundle = this.getBundleFromIntent(intent);
        if (bundle != null) {
            bundle.putBoolean("foreground", false);
            intent.putExtra("notification", bundle);
            this.mJsDelivery.notifyNotification(bundle);
        }
    }

    @ReactMethod
    public void presentLocalNotification(ReadableMap readableMap) {
        Bundle bundle = Arguments.toBundle((ReadableMap)readableMap);
        if (bundle.getString("id") == null) {
            bundle.putString("id", String.valueOf((int)this.mRandomNumberGenerator.nextInt()));
        }
        this.mRNPushNotificationHelper.sendToNotificationCentre(bundle);
    }

    @ReactMethod
    public void registerNotificationActions(ReadableArray readableArray) {
        this.registerNotificationsReceiveNotificationActions(readableArray);
    }

    @ReactMethod
    public void requestPermissions(String string) {
        ReactApplicationContext reactApplicationContext = this.getReactApplicationContext();
        Intent intent = new Intent((Context)reactApplicationContext, RNPushNotificationRegistrationService.class);
        try {
            intent.putExtra("senderID", string);
            reactApplicationContext.startService(intent);
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("requestPermissions: ");
            stringBuilder.append((Object)exception);
            Log.d((String)"EXCEPTION SERVICE::::::", (String)stringBuilder.toString());
            return;
        }
    }

    @ReactMethod
    public void scheduleLocalNotification(ReadableMap readableMap) {
        Bundle bundle = Arguments.toBundle((ReadableMap)readableMap);
        if (bundle.getString("id") == null) {
            bundle.putString("id", String.valueOf((int)this.mRandomNumberGenerator.nextInt()));
        }
        this.mRNPushNotificationHelper.sendNotificationScheduled(bundle);
    }

    @ReactMethod
    public void setApplicationIconBadgeNumber(int n) {
        ApplicationBadgeHelper.INSTANCE.setApplicationIconBadgeNumber((Context)this.getReactApplicationContext(), n);
    }

    @ReactMethod
    public void subscribeToTopic(String string) {
        FirebaseMessaging.getInstance().subscribeToTopic(string);
    }
}

