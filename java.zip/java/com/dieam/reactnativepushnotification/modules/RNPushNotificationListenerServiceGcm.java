/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningAppProcessInfo
 *  android.app.Application
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Log
 *  com.dieam.reactnativepushnotification.helpers.ApplicationBadgeHelper
 *  com.dieam.reactnativepushnotification.modules.RNPushNotificationHelper
 *  com.dieam.reactnativepushnotification.modules.RNPushNotificationJsDelivery
 *  com.dieam.reactnativepushnotification.modules.RNPushNotificationListenerServiceGcm$1
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.google.android.gms.gcm.GcmListenerService
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.List
 *  java.util.Random
 *  org.json.JSONObject
 */
package com.dieam.reactnativepushnotification.modules;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.dieam.reactnativepushnotification.helpers.ApplicationBadgeHelper;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationHelper;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationJsDelivery;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationListenerServiceGcm;
import com.facebook.react.bridge.ReactApplicationContext;
import com.google.android.gms.gcm.GcmListenerService;
import java.util.List;
import java.util.Random;
import org.json.JSONObject;

public class RNPushNotificationListenerServiceGcm
extends GcmListenerService {
    static /* synthetic */ void access$000(RNPushNotificationListenerServiceGcm rNPushNotificationListenerServiceGcm, ReactApplicationContext reactApplicationContext, Bundle bundle) {
        rNPushNotificationListenerServiceGcm.handleRemotePushNotification(reactApplicationContext, bundle);
    }

    private JSONObject getPushData(String string2) {
        try {
            JSONObject jSONObject = new JSONObject(string2);
            return jSONObject;
        }
        catch (Exception exception) {
            return null;
        }
    }

    private void handleRemotePushNotification(ReactApplicationContext reactApplicationContext, Bundle bundle) {
        if (bundle.getString("id") == null) {
            bundle.putString("id", String.valueOf((int)new Random(System.currentTimeMillis()).nextInt()));
        }
        Boolean bl = this.isApplicationInForeground();
        RNPushNotificationJsDelivery rNPushNotificationJsDelivery = new RNPushNotificationJsDelivery(reactApplicationContext);
        bundle.putBoolean("foreground", bl.booleanValue());
        bundle.putBoolean("userInteraction", false);
        rNPushNotificationJsDelivery.notifyNotification(bundle);
        if (bundle.getString("contentAvailable", "false").equalsIgnoreCase("true")) {
            rNPushNotificationJsDelivery.notifyRemoteFetch(bundle);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("sendNotification: ");
        stringBuilder.append((Object)bundle);
        Log.v((String)"RNPushNotification", (String)stringBuilder.toString());
        if (!bl.booleanValue()) {
            new RNPushNotificationHelper((Application)reactApplicationContext.getApplicationContext()).sendToNotificationCentre(bundle);
        }
    }

    private boolean isApplicationInForeground() {
        List list = ((ActivityManager)this.getSystemService("activity")).getRunningAppProcesses();
        if (list != null) {
            for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : list) {
                String[] arrstring;
                if (!runningAppProcessInfo.processName.equals((Object)this.getApplication().getPackageName()) || runningAppProcessInfo.importance != 100 || (arrstring = runningAppProcessInfo.pkgList).length <= 0) continue;
                arrstring[0];
                return true;
            }
        }
        return false;
    }

    public void onMessageReceived(String string2, Bundle bundle) {
        JSONObject jSONObject = this.getPushData(bundle.getString("data"));
        if (bundle.containsKey("twi_body")) {
            bundle.putString("message", bundle.getString("twi_body"));
        }
        if (jSONObject != null) {
            int n2;
            if (!bundle.containsKey("message")) {
                bundle.putString("message", jSONObject.optString("alert", null));
            }
            if (!bundle.containsKey("title")) {
                bundle.putString("title", jSONObject.optString("title", null));
            }
            if (!bundle.containsKey("sound")) {
                bundle.putString("soundName", jSONObject.optString("sound", null));
            }
            if (!bundle.containsKey("color")) {
                bundle.putString("color", jSONObject.optString("color", null));
            }
            if ((n2 = jSONObject.optInt("badge", -1)) >= 0) {
                ApplicationBadgeHelper.INSTANCE.setApplicationIconBadgeNumber((Context)this, n2);
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onMessageReceived: ");
        stringBuilder.append((Object)bundle);
        Log.v((String)"RNPushNotification", (String)stringBuilder.toString());
        new Handler(Looper.getMainLooper()).post((Runnable)new 1(this, bundle));
    }
}

