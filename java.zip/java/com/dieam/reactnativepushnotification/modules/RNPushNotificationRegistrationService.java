/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.IntentService
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.util.Log
 *  com.google.android.gms.iid.InstanceID
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.dieam.reactnativepushnotification.modules;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.iid.InstanceID;

public class RNPushNotificationRegistrationService
extends IntentService {
    private static final String TAG = "RNPushNotification";

    public RNPushNotificationRegistrationService() {
        super(TAG);
    }

    private void sendRegistrationToken(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getPackageName());
        stringBuilder.append(".RNPushNotificationRegisteredToken");
        Intent intent = new Intent(stringBuilder.toString());
        intent.putExtra("token", string2);
        this.sendBroadcast(intent);
    }

    protected void onHandleIntent(Intent intent) {
        try {
            String string2 = intent.getStringExtra("senderID");
            this.sendRegistrationToken(InstanceID.getInstance((Context)this).getToken(string2, "GCM", null));
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("RNPushNotification failed to process intent ");
            stringBuilder.append((Object)intent);
            Log.e((String)TAG, (String)stringBuilder.toString(), (Throwable)exception);
            return;
        }
    }
}

