/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.Log
 *  androidx.core.content.res.ResourcesCompat
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.dieam.reactnativepushnotification.modules;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import androidx.core.content.res.ResourcesCompat;

class RNPushNotificationConfig {
    private static final String KEY_CHANNEL_DESCRIPTION = "com.dieam.reactnativepushnotification.notification_channel_description";
    private static final String KEY_CHANNEL_NAME = "com.dieam.reactnativepushnotification.notification_channel_name";
    private static final String KEY_NOTIFICATION_COLOR = "com.dieam.reactnativepushnotification.notification_color";
    private static Bundle metadata;
    private Context context;

    public RNPushNotificationConfig(Context context) {
        this.context = context;
        if (metadata == null) {
            try {
                metadata = context.getPackageManager().getApplicationInfo((String)context.getPackageName(), (int)128).metaData;
                return;
            }
            catch (PackageManager.NameNotFoundException nameNotFoundException) {
                nameNotFoundException.printStackTrace();
                Log.e((String)"RNPushNotification", (String)"Error reading application meta, falling back to defaults");
                metadata = new Bundle();
            }
        }
    }

    public String getChannelDescription() {
        try {
            String string2 = metadata.getString(KEY_CHANNEL_DESCRIPTION);
            return string2;
        }
        catch (Exception exception) {
            Log.w((String)"RNPushNotification", (String)"Unable to find com.dieam.reactnativepushnotification.notification_channel_description in manifest. Falling back to default");
            return "";
        }
    }

    public String getChannelName() {
        try {
            String string2 = metadata.getString(KEY_CHANNEL_NAME);
            return string2;
        }
        catch (Exception exception) {
            Log.w((String)"RNPushNotification", (String)"Unable to find com.dieam.reactnativepushnotification.notification_channel_name in manifest. Falling back to default");
            return "rn-push-notification-channel";
        }
    }

    public int getNotificationColor() {
        try {
            int n = metadata.getInt(KEY_NOTIFICATION_COLOR);
            int n2 = ResourcesCompat.getColor((Resources)this.context.getResources(), (int)n, null);
            return n2;
        }
        catch (Exception exception) {
            Log.w((String)"RNPushNotification", (String)"Unable to find com.dieam.reactnativepushnotification.notification_color in manifest. Falling back to default");
            return -1;
        }
    }
}

