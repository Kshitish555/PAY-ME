/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.util.Log
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package com.dieam.reactnativepushnotification.modules;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationHelper;

public class RNPushNotificationPublisher
extends BroadcastReceiver {
    static final String NOTIFICATION_ID = "notificationId";

    public void onReceive(Context context, Intent intent) {
        int n = intent.getIntExtra(NOTIFICATION_ID, 0);
        long l = System.currentTimeMillis();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NotificationPublisher: Prepare To Publish: ");
        stringBuilder.append(n);
        stringBuilder.append(", Now Time: ");
        stringBuilder.append(l);
        Log.i((String)"RNPushNotification", (String)stringBuilder.toString());
        new RNPushNotificationHelper((Application)context.getApplicationContext()).sendToNotificationCentre(intent.getExtras());
    }
}

