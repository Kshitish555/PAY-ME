/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AlarmManager
 *  android.app.Application
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.Color
 *  android.media.RingtoneManager
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.util.Log
 *  androidx.core.app.NotificationCompat
 *  androidx.core.app.NotificationCompat$BigTextStyle
 *  androidx.core.app.NotificationCompat$Builder
 *  androidx.core.app.NotificationCompat$Style
 *  com.facebook.react.bridge.ReadableMap
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Arrays
 *  java.util.Date
 *  java.util.GregorianCalendar
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Set
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dieam.reactnativepushnotification.modules;

import android.app.AlarmManager;
import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationAttributes;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationConfig;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationPublisher;
import com.facebook.react.bridge.ReadableMap;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RNPushNotificationHelper {
    private static final long DEFAULT_VIBRATION = 300L;
    private static final String NOTIFICATION_CHANNEL_ID = "rn-push-notification-channel-id";
    private static final long ONE_DAY = 86400000L;
    private static final long ONE_HOUR = 3600000L;
    private static final int ONE_MINUTE = 60000;
    public static final String PREFERENCES_KEY = "rn_push_notification";
    private static boolean channelCreated;
    private RNPushNotificationConfig config;
    private Context context;
    private final SharedPreferences scheduledNotificationsPersistence;

    public RNPushNotificationHelper(Application application) {
        this.context = application;
        this.config = new RNPushNotificationConfig((Context)application);
        this.scheduledNotificationsPersistence = application.getSharedPreferences(PREFERENCES_KEY, 0);
    }

    private void cancelScheduledNotification(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cancelling notification: ");
        stringBuilder.append(string2);
        Log.i((String)"RNPushNotification", (String)stringBuilder.toString());
        Bundle bundle = new Bundle();
        bundle.putString("id", string2);
        this.getAlarmManager().cancel(this.toScheduleNotificationIntent(bundle));
        if (this.scheduledNotificationsPersistence.contains(string2)) {
            SharedPreferences.Editor editor = this.scheduledNotificationsPersistence.edit();
            editor.remove(string2);
            RNPushNotificationHelper.commit(editor);
        } else {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Unable to find notification ");
            stringBuilder2.append(string2);
            Log.w((String)"RNPushNotification", (String)stringBuilder2.toString());
        }
        this.notificationManager().cancel(Integer.parseInt((String)string2));
    }

    private void checkOrCreateChannel(NotificationManager notificationManager) {
        int n;
        block21 : {
            int n2;
            block22 : {
                if (Build.VERSION.SDK_INT < 26) {
                    return;
                }
                if (channelCreated) {
                    return;
                }
                if (notificationManager == null) {
                    return;
                }
                String string2 = new Bundle().getString("importance");
                n = 4;
                if (string2 == null) break block21;
                String string3 = string2.toLowerCase();
                switch (string3.hashCode()) {
                    default: {
                        break;
                    }
                    case 1544803905: {
                        if (!string3.equals((Object)"default")) break;
                        n2 = 0;
                        break block22;
                    }
                    case 3387192: {
                        if (!string3.equals((Object)"none")) break;
                        n2 = 5;
                        break block22;
                    }
                    case 3202466: {
                        if (!string3.equals((Object)"high")) break;
                        n2 = 2;
                        break block22;
                    }
                    case 108114: {
                        if (!string3.equals((Object)"min")) break;
                        n2 = 4;
                        break block22;
                    }
                    case 107876: {
                        if (!string3.equals((Object)"max")) break;
                        n2 = 1;
                        break block22;
                    }
                    case 107348: {
                        if (!string3.equals((Object)"low")) break;
                        n2 = 3;
                        break block22;
                    }
                    case -1626174665: {
                        if (!string3.equals((Object)"unspecified")) break;
                        n2 = 6;
                        break block22;
                    }
                }
                n2 = -1;
            }
            switch (n2) {
                default: {
                    break;
                }
                case 6: {
                    n = -1000;
                    break;
                }
                case 5: {
                    n = 0;
                    break;
                }
                case 4: {
                    n = 1;
                    break;
                }
                case 3: {
                    n = 2;
                    break;
                }
                case 1: {
                    n = 5;
                    break;
                }
                case 0: {
                    n = 3;
                }
                case 2: 
            }
        }
        String string4 = this.config.getChannelName() != null ? this.config.getChannelName() : "rn-push-notification-channel";
        NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, (CharSequence)string4, n);
        notificationChannel.setDescription(this.config.getChannelDescription());
        notificationChannel.enableLights(true);
        notificationChannel.enableVibration(true);
        notificationManager.createNotificationChannel(notificationChannel);
        channelCreated = true;
    }

    private static void commit(SharedPreferences.Editor editor) {
        if (Build.VERSION.SDK_INT < 9) {
            editor.commit();
            return;
        }
        editor.apply();
    }

    private AlarmManager getAlarmManager() {
        return (AlarmManager)this.context.getSystemService("alarm");
    }

    private NotificationManager notificationManager() {
        return (NotificationManager)this.context.getSystemService("notification");
    }

    private void scheduleNextNotificationIfRepeating(Bundle bundle) {
        block12 : {
            long l;
            block20 : {
                long l2;
                long l3;
                block14 : {
                    block15 : {
                        long l4;
                        block21 : {
                            block16 : {
                                block17 : {
                                    block18 : {
                                        block19 : {
                                            int n;
                                            block13 : {
                                                String string2 = bundle.getString("repeatType");
                                                l2 = (long)bundle.getDouble("repeatTime");
                                                if (string2 == null) break block12;
                                                l3 = (long)bundle.getDouble("fireDate");
                                                if (!Arrays.asList((Object[])new String[]{"time", "month", "week", "day", "hour", "minute"}).contains((Object)string2)) {
                                                    Log.w((String)"RNPushNotification", (String)String.format((String)"Invalid repeatType specified as %s", (Object[])new Object[]{string2}));
                                                    return;
                                                }
                                                if ("time".equals((Object)string2) && l2 <= 0L) {
                                                    Log.w((String)"RNPushNotification", (String)"repeatType specified as time but no repeatTime has been mentioned");
                                                    return;
                                                }
                                                switch (string2.hashCode()) {
                                                    default: {
                                                        break;
                                                    }
                                                    case 104080000: {
                                                        if (!string2.equals((Object)"month")) break;
                                                        n = 1;
                                                        break block13;
                                                    }
                                                    case 3645428: {
                                                        if (!string2.equals((Object)"week")) break;
                                                        n = 2;
                                                        break block13;
                                                    }
                                                    case 3560141: {
                                                        if (!string2.equals((Object)"time")) break;
                                                        n = 0;
                                                        break block13;
                                                    }
                                                    case 3208676: {
                                                        if (!string2.equals((Object)"hour")) break;
                                                        n = 4;
                                                        break block13;
                                                    }
                                                    case 99228: {
                                                        if (!string2.equals((Object)"day")) break;
                                                        n = 3;
                                                        break block13;
                                                    }
                                                    case -1074026988: {
                                                        if (!string2.equals((Object)"minute")) break;
                                                        n = 5;
                                                        break block13;
                                                    }
                                                }
                                                n = -1;
                                            }
                                            if (n == 0) break block14;
                                            if (n == 1) break block15;
                                            if (n == 2) break block16;
                                            if (n == 3) break block17;
                                            if (n == 4) break block18;
                                            if (n == 5) break block19;
                                            l = 0L;
                                            break block20;
                                        }
                                        l4 = 60000L;
                                        break block21;
                                    }
                                    l4 = 3600000L;
                                    break block21;
                                }
                                l4 = 86400000L;
                                break block21;
                            }
                            l4 = 604800000L;
                        }
                        l = l4 + l3;
                        break block20;
                    }
                    GregorianCalendar gregorianCalendar = new GregorianCalendar();
                    gregorianCalendar.setTime(new Date(l3));
                    int n = gregorianCalendar.get(5);
                    int n2 = gregorianCalendar.get(12);
                    int n3 = gregorianCalendar.get(11);
                    GregorianCalendar gregorianCalendar2 = new GregorianCalendar();
                    gregorianCalendar2.setTime(new Date());
                    int n4 = gregorianCalendar2.get(2);
                    int n5 = n4 < 11 ? n4 + 1 : 0;
                    int n6 = gregorianCalendar2.get(1);
                    int n7 = n5 == 0 ? 1 : 0;
                    gregorianCalendar2.set(1, n6 + n7);
                    gregorianCalendar2.set(2, n5);
                    int n8 = gregorianCalendar2.getActualMaximum(5);
                    if (n > n8) {
                        n = n8;
                    }
                    gregorianCalendar2.set(5, n);
                    gregorianCalendar2.set(11, n3);
                    gregorianCalendar2.set(12, n2);
                    gregorianCalendar2.set(13, 0);
                    l = gregorianCalendar2.getTimeInMillis();
                    break block20;
                }
                l = l2 + l3;
            }
            if (l != 0L) {
                Object[] arrobject = new Object[]{bundle.getString("id"), Long.toString((long)l)};
                Log.d((String)"RNPushNotification", (String)String.format((String)"Repeating notification with id %s at time %s", (Object[])arrobject));
                bundle.putDouble("fireDate", (double)l);
                this.sendNotificationScheduled(bundle);
            }
        }
    }

    private PendingIntent toScheduleNotificationIntent(Bundle bundle) {
        int n = Integer.parseInt((String)bundle.getString("id"));
        Intent intent = new Intent(this.context, RNPushNotificationPublisher.class);
        intent.putExtra("notificationId", n);
        intent.putExtras(bundle);
        return PendingIntent.getBroadcast((Context)this.context, (int)n, (Intent)intent, (int)134217728);
    }

    public void cancelAllScheduledNotifications() {
        Log.i((String)"RNPushNotification", (String)"Cancelling all notifications");
        Iterator iterator = this.scheduledNotificationsPersistence.getAll().keySet().iterator();
        while (iterator.hasNext()) {
            this.cancelScheduledNotification((String)iterator.next());
        }
    }

    public void cancelScheduledNotification(ReadableMap readableMap) {
        for (String string2 : this.scheduledNotificationsPersistence.getAll().keySet()) {
            String string3 = this.scheduledNotificationsPersistence.getString(string2, null);
            if (string3 == null) continue;
            try {
                if (!RNPushNotificationAttributes.fromJson(string3).matches(readableMap)) continue;
                this.cancelScheduledNotification(string2);
            }
            catch (JSONException jSONException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Problem dealing with scheduled notification ");
                stringBuilder.append(string2);
                Log.w((String)"RNPushNotification", (String)stringBuilder.toString(), (Throwable)jSONException);
            }
        }
    }

    public void clearNotification(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Clearing notification: ");
        stringBuilder.append(n);
        Log.i((String)"RNPushNotification", (String)stringBuilder.toString());
        this.notificationManager().cancel(n);
    }

    public void clearNotifications() {
        Log.i((String)"RNPushNotification", (String)"Clearing alerts from the notification centre");
        this.notificationManager().cancelAll();
    }

    public Class getMainActivityClass() {
        String string2 = this.context.getPackageName();
        String string3 = this.context.getPackageManager().getLaunchIntentForPackage(string2).getComponent().getClassName();
        try {
            Class class_ = Class.forName((String)string3);
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            classNotFoundException.printStackTrace();
            return null;
        }
    }

    public void sendNotificationScheduled(Bundle bundle) {
        if (this.getMainActivityClass() == null) {
            Log.e((String)"RNPushNotification", (String)"No activity class found for the scheduled notification");
            return;
        }
        if (bundle.getString("message") == null) {
            Log.e((String)"RNPushNotification", (String)"No message specified for the scheduled notification");
            return;
        }
        if (bundle.getString("id") == null) {
            Log.e((String)"RNPushNotification", (String)"No notification ID specified for the scheduled notification");
            return;
        }
        if (bundle.getDouble("fireDate") == 0.0) {
            Log.e((String)"RNPushNotification", (String)"No date specified for the scheduled notification");
            return;
        }
        RNPushNotificationAttributes rNPushNotificationAttributes = new RNPushNotificationAttributes(bundle);
        String string2 = rNPushNotificationAttributes.getId();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Storing push notification with id ");
        stringBuilder.append(string2);
        Log.d((String)"RNPushNotification", (String)stringBuilder.toString());
        SharedPreferences.Editor editor = this.scheduledNotificationsPersistence.edit();
        editor.putString(string2, rNPushNotificationAttributes.toJson().toString());
        RNPushNotificationHelper.commit(editor);
        if (!this.scheduledNotificationsPersistence.contains(string2)) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Failed to save ");
            stringBuilder2.append(string2);
            Log.e((String)"RNPushNotification", (String)stringBuilder2.toString());
        }
        this.sendNotificationScheduledCore(bundle);
    }

    public void sendNotificationScheduledCore(Bundle bundle) {
        long l = (long)bundle.getDouble("fireDate");
        PendingIntent pendingIntent = this.toScheduleNotificationIntent(bundle);
        Object[] arrobject = new Object[]{bundle.getString("id"), Long.toString((long)l)};
        Log.d((String)"RNPushNotification", (String)String.format((String)"Setting a notification with id %s at time %s", (Object[])arrobject));
        if (Build.VERSION.SDK_INT >= 19) {
            this.getAlarmManager().setExact(0, l, pendingIntent);
            return;
        }
        this.getAlarmManager().set(0, l, pendingIntent);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void sendToNotificationCentre(Bundle var1_1) {
        block47 : {
            block46 : {
                block58 : {
                    block53 : {
                        block57 : {
                            block56 : {
                                block54 : {
                                    block55 : {
                                        block52 : {
                                            block45 : {
                                                block49 : {
                                                    block50 : {
                                                        block51 : {
                                                            var5_2 = this.getMainActivityClass();
                                                            if (var5_2 == null) {
                                                                Log.e((String)"RNPushNotification", (String)"No activity class found for the notification");
                                                                return;
                                                            }
                                                            if (var1_1.getString("message") == null) {
                                                                var7_3 = new StringBuilder();
                                                                var7_3.append("Cannot send to notification centre because there is no 'message' field in: ");
                                                                var7_3.append((Object)var1_1);
                                                                Log.d((String)"RNPushNotification", (String)var7_3.toString());
                                                                return;
                                                            }
                                                            var11_4 = var1_1.getString("id");
                                                            if (var11_4 == null) {
                                                                Log.e((String)"RNPushNotification", (String)"No notification ID specified for the notification");
                                                                return;
                                                            }
                                                            var13_5 = this.context.getResources();
                                                            var14_6 = this.context.getPackageName();
                                                            var15_7 = var1_1.getString("title");
                                                            if (var15_7 == null) {
                                                                var16_8 = this.context.getApplicationInfo();
                                                                var15_7 = this.context.getPackageManager().getApplicationLabel(var16_8).toString();
                                                            }
                                                            if ((var17_9 = var1_1.getString("priority")) != null) {
                                                                var89_10 = var17_9.toLowerCase();
                                                                switch (var89_10.hashCode()) {
                                                                    case 1544803905: {
                                                                        if (!var89_10.equals((Object)"default")) break;
                                                                        var90_11 = 4;
                                                                        ** break;
                                                                    }
                                                                    case 3202466: {
                                                                        if (!var89_10.equals((Object)"high")) break;
                                                                        var90_11 = 1;
                                                                        ** break;
                                                                    }
                                                                    case 108114: {
                                                                        if (!var89_10.equals((Object)"min")) break;
                                                                        var90_11 = 3;
                                                                        ** break;
                                                                    }
                                                                    case 107876: {
                                                                        if (!var89_10.equals((Object)"max")) break;
                                                                        var90_11 = 0;
                                                                        ** break;
                                                                    }
                                                                    case 107348: {
                                                                        if (!var89_10.equals((Object)"low")) break;
                                                                        var90_11 = 2;
                                                                        ** break;
                                                                    }
                                                                }
                                                            }
                                                            break block45;
                                                            {
                                                                catch (Exception var2_55) {
                                                                    var3_43 = "RNPushNotification";
                                                                    break block46;
                                                                }
                                                            }
                                                            var90_11 = -1;
lbl50: // 6 sources:
                                                            if (var90_11 == 0) break block49;
                                                            if (var90_11 == 1) break block45;
                                                            if (var90_11 == 2) break block50;
                                                            if (var90_11 == 3) break block51;
                                                            if (var90_11 != 4) break block45;
                                                            var18_12 = 0;
                                                            break block52;
                                                        }
                                                        var18_12 = -2;
                                                        break block52;
                                                    }
                                                    var18_12 = -1;
                                                    break block52;
                                                }
                                                var18_12 = 2;
                                                break block52;
                                            }
                                            var18_12 = 1;
                                        }
                                        if ((var19_13 = var1_1.getString("visibility")) == null) break block53;
                                        var20_14 = var19_13.toLowerCase();
                                        var21_15 = var20_14.hashCode();
                                        if (var21_15 == -977423767) break block54;
                                        if (var21_15 == -906277200) break block55;
                                        if (var21_15 != -314497661 || !var20_14.equals((Object)"private")) ** GOTO lbl-1000
                                        var22_16 = 0;
                                        break block56;
                                    }
                                    if (!var20_14.equals((Object)"secret")) ** GOTO lbl-1000
                                    var22_16 = 2;
                                    break block56;
                                }
                                if (var20_14.equals((Object)"public")) {
                                    var22_16 = 1;
                                } else lbl-1000: // 3 sources:
                                {
                                    var22_16 = -1;
                                }
                            }
                            if (var22_16 == 0) break block53;
                            if (var22_16 == 1) break block57;
                            if (var22_16 != 2) break block53;
                            var23_17 = -1;
                            break block58;
                        }
                        var23_17 = 1;
                        break block58;
                    }
                    var23_17 = 0;
                }
                var24_18 = this.context;
                try {
                    block59 : {
                        var25_19 = new NotificationCompat.Builder(var24_18, "rn-push-notification-channel-id").setContentTitle((CharSequence)var15_7).setTicker((CharSequence)var1_1.getString("ticker")).setVisibility(var23_17).setPriority(var18_12).setAutoCancel(var1_1.getBoolean("autoCancel", true));
                        var26_20 = var1_1.getString("group");
                        if (var26_20 != null) {
                            var25_19.setGroup(var26_20);
                        }
                        var25_19.setContentText((CharSequence)var1_1.getString("message"));
                        var29_21 = var1_1.getString("largeIcon");
                        var30_22 = var1_1.getString("subText");
                        if (var30_22 != null) {
                            var25_19.setSubText((CharSequence)var30_22);
                        }
                        if ((var32_23 = var1_1.getString("number")) != null) {
                            var25_19.setNumber(Integer.parseInt((String)var32_23));
                        }
                        if ((var35_25 = (var34_24 = var1_1.getString("smallIcon")) != null ? var13_5.getIdentifier(var34_24, "mipmap", var14_6) : var13_5.getIdentifier("ic_notification", "mipmap", var14_6)) == 0 && (var35_25 = var13_5.getIdentifier("ic_launcher", "mipmap", var14_6)) == 0) {
                            var35_25 = 17301659;
                        }
                        var36_26 = var29_21 != null ? var13_5.getIdentifier(var29_21, "mipmap", var14_6) : var13_5.getIdentifier("ic_launcher", "mipmap", var14_6);
                        var37_27 = BitmapFactory.decodeResource((Resources)var13_5, (int)var36_26);
                        if (var36_26 != 0 && (var29_21 != null || Build.VERSION.SDK_INT >= 21)) {
                            var25_19.setLargeIcon(var37_27);
                        }
                        var25_19.setSmallIcon(var35_25);
                        var39_28 = var1_1.getString("bigText");
                        if (var39_28 == null) {
                            var39_28 = var1_1.getString("message");
                        }
                        var25_19.setStyle((NotificationCompat.Style)new NotificationCompat.BigTextStyle().bigText((CharSequence)var39_28));
                        var41_29 = new Intent(this.context, var5_2);
                        var41_29.addFlags(536870912);
                        var1_1.putBoolean("userInteraction", true);
                        var41_29.putExtra("notification", var1_1);
                        if (!var1_1.containsKey("playSound") || var1_1.getBoolean("playSound")) {
                            var44_30 = RingtoneManager.getDefaultUri((int)2);
                            var45_31 = var1_1.getString("soundName");
                            if (var45_31 != null && !"default".equalsIgnoreCase(var45_31)) {
                                if (this.context.getResources().getIdentifier(var45_31, "raw", this.context.getPackageName()) != 0) {
                                    var82_32 = this.context.getResources().getIdentifier(var45_31, "raw", this.context.getPackageName());
                                } else {
                                    var81_33 = var45_31.substring(0, var45_31.lastIndexOf(46));
                                    var82_32 = this.context.getResources().getIdentifier(var81_33, "raw", this.context.getPackageName());
                                }
                                var83_34 = new StringBuilder();
                                var83_34.append("android.resource://");
                                var83_34.append(this.context.getPackageName());
                                var83_34.append("/");
                                var83_34.append(var82_32);
                                var44_30 = Uri.parse((String)var83_34.toString());
                            }
                            var25_19.setSound(var44_30);
                        }
                        if (var1_1.containsKey("ongoing") || var1_1.getBoolean("ongoing")) {
                            var25_19.setOngoing(var1_1.getBoolean("ongoing"));
                        }
                        if (Build.VERSION.SDK_INT >= 21) {
                            var25_19.setCategory("call");
                            var77_35 = var1_1.getString("color");
                            var78_36 = this.config.getNotificationColor();
                            if (var77_35 != null) {
                                var25_19.setColor(Color.parseColor((String)var77_35));
                            } else if (var78_36 != -1) {
                                var25_19.setColor(var78_36);
                            }
                        }
                        var48_37 = Integer.parseInt((String)var11_4);
                        var49_38 = PendingIntent.getActivity((Context)this.context, (int)var48_37, (Intent)var41_29, (int)134217728);
                        var50_39 = this.notificationManager();
                        this.checkOrCreateChannel(var50_39);
                        var25_19.setContentIntent(var49_38);
                        if (var1_1.containsKey("vibrate") && !var1_1.getBoolean("vibrate")) break block59;
                    }
lbl160: // 2 sources:
                    do {
                        try {
                            var75_41 = var1_1.getString("actions") != null ? new JSONArray(var1_1.getString("actions")) : null;
                            var57_42 = var75_41;
                            var3_43 = "RNPushNotification";
                        }
                        catch (JSONException var55_44) {
                            var3_43 = "RNPushNotification";
                            try {
                                Log.e((String)var3_43, (String)"Exception while converting actions to JSON object.", (Throwable)var55_44);
                                var57_42 = null;
                                break block47;
                            }
                            catch (Exception var2_53) {
                            }
                        }
                        break;
                    } while (true);
                }
                catch (Exception var2_54) {
                    var3_43 = "RNPushNotification";
                }
            }
            Log.e((String)var3_43, (String)"failed to send push notification", (Throwable)var2_56);
            return;
            var52_40 = var1_1.containsKey("vibration") != false ? (long)var1_1.getDouble("vibration") : 300L;
            if (var52_40 == 0L) {
                var52_40 = 300L;
            }
            var25_19.setVibrate(new long[]{0L, var52_40});
            ** while (true)
        }
        if (var57_42 == null) ** GOTO lbl205
        var58_45 = 0;
        do {
            block48 : {
                block60 : {
                    if (var58_45 >= (var59_46 = var57_42.length())) break block60;
                    try {
                        var65_48 = var57_42.getString(var58_45);
                    }
                    catch (JSONException var63_47) {
                        Log.e((String)var3_43, (String)"Exception while getting action from actionsArray.", (Throwable)var63_47);
                        break block48;
                    }
                    var66_49 = new Intent(this.context, var5_2);
                    var66_49.addFlags(536870912);
                    var68_50 = new StringBuilder();
                    var68_50.append(this.context.getPackageName());
                    var68_50.append(".");
                    var68_50.append(var65_48);
                    var66_49.setAction(var68_50.toString());
                    var1_1.putString("action", var65_48);
                    var66_49.putExtra("notification", var1_1);
                    var25_19.addAction(0, (CharSequence)var65_48, PendingIntent.getActivity((Context)this.context, (int)var48_37, (Intent)var66_49, (int)134217728));
                    break block48;
                }
                if (this.scheduledNotificationsPersistence.getString(var11_4, null) != null) {
                    var61_51 = this.scheduledNotificationsPersistence.edit();
                    var61_51.remove(var11_4);
                    RNPushNotificationHelper.commit(var61_51);
                }
                var60_52 = var25_19.build();
                var60_52.defaults = 4 | var60_52.defaults;
                if (var1_1.containsKey("tag")) {
                    var50_39.notify(var1_1.getString("tag"), var48_37, var60_52);
                } else {
                    var50_39.notify(var48_37, var60_52);
                }
                this.scheduleNextNotificationIfRepeating(var1_1);
                return;
            }
            ++var58_45;
        } while (true);
    }
}

