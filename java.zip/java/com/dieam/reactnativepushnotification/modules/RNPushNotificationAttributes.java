/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.util.Log
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.ReadableMapKeySetIterator
 *  com.facebook.react.bridge.ReadableType
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dieam.reactnativepushnotification.modules;

import android.os.Bundle;
import android.util.Log;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableMapKeySetIterator;
import com.facebook.react.bridge.ReadableType;
import org.json.JSONException;
import org.json.JSONObject;

public class RNPushNotificationAttributes {
    private static final String ACTIONS = "actions";
    private static final String AUTO_CANCEL = "autoCancel";
    private static final String BIG_TEXT = "bigText";
    private static final String COLOR = "color";
    private static final String FIRE_DATE = "fireDate";
    private static final String GROUP = "group";
    private static final String ID = "id";
    private static final String LARGE_ICON = "largeIcon";
    private static final String MESSAGE = "message";
    private static final String NUMBER = "number";
    private static final String ONGOING = "ongoing";
    private static final String PLAY_SOUND = "playSound";
    private static final String REPEAT_TIME = "repeatTime";
    private static final String REPEAT_TYPE = "repeatType";
    private static final String SMALL_ICON = "smallIcon";
    private static final String SOUND = "sound";
    private static final String SUB_TEXT = "subText";
    private static final String TAG = "tag";
    private static final String TICKER = "ticker";
    private static final String TITLE = "title";
    private static final String USER_INTERACTION = "userInteraction";
    private static final String VIBRATE = "vibrate";
    private static final String VIBRATION = "vibration";
    private final String actions;
    private final boolean autoCancel;
    private final String bigText;
    private final String color;
    private final double fireDate;
    private final String group;
    private final String id;
    private final String largeIcon;
    private final String message;
    private final String number;
    private final boolean ongoing;
    private final boolean playSound;
    private final double repeatTime;
    private final String repeatType;
    private final String smallIcon;
    private final String sound;
    private final String subText;
    private final String tag;
    private final String ticker;
    private final String title;
    private final boolean userInteraction;
    private final boolean vibrate;
    private final double vibration;

    public RNPushNotificationAttributes(Bundle bundle) {
        this.id = bundle.getString(ID);
        this.message = bundle.getString(MESSAGE);
        this.fireDate = bundle.getDouble(FIRE_DATE);
        this.title = bundle.getString(TITLE);
        this.ticker = bundle.getString(TICKER);
        this.autoCancel = bundle.getBoolean(AUTO_CANCEL);
        this.largeIcon = bundle.getString(LARGE_ICON);
        this.smallIcon = bundle.getString(SMALL_ICON);
        this.bigText = bundle.getString(BIG_TEXT);
        this.subText = bundle.getString(SUB_TEXT);
        this.number = bundle.getString(NUMBER);
        this.sound = bundle.getString(SOUND);
        this.color = bundle.getString(COLOR);
        this.group = bundle.getString(GROUP);
        this.userInteraction = bundle.getBoolean(USER_INTERACTION);
        this.playSound = bundle.getBoolean(PLAY_SOUND);
        this.vibrate = bundle.getBoolean(VIBRATE);
        this.vibration = bundle.getDouble(VIBRATION);
        this.actions = bundle.getString(ACTIONS);
        this.tag = bundle.getString(TAG);
        this.repeatType = bundle.getString(REPEAT_TYPE);
        this.repeatTime = bundle.getDouble(REPEAT_TIME);
        this.ongoing = bundle.getBoolean(ONGOING);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private RNPushNotificationAttributes(JSONObject jSONObject) {
        try {
            String string2 = jSONObject.has(ID) ? jSONObject.getString(ID) : null;
            this.id = string2;
            String string3 = jSONObject.has(MESSAGE) ? jSONObject.getString(MESSAGE) : null;
            this.message = string3;
            boolean bl = jSONObject.has(FIRE_DATE);
            double d = 0.0;
            double d2 = bl ? jSONObject.getDouble(FIRE_DATE) : d;
            this.fireDate = d2;
            String string4 = jSONObject.has(TITLE) ? jSONObject.getString(TITLE) : null;
            this.title = string4;
            String string5 = jSONObject.has(TICKER) ? jSONObject.getString(TICKER) : null;
            this.ticker = string5;
            boolean bl2 = jSONObject.has(AUTO_CANCEL);
            boolean bl3 = true;
            boolean bl4 = bl2 ? jSONObject.getBoolean(AUTO_CANCEL) : true;
            this.autoCancel = bl4;
            String string6 = jSONObject.has(LARGE_ICON) ? jSONObject.getString(LARGE_ICON) : null;
            this.largeIcon = string6;
            String string7 = jSONObject.has(SMALL_ICON) ? jSONObject.getString(SMALL_ICON) : null;
            this.smallIcon = string7;
            String string8 = jSONObject.has(BIG_TEXT) ? jSONObject.getString(BIG_TEXT) : null;
            this.bigText = string8;
            String string9 = jSONObject.has(SUB_TEXT) ? jSONObject.getString(SUB_TEXT) : null;
            this.subText = string9;
            String string10 = jSONObject.has(NUMBER) ? jSONObject.getString(NUMBER) : null;
            this.number = string10;
            String string11 = jSONObject.has(SOUND) ? jSONObject.getString(SOUND) : null;
            this.sound = string11;
            String string12 = jSONObject.has(COLOR) ? jSONObject.getString(COLOR) : null;
            this.color = string12;
            String string13 = jSONObject.has(GROUP) ? jSONObject.getString(GROUP) : null;
            this.group = string13;
            boolean bl5 = jSONObject.has(USER_INTERACTION) ? jSONObject.getBoolean(USER_INTERACTION) : false;
            this.userInteraction = bl5;
            boolean bl6 = jSONObject.has(PLAY_SOUND) ? jSONObject.getBoolean(PLAY_SOUND) : true;
            this.playSound = bl6;
            if (jSONObject.has(VIBRATE)) {
                bl3 = jSONObject.getBoolean(VIBRATE);
            }
            this.vibrate = bl3;
            double d3 = jSONObject.has(VIBRATION) ? jSONObject.getDouble(VIBRATION) : 1000.0;
            this.vibration = d3;
            String string14 = jSONObject.has(ACTIONS) ? jSONObject.getString(ACTIONS) : null;
            this.actions = string14;
            String string15 = jSONObject.has(TAG) ? jSONObject.getString(TAG) : null;
            this.tag = string15;
            boolean bl7 = jSONObject.has(REPEAT_TYPE);
            String string16 = null;
            if (bl7) {
                string16 = jSONObject.getString(REPEAT_TYPE);
            }
            this.repeatType = string16;
            if (jSONObject.has(REPEAT_TIME)) {
                d = jSONObject.getDouble(REPEAT_TIME);
            }
            this.repeatTime = d;
            boolean bl8 = jSONObject.has(ONGOING) ? jSONObject.getBoolean(ONGOING) : false;
            this.ongoing = bl8;
            return;
        }
        catch (JSONException jSONException) {
            throw new IllegalStateException("Exception while initializing RNPushNotificationAttributes from JSON", (Throwable)jSONException);
        }
    }

    public static RNPushNotificationAttributes fromJson(String string2) throws JSONException {
        return new RNPushNotificationAttributes(new JSONObject(string2));
    }

    public double getFireDate() {
        return this.fireDate;
    }

    public String getId() {
        return this.id;
    }

    public boolean matches(ReadableMap readableMap) {
        Bundle bundle = this.toBundle();
        ReadableMapKeySetIterator readableMapKeySetIterator = readableMap.keySetIterator();
        block7 : while (readableMapKeySetIterator.hasNextKey()) {
            String string2 = readableMapKeySetIterator.nextKey();
            if (!bundle.containsKey(string2)) {
                return false;
            }
            switch (1.$SwitchMap$com$facebook$react$bridge$ReadableType[readableMap.getType(string2).ordinal()]) {
                default: {
                    continue block7;
                }
                case 5: 
                case 6: {
                    return false;
                }
                case 4: {
                    if (readableMap.getString(string2).equals((Object)bundle.getString(string2))) continue block7;
                    return false;
                }
                case 3: {
                    if (readableMap.getDouble(string2) == bundle.getDouble(string2) || readableMap.getInt(string2) == bundle.getInt(string2)) continue block7;
                    return false;
                }
                case 2: {
                    if (readableMap.getBoolean(string2) == bundle.getBoolean(string2)) continue block7;
                    return false;
                }
                case 1: 
            }
            if (bundle.get(string2) == null) continue;
            return false;
        }
        return true;
    }

    public Bundle toBundle() {
        Bundle bundle = new Bundle();
        bundle.putString(ID, this.id);
        bundle.putString(MESSAGE, this.message);
        bundle.putDouble(FIRE_DATE, this.fireDate);
        bundle.putString(TITLE, this.title);
        bundle.putString(TICKER, this.ticker);
        bundle.putBoolean(AUTO_CANCEL, this.autoCancel);
        bundle.putString(LARGE_ICON, this.largeIcon);
        bundle.putString(SMALL_ICON, this.smallIcon);
        bundle.putString(BIG_TEXT, this.bigText);
        bundle.putString(SUB_TEXT, this.subText);
        bundle.putString(NUMBER, this.number);
        bundle.putString(SOUND, this.sound);
        bundle.putString(COLOR, this.color);
        bundle.putString(GROUP, this.group);
        bundle.putBoolean(USER_INTERACTION, this.userInteraction);
        bundle.putBoolean(PLAY_SOUND, this.playSound);
        bundle.putBoolean(VIBRATE, this.vibrate);
        bundle.putDouble(VIBRATION, this.vibration);
        bundle.putString(ACTIONS, this.actions);
        bundle.putString(TAG, this.tag);
        bundle.putString(REPEAT_TYPE, this.repeatType);
        bundle.putDouble(REPEAT_TIME, this.repeatTime);
        bundle.putBoolean(ONGOING, this.ongoing);
        return bundle;
    }

    public JSONObject toJson() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(ID, (Object)this.id);
            jSONObject.put(MESSAGE, (Object)this.message);
            jSONObject.put(FIRE_DATE, this.fireDate);
            jSONObject.put(TITLE, (Object)this.title);
            jSONObject.put(TICKER, (Object)this.ticker);
            jSONObject.put(AUTO_CANCEL, this.autoCancel);
            jSONObject.put(LARGE_ICON, (Object)this.largeIcon);
            jSONObject.put(SMALL_ICON, (Object)this.smallIcon);
            jSONObject.put(BIG_TEXT, (Object)this.bigText);
            jSONObject.put(SUB_TEXT, (Object)this.subText);
            jSONObject.put(NUMBER, (Object)this.number);
            jSONObject.put(SOUND, (Object)this.sound);
            jSONObject.put(COLOR, (Object)this.color);
            jSONObject.put(GROUP, (Object)this.group);
            jSONObject.put(USER_INTERACTION, this.userInteraction);
            jSONObject.put(PLAY_SOUND, this.playSound);
            jSONObject.put(VIBRATE, this.vibrate);
            jSONObject.put(VIBRATION, this.vibration);
            jSONObject.put(ACTIONS, (Object)this.actions);
            jSONObject.put(TAG, (Object)this.tag);
            jSONObject.put(REPEAT_TYPE, (Object)this.repeatType);
            jSONObject.put(REPEAT_TIME, this.repeatTime);
            jSONObject.put(ONGOING, this.ongoing);
            return jSONObject;
        }
        catch (JSONException jSONException) {
            Log.e((String)"RNPushNotification", (String)"Exception while converting RNPushNotificationAttributes to JSON. Returning an empty object", (Throwable)jSONException);
            return new JSONObject();
        }
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RNPushNotificationAttributes{id='");
        stringBuilder.append(this.id);
        stringBuilder.append('\'');
        stringBuilder.append(", message='");
        stringBuilder.append(this.message);
        stringBuilder.append('\'');
        stringBuilder.append(", fireDate=");
        stringBuilder.append(this.fireDate);
        stringBuilder.append(", title='");
        stringBuilder.append(this.title);
        stringBuilder.append('\'');
        stringBuilder.append(", ticker='");
        stringBuilder.append(this.ticker);
        stringBuilder.append('\'');
        stringBuilder.append(", autoCancel=");
        stringBuilder.append(this.autoCancel);
        stringBuilder.append(", largeIcon='");
        stringBuilder.append(this.largeIcon);
        stringBuilder.append('\'');
        stringBuilder.append(", smallIcon='");
        stringBuilder.append(this.smallIcon);
        stringBuilder.append('\'');
        stringBuilder.append(", bigText='");
        stringBuilder.append(this.bigText);
        stringBuilder.append('\'');
        stringBuilder.append(", subText='");
        stringBuilder.append(this.subText);
        stringBuilder.append('\'');
        stringBuilder.append(", number='");
        stringBuilder.append(this.number);
        stringBuilder.append('\'');
        stringBuilder.append(", sound='");
        stringBuilder.append(this.sound);
        stringBuilder.append('\'');
        stringBuilder.append(", color='");
        stringBuilder.append(this.color);
        stringBuilder.append('\'');
        stringBuilder.append(", group='");
        stringBuilder.append(this.group);
        stringBuilder.append('\'');
        stringBuilder.append(", userInteraction=");
        stringBuilder.append(this.userInteraction);
        stringBuilder.append(", playSound=");
        stringBuilder.append(this.playSound);
        stringBuilder.append(", vibrate=");
        stringBuilder.append(this.vibrate);
        stringBuilder.append(", vibration=");
        stringBuilder.append(this.vibration);
        stringBuilder.append(", actions='");
        stringBuilder.append(this.actions);
        stringBuilder.append('\'');
        stringBuilder.append(", tag='");
        stringBuilder.append(this.tag);
        stringBuilder.append('\'');
        stringBuilder.append(", repeatType='");
        stringBuilder.append(this.repeatType);
        stringBuilder.append('\'');
        stringBuilder.append(", repeatTime=");
        stringBuilder.append(this.repeatTime);
        stringBuilder.append(", ongoing=");
        stringBuilder.append(this.ongoing);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

}

