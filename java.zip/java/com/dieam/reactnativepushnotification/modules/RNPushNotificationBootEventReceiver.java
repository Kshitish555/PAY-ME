/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.os.Bundle
 *  android.util.Log
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.Map
 *  java.util.Set
 */
package com.dieam.reactnativepushnotification.modules;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationAttributes;
import com.dieam.reactnativepushnotification.modules.RNPushNotificationHelper;
import java.util.Map;
import java.util.Set;

public class RNPushNotificationBootEventReceiver
extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        Log.i((String)"RNPushNotification", (String)"RNPushNotificationBootEventReceiver loading scheduled notifications");
        if (intent.getAction().equals((Object)"android.intent.action.BOOT_COMPLETED")) {
            SharedPreferences sharedPreferences = context.getSharedPreferences("rn_push_notification", 0);
            Set set = sharedPreferences.getAll().keySet();
            RNPushNotificationHelper rNPushNotificationHelper = new RNPushNotificationHelper((Application)context.getApplicationContext());
            for (String string2 : set) {
                String string3 = sharedPreferences.getString(string2, null);
                if (string3 == null) continue;
                try {
                    RNPushNotificationAttributes rNPushNotificationAttributes = RNPushNotificationAttributes.fromJson(string3);
                    if (rNPushNotificationAttributes.getFireDate() < (double)System.currentTimeMillis()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("RNPushNotificationBootEventReceiver: Showing notification for ");
                        stringBuilder.append(rNPushNotificationAttributes.getId());
                        Log.i((String)"RNPushNotification", (String)stringBuilder.toString());
                        rNPushNotificationHelper.sendToNotificationCentre(rNPushNotificationAttributes.toBundle());
                        continue;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("RNPushNotificationBootEventReceiver: Scheduling notification for ");
                    stringBuilder.append(rNPushNotificationAttributes.getId());
                    Log.i((String)"RNPushNotification", (String)stringBuilder.toString());
                    rNPushNotificationHelper.sendNotificationScheduledCore(rNPushNotificationAttributes.toBundle());
                }
                catch (Exception exception) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Problem with boot receiver loading notification ");
                    stringBuilder.append(string2);
                    Log.e((String)"RNPushNotification", (String)stringBuilder.toString(), (Throwable)exception);
                }
            }
        }
    }
}

