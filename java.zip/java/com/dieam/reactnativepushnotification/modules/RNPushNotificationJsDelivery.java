/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.modules.core.DeviceEventManagerModule
 *  com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Set
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.dieam.reactnativepushnotification.modules;

import android.os.Build;
import android.os.Bundle;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class RNPushNotificationJsDelivery {
    private ReactApplicationContext mReactContext;

    public RNPushNotificationJsDelivery(ReactApplicationContext reactApplicationContext) {
        this.mReactContext = reactApplicationContext;
    }

    String convertJSON(Bundle bundle) {
        try {
            String string2 = this.convertJSONObject(bundle).toString();
            return string2;
        }
        catch (JSONException jSONException) {
            return null;
        }
    }

    JSONObject convertJSONObject(Bundle bundle) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        for (String string2 : bundle.keySet()) {
            Object object = bundle.get(string2);
            if (object instanceof Bundle) {
                jSONObject.put(string2, (Object)this.convertJSONObject((Bundle)object));
                continue;
            }
            if (Build.VERSION.SDK_INT >= 19) {
                jSONObject.put(string2, JSONObject.wrap((Object)object));
                continue;
            }
            jSONObject.put(string2, object);
        }
        return jSONObject;
    }

    void notifyNotification(Bundle bundle) {
        String string2 = this.convertJSON(bundle);
        WritableMap writableMap = Arguments.createMap();
        writableMap.putString("dataJSON", string2);
        this.sendEvent("remoteNotificationReceived", (Object)writableMap);
    }

    void notifyNotificationAction(Bundle bundle) {
        String string2 = this.convertJSON(bundle);
        WritableMap writableMap = Arguments.createMap();
        writableMap.putString("dataJSON", string2);
        this.sendEvent("notificationActionReceived", (Object)writableMap);
    }

    void notifyRemoteFetch(Bundle bundle) {
        String string2 = this.convertJSON(bundle);
        WritableMap writableMap = Arguments.createMap();
        writableMap.putString("dataJSON", string2);
        this.sendEvent("remoteFetch", (Object)writableMap);
    }

    void sendEvent(String string2, Object object) {
        if (this.mReactContext.hasActiveCatalystInstance()) {
            ((DeviceEventManagerModule.RCTDeviceEventEmitter)this.mReactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)).emit(string2, object);
        }
    }
}

