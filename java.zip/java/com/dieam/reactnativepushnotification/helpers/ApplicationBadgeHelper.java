/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  com.facebook.common.logging.FLog
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 *  me.leolin.shortcutbadger.Badger
 *  me.leolin.shortcutbadger.ShortcutBadger
 *  me.leolin.shortcutbadger.impl.SamsungHomeBadger
 */
package com.dieam.reactnativepushnotification.helpers;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import com.facebook.common.logging.FLog;
import java.util.List;
import me.leolin.shortcutbadger.Badger;
import me.leolin.shortcutbadger.ShortcutBadger;
import me.leolin.shortcutbadger.impl.SamsungHomeBadger;

public class ApplicationBadgeHelper {
    public static final ApplicationBadgeHelper INSTANCE = new ApplicationBadgeHelper();
    private static final Badger LEGACY_SAMSUNG_BADGER = new SamsungHomeBadger();
    private static final String LOG_TAG = "ApplicationBadgeHelper";
    private Boolean applyAutomaticBadger;
    private Boolean applySamsungBadger;
    private ComponentName componentName;

    private ApplicationBadgeHelper() {
    }

    private boolean applyLegacySamsungBadge(Context context, int n) {
        try {
            LEGACY_SAMSUNG_BADGER.executeBadge(context, this.componentName, n);
            return true;
        }
        catch (Exception exception) {
            FLog.w((String)LOG_TAG, (String)"Legacy Samsung badger failed", (Throwable)exception);
            return false;
        }
    }

    private boolean isLegacySamsungLauncher(Context context) {
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        ResolveInfo resolveInfo = context.getPackageManager().resolveActivity(intent, 65536);
        if (resolveInfo != null && !resolveInfo.activityInfo.name.toLowerCase().contains((CharSequence)"resolver")) {
            String string2 = resolveInfo.activityInfo.packageName;
            return LEGACY_SAMSUNG_BADGER.getSupportLaunchers().contains((Object)string2);
        }
        return false;
    }

    private void tryAutomaticBadge(Context context, int n) {
        Boolean bl = this.applyAutomaticBadger;
        if (bl == null) {
            this.applyAutomaticBadger = ShortcutBadger.applyCount((Context)context, (int)n);
            if (this.applyAutomaticBadger.booleanValue()) {
                FLog.i((String)LOG_TAG, (String)"First attempt to use automatic badger succeeded; permanently enabling method.");
                return;
            }
            FLog.i((String)LOG_TAG, (String)"First attempt to use automatic badger failed; permanently disabling method.");
            return;
        }
        if (!bl.booleanValue()) {
            return;
        }
        ShortcutBadger.applyCount((Context)context, (int)n);
    }

    private void tryLegacySamsungBadge(Context context, int n) {
        Boolean bl = this.applySamsungBadger;
        if (bl == null) {
            boolean bl2 = this.isLegacySamsungLauncher(context) && this.applyLegacySamsungBadge(context, n);
            this.applySamsungBadger = bl2;
            if (this.applySamsungBadger.booleanValue()) {
                FLog.i((String)LOG_TAG, (String)"First attempt to use legacy Samsung badger succeeded; permanently enabling method.");
                return;
            }
            FLog.w((String)LOG_TAG, (String)"First attempt to use legacy Samsung badger failed; permanently disabling method.");
            return;
        }
        if (!bl.booleanValue()) {
            return;
        }
        this.applyLegacySamsungBadge(context, n);
    }

    public void setApplicationIconBadgeNumber(Context context, int n) {
        if (this.componentName == null) {
            this.componentName = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName()).getComponent();
        }
        this.tryAutomaticBadge(context, n);
        this.tryLegacySamsungBadge(context, n);
    }
}

