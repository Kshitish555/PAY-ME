/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.payoneer;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.payoneer.android";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final boolean PAYONEER_MOBILE_APP_WEBVIEW_DEBUG = false;
    public static final int VERSION_CODE = 5004000;
    public static final String VERSION_NAME = "5.4.0";
}

