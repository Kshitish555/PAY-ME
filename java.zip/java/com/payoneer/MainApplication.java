/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningAppProcessInfo
 *  android.app.Application
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Process
 *  android.util.Log
 *  android.webkit.WebView
 *  androidx.multidex.MultiDex
 *  com.facebook.react.PackageList
 *  com.facebook.react.ReactApplication
 *  com.facebook.react.ReactInstanceManager
 *  com.facebook.react.ReactNativeHost
 *  com.facebook.react.ReactPackage
 *  com.facebook.soloader.SoLoader
 *  com.google.android.gms.common.GooglePlayServicesNotAvailableException
 *  com.google.android.gms.common.GooglePlayServicesRepairableException
 *  com.google.android.gms.security.ProviderInstaller
 *  io.branch.rnbranch.RNBranchModule
 *  io.invertase.firebase.fabric.crashlytics.RNFirebaseCrashlyticsPackage
 *  io.invertase.firebase.messaging.RNFirebaseMessagingPackage
 *  io.invertase.firebase.notifications.RNFirebaseNotificationsPackage
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.payoneer;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.util.Log;
import android.webkit.WebView;
import androidx.multidex.MultiDex;
import com.facebook.react.PackageList;
import com.facebook.react.ReactApplication;
import com.facebook.react.ReactInstanceManager;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.soloader.SoLoader;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.security.ProviderInstaller;
import com.payoneer.PerimeterXPackage;
import com.payoneer.RNRestartAndroidPackage;
import com.payoneer.VectorIconsPackage;
import io.branch.rnbranch.RNBranchModule;
import io.invertase.firebase.analytics.RNFirebaseAnalyticsPackage;
import io.invertase.firebase.fabric.crashlytics.RNFirebaseCrashlyticsPackage;
import io.invertase.firebase.messaging.RNFirebaseMessagingPackage;
import io.invertase.firebase.notifications.RNFirebaseNotificationsPackage;
import java.util.ArrayList;
import java.util.List;

public class MainApplication
extends Application
implements ReactApplication {
    private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this){

        protected String getJSMainModuleName() {
            return "index";
        }

        protected List<ReactPackage> getPackages() {
            ArrayList arrayList = new PackageList((ReactNativeHost)this).getPackages();
            arrayList.add((Object)new RNRestartAndroidPackage());
            arrayList.add((Object)new VectorIconsPackage());
            arrayList.add((Object)new PerimeterXPackage());
            arrayList.add((Object)new RNFirebaseMessagingPackage());
            arrayList.add((Object)new RNFirebaseNotificationsPackage());
            arrayList.add((Object)new RNFirebaseAnalyticsPackage());
            arrayList.add((Object)new RNFirebaseCrashlyticsPackage());
            return arrayList;
        }

        public boolean getUseDeveloperSupport() {
            return false;
        }
    };

    private String getProcessName(Context context) {
        if (context == null) {
            return null;
        }
        for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : ((ActivityManager)context.getSystemService("activity")).getRunningAppProcesses()) {
            if (runningAppProcessInfo.pid != Process.myPid()) continue;
            return runningAppProcessInfo.processName;
        }
        return null;
    }

    private static void initializeFlipper(Context context, ReactInstanceManager reactInstanceManager) {
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install((Context)this);
    }

    public ReactNativeHost getReactNativeHost() {
        return this.mReactNativeHost;
    }

    public void onCreate() {
        block5 : {
            void var1_3;
            super.onCreate();
            RNBranchModule.getAutoInstance((Context)this);
            try {
                ProviderInstaller.installIfNeeded((Context)this.getApplicationContext());
                break block5;
            }
            catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
            }
            catch (GooglePlayServicesRepairableException googlePlayServicesRepairableException) {
                // empty catch block
            }
            var1_3.printStackTrace();
        }
        SoLoader.init((Context)this, (boolean)false);
        MainApplication.initializeFlipper((Context)this, this.getReactNativeHost().getReactInstanceManager());
        if (Build.VERSION.SDK_INT >= 28) {
            String string2 = this.getProcessName((Context)this);
            if (!this.getPackageName().equals((Object)string2)) {
                WebView.setDataDirectorySuffix((String)string2);
            }
        }
        WebView.setWebContentsDebuggingEnabled((boolean)false);
        Log.d((String)"WEBVIEW", (String)"DEBUG Enabled is false");
    }

}

