/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.ReactPackage
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.uimanager.ViewManager
 *  com.payoneer.PerimeterXPackage$PerimeterXModule
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.payoneer;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.uimanager.ViewManager;
import com.payoneer.PerimeterXPackage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/*
 * Exception performing whole class analysis.
 */
public class PerimeterXPackage
implements ReactPackage {
    public static WritableMap toReactNativeMap(HashMap<String, String> hashMap) {
        WritableMap writableMap = Arguments.createMap();
        for (Map.Entry entry : hashMap.entrySet()) {
            writableMap.putString((String)entry.getKey(), (String)entry.getValue());
        }
        return writableMap;
    }

    public List<NativeModule> createNativeModules(ReactApplicationContext reactApplicationContext) {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new /* Unavailable Anonymous Inner Class!! */);
        return arrayList;
    }

    public List<ViewManager> createViewManagers(ReactApplicationContext reactApplicationContext) {
        return Collections.emptyList();
    }
}

