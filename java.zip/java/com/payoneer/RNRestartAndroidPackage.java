/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.ReactPackage
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.uimanager.ViewManager
 *  com.payoneer.RNRestartAndroidModule
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 */
package com.payoneer;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import com.payoneer.RNRestartAndroidModule;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RNRestartAndroidPackage
implements ReactPackage {
    public List<NativeModule> createNativeModules(ReactApplicationContext reactApplicationContext) {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new RNRestartAndroidModule(reactApplicationContext));
        return arrayList;
    }

    public List<ViewManager> createViewManagers(ReactApplicationContext reactApplicationContext) {
        return Arrays.asList((Object[])new ViewManager[0]);
    }
}

