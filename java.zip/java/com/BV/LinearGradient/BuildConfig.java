/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package com.BV.LinearGradient;

public final class BuildConfig {
    @Deprecated
    public static final String APPLICATION_ID = "com.BV.LinearGradient";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final String LIBRARY_PACKAGE_NAME = "com.BV.LinearGradient";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}

