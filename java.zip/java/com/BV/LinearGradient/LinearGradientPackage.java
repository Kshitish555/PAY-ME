/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.BV.LinearGradient.LinearGradientManager
 *  com.facebook.react.ReactPackage
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.uimanager.ViewManager
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 */
package com.BV.LinearGradient;

import com.BV.LinearGradient.LinearGradientManager;
import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LinearGradientPackage
implements ReactPackage {
    public List<Class<? extends JavaScriptModule>> createJSModules() {
        return Collections.emptyList();
    }

    public List<NativeModule> createNativeModules(ReactApplicationContext reactApplicationContext) {
        return Collections.emptyList();
    }

    public List<ViewManager> createViewManagers(ReactApplicationContext reactApplicationContext) {
        Object[] arrobject = new ViewManager[]{new LinearGradientManager()};
        return Arrays.asList((Object[])arrobject);
    }
}

