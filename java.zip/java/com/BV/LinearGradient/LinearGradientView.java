/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.LinearGradient
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$Direction
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.view.View
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.uimanager.PixelUtil
 *  java.lang.Math
 */
package com.BV.LinearGradient;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.uimanager.PixelUtil;

public class LinearGradientView
extends View {
    private float mAngle = 45.0f;
    private float[] mAngleCenter = new float[]{0.5f, 0.5f};
    private float[] mBorderRadii = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
    private int[] mColors;
    private float[] mEndPos = new float[]{0.0f, 1.0f};
    private float[] mLocations;
    private final Paint mPaint = new Paint(1);
    private Path mPathForBorderRadius;
    private LinearGradient mShader;
    private int[] mSize = new int[]{0, 0};
    private float[] mStartPos = new float[]{0.0f, 0.0f};
    private RectF mTempRectForBorderRadius;
    private boolean mUseAngle = false;

    public LinearGradientView(Context context) {
        super(context);
    }

    private float[] calculateGradientLocationWithAngle(float f) {
        float f2 = 0.017453292f * (f - 90.0f);
        float f3 = (float)Math.sqrt((double)2.0);
        float[] arrf = new float[2];
        double d = f2;
        arrf[0] = f3 * (float)Math.cos((double)d);
        arrf[1] = f3 * (float)Math.sin((double)d);
        return arrf;
    }

    private void drawGradient() {
        int[] arrn = this.mColors;
        if (arrn != null) {
            LinearGradient linearGradient;
            float[] arrf = this.mLocations;
            if (arrf != null && arrn.length != arrf.length) {
                return;
            }
            float[] arrf2 = this.mStartPos;
            float[] arrf3 = this.mEndPos;
            if (this.mUseAngle && this.mAngleCenter != null) {
                float[] arrf4 = this.calculateGradientLocationWithAngle(this.mAngle);
                float[] arrf5 = new float[2];
                float[] arrf6 = this.mAngleCenter;
                arrf5[0] = arrf6[0] - arrf4[0] / 2.0f;
                arrf5[1] = arrf6[1] - arrf4[1] / 2.0f;
                arrf3 = new float[]{arrf6[0] + arrf4[0] / 2.0f, arrf6[1] + arrf4[1] / 2.0f};
                arrf2 = arrf5;
            }
            float f = arrf2[0];
            int[] arrn2 = this.mSize;
            this.mShader = linearGradient = new LinearGradient(f * (float)arrn2[0], arrf2[1] * (float)arrn2[1], arrf3[0] * (float)arrn2[0], arrf3[1] * (float)arrn2[1], this.mColors, this.mLocations, Shader.TileMode.CLAMP);
            this.mPaint.setShader((Shader)this.mShader);
            this.invalidate();
        }
    }

    private void updatePath() {
        if (this.mPathForBorderRadius == null) {
            this.mPathForBorderRadius = new Path();
            this.mTempRectForBorderRadius = new RectF();
        }
        this.mPathForBorderRadius.reset();
        RectF rectF = this.mTempRectForBorderRadius;
        int[] arrn = this.mSize;
        rectF.set(0.0f, 0.0f, (float)arrn[0], (float)arrn[1]);
        this.mPathForBorderRadius.addRoundRect(this.mTempRectForBorderRadius, this.mBorderRadii, Path.Direction.CW);
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Path path = this.mPathForBorderRadius;
        if (path == null) {
            canvas.drawPaint(this.mPaint);
            return;
        }
        canvas.drawPath(path, this.mPaint);
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        this.mSize = new int[]{n, n2};
        this.updatePath();
        this.drawGradient();
    }

    public void setAngle(float f) {
        this.mAngle = f;
        this.drawGradient();
    }

    public void setAngleCenter(ReadableArray readableArray) {
        float[] arrf = new float[]{(float)readableArray.getDouble(0), (float)readableArray.getDouble(1)};
        this.mAngleCenter = arrf;
        this.drawGradient();
    }

    public void setBorderRadii(ReadableArray readableArray) {
        float[] arrf = new float[readableArray.size()];
        for (int i = 0; i < arrf.length; ++i) {
            arrf[i] = PixelUtil.toPixelFromDIP((float)((float)readableArray.getDouble(i)));
        }
        this.mBorderRadii = arrf;
        this.updatePath();
        this.drawGradient();
    }

    public void setColors(ReadableArray readableArray) {
        int[] arrn = new int[readableArray.size()];
        for (int i = 0; i < arrn.length; ++i) {
            arrn[i] = readableArray.getInt(i);
        }
        this.mColors = arrn;
        this.drawGradient();
    }

    public void setEndPosition(ReadableArray readableArray) {
        float[] arrf = new float[]{(float)readableArray.getDouble(0), (float)readableArray.getDouble(1)};
        this.mEndPos = arrf;
        this.drawGradient();
    }

    public void setLocations(ReadableArray readableArray) {
        float[] arrf = new float[readableArray.size()];
        for (int i = 0; i < arrf.length; ++i) {
            arrf[i] = (float)readableArray.getDouble(i);
        }
        this.mLocations = arrf;
        this.drawGradient();
    }

    public void setStartPosition(ReadableArray readableArray) {
        float[] arrf = new float[]{(float)readableArray.getDouble(0), (float)readableArray.getDouble(1)};
        this.mStartPos = arrf;
        this.drawGradient();
    }

    public void setUseAngle(boolean bl) {
        this.mUseAngle = bl;
        this.drawGradient();
    }
}

