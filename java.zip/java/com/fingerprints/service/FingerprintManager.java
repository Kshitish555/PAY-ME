/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Message
 *  android.os.RemoteException
 *  android.os.ServiceManager
 *  android.util.Log
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchMethodException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 */
package com.fingerprints.service;

import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.Log;
import com.fingerprints.service.FingerprintManager;
import com.fingerprints.service.IFingerprintClient;
import com.fingerprints.service.IFingerprintService;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class FingerprintManager {
    static final int ARG_IDENTIFY_UPDATED = 1;
    public static final int CAPTURE_FAILED_TOO_FAST = 1;
    public static final int DELETE_TEMPLATES_SUCCESS = 1;
    static final int FPC_GUIDE_DATA_INVALID = Integer.MIN_VALUE;
    static final int FPC_GUIDE_DIRECTION_E = 7;
    static final int FPC_GUIDE_DIRECTION_N = 5;
    static final int FPC_GUIDE_DIRECTION_NA = 0;
    static final int FPC_GUIDE_DIRECTION_NE = 6;
    static final int FPC_GUIDE_DIRECTION_NW = 4;
    static final int FPC_GUIDE_DIRECTION_S = 2;
    static final int FPC_GUIDE_DIRECTION_SE = 3;
    static final int FPC_GUIDE_DIRECTION_SW = 1;
    static final int FPC_GUIDE_DIRECTION_W = 8;
    static final int INTERNEL_FINGERDOWN_TIMEOUT = 3000;
    static final int MEG_FINGERDOWN_TIMEOUT = 26;
    public static final int MEG_WAIT_FINGERDOWN_TIMEOUT = 21;
    public static final int MSG_CAPTURE_FAILED = 19;
    public static final int MSG_DELETE_RESULT = 30;
    static final int MSG_ENROLMENT_DATA_IMAGE_QUALITY = 14;
    static final int MSG_ENROLMENT_DATA_IMAGE_STITCHED = 18;
    static final int MSG_ENROLMENT_DATA_IMMOBILE = 15;
    static final int MSG_ENROLMENT_DATA_NEXT_DIRECTION = 16;
    static final int MSG_ENROLMENT_DATA_PROGRESS = 17;
    static final int MSG_ENROLMENT_DONE = 5;
    static final int MSG_ENROLMENT_FAILED = 8;
    static final int MSG_ENROLMENT_LAST_TOUCH = 11;
    static final int MSG_ENROLMENT_MASK_LIST = 13;
    static final int MSG_ENROLMENT_NEXT_TOUCH = 12;
    static final int MSG_ENROLMENT_SEND_GUIDE_DATA = 10;
    static final int MSG_ENROLMENT_TOUCHES_QUALITY = 9;
    static final int MSG_ENROL_PROGRESS = 4;
    public static final int MSG_FINGER_PRESENT = 2;
    public static final int MSG_FINGER_UP = 3;
    public static final int MSG_IDENTIFY_MATCH = 6;
    public static final int MSG_IDENTIFY_NO_MATCH = 7;
    public static final int MSG_NOT_ENABLED = 22;
    public static final int MSG_NOT_ENROLLED = 20;
    public static final int MSG_SENSOR_ERROR = 25;
    public static final int MSG_UNKNOWN = 23;
    public static final int MSG_USER_CANCEL = 24;
    public static final int MSG_WAITING_FINGER = 1;
    private static String TAG = "MzFingerManager";
    private static Bundle mBundle;
    private static Bundle mGuidedDataBundle;
    private CaptureCallback mCaptureCallback;
    private IFingerprintClient mClient;
    private DeleteTemplateCallback mDeleteTemplateCallback;
    private EnrolCallback mEnrolCallback;
    private EventHandler mEventhHandler;
    private GuidedDataCallback mGuidedDataCallback;
    private IdentifyCallback mIdentifyCallback;
    private IdentifyListener mIdentifyListener;
    private boolean mReadyToStore = false;
    private IFingerprintService mService;
    private int mUserdata = Integer.MIN_VALUE;
    HandlerThread mzHanderThread;

    private FingerprintManager(IBinder iBinder, Looper looper) throws RemoteException {
        this.mService = IFingerprintService.Stub.asInterface(iBinder);
        if (looper == null) {
            Log.d((String)TAG, (String)" create--------HandlerThread  ");
            this.mzHanderThread = new HandlerThread("result_handler");
            this.mzHanderThread.start();
            looper = this.mzHanderThread.getLooper();
        }
        String string2 = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("get fp method time, mService = ");
        stringBuilder.append((Object)this.mService);
        Log.e((String)string2, (String)stringBuilder.toString());
        EventHandler eventHandler = new EventHandler(looper);
        mBundle = new Bundle();
        mGuidedDataBundle = new Bundle();
        this.mClient = new IFingerprintClient.Stub(this){
            final /* synthetic */ FingerprintManager this$0;
            {
                this.this$0 = fingerprintManager;
            }

            public void onBundleMessage(int n, int n2, int n3, Bundle bundle) throws RemoteException {
                Message message = FingerprintManager.access$1000(this.this$0).obtainMessage(n, n2, n3);
                message.setData(bundle);
                FingerprintManager.access$1000(this.this$0).sendMessage(message);
            }

            public void onBundleMessage2(int n, int n2, int[] arrn) throws RemoteException {
                Message message = FingerprintManager.access$1000(this.this$0).obtainMessage(n, n2, 0);
                switch (n) {
                    default: {
                        break;
                    }
                    case 13: {
                        FingerprintManager.access$1100().putIntArray("maskList", arrn);
                        FingerprintManager.access$1100().putInt("maskNumber", n2);
                        message.setData(FingerprintManager.access$1100());
                        break;
                    }
                    case 12: {
                        FingerprintManager.access$1100().putIntArray("nextTouch", arrn);
                        message.setData(FingerprintManager.access$1100());
                        break;
                    }
                    case 11: {
                        FingerprintManager.access$1100().putIntArray("lastTouch", arrn);
                        message.setData(FingerprintManager.access$1100());
                    }
                }
                FingerprintManager.access$1000(this.this$0).sendMessage(message);
            }

            public void onMessage(int n, int n2, int n3) throws RemoteException {
                String string2 = FingerprintManager.access$000();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(" onMessage--------what  ");
                stringBuilder.append(n);
                Log.i((String)string2, (String)stringBuilder.toString());
                FingerprintManager.access$1000(this.this$0).sendMessage(FingerprintManager.access$1000(this.this$0).obtainMessage(n, n2, n3));
            }
        };
        IFingerprintService iFingerprintService = this.mService;
        if (iFingerprintService != null && iFingerprintService.open(this.mClient)) {
            this.mEventhHandler = eventHandler;
            return;
        }
        throw new RuntimeException();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void PackGuidedData() {
        int n;
        boolean bl;
        int n2;
        boolean bl2;
        int n3;
        boolean bl3;
        int n4;
        boolean bl4;
        block5 : {
            block2 : {
                block4 : {
                    block3 : {
                        n2 = mGuidedDataBundle.getInt("progress");
                        n4 = mGuidedDataBundle.getInt("next_direction");
                        n3 = mGuidedDataBundle.getInt("acceptance");
                        bl = mGuidedDataBundle.getInt("stitched") != 0;
                        bl4 = mGuidedDataBundle.getInt("immobile") != 0;
                        int n5 = mGuidedDataBundle.getInt("reject_reason");
                        n = mGuidedDataBundle.getInt("maskNumber");
                        if (n5 == 1) break block2;
                        if (n5 == 16) break block3;
                        if (n5 == 17) break block2;
                        bl3 = false;
                        break block4;
                    }
                    bl3 = true;
                }
                bl2 = false;
                break block5;
            }
            bl3 = false;
            bl2 = true;
        }
        GuidedRejectReasons guidedRejectReasons = new GuidedRejectReasons(bl3, bl2);
        GuidedResult guidedResult = new GuidedResult(n3, bl, bl4, guidedRejectReasons);
        Point point = new Point(mGuidedDataBundle.getIntArray("lastTouch")[0], mGuidedDataBundle.getIntArray("lastTouch")[1]);
        Point point2 = new Point(mGuidedDataBundle.getIntArray("lastTouch")[2], mGuidedDataBundle.getIntArray("lastTouch")[3]);
        Point point3 = new Point(mGuidedDataBundle.getIntArray("lastTouch")[4], mGuidedDataBundle.getIntArray("lastTouch")[5]);
        Point point4 = new Point(mGuidedDataBundle.getIntArray("lastTouch")[6], mGuidedDataBundle.getIntArray("lastTouch")[7]);
        Point point5 = new Point(mGuidedDataBundle.getIntArray("nextTouch")[0], mGuidedDataBundle.getIntArray("nextTouch")[1]);
        Point point6 = new Point(mGuidedDataBundle.getIntArray("nextTouch")[2], mGuidedDataBundle.getIntArray("nextTouch")[3]);
        Point point7 = new Point(mGuidedDataBundle.getIntArray("nextTouch")[4], mGuidedDataBundle.getIntArray("nextTouch")[5]);
        Point point8 = new Point(mGuidedDataBundle.getIntArray("nextTouch")[6], mGuidedDataBundle.getIntArray("nextTouch")[7]);
        GuidedRect guidedRect = new GuidedRect(point, point2, point3, point4);
        GuidedRect guidedRect2 = new GuidedRect(point5, point6, point7, point8);
        ArrayList arrayList = new ArrayList();
        int n6 = 0;
        do {
            if (n6 >= n) {
                GuidedResult guidedResult2 = guidedResult;
                GuidedRect guidedRect3 = guidedRect;
                GuidedRect guidedRect4 = guidedRect2;
                GuidedMaskList guidedMaskList = new GuidedMaskList((ArrayList<GuidedRect>)arrayList, n);
                GuidedData guidedData = new GuidedData(n2, n4, guidedResult2, guidedRect3, guidedRect4, guidedMaskList);
                this.mEnrolCallback.onProgress(guidedData);
                return;
            }
            int[] arrn = mGuidedDataBundle.getIntArray("maskList");
            int n7 = n6 * 8;
            int n8 = arrn[n7 + 0];
            int n9 = mGuidedDataBundle.getIntArray("maskList")[n7 + 1];
            int n10 = mGuidedDataBundle.getIntArray("maskList")[n7 + 2];
            int n11 = mGuidedDataBundle.getIntArray("maskList")[n7 + 3];
            int n12 = mGuidedDataBundle.getIntArray("maskList")[n7 + 4];
            GuidedRect guidedRect5 = guidedRect2;
            int n13 = mGuidedDataBundle.getIntArray("maskList")[n7 + 5];
            GuidedRect guidedRect6 = guidedRect;
            int n14 = mGuidedDataBundle.getIntArray("maskList")[n7 + 6];
            GuidedResult guidedResult3 = guidedResult;
            int n15 = mGuidedDataBundle.getIntArray("maskList")[n7 + 7];
            Point point9 = new Point(n12, n13);
            Point point10 = new Point(n14, n15);
            Point point11 = new Point(n8, n9);
            Point point12 = new Point(n10, n11);
            GuidedRect guidedRect7 = new GuidedRect(point11, point12, point9, point10);
            arrayList.add((Object)guidedRect7);
            ++n6;
            guidedRect2 = guidedRect5;
            guidedRect = guidedRect6;
            guidedResult = guidedResult3;
        } while (true);
    }

    static /* synthetic */ EventHandler access$1000(FingerprintManager fingerprintManager) {
        return fingerprintManager.mEventhHandler;
    }

    static /* synthetic */ Bundle access$1100() {
        return mBundle;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void notifyScreenOff() {
        String string2 = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" notifyScreenOff--------  ");
        stringBuilder.append(Thread.currentThread().hashCode());
        Log.i((String)string2, (String)stringBuilder.toString());
        IBinder iBinder = ServiceManager.getService((String)"fingerprints_service");
        if (iBinder == null) return;
        try {
            IFingerprintService.Stub.asInterface(iBinder).notifyScreenOff();
            return;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void notifyScreenOn() {
        String string2 = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" notifyScreenOn--------  ");
        stringBuilder.append(Thread.currentThread().hashCode());
        Log.i((String)string2, (String)stringBuilder.toString());
        IBinder iBinder = ServiceManager.getService((String)"fingerprints_service");
        if (iBinder == null) return;
        try {
            IFingerprintService.Stub.asInterface(iBinder).notifyScreenOn();
            return;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
        }
    }

    public static FingerprintManager open() {
        try {
            FingerprintManager fingerprintManager = new FingerprintManager((IBinder)Class.forName((String)"android.os.ServiceManager").getMethod("getService", new Class[]{String.class}).invoke(null, new Object[]{"fingerprints_service"}), Looper.myLooper());
            return fingerprintManager;
        }
        catch (RuntimeException runtimeException) {
            runtimeException.printStackTrace();
            return null;
        }
        catch (InvocationTargetException invocationTargetException) {
            invocationTargetException.printStackTrace();
            return null;
        }
        catch (IllegalAccessException illegalAccessException) {
            illegalAccessException.printStackTrace();
            return null;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            illegalArgumentException.printStackTrace();
            return null;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            noSuchMethodException.printStackTrace();
            return null;
        }
        catch (ClassNotFoundException classNotFoundException) {
            classNotFoundException.printStackTrace();
            return null;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            return null;
        }
    }

    public void abort() {
        try {
            this.mService.cancel(this.mClient);
            return;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            return;
        }
    }

    public void deleteFingerData(DeleteTemplateCallback deleteTemplateCallback, int[] arrn) {
        if (deleteTemplateCallback == null) {
            return;
        }
        this.mDeleteTemplateCallback = deleteTemplateCallback;
        try {
            this.mService.removeData(this.mClient, arrn);
            return;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            return;
        }
    }

    public int[] getIds() {
        try {
            Log.i((String)TAG, (String)"getIds      ");
            int[] arrn = this.mService.getIds(this.mClient);
            return arrn;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            return null;
        }
    }

    public boolean isFingerEnable() {
        try {
            boolean bl = this.mService.isFingerEnable();
            return bl;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            return false;
        }
    }

    public boolean isSurpport() {
        try {
            boolean bl = this.mService.isSurpport();
            return bl;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            return false;
        }
    }

    public void release() {
        Log.i((String)TAG, (String)" release--------              ");
        if (this.mzHanderThread != null) {
            Log.i((String)TAG, (String)" release--------  mzHanderThread");
            this.mzHanderThread.quit();
            this.mzHanderThread = null;
        }
        try {
            this.mService.release(this.mClient);
            if (this.mCaptureCallback != null) {
                this.mCaptureCallback = null;
            }
            if (this.mEnrolCallback != null && !this.mReadyToStore) {
                this.mEnrolCallback = null;
            }
            if (this.mIdentifyCallback != null) {
                this.mIdentifyCallback = null;
            }
            this.mIdentifyListener = null;
            this.mClient = null;
            return;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            return;
        }
    }

    public void setCaptureCallback(CaptureCallback captureCallback) {
        this.mCaptureCallback = captureCallback;
    }

    public void shouldRestartByScreenOn() {
        try {
            String string2 = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" shouldRestartByScreenOn--------  ");
            stringBuilder.append(Thread.currentThread().hashCode());
            Log.i((String)string2, (String)stringBuilder.toString());
            this.mService.shouldRestartByScreenOn(this.mClient);
            return;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            return;
        }
    }

    public void startEnrol(EnrolCallback enrolCallback, int n) {
        if (enrolCallback != null) {
            this.mEnrolCallback = enrolCallback;
            try {
                this.mService.startGuidedEnrol(this.mClient, n);
                return;
            }
            catch (RemoteException remoteException) {
                remoteException.printStackTrace();
                return;
            }
        }
        throw new NullPointerException();
    }

    public void startIdentify(IdentifyCallback identifyCallback, int[] arrn) {
        if (arrn != null) {
            if (identifyCallback == null) {
                return;
            }
            this.mIdentifyCallback = identifyCallback;
            try {
                this.mService.startIdentify(this.mClient, arrn);
                return;
            }
            catch (RemoteException remoteException) {
                remoteException.printStackTrace();
            }
        }
    }

    public void startIdentify(IdentifyListener identifyListener, int[] arrn, int n, int n2) {
        if (arrn != null && identifyListener != null) {
            this.mIdentifyListener = identifyListener;
            this.mUserdata = n2;
            String string2 = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" startIdentify--------  ");
            stringBuilder.append(arrn[0]);
            Log.i((String)string2, (String)stringBuilder.toString());
            if (n > 0) {
                EventHandler eventHandler = this.mEventhHandler;
                eventHandler.sendMessageDelayed(eventHandler.obtainMessage(21, -1, n2), (long)n);
            }
            try {
                this.mService.startIdentify(this.mClient, arrn);
                return;
            }
            catch (RemoteException remoteException) {
                remoteException.printStackTrace();
                return;
            }
        }
        throw new NullPointerException();
    }

    public boolean updateTA(String string2) {
        try {
            boolean bl = this.mService.updateTA(string2);
            return bl;
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            return false;
        }
    }

    public static interface CaptureCallback {
        public void onCaptureCompleted();

        public void onCaptureFailed(int var1);

        public void onInput();

        public void onWaitingForInput();
    }

    public static interface DeleteTemplateCallback {
        public void onDeleteResult(boolean var1);
    }

    public static interface EnrolCallback {
        public void onEnrolled(int var1);

        public void onEnrollmentFailed();

        public void onFingerDownTimeOut();

        public void onProgress(GuidedData var1);
    }

    private class EventHandler
    extends Handler {
        public EventHandler(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            String string2 = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Message     what  ");
            stringBuilder.append(message.what);
            Log.i((String)string2, (String)stringBuilder.toString());
            switch (message.what) {
                default: {
                    return;
                }
                case 30: {
                    if (FingerprintManager.this.mDeleteTemplateCallback == null) break;
                    String string3 = TAG;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(" MSG_DELETE_RESULT    msg.arg1:  ");
                    stringBuilder2.append(message.arg1);
                    Log.d((String)string3, (String)stringBuilder2.toString());
                    DeleteTemplateCallback deleteTemplateCallback = FingerprintManager.this.mDeleteTemplateCallback;
                    int n = message.arg1;
                    boolean bl = false;
                    if (n == 1) {
                        bl = true;
                    }
                    deleteTemplateCallback.onDeleteResult(bl);
                    return;
                }
                case 26: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    FingerprintManager.this.mEnrolCallback.onFingerDownTimeOut();
                    return;
                }
                case 24: {
                    if (FingerprintManager.this.mIdentifyListener == null) break;
                    FingerprintManager.this.mIdentifyListener.onResult(24, message.arg1, FingerprintManager.this.mUserdata);
                    return;
                }
                case 21: {
                    if (FingerprintManager.this.mIdentifyListener == null) break;
                    FingerprintManager.this.mIdentifyListener.onResult(21, message.arg1, FingerprintManager.this.mUserdata);
                    return;
                }
                case 19: {
                    if (FingerprintManager.this.mCaptureCallback != null) {
                        FingerprintManager.this.mCaptureCallback.onCaptureFailed(message.arg1);
                    }
                    if (FingerprintManager.this.mIdentifyListener == null) break;
                    FingerprintManager.this.mIdentifyListener.onResult(19, message.arg1, FingerprintManager.this.mUserdata);
                    return;
                }
                case 18: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    mGuidedDataBundle.putInt("stitched", message.arg1);
                    return;
                }
                case 17: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    mGuidedDataBundle.putInt("progress", message.arg1);
                    if (message.arg1 != 100) break;
                    FingerprintManager.this.mReadyToStore = true;
                    return;
                }
                case 16: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    mGuidedDataBundle.putInt("next_direction", message.arg1);
                    return;
                }
                case 15: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    mGuidedDataBundle.putInt("immobile", message.arg1);
                    return;
                }
                case 14: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    mGuidedDataBundle.putInt("acceptance", message.arg1);
                    mGuidedDataBundle.putInt("reject_reason", message.arg2);
                    return;
                }
                case 13: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    int[] arrn = message.getData().getIntArray("maskList");
                    mGuidedDataBundle.putIntArray("maskList", arrn);
                    mGuidedDataBundle.putInt("maskNumber", message.arg1);
                    return;
                }
                case 12: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    int[] arrn = message.getData().getIntArray("nextTouch");
                    mGuidedDataBundle.putIntArray("nextTouch", arrn);
                    return;
                }
                case 11: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    int[] arrn = message.getData().getIntArray("lastTouch");
                    mGuidedDataBundle.putIntArray("lastTouch", arrn);
                    return;
                }
                case 10: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    FingerprintManager.this.PackGuidedData();
                    return;
                }
                case 8: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    FingerprintManager.this.mEnrolCallback.onEnrollmentFailed();
                    return;
                }
                case 7: {
                    if (FingerprintManager.this.mIdentifyCallback != null) {
                        FingerprintManager.this.mIdentifyCallback.onNoMatch();
                    }
                    if (FingerprintManager.this.mIdentifyListener == null) break;
                    FingerprintManager.this.mIdentifyListener.onResult(7, message.arg1, FingerprintManager.this.mUserdata);
                    return;
                }
                case 6: {
                    if (FingerprintManager.this.mIdentifyCallback != null) {
                        IdentifyCallback identifyCallback = FingerprintManager.this.mIdentifyCallback;
                        int n = message.arg1;
                        int n2 = message.arg2;
                        boolean bl = false;
                        if (n2 == 1) {
                            bl = true;
                        }
                        identifyCallback.onIdentified(n, bl);
                    }
                    if (FingerprintManager.this.mIdentifyListener == null) break;
                    FingerprintManager.this.mIdentifyListener.onResult(6, message.arg1, FingerprintManager.this.mUserdata);
                    return;
                }
                case 5: {
                    if (FingerprintManager.this.mEnrolCallback == null) break;
                    FingerprintManager.this.mEnrolCallback.onEnrolled(message.arg1);
                    if (!FingerprintManager.this.mReadyToStore) break;
                    FingerprintManager.this.mReadyToStore = false;
                    FingerprintManager.this.mEnrolCallback = null;
                    return;
                }
                case 4: {
                    FingerprintManager.this.mEnrolCallback;
                    return;
                }
                case 3: {
                    if (FingerprintManager.this.mCaptureCallback != null) {
                        FingerprintManager.this.mCaptureCallback.onCaptureCompleted();
                    }
                    if (FingerprintManager.this.mEnrolCallback != null) {
                        this.removeMessages(26);
                    }
                    if (FingerprintManager.this.mIdentifyListener == null) break;
                    FingerprintManager.this.mIdentifyListener.onStatus(3, FingerprintManager.this.mUserdata);
                    return;
                }
                case 2: {
                    if (FingerprintManager.this.mCaptureCallback != null) {
                        FingerprintManager.this.mCaptureCallback.onInput();
                    }
                    if (FingerprintManager.this.mEnrolCallback != null) {
                        this.sendMessageDelayed(this.obtainMessage(26), 3000L);
                    }
                    if (FingerprintManager.this.mIdentifyListener == null) break;
                    FingerprintManager.this.mIdentifyListener.onStatus(2, FingerprintManager.this.mUserdata);
                    this.removeMessages(21);
                    return;
                }
                case 1: {
                    if (FingerprintManager.this.mCaptureCallback != null) {
                        FingerprintManager.this.mCaptureCallback.onWaitingForInput();
                    }
                    if (FingerprintManager.this.mIdentifyListener == null) break;
                    FingerprintManager.this.mIdentifyListener.onStatus(1, FingerprintManager.this.mUserdata);
                }
            }
        }
    }

    public class GuidedData {
        public GuidedRect guidedLastTouch;
        public GuidedMaskList guidedMaskList;
        public int guidedNextDirection;
        public GuidedRect guidedNextTouch;
        public int guidedProgress;
        public GuidedResult guidedResult;

        public GuidedData(int n, int n2, GuidedResult guidedResult, GuidedRect guidedRect, GuidedRect guidedRect2, GuidedMaskList guidedMaskList) {
            this.guidedProgress = n;
            this.guidedNextDirection = n2;
            this.guidedResult = guidedResult;
            this.guidedLastTouch = guidedRect;
            this.guidedNextTouch = guidedRect2;
            this.guidedMaskList = guidedMaskList;
        }
    }

    public static interface GuidedDataCallback {
        public void onImageQuality(int var1, int var2);

        public void onImageStitched(int var1);

        public void onImmobile(int var1);

        public void onLastTouch(int[] var1);

        public void onMaskList(int var1, int[] var2);

        public void onNextDirection(int var1);

        public void onNextTouch(int[] var1);

        public void onProgressPercentage(int var1);

        public void onSendGuideData();
    }

    public class GuidedMaskList {
        public ArrayList<GuidedRect> guidedMaskList;
        public int guidedNumberOfMask;

        public GuidedMaskList(ArrayList<GuidedRect> arrayList, int n) {
            this.guidedMaskList = arrayList;
            this.guidedNumberOfMask = n;
        }
    }

    public class GuidedRect {
        public Point guidedBottomLeft;
        public Point guidedBottomRight;
        public Point guidedTopLeft;
        public Point guidedTopRight;

        public GuidedRect(Point point, Point point2, Point point3, Point point4) {
            this.guidedBottomLeft = point;
            this.guidedBottomRight = point2;
            this.guidedTopLeft = point3;
            this.guidedTopRight = point4;
        }
    }

    public class GuidedRejectReasons {
        public boolean guidedLowCoverage;
        public boolean guidedLowQuality;

        public GuidedRejectReasons(boolean bl, boolean bl2) {
            this.guidedLowCoverage = bl;
            this.guidedLowQuality = bl2;
        }
    }

    public class GuidedResult {
        public int guidedAcceptance;
        public boolean guidedImmobile;
        public GuidedRejectReasons guidedRejectReasons;
        public boolean guidedStitched;

        public GuidedResult(int n, boolean bl, boolean bl2, GuidedRejectReasons guidedRejectReasons) {
            this.guidedAcceptance = n;
            this.guidedStitched = bl;
            this.guidedImmobile = bl2;
            this.guidedRejectReasons = guidedRejectReasons;
        }
    }

    public static interface IdentifyCallback {
        public void onIdentified(int var1, boolean var2);

        public void onNoMatch();
    }

    public static interface IdentifyListener {
        public void onResult(int var1, int var2, int var3);

        public void onStatus(int var1, int var2);
    }

}

