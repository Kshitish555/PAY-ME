/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable$Creator
 *  android.os.RemoteException
 *  java.lang.Object
 *  java.lang.String
 */
package com.fingerprints.service;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

public interface IFingerprintClient
extends IInterface {
    public void onBundleMessage(int var1, int var2, int var3, Bundle var4) throws RemoteException;

    public void onBundleMessage2(int var1, int var2, int[] var3) throws RemoteException;

    public void onMessage(int var1, int var2, int var3) throws RemoteException;

}

