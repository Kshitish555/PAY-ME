/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.RemoteException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.fingerprints.service;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.fingerprints.service.IFingerprintClient;

public interface IFingerprintService
extends IInterface {
    public void cancel(IFingerprintClient var1) throws RemoteException;

    public int[] getIds(IFingerprintClient var1) throws RemoteException;

    public boolean isFingerEnable() throws RemoteException;

    public boolean isSurpport() throws RemoteException;

    public void notifyScreenOff() throws RemoteException;

    public void notifyScreenOn() throws RemoteException;

    public boolean open(IFingerprintClient var1) throws RemoteException;

    public void release(IFingerprintClient var1) throws RemoteException;

    public boolean removeData(IFingerprintClient var1, int[] var2) throws RemoteException;

    public void shouldRestartByScreenOn(IFingerprintClient var1) throws RemoteException;

    public void startEnrol(IFingerprintClient var1, int var2) throws RemoteException;

    public void startGuidedEnrol(IFingerprintClient var1, int var2) throws RemoteException;

    public void startIdentify(IFingerprintClient var1, int[] var2) throws RemoteException;

    public boolean updateTA(String var1) throws RemoteException;

}

