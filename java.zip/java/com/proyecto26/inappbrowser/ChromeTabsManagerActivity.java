/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Parcelable
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  org.greenrobot.eventbus.EventBus
 */
package com.proyecto26.inappbrowser;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import com.proyecto26.inappbrowser.ChromeTabsDismissedEvent;
import org.greenrobot.eventbus.EventBus;

public class ChromeTabsManagerActivity
extends Activity {
    static final String BROWSER_RESULT_TYPE = "browserResultType";
    static final String DEFAULT_RESULT_TYPE = "dismiss";
    static final String KEY_BROWSER_INTENT = "browserIntent";
    private boolean mOpened = false;
    private String resultType = null;

    private static Intent createBaseIntent(Context context) {
        return new Intent(context, ChromeTabsManagerActivity.class);
    }

    public static Intent createDismissIntent(Context context) {
        Intent intent = ChromeTabsManagerActivity.createBaseIntent(context);
        intent.addFlags(67108864);
        return intent;
    }

    public static Intent createStartIntent(Context context, Intent intent) {
        Intent intent2 = ChromeTabsManagerActivity.createBaseIntent(context);
        intent2.putExtra(KEY_BROWSER_INTENT, (Parcelable)intent);
        return intent2;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (this.getIntent().hasExtra(KEY_BROWSER_INTENT) && (bundle == null || bundle.getString(BROWSER_RESULT_TYPE) == null)) {
            Intent intent = (Intent)this.getIntent().getParcelableExtra(KEY_BROWSER_INTENT);
            intent.addFlags(67108864);
            this.startActivity(intent);
            this.resultType = DEFAULT_RESULT_TYPE;
            return;
        }
        this.finish();
    }

    protected void onDestroy() {
        String string2 = this.resultType;
        if (string2 != null) {
            int n2 = -1;
            if (string2.hashCode() == -1367724422 && string2.equals((Object)"cancel")) {
                n2 = 0;
            }
            if (n2 != 0) {
                EventBus.getDefault().post((Object)new ChromeTabsDismissedEvent("chrome tabs activity destroyed", DEFAULT_RESULT_TYPE));
            } else {
                EventBus.getDefault().post((Object)new ChromeTabsDismissedEvent("chrome tabs activity closed", this.resultType));
            }
            this.resultType = null;
        }
        super.onDestroy();
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.setIntent(intent);
    }

    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.resultType = bundle.getString(BROWSER_RESULT_TYPE);
    }

    protected void onResume() {
        super.onResume();
        if (!this.mOpened) {
            this.mOpened = true;
            return;
        }
        this.resultType = "cancel";
        this.finish();
    }

    protected void onSaveInstanceState(Bundle bundle) {
        bundle.putString(BROWSER_RESULT_TYPE, DEFAULT_RESULT_TYPE);
        super.onSaveInstanceState(bundle);
    }
}

