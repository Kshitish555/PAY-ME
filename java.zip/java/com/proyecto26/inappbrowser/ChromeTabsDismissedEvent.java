/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.proyecto26.inappbrowser;

public class ChromeTabsDismissedEvent {
    public final String message;
    public final String resultType;

    public ChromeTabsDismissedEvent(String string2, String string3) {
        this.message = string2;
        this.resultType = string3;
    }
}

