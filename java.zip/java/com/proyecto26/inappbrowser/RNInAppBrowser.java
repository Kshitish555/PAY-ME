/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.Color
 *  android.net.Uri
 *  android.os.Bundle
 *  androidx.browser.customtabs.CustomTabsIntent
 *  androidx.browser.customtabs.CustomTabsIntent$Builder
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.JSApplicationIllegalArgumentException
 *  com.facebook.react.bridge.Promise
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.ReadableMapKeySetIterator
 *  com.facebook.react.bridge.ReadableType
 *  com.facebook.react.bridge.WritableMap
 *  java.lang.AssertionError
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  org.greenrobot.eventbus.EventBus
 *  org.greenrobot.eventbus.Subscribe
 */
package com.proyecto26.inappbrowser;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import androidx.browser.customtabs.CustomTabsIntent;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.JSApplicationIllegalArgumentException;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableMapKeySetIterator;
import com.facebook.react.bridge.ReadableType;
import com.facebook.react.bridge.WritableMap;
import com.proyecto26.inappbrowser.ChromeTabsDismissedEvent;
import com.proyecto26.inappbrowser.ChromeTabsManagerActivity;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class RNInAppBrowser {
    private static final String ERROR_CODE = "InAppBrowser";
    private static final String KEY_ANIMATIONS = "animations";
    private static final String KEY_ANIMATION_END_ENTER = "endEnter";
    private static final String KEY_ANIMATION_END_EXIT = "endExit";
    private static final String KEY_ANIMATION_START_ENTER = "startEnter";
    private static final String KEY_ANIMATION_START_EXIT = "startExit";
    private static final String KEY_DEFAULT_SHARE_MENU_ITEM = "enableDefaultShare";
    private static final String KEY_ENABLE_URL_BAR_HIDING = "enableUrlBarHiding";
    private static final String KEY_FORCE_CLOSE_ON_REDIRECTION = "forceCloseOnRedirection";
    private static final String KEY_HEADERS = "headers";
    private static final String KEY_SECONDARY_TOOLBAR_COLOR = "secondaryToolbarColor";
    private static final String KEY_SHOW_PAGE_TITLE = "showTitle";
    private static final String KEY_TOOLBAR_COLOR = "toolbarColor";
    private static final Pattern animationIdentifierPattern = Pattern.compile((String)"^.+:.+/");
    private Activity currentActivity;
    private Promise mOpenBrowserPromise;

    private void registerEventBus() {
        if (!EventBus.getDefault().isRegistered((Object)this)) {
            EventBus.getDefault().register((Object)this);
        }
    }

    private int resolveAnimationIdentifierIfNeeded(Context context, String string2) {
        if (animationIdentifierPattern.matcher((CharSequence)string2).find()) {
            return context.getResources().getIdentifier(string2, null, null);
        }
        return context.getResources().getIdentifier(string2, "anim", context.getPackageName());
    }

    private void unRegisterEventBus() {
        if (EventBus.getDefault().isRegistered((Object)this)) {
            EventBus.getDefault().unregister((Object)this);
        }
    }

    void applyAnimation(Context context, CustomTabsIntent.Builder builder, ReadableMap readableMap) {
        int n2 = readableMap.hasKey(KEY_ANIMATION_START_ENTER) ? this.resolveAnimationIdentifierIfNeeded(context, readableMap.getString(KEY_ANIMATION_START_ENTER)) : -1;
        int n3 = readableMap.hasKey(KEY_ANIMATION_START_EXIT) ? this.resolveAnimationIdentifierIfNeeded(context, readableMap.getString(KEY_ANIMATION_START_EXIT)) : -1;
        int n4 = readableMap.hasKey(KEY_ANIMATION_END_ENTER) ? this.resolveAnimationIdentifierIfNeeded(context, readableMap.getString(KEY_ANIMATION_END_ENTER)) : -1;
        int n5 = readableMap.hasKey(KEY_ANIMATION_END_EXIT) ? this.resolveAnimationIdentifierIfNeeded(context, readableMap.getString(KEY_ANIMATION_END_EXIT)) : -1;
        if (n2 != -1 && n3 != -1) {
            builder.setStartAnimations(context, n2, n3);
        }
        if (n4 != -1 && n5 != -1) {
            builder.setExitAnimations(context, n4, n5);
        }
    }

    public void close() {
        Promise promise = this.mOpenBrowserPromise;
        if (promise == null) {
            return;
        }
        if (this.currentActivity == null) {
            promise.reject(ERROR_CODE, "No activity");
            this.mOpenBrowserPromise = null;
            return;
        }
        this.unRegisterEventBus();
        WritableMap writableMap = Arguments.createMap();
        writableMap.putString("type", "dismiss");
        this.mOpenBrowserPromise.resolve((Object)writableMap);
        this.mOpenBrowserPromise = null;
        Activity activity = this.currentActivity;
        activity.startActivity(ChromeTabsManagerActivity.createDismissIntent((Context)activity));
    }

    @Subscribe
    public void onEvent(ChromeTabsDismissedEvent chromeTabsDismissedEvent) {
        this.unRegisterEventBus();
        if (this.mOpenBrowserPromise != null) {
            WritableMap writableMap = Arguments.createMap();
            writableMap.putString("type", chromeTabsDismissedEvent.resultType);
            this.mOpenBrowserPromise.resolve((Object)writableMap);
            this.mOpenBrowserPromise = null;
            return;
        }
        throw new AssertionError();
    }

    public void open(Context context, ReadableMap readableMap, Promise promise, Activity activity) {
        ReadableMapKeySetIterator readableMapKeySetIterator;
        ReadableMap readableMap2;
        String string2 = readableMap.getString("url");
        this.currentActivity = activity;
        if (this.mOpenBrowserPromise != null) {
            WritableMap writableMap = Arguments.createMap();
            writableMap.putString("type", "cancel");
            this.mOpenBrowserPromise.resolve((Object)writableMap);
            this.mOpenBrowserPromise = null;
            return;
        }
        this.mOpenBrowserPromise = promise;
        if (this.currentActivity == null) {
            this.mOpenBrowserPromise.reject(ERROR_CODE, "No activity");
            this.mOpenBrowserPromise = null;
            return;
        }
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        if (readableMap.hasKey(KEY_TOOLBAR_COLOR)) {
            String string3 = readableMap.getString(KEY_TOOLBAR_COLOR);
            try {
                builder.setToolbarColor(Color.parseColor((String)string3));
            }
            catch (IllegalArgumentException illegalArgumentException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Invalid toolbar color '");
                stringBuilder.append(string3);
                stringBuilder.append("': ");
                stringBuilder.append(illegalArgumentException.getMessage());
                throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
            }
        }
        if (readableMap.hasKey(KEY_SECONDARY_TOOLBAR_COLOR)) {
            String string4 = readableMap.getString(KEY_SECONDARY_TOOLBAR_COLOR);
            try {
                builder.setSecondaryToolbarColor(Color.parseColor((String)string4));
            }
            catch (IllegalArgumentException illegalArgumentException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Invalid secondary toolbar color '");
                stringBuilder.append(string4);
                stringBuilder.append("': ");
                stringBuilder.append(illegalArgumentException.getMessage());
                throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
            }
        }
        if (readableMap.hasKey(KEY_ENABLE_URL_BAR_HIDING) && readableMap.getBoolean(KEY_ENABLE_URL_BAR_HIDING)) {
            builder.enableUrlBarHiding();
        }
        if (readableMap.hasKey(KEY_DEFAULT_SHARE_MENU_ITEM) && readableMap.getBoolean(KEY_DEFAULT_SHARE_MENU_ITEM)) {
            builder.addDefaultShareMenuItem();
        }
        if (readableMap.hasKey(KEY_ANIMATIONS)) {
            this.applyAnimation(context, builder, readableMap.getMap(KEY_ANIMATIONS));
        }
        CustomTabsIntent customTabsIntent = builder.build();
        if (readableMap.hasKey(KEY_HEADERS) && (readableMap2 = readableMap.getMap(KEY_HEADERS)) != null && (readableMapKeySetIterator = readableMap2.keySetIterator()).hasNextKey()) {
            Bundle bundle = new Bundle();
            while (readableMapKeySetIterator.hasNextKey()) {
                String string5 = readableMapKeySetIterator.nextKey();
                ReadableType readableType = readableMap2.getType(string5);
                if (1.$SwitchMap$com$facebook$react$bridge$ReadableType[readableType.ordinal()] != 1) continue;
                bundle.putString(string5, readableMap2.getString(string5));
            }
            customTabsIntent.intent.putExtra("com.android.browser.headers", bundle);
        }
        if (readableMap.hasKey(KEY_FORCE_CLOSE_ON_REDIRECTION) && readableMap.getBoolean(KEY_FORCE_CLOSE_ON_REDIRECTION)) {
            customTabsIntent.intent.addFlags(1073741824);
            customTabsIntent.intent.addFlags(268435456);
            customTabsIntent.intent.addFlags(8388608);
        }
        Intent intent = customTabsIntent.intent;
        intent.setData(Uri.parse((String)string2));
        if (readableMap.hasKey(KEY_SHOW_PAGE_TITLE)) {
            builder.setShowTitle(readableMap.getBoolean(KEY_SHOW_PAGE_TITLE));
        } else {
            intent.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY", 0);
        }
        this.registerEventBus();
        Activity activity2 = this.currentActivity;
        activity2.startActivity(ChromeTabsManagerActivity.createStartIntent((Context)activity2, intent), customTabsIntent.startAnimationBundle);
    }

}

