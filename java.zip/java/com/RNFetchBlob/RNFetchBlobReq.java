/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.DownloadManager
 *  android.app.DownloadManager$Query
 *  android.app.DownloadManager$Request
 *  android.content.BroadcastReceiver
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.database.Cursor
 *  android.net.ConnectivityManager
 *  android.net.Network
 *  android.net.NetworkCapabilities
 *  android.net.NetworkInfo
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  com.RNFetchBlob.RNFetchBlob
 *  com.facebook.common.logging.FLog
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.ReadableMapKeySetIterator
 *  com.facebook.react.bridge.WritableArray
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.modules.core.DeviceEventManagerModule
 *  com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Long
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.MalformedURLException
 *  java.net.Proxy
 *  java.net.URL
 *  java.security.KeyStore
 *  java.security.SecureRandom
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.TimeUnit
 *  javax.net.SocketFactory
 *  javax.net.ssl.KeyManager
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSocketFactory
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.TrustManagerFactory
 *  javax.net.ssl.X509TrustManager
 *  okhttp3.Call
 *  okhttp3.Callback
 *  okhttp3.ConnectionPool
 *  okhttp3.ConnectionSpec
 *  okhttp3.ConnectionSpec$Builder
 *  okhttp3.Headers
 *  okhttp3.Interceptor
 *  okhttp3.MediaType
 *  okhttp3.OkHttpClient
 *  okhttp3.OkHttpClient$Builder
 *  okhttp3.Request
 *  okhttp3.Request$Builder
 *  okhttp3.RequestBody
 *  okhttp3.Response
 *  okhttp3.TlsVersion
 */
package com.RNFetchBlob;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import com.RNFetchBlob.RNFetchBlob;
import com.RNFetchBlob.RNFetchBlobBody;
import com.RNFetchBlob.RNFetchBlobConfig;
import com.RNFetchBlob.RNFetchBlobFS;
import com.RNFetchBlob.RNFetchBlobProgressConfig;
import com.RNFetchBlob.RNFetchBlobReq;
import com.RNFetchBlob.RNFetchBlobUtils;
import com.facebook.common.logging.FLog;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableMapKeySetIterator;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import java.io.File;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.SocketFactory;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import okhttp3.Call;
import okhttp3.ConnectionPool;
import okhttp3.ConnectionSpec;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.TlsVersion;

public class RNFetchBlobReq
extends BroadcastReceiver
implements Runnable {
    public static HashMap<String, Long> androidDownloadManagerTaskTable;
    static ConnectionPool pool;
    static HashMap<String, RNFetchBlobProgressConfig> progressReport;
    public static HashMap<String, Call> taskTable;
    static HashMap<String, RNFetchBlobProgressConfig> uploadProgressReport;
    Callback callback;
    OkHttpClient client;
    long contentLength;
    String destPath;
    long downloadManagerId;
    ReadableMap headers;
    String method;
    RNFetchBlobConfig options;
    String rawRequestBody;
    ReadableArray rawRequestBodyArray;
    ArrayList<String> redirects = new ArrayList();
    RNFetchBlobBody requestBody;
    RequestType requestType;
    WritableMap respInfo;
    ResponseFormat responseFormat = ResponseFormat.Auto;
    ResponseType responseType;
    String taskId;
    boolean timeout = false;
    String url;

    static {
        taskTable = new HashMap();
        androidDownloadManagerTaskTable = new HashMap();
        progressReport = new HashMap();
        uploadProgressReport = new HashMap();
        pool = new ConnectionPool();
    }

    public RNFetchBlobReq(ReadableMap readableMap, String string2, String string3, String string4, ReadableMap readableMap2, String string5, ReadableArray readableArray, OkHttpClient okHttpClient, Callback callback) {
        this.method = string3.toUpperCase();
        this.options = new RNFetchBlobConfig(readableMap);
        this.taskId = string2;
        this.url = string4;
        this.headers = readableMap2;
        this.callback = callback;
        this.rawRequestBody = string5;
        this.rawRequestBodyArray = readableArray;
        this.client = okHttpClient;
        this.responseType = !this.options.fileCache.booleanValue() && this.options.path == null ? ResponseType.KeepInMemory : ResponseType.FileStorage;
        if (string5 != null) {
            this.requestType = RequestType.SingleFile;
            return;
        }
        if (readableArray != null) {
            this.requestType = RequestType.Form;
            return;
        }
        this.requestType = RequestType.WithoutBody;
    }

    static /* synthetic */ void access$000(RNFetchBlobReq rNFetchBlobReq) {
        rNFetchBlobReq.releaseTaskResource();
    }

    static /* synthetic */ void access$100(RNFetchBlobReq rNFetchBlobReq, Response response) {
        rNFetchBlobReq.done(response);
    }

    public static void cancelTask(String string2) {
        if (taskTable.containsKey((Object)string2)) {
            ((Call)taskTable.get((Object)string2)).cancel();
            taskTable.remove((Object)string2);
        }
        if (androidDownloadManagerTaskTable.containsKey((Object)string2)) {
            long l = (Long)androidDownloadManagerTaskTable.get((Object)string2);
            ((DownloadManager)RNFetchBlob.RCTContext.getApplicationContext().getSystemService("download")).remove(new long[]{l});
        }
    }

    /*
     * Exception decompiling
     */
    private void done(Response var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl320 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private void emitStateEvent(WritableMap writableMap) {
        ((DeviceEventManagerModule.RCTDeviceEventEmitter)RNFetchBlob.RCTContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)).emit("RNFetchBlobState", (Object)writableMap);
    }

    public static OkHttpClient.Builder enableTls12OnPreLollipop(OkHttpClient.Builder builder) {
        if (Build.VERSION.SDK_INT >= 16 && Build.VERSION.SDK_INT <= 19) {
            Object[] arrobject;
            block4 : {
                TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance((String)TrustManagerFactory.getDefaultAlgorithm());
                trustManagerFactory.init((KeyStore)null);
                arrobject = trustManagerFactory.getTrustManagers();
                if (arrobject.length != 1 || !(arrobject[0] instanceof X509TrustManager)) break block4;
                X509TrustManager x509TrustManager = (X509TrustManager)arrobject[0];
                SSLContext sSLContext = SSLContext.getInstance((String)"SSL");
                sSLContext.init(null, new TrustManager[]{x509TrustManager}, null);
                builder.sslSocketFactory(sSLContext.getSocketFactory(), x509TrustManager);
                ConnectionSpec.Builder builder2 = new ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS);
                TlsVersion[] arrtlsVersion = new TlsVersion[]{TlsVersion.TLS_1_2};
                ConnectionSpec connectionSpec = builder2.tlsVersions(arrtlsVersion).build();
                ArrayList arrayList = new ArrayList();
                arrayList.add((Object)connectionSpec);
                arrayList.add((Object)ConnectionSpec.COMPATIBLE_TLS);
                arrayList.add((Object)ConnectionSpec.CLEARTEXT);
                builder.connectionSpecs((List)arrayList);
                return builder;
            }
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unexpected default trust managers:");
                stringBuilder.append(Arrays.toString((Object[])arrobject));
                throw new IllegalStateException(stringBuilder.toString());
            }
            catch (Exception exception) {
                FLog.e((String)"OkHttpClientProvider", (String)"Error while enabling TLS 1.2", (Throwable)exception);
            }
        }
        return builder;
    }

    private String getHeaderIgnoreCases(HashMap<String, String> hashMap, String string2) {
        String string3 = (String)hashMap.get((Object)string2);
        if (string3 != null) {
            return string3;
        }
        String string4 = (String)hashMap.get((Object)string2.toLowerCase());
        if (string4 == null) {
            string4 = "";
        }
        return string4;
    }

    private String getHeaderIgnoreCases(Headers headers, String string2) {
        String string3 = headers.get(string2);
        if (string3 != null) {
            return string3;
        }
        if (headers.get(string2.toLowerCase()) == null) {
            return "";
        }
        return headers.get(string2.toLowerCase());
    }

    public static RNFetchBlobProgressConfig getReportProgress(String string2) {
        if (!progressReport.containsKey((Object)string2)) {
            return null;
        }
        return (RNFetchBlobProgressConfig)progressReport.get((Object)string2);
    }

    public static RNFetchBlobProgressConfig getReportUploadProgress(String string2) {
        if (!uploadProgressReport.containsKey((Object)string2)) {
            return null;
        }
        return (RNFetchBlobProgressConfig)uploadProgressReport.get((Object)string2);
    }

    private WritableMap getResponseInfo(Response response, boolean bl) {
        WritableMap writableMap = Arguments.createMap();
        writableMap.putInt("status", response.code());
        writableMap.putString("state", "2");
        writableMap.putString("taskId", this.taskId);
        writableMap.putBoolean("timeout", this.timeout);
        WritableMap writableMap2 = Arguments.createMap();
        for (int i = 0; i < response.headers().size(); ++i) {
            writableMap2.putString(response.headers().name(i), response.headers().value(i));
        }
        WritableArray writableArray = Arguments.createArray();
        Iterator iterator = this.redirects.iterator();
        while (iterator.hasNext()) {
            writableArray.pushString((String)iterator.next());
        }
        writableMap.putArray("redirects", (ReadableArray)writableArray);
        writableMap.putMap("headers", (ReadableMap)writableMap2);
        Headers headers = response.headers();
        if (bl) {
            writableMap.putString("respType", "blob");
            return writableMap;
        }
        if (this.getHeaderIgnoreCases(headers, "content-type").equalsIgnoreCase("text/")) {
            writableMap.putString("respType", "text");
            return writableMap;
        }
        if (this.getHeaderIgnoreCases(headers, "content-type").contains((CharSequence)"application/json")) {
            writableMap.putString("respType", "json");
            return writableMap;
        }
        writableMap.putString("respType", "");
        return writableMap;
    }

    private boolean isBlobResponse(Response response) {
        boolean bl;
        String string2 = this.getHeaderIgnoreCases(response.headers(), "Content-Type");
        boolean bl2 = string2.equalsIgnoreCase("text/");
        boolean bl3 = true;
        boolean bl4 = bl2 ^ bl3;
        boolean bl5 = bl3 ^ string2.equalsIgnoreCase("application/json");
        if (this.options.binaryContentTypes != null) {
            for (int i = 0; i < this.options.binaryContentTypes.size(); ++i) {
                if (!string2.toLowerCase().contains((CharSequence)this.options.binaryContentTypes.getString(i).toLowerCase())) continue;
                bl = true;
                break;
            }
        } else {
            bl = false;
        }
        if (bl5 || bl4) {
            if (bl) {
                return bl3;
            }
            bl3 = false;
        }
        return bl3;
    }

    private void releaseTaskResource() {
        RNFetchBlobBody rNFetchBlobBody;
        if (taskTable.containsKey((Object)this.taskId)) {
            taskTable.remove((Object)this.taskId);
        }
        if (androidDownloadManagerTaskTable.containsKey((Object)this.taskId)) {
            androidDownloadManagerTaskTable.remove((Object)this.taskId);
        }
        if (uploadProgressReport.containsKey((Object)this.taskId)) {
            uploadProgressReport.remove((Object)this.taskId);
        }
        if (progressReport.containsKey((Object)this.taskId)) {
            progressReport.remove((Object)this.taskId);
        }
        if ((rNFetchBlobBody = this.requestBody) != null) {
            rNFetchBlobBody.clearRequestBody();
        }
    }

    public void onReceive(Context context, Intent intent) {
        if ("android.intent.action.DOWNLOAD_COMPLETE".equals((Object)intent.getAction())) {
            Context context2 = RNFetchBlob.RCTContext.getApplicationContext();
            if (intent.getExtras().getLong("extra_download_id") == this.downloadManagerId) {
                Cursor cursor;
                String string2;
                block17 : {
                    block18 : {
                        this.releaseTaskResource();
                        DownloadManager.Query query = new DownloadManager.Query();
                        long[] arrl = new long[]{this.downloadManagerId};
                        query.setFilterById(arrl);
                        DownloadManager downloadManager = (DownloadManager)context2.getSystemService("download");
                        downloadManager.query(query);
                        cursor = downloadManager.query(query);
                        if (cursor == null) {
                            Callback callback = this.callback;
                            Object[] arrobject = new Object[3];
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Download manager failed to download from  ");
                            stringBuilder.append(this.url);
                            stringBuilder.append(". Query was unsuccessful ");
                            arrobject[0] = stringBuilder.toString();
                            arrobject[1] = null;
                            arrobject[2] = null;
                            callback.invoke(arrobject);
                            return;
                        }
                        if (!cursor.moveToFirst()) break block17;
                        int n = cursor.getInt(cursor.getColumnIndex("status"));
                        if (n != 16) break block18;
                        Callback callback = this.callback;
                        Object[] arrobject = new Object[3];
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Download manager failed to download from  ");
                        stringBuilder.append(this.url);
                        stringBuilder.append(". Status Code = ");
                        stringBuilder.append(n);
                        arrobject[0] = stringBuilder.toString();
                        arrobject[1] = null;
                        arrobject[2] = null;
                        callback.invoke(arrobject);
                        return;
                    }
                    String string3 = cursor.getString(cursor.getColumnIndex("local_uri"));
                    if (string3 == null) break block17;
                    if (!this.options.addAndroidDownloads.hasKey("mime") || !this.options.addAndroidDownloads.getString("mime").contains((CharSequence)"image")) break block17;
                    Uri uri = Uri.parse((String)string3);
                    Cursor cursor2 = context2.getContentResolver().query(uri, new String[]{"_data"}, null, null, null);
                    if (cursor2 == null) break block17;
                    cursor2.moveToFirst();
                    string2 = cursor2.getString(0);
                    cursor2.close();
                }
                string2 = null;
                if (cursor != null) {
                    cursor.close();
                }
                if (this.options.addAndroidDownloads.hasKey("path")) {
                    try {
                        String string4 = this.options.addAndroidDownloads.getString("path");
                        if (new File(string4).exists()) {
                            this.callback.invoke(new Object[]{null, "path", string4});
                            return;
                        }
                        throw new Exception("Download manager download failed, the file does not downloaded to destination.");
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        Callback callback = this.callback;
                        Object[] arrobject = new Object[]{exception.getLocalizedMessage(), null};
                        callback.invoke(arrobject);
                        return;
                    }
                }
                if (string2 == null) {
                    this.callback.invoke(new Object[]{"Download manager could not resolve downloaded file path.", "path", null});
                    return;
                }
                this.callback.invoke(new Object[]{null, "path", string2});
                return;
                finally {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void run() {
        String string2;
        if (this.options.addAndroidDownloads != null && this.options.addAndroidDownloads.hasKey("useDownloadManager") && this.options.addAndroidDownloads.getBoolean("useDownloadManager")) {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse((String)this.url));
            if (this.options.addAndroidDownloads.hasKey("notification") && this.options.addAndroidDownloads.getBoolean("notification")) {
                request.setNotificationVisibility(1);
            } else {
                request.setNotificationVisibility(2);
            }
            if (this.options.addAndroidDownloads.hasKey("title")) {
                request.setTitle((CharSequence)this.options.addAndroidDownloads.getString("title"));
            }
            if (this.options.addAndroidDownloads.hasKey("description")) {
                request.setDescription((CharSequence)this.options.addAndroidDownloads.getString("description"));
            }
            if (this.options.addAndroidDownloads.hasKey("path")) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("file://");
                stringBuilder.append(this.options.addAndroidDownloads.getString("path"));
                request.setDestinationUri(Uri.parse((String)stringBuilder.toString()));
            }
            if (this.options.addAndroidDownloads.hasKey("mime")) {
                request.setMimeType(this.options.addAndroidDownloads.getString("mime"));
            }
            ReadableMapKeySetIterator readableMapKeySetIterator = this.headers.keySetIterator();
            if (this.options.addAndroidDownloads.hasKey("mediaScannable") && this.options.addAndroidDownloads.hasKey("mediaScannable")) {
                request.allowScanningByMediaScanner();
            }
            do {
                if (!readableMapKeySetIterator.hasNextKey()) {
                    Context context = RNFetchBlob.RCTContext.getApplicationContext();
                    this.downloadManagerId = ((DownloadManager)context.getSystemService("download")).enqueue(request);
                    androidDownloadManagerTaskTable.put((Object)this.taskId, (Object)this.downloadManagerId);
                    context.registerReceiver((BroadcastReceiver)this, new IntentFilter("android.intent.action.DOWNLOAD_COMPLETE"));
                    return;
                }
                String string3 = readableMapKeySetIterator.nextKey();
                request.addRequestHeader(string3, this.headers.getString(string3));
            } while (true);
        }
        String string4 = this.taskId;
        if (this.options.appendExt.isEmpty()) {
            string2 = "";
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(".");
            stringBuilder.append(this.options.appendExt);
            string2 = stringBuilder.toString();
        }
        if (this.options.key != null) {
            string4 = RNFetchBlobUtils.getMD5(this.options.key);
            if (string4 == null) {
                string4 = this.taskId;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(RNFetchBlobFS.getTmpPath(string4));
            stringBuilder.append(string2);
            File file = new File(stringBuilder.toString());
            if (file.exists()) {
                Callback callback = this.callback;
                Object[] arrobject = new Object[]{null, "path", file.getAbsolutePath()};
                callback.invoke(arrobject);
                return;
            }
        }
        if (this.options.path != null) {
            this.destPath = this.options.path;
        } else if (this.options.fileCache.booleanValue()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(RNFetchBlobFS.getTmpPath(string4));
            stringBuilder.append(string2);
            this.destPath = stringBuilder.toString();
        }
        try {
            boolean bl;
            OkHttpClient.Builder builder = this.options.trusty != false ? RNFetchBlobUtils.getUnsafeOkHttpClient(this.client) : this.client.newBuilder();
            if (this.options.wifiOnly.booleanValue()) {
                if (Build.VERSION.SDK_INT < 21) {
                    RNFetchBlobUtils.emitWarningEvent("RNFetchBlob: wifiOnly was set, but SDK < 21. wifiOnly was ignored.");
                } else {
                    boolean bl2;
                    block54 : {
                        ReactApplicationContext reactApplicationContext = RNFetchBlob.RCTContext;
                        ConnectivityManager connectivityManager = (ConnectivityManager)reactApplicationContext.getSystemService("connectivity");
                        for (Network network : connectivityManager.getAllNetworks()) {
                            NetworkInfo networkInfo = connectivityManager.getNetworkInfo(network);
                            NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(network);
                            if (networkCapabilities == null || networkInfo == null || !networkInfo.isConnected() || !networkCapabilities.hasTransport(1)) continue;
                            builder.proxy(Proxy.NO_PROXY);
                            builder.socketFactory(network.getSocketFactory());
                            bl2 = true;
                            break block54;
                        }
                        bl2 = false;
                    }
                    if (!bl2) {
                        this.callback.invoke(new Object[]{"No available WiFi connections.", null, null});
                        this.releaseTaskResource();
                        return;
                    }
                }
            }
            Request.Builder builder2 = new Request.Builder();
            try {
                builder2.url(new URL(this.url));
            }
            catch (MalformedURLException malformedURLException) {
                malformedURLException.printStackTrace();
            }
            HashMap hashMap = new HashMap();
            if (this.headers != null) {
                ReadableMapKeySetIterator readableMapKeySetIterator = this.headers.keySetIterator();
                while (readableMapKeySetIterator.hasNextKey()) {
                    String string5 = readableMapKeySetIterator.nextKey();
                    String string6 = this.headers.getString(string5);
                    if (string5.equalsIgnoreCase("RNFB-Response")) {
                        if (string6.equalsIgnoreCase("base64")) {
                            this.responseFormat = ResponseFormat.BASE64;
                            continue;
                        }
                        if (!string6.equalsIgnoreCase("utf8")) continue;
                        this.responseFormat = ResponseFormat.UTF8;
                        continue;
                    }
                    builder2.header(string5.toLowerCase(), string6);
                    hashMap.put((Object)string5.toLowerCase(), (Object)string6);
                }
            }
            if (!((bl = this.method.equalsIgnoreCase("post")) || this.method.equalsIgnoreCase("put") || this.method.equalsIgnoreCase("patch"))) {
                this.requestType = RequestType.WithoutBody;
            } else {
                String string7 = this.getHeaderIgnoreCases((HashMap<String, String>)hashMap, "Content-Type").toLowerCase();
                if (this.rawRequestBodyArray != null) {
                    this.requestType = RequestType.Form;
                } else if (string7.isEmpty()) {
                    if (!string7.equalsIgnoreCase("")) {
                        builder2.header("Content-Type", "application/octet-stream");
                    }
                    this.requestType = RequestType.SingleFile;
                }
                if (this.rawRequestBody != null) {
                    if (!this.rawRequestBody.startsWith("RNFetchBlob-file://") && !this.rawRequestBody.startsWith("RNFetchBlob-content://")) {
                        if (!string7.toLowerCase().contains((CharSequence)";base64") && !string7.toLowerCase().startsWith("application/octet")) {
                            this.requestType = RequestType.AsIs;
                        } else {
                            String string8 = string7.replace((CharSequence)";base64", (CharSequence)"").replace((CharSequence)";BASE64", (CharSequence)"");
                            if (hashMap.containsKey((Object)"content-type")) {
                                hashMap.put((Object)"content-type", (Object)string8);
                            }
                            if (hashMap.containsKey((Object)"Content-Type")) {
                                hashMap.put((Object)"Content-Type", (Object)string8);
                            }
                            this.requestType = RequestType.SingleFile;
                        }
                    } else {
                        this.requestType = RequestType.SingleFile;
                    }
                }
            }
            boolean bl3 = this.getHeaderIgnoreCases((HashMap<String, String>)hashMap, "Transfer-Encoding").equalsIgnoreCase("chunked");
            int n = 4.$SwitchMap$com$RNFetchBlob$RNFetchBlobReq$RequestType[this.requestType.ordinal()];
            if (n != 1) {
                if (n != 2) {
                    if (n != 3) {
                        if (n == 4) {
                            if (!(this.method.equalsIgnoreCase("post") || this.method.equalsIgnoreCase("put") || this.method.equalsIgnoreCase("patch"))) {
                                builder2.method(this.method, null);
                            } else {
                                builder2.method(this.method, RequestBody.create(null, (byte[])new byte[0]));
                            }
                        }
                    } else {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("RNFetchBlob-");
                        stringBuilder.append(this.taskId);
                        String string9 = stringBuilder.toString();
                        RNFetchBlobBody rNFetchBlobBody = new RNFetchBlobBody(this.taskId).chunkedEncoding(bl3).setRequestType(this.requestType).setBody(this.rawRequestBodyArray);
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("multipart/form-data; boundary=");
                        stringBuilder2.append(string9);
                        this.requestBody = rNFetchBlobBody.setMIME(MediaType.parse((String)stringBuilder2.toString()));
                        builder2.method(this.method, (RequestBody)this.requestBody);
                    }
                } else {
                    this.requestBody = new RNFetchBlobBody(this.taskId).chunkedEncoding(bl3).setRequestType(this.requestType).setBody(this.rawRequestBody).setMIME(MediaType.parse((String)this.getHeaderIgnoreCases((HashMap<String, String>)hashMap, "content-type")));
                    builder2.method(this.method, (RequestBody)this.requestBody);
                }
            } else {
                this.requestBody = new RNFetchBlobBody(this.taskId).chunkedEncoding(bl3).setRequestType(this.requestType).setBody(this.rawRequestBody).setMIME(MediaType.parse((String)this.getHeaderIgnoreCases((HashMap<String, String>)hashMap, "content-type")));
                builder2.method(this.method, (RequestBody)this.requestBody);
            }
            Request request = builder2.build();
            builder.addNetworkInterceptor(new Interceptor(this){
                final /* synthetic */ RNFetchBlobReq this$0;
                {
                    this.this$0 = rNFetchBlobReq;
                }

                public Response intercept(okhttp3.Interceptor$Chain chain) throws java.io.IOException {
                    this.this$0.redirects.add((Object)chain.request().url().toString());
                    return chain.proceed(chain.request());
                }
            });
            builder.addInterceptor(new Interceptor(this, request){
                final /* synthetic */ RNFetchBlobReq this$0;
                final /* synthetic */ Request val$req;
                {
                    this.this$0 = rNFetchBlobReq;
                    this.val$req = request;
                }

                /*
                 * Exception decompiling
                 */
                public Response intercept(}
        }
        java.lang.IllegalStateException: Parameters not created
        
        