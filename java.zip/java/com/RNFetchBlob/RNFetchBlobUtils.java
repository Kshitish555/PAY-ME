/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.RNFetchBlob.RNFetchBlob
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.modules.core.DeviceEventManagerModule
 *  com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.security.MessageDigest
 *  java.security.SecureRandom
 *  java.security.cert.CertificateException
 *  java.security.cert.X509Certificate
 *  javax.net.ssl.HostnameVerifier
 *  javax.net.ssl.KeyManager
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSession
 *  javax.net.ssl.SSLSocketFactory
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.X509TrustManager
 *  okhttp3.OkHttpClient
 *  okhttp3.OkHttpClient$Builder
 */
package com.RNFetchBlob;

import com.RNFetchBlob.RNFetchBlob;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import okhttp3.OkHttpClient;

public class RNFetchBlobUtils {
    public static void emitWarningEvent(String string2) {
        WritableMap writableMap = Arguments.createMap();
        writableMap.putString("event", "warn");
        writableMap.putString("detail", string2);
        ((DeviceEventManagerModule.RCTDeviceEventEmitter)RNFetchBlob.RCTContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)).emit("RNFetchBlobMessage", (Object)writableMap);
    }

    public static String getMD5(String string2) {
        MessageDigest messageDigest = MessageDigest.getInstance((String)"MD5");
        messageDigest.update(string2.getBytes());
        byte[] arrby = messageDigest.digest();
        StringBuilder stringBuilder = new StringBuilder();
        int n = arrby.length;
        for (int i = 0; i < n; ++i) {
            byte by = arrby[i];
            Object[] arrobject = new Object[]{by & 255};
            stringBuilder.append(String.format((String)"%02x", (Object[])arrobject));
        }
        try {
            String string3 = stringBuilder.toString();
            return string3;
        }
        catch (Exception exception) {
            try {
                exception.printStackTrace();
            }
            catch (Throwable throwable) {}
        }
        return null;
    }

    public static OkHttpClient.Builder getUnsafeOkHttpClient(OkHttpClient okHttpClient) {
        try {
            X509TrustManager x509TrustManager = new X509TrustManager(){

                public void checkClientTrusted(X509Certificate[] arrx509Certificate, String string2) throws CertificateException {
                }

                public void checkServerTrusted(X509Certificate[] arrx509Certificate, String string2) throws CertificateException {
                }

                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            };
            TrustManager[] arrtrustManager = new TrustManager[]{x509TrustManager};
            SSLContext sSLContext = SSLContext.getInstance((String)"SSL");
            sSLContext.init(null, arrtrustManager, new SecureRandom());
            SSLSocketFactory sSLSocketFactory = sSLContext.getSocketFactory();
            OkHttpClient.Builder builder = okHttpClient.newBuilder();
            builder.sslSocketFactory(sSLSocketFactory, x509TrustManager);
            builder.hostnameVerifier(new HostnameVerifier(){

                public boolean verify(String string2, SSLSession sSLSession) {
                    return true;
                }
            });
            return builder;
        }
        catch (Exception exception) {
            throw new RuntimeException((Throwable)exception);
        }
    }

}

