/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.res.AssetFileDescriptor
 *  android.content.res.AssetManager
 *  android.media.MediaScannerConnection
 *  android.media.MediaScannerConnection$OnScanCompletedListener
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.os.StatFs
 *  android.os.SystemClock
 *  android.util.Base64
 *  com.RNFetchBlob.RNFetchBlob
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.Promise
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.WritableArray
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.modules.core.DeviceEventManagerModule
 *  com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 *  java.nio.CharBuffer
 *  java.nio.charset.Charset
 *  java.nio.charset.CharsetEncoder
 *  java.security.MessageDigest
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.UUID
 */
package com.RNFetchBlob;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;
import android.util.Base64;
import com.RNFetchBlob.RNFetchBlob;
import com.RNFetchBlob.Utils.PathResolver;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

class RNFetchBlobFS {
    private static HashMap<String, RNFetchBlobFS> fileStreams = new HashMap();
    private DeviceEventManagerModule.RCTDeviceEventEmitter emitter;
    private String encoding = "base64";
    private ReactApplicationContext mCtx;
    private OutputStream writeStreamInstance = null;

    RNFetchBlobFS(ReactApplicationContext reactApplicationContext) {
        this.mCtx = reactApplicationContext;
        this.emitter = (DeviceEventManagerModule.RCTDeviceEventEmitter)reactApplicationContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class);
    }

    static void closeStream(String string2, Callback callback) {
        try {
            OutputStream outputStream = ((RNFetchBlobFS)RNFetchBlobFS.fileStreams.get((Object)string2)).writeStreamInstance;
            fileStreams.remove((Object)string2);
            outputStream.close();
            callback.invoke(new Object[0]);
            return;
        }
        catch (Exception exception) {
            Object[] arrobject = new Object[]{exception.getLocalizedMessage()};
            callback.invoke(arrobject);
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static void cp(String var0, String var1_1, Callback var2_2) {
        block22 : {
            block25 : {
                block26 : {
                    block24 : {
                        block23 : {
                            var3_3 = RNFetchBlobFS.normalizePath(var0);
                            var4_4 = null;
                            if (!RNFetchBlobFS.isPathExists(var3_3)) {
                                var35_5 = new Object[1];
                                var36_6 = new StringBuilder();
                                var36_6.append("Source file at path`");
                                var36_6.append(var3_3);
                                var36_6.append("` does not exist");
                                var35_5[0] = var36_6.toString();
                                var2_2.invoke(var35_5);
                                return;
                            }
                            if (!new File(var1_1).exists() && !new File(var1_1).createNewFile()) {
                                var30_7 = new Object[1];
                                var31_8 = new StringBuilder();
                                var31_8.append("Destination file at '");
                                var31_8.append(var1_1);
                                var31_8.append("' already exists");
                                var30_7[0] = var31_8.toString();
                                var2_2.invoke(var30_7);
                                return;
                            }
                            var21_9 = RNFetchBlobFS.inputStreamFromPath(var3_3);
                            var6_10 = new FileOutputStream(var1_1);
                            var24_11 = new byte[10240];
                            while ((var25_12 = var21_9.read(var24_11)) > 0) {
                                var6_10.write(var24_11, 0, var25_12);
                            }
                            if (var21_9 == null) ** GOTO lbl33
                            try {
                                var21_9.close();
lbl33: // 2 sources:
                                var6_10.close();
                                var16_13 = "";
                                break block22;
                            }
                            catch (Exception var26_14) {}
                            catch (Throwable var23_16) {
                                break block23;
                            }
                            catch (Exception var22_19) {
                                break block24;
                            }
                            catch (Throwable var23_17) {
                                var6_10 = null;
                            }
                        }
                        var4_4 = var21_9;
                        var8_22 = var23_18;
                        break block25;
                        catch (Exception var22_20) {
                            var6_10 = null;
                        }
                    }
                    var4_4 = var21_9;
                    var5_25 = var22_21;
                    break block26;
                    catch (Throwable var8_23) {
                        var4_4 = null;
                        var6_10 = null;
                        break block25;
                    }
                    catch (Exception var5_26) {
                        var6_10 = null;
                    }
                }
                var7_27 = new StringBuilder();
                var7_27.append("");
                var7_27.append(var5_25.getLocalizedMessage());
                var16_13 = var7_27.toString();
                if (var4_4 == null) ** GOTO lbl68
                try {
                    var4_4.close();
lbl68: // 2 sources:
                    if (var6_10 != null) {
                        var6_10.close();
                    }
                    break block22;
                }
                catch (Exception var17_28) {}
                catch (Throwable var8_24) {
                    // empty catch block
                }
            }
            if (var4_4 == null) ** GOTO lbl78
            try {
                var4_4.close();
lbl78: // 2 sources:
                if (var6_10 == null) throw var8_22;
                var6_10.close();
                throw var8_22;
            }
            catch (Exception var9_30) {}
            var27_15 = new StringBuilder();
            var27_15.append("");
            var27_15.append(var26_14.getLocalizedMessage());
            var16_13 = var27_15.toString();
            break block22;
            var18_29 = new StringBuilder();
            var18_29.append(var16_13);
            var18_29.append(var17_28.getLocalizedMessage());
            var16_13 = var18_29.toString();
        }
        if (var16_13 != "") {
            var2_2.invoke(new Object[]{var16_13});
            return;
        }
        var2_2.invoke(new Object[0]);
        return;
        var10_31 = new StringBuilder();
        var10_31.append("");
        var10_31.append(var9_30.getLocalizedMessage());
        var10_31.toString();
        throw var8_22;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void createFile(String string2, String string3, String string4, Promise promise) {
        try {
            File file = new File(string2);
            boolean bl = file.createNewFile();
            if (string4.equals((Object)"uri")) {
                File file2 = new File(string3.replace((CharSequence)"RNFetchBlob-file://", (CharSequence)""));
                if (!file2.exists()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Source file : ");
                    stringBuilder.append(string3);
                    stringBuilder.append(" does not exist");
                    promise.reject("ENOENT", stringBuilder.toString());
                    return;
                }
                FileInputStream fileInputStream = new FileInputStream(file2);
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                byte[] arrby = new byte[10240];
                int n = fileInputStream.read(arrby);
                while (n > 0) {
                    fileOutputStream.write(arrby, 0, n);
                    n = fileInputStream.read(arrby);
                }
                fileInputStream.close();
                fileOutputStream.close();
            } else {
                if (!bl) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("File `");
                    stringBuilder.append(string2);
                    stringBuilder.append("` already exists");
                    promise.reject("EEXIST", stringBuilder.toString());
                    return;
                }
                new FileOutputStream(file).write(RNFetchBlobFS.stringToBytes(string3, string4));
            }
            promise.resolve((Object)string2);
            return;
        }
        catch (Exception exception) {
            promise.reject("EUNSPECIFIED", exception.getLocalizedMessage());
            return;
        }
    }

    static void createFileASCII(String string2, ReadableArray readableArray, Promise promise) {
        File file = new File(string2);
        if (!file.createNewFile()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("File at path `");
            stringBuilder.append(string2);
            stringBuilder.append("` already exists");
            promise.reject("EEXIST", stringBuilder.toString());
            return;
        }
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        byte[] arrby = new byte[readableArray.size()];
        int n = 0;
        do {
            if (n >= readableArray.size()) break;
            arrby[n] = (byte)readableArray.getInt(n);
            ++n;
        } while (true);
        try {
            fileOutputStream.write(arrby);
            promise.resolve((Object)string2);
            return;
        }
        catch (Exception exception) {
            promise.reject("EUNSPECIFIED", exception.getLocalizedMessage());
            return;
        }
    }

    private static void deleteRecursive(File file) throws IOException {
        IOException iOException;
        if (file.isDirectory()) {
            File[] arrfile = file.listFiles();
            if (arrfile != null) {
                int n = arrfile.length;
                for (int i = 0; i < n; ++i) {
                    RNFetchBlobFS.deleteRecursive(arrfile[i]);
                }
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Received null trying to list files of directory '");
                stringBuilder.append((Object)file);
                stringBuilder.append("'");
                throw new NullPointerException(stringBuilder.toString());
            }
        }
        if (file.delete()) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to delete '");
        stringBuilder.append((Object)file);
        stringBuilder.append("'");
        iOException = new IOException(stringBuilder.toString());
        throw iOException;
    }

    static void df(Callback callback) {
        StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
        WritableMap writableMap = Arguments.createMap();
        if (Build.VERSION.SDK_INT >= 18) {
            writableMap.putString("internal_free", String.valueOf((long)statFs.getFreeBytes()));
            writableMap.putString("internal_total", String.valueOf((long)statFs.getTotalBytes()));
            StatFs statFs2 = new StatFs(Environment.getExternalStorageDirectory().getPath());
            writableMap.putString("external_free", String.valueOf((long)statFs2.getFreeBytes()));
            writableMap.putString("external_total", String.valueOf((long)statFs2.getTotalBytes()));
        }
        callback.invoke(new Object[]{null, writableMap});
    }

    private void emitStreamEvent(String string2, String string3, WritableArray writableArray) {
        WritableMap writableMap = Arguments.createMap();
        writableMap.putString("event", string3);
        writableMap.putArray("detail", (ReadableArray)writableArray);
        this.emitter.emit(string2, (Object)writableMap);
    }

    private void emitStreamEvent(String string2, String string3, String string4) {
        WritableMap writableMap = Arguments.createMap();
        writableMap.putString("event", string3);
        writableMap.putString("detail", string4);
        this.emitter.emit(string2, (Object)writableMap);
    }

    private void emitStreamEvent(String string2, String string3, String string4, String string5) {
        WritableMap writableMap = Arguments.createMap();
        writableMap.putString("event", string3);
        writableMap.putString("code", string4);
        writableMap.putString("detail", string5);
        this.emitter.emit(string2, (Object)writableMap);
    }

    static void exists(String string2, Callback callback) {
        boolean bl = RNFetchBlobFS.isAsset(string2);
        Boolean bl2 = false;
        if (bl) {
            try {
                String string3 = string2.replace((CharSequence)"bundle-assets://", (CharSequence)"");
                RNFetchBlob.RCTContext.getAssets().openFd(string3);
                Object[] arrobject = new Object[]{true, bl2};
                callback.invoke(arrobject);
                return;
            }
            catch (IOException iOException) {
                callback.invoke(new Object[]{bl2, bl2});
                return;
            }
        }
        String string4 = RNFetchBlobFS.normalizePath(string2);
        if (string4 != null) {
            boolean bl3 = new File(string4).exists();
            boolean bl4 = new File(string4).isDirectory();
            Object[] arrobject = new Object[]{bl3, bl4};
            callback.invoke(arrobject);
            return;
        }
        callback.invoke(new Object[]{bl2, bl2});
    }

    public static void getSDCardApplicationDir(ReactApplicationContext reactApplicationContext, Promise promise) {
        if (Environment.getExternalStorageState().equals((Object)"mounted")) {
            try {
                promise.resolve((Object)reactApplicationContext.getExternalFilesDir(null).getParentFile().getAbsolutePath());
                return;
            }
            catch (Exception exception) {
                promise.reject("RNFetchBlob.getSDCardApplicationDir", exception.getLocalizedMessage());
                return;
            }
        }
        promise.reject("RNFetchBlob.getSDCardApplicationDir", "External storage not mounted");
    }

    public static void getSDCardDir(Promise promise) {
        if (Environment.getExternalStorageState().equals((Object)"mounted")) {
            promise.resolve((Object)Environment.getExternalStorageDirectory().getAbsolutePath());
            return;
        }
        promise.reject("RNFetchBlob.getSDCardDir", "External storage not mounted");
    }

    static Map<String, Object> getSystemfolders(ReactApplicationContext reactApplicationContext) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"DocumentDir", (Object)reactApplicationContext.getFilesDir().getAbsolutePath());
        hashMap.put((Object)"CacheDir", (Object)reactApplicationContext.getCacheDir().getAbsolutePath());
        hashMap.put((Object)"DCIMDir", (Object)Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_DCIM).getAbsolutePath());
        hashMap.put((Object)"PictureDir", (Object)Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_PICTURES).getAbsolutePath());
        hashMap.put((Object)"MusicDir", (Object)Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_MUSIC).getAbsolutePath());
        hashMap.put((Object)"DownloadDir", (Object)Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_DOWNLOADS).getAbsolutePath());
        hashMap.put((Object)"MovieDir", (Object)Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_MOVIES).getAbsolutePath());
        hashMap.put((Object)"RingtoneDir", (Object)Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_RINGTONES).getAbsolutePath());
        if (Environment.getExternalStorageState().equals((Object)"mounted")) {
            hashMap.put((Object)"SDCardDir", (Object)Environment.getExternalStorageDirectory().getAbsolutePath());
            File file = reactApplicationContext.getExternalFilesDir(null);
            if (file != null) {
                hashMap.put((Object)"SDCardApplicationDir", (Object)file.getParentFile().getAbsolutePath());
            } else {
                hashMap.put((Object)"SDCardApplicationDir", (Object)"");
            }
        }
        hashMap.put((Object)"MainBundleDir", (Object)reactApplicationContext.getApplicationInfo().dataDir);
        return hashMap;
    }

    static String getTmpPath(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((Object)RNFetchBlob.RCTContext.getFilesDir());
        stringBuilder.append("/RNFetchBlobTmp_");
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void hash(String string2, String string3, Promise promise) {
        try {
            HashMap hashMap = new HashMap();
            hashMap.put((Object)"md5", (Object)"MD5");
            hashMap.put((Object)"sha1", (Object)"SHA-1");
            hashMap.put((Object)"sha224", (Object)"SHA-224");
            hashMap.put((Object)"sha256", (Object)"SHA-256");
            hashMap.put((Object)"sha384", (Object)"SHA-384");
            hashMap.put((Object)"sha512", (Object)"SHA-512");
            if (!hashMap.containsKey((Object)string3)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Invalid algorithm '");
                stringBuilder.append(string3);
                stringBuilder.append("', must be one of md5, sha1, sha224, sha256, sha384, sha512");
                promise.reject("EINVAL", stringBuilder.toString());
                return;
            }
            File file = new File(string2);
            if (file.isDirectory()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Expecting a file but '");
                stringBuilder.append(string2);
                stringBuilder.append("' is a directory");
                promise.reject("EISDIR", stringBuilder.toString());
                return;
            }
            if (!file.exists()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("No such file '");
                stringBuilder.append(string2);
                stringBuilder.append("'");
                promise.reject("ENOENT", stringBuilder.toString());
                return;
            }
            MessageDigest messageDigest = MessageDigest.getInstance((String)((String)hashMap.get((Object)string3)));
            FileInputStream fileInputStream = new FileInputStream(string2);
            byte[] arrby = new byte[1048576];
            if (file.length() != 0L) {
                int n;
                while ((n = fileInputStream.read(arrby)) != -1) {
                    messageDigest.update(arrby, 0, n);
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            for (byte by : messageDigest.digest()) {
                Object[] arrobject = new Object[]{by};
                stringBuilder.append(String.format((String)"%02x", (Object[])arrobject));
            }
            promise.resolve((Object)stringBuilder.toString());
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            promise.reject("EUNSPECIFIED", exception.getLocalizedMessage());
            return;
        }
    }

    private static InputStream inputStreamFromPath(String string2) throws IOException {
        if (string2.startsWith("bundle-assets://")) {
            return RNFetchBlob.RCTContext.getAssets().open(string2.replace((CharSequence)"bundle-assets://", (CharSequence)""));
        }
        return new FileInputStream(new File(string2));
    }

    static boolean isAsset(String string2) {
        return string2 != null && string2.startsWith("bundle-assets://");
    }

    private static boolean isPathExists(String string2) {
        if (string2.startsWith("bundle-assets://")) {
            try {
                RNFetchBlob.RCTContext.getAssets().open(string2.replace((CharSequence)"bundle-assets://", (CharSequence)""));
                return true;
            }
            catch (IOException iOException) {
                return false;
            }
        }
        return new File(string2).exists();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void ls(String string2, Promise promise) {
        try {
            String string3 = RNFetchBlobFS.normalizePath(string2);
            File file = new File(string3);
            boolean bl = file.exists();
            if (!bl) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("No such file '");
                stringBuilder.append(string3);
                stringBuilder.append("'");
                promise.reject("ENOENT", stringBuilder.toString());
                return;
            }
            if (!file.isDirectory()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Not a directory '");
                stringBuilder.append(string3);
                stringBuilder.append("'");
                promise.reject("ENOTDIR", stringBuilder.toString());
                return;
            }
            String[] arrstring = new File(string3).list();
            WritableArray writableArray = Arguments.createArray();
            int n = arrstring.length;
            for (int i = 0; i < n; ++i) {
                writableArray.pushString(arrstring[i]);
            }
            promise.resolve((Object)writableArray);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            promise.reject("EUNSPECIFIED", exception.getLocalizedMessage());
            return;
        }
    }

    static void lstat(String string2, final Callback callback) {
        String string3 = RNFetchBlobFS.normalizePath(string2);
        new AsyncTask<String, Integer, Integer>(){

            protected /* varargs */ Integer doInBackground(String ... arrstring) {
                WritableArray writableArray = Arguments.createArray();
                Integer n = 0;
                if (arrstring[0] == null) {
                    callback.invoke(new Object[]{"the path specified for lstat is either `null` or `undefined`."});
                    return n;
                }
                File file = new File(arrstring[0]);
                if (!file.exists()) {
                    Callback callback2 = callback;
                    Object[] arrobject = new Object[1];
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("failed to lstat path `");
                    stringBuilder.append(arrstring[0]);
                    stringBuilder.append("` because it does not exist or it is not a folder");
                    arrobject[0] = stringBuilder.toString();
                    callback2.invoke(arrobject);
                    return n;
                }
                if (file.isDirectory()) {
                    for (String string2 : file.list()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(file.getPath());
                        stringBuilder.append("/");
                        stringBuilder.append(string2);
                        writableArray.pushMap((ReadableMap)RNFetchBlobFS.statFile(stringBuilder.toString()));
                    }
                } else {
                    writableArray.pushMap((ReadableMap)RNFetchBlobFS.statFile(file.getAbsolutePath()));
                }
                callback.invoke(new Object[]{null, writableArray});
                return n;
            }
        }.execute((Object[])new String[]{string3});
    }

    static void mkdir(String string2, Promise promise) {
        block3 : {
            File file = new File(string2);
            if (file.exists()) {
                StringBuilder stringBuilder = new StringBuilder();
                String string3 = file.isDirectory() ? "Folder" : "File";
                stringBuilder.append(string3);
                stringBuilder.append(" '");
                stringBuilder.append(string2);
                stringBuilder.append("' already exists");
                promise.reject("EEXIST", stringBuilder.toString());
                return;
            }
            try {
                if (file.mkdirs()) break block3;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("mkdir failed to create some or all directories in '");
                stringBuilder.append(string2);
                stringBuilder.append("'");
                promise.reject("EUNSPECIFIED", stringBuilder.toString());
                return;
            }
            catch (Exception exception) {
                promise.reject("EUNSPECIFIED", exception.getLocalizedMessage());
                return;
            }
        }
        promise.resolve((Object)true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void mv(String string2, String string3, Callback callback) {
        File file = new File(string2);
        if (!file.exists()) {
            Object[] arrobject = new Object[1];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Source file at path `");
            stringBuilder.append(string2);
            stringBuilder.append("` does not exist");
            arrobject[0] = stringBuilder.toString();
            callback.invoke(arrobject);
            return;
        }
        try {
            int n;
            FileInputStream fileInputStream = new FileInputStream(string2);
            FileOutputStream fileOutputStream = new FileOutputStream(string3);
            byte[] arrby = new byte[1024];
            while ((n = fileInputStream.read(arrby)) != -1) {
                fileOutputStream.write(arrby, 0, n);
            }
            fileInputStream.close();
            fileOutputStream.flush();
            file.delete();
        }
        catch (Exception exception) {
            Object[] arrobject = new Object[]{exception.toString()};
            callback.invoke(arrobject);
            return;
        }
        catch (FileNotFoundException fileNotFoundException) {
            callback.invoke(new Object[]{"Source file not found."});
            return;
        }
        callback.invoke(new Object[0]);
        return;
    }

    static String normalizePath(String string2) {
        if (string2 == null) {
            return null;
        }
        if (!string2.matches("\\w+\\:.*")) {
            return string2;
        }
        if (string2.startsWith("file://")) {
            return string2.replace((CharSequence)"file://", (CharSequence)"");
        }
        Uri uri = Uri.parse((String)string2);
        if (string2.startsWith("bundle-assets://")) {
            return string2;
        }
        return PathResolver.getRealPathFromURI((Context)RNFetchBlob.RCTContext, uri);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static void readFile(String var0, String var1_1, Promise var2_2) {
        var3_3 = RNFetchBlobFS.normalizePath(var0);
        if (var3_3 != null) {
            var0 = var3_3;
        }
        var4_4 = 0;
        if (var3_3 == null) ** GOTO lbl-1000
        try {
            if (var3_3.startsWith("bundle-assets://")) {
                var35_5 = var0.replace((CharSequence)"bundle-assets://", (CharSequence)"");
                var19_6 = (int)RNFetchBlob.RCTContext.getAssets().openFd(var35_5).getLength();
                var20_7 = new byte[var19_6];
                var36_8 = RNFetchBlob.RCTContext.getAssets().open(var35_5);
                var21_9 = var36_8.read(var20_7, 0, var19_6);
                var36_8.close();
            } else if (var3_3 == null) {
                var18_10 = RNFetchBlob.RCTContext.getContentResolver().openInputStream(Uri.parse((String)var0));
                var19_6 = var18_10.available();
                var20_7 = new byte[var19_6];
                var21_9 = var18_10.read(var20_7);
                var18_10.close();
            } else {
                var32_11 = new File(var0);
                var19_6 = (int)var32_11.length();
                var20_7 = new byte[var19_6];
                var33_12 = new FileInputStream(var32_11);
                var34_13 = var33_12.read(var20_7);
                var33_12.close();
                var21_9 = var34_13;
            }
            if (var21_9 < var19_6) {
                var22_14 = new StringBuilder();
                var22_14.append("Read only ");
                var22_14.append(var21_9);
                var22_14.append(" bytes of ");
                var22_14.append(var19_6);
                var2_2.reject("EUNSPECIFIED", var22_14.toString());
                return;
            }
            var27_15 = var1_1.toLowerCase();
            var28_16 = -1;
            var29_17 = var27_15.hashCode();
            if (var29_17 != -1396204209) {
                if (var29_17 != 3600241) {
                    if (var29_17 == 93106001 && var27_15.equals((Object)"ascii")) {
                        var28_16 = 1;
                    }
                } else if (var27_15.equals((Object)"utf8")) {
                    var28_16 = 2;
                }
            } else if (var27_15.equals((Object)"base64")) {
                var28_16 = 0;
            }
            if (var28_16 != 0) {
                if (var28_16 != 1) {
                    if (var28_16 != 2) {
                        var2_2.resolve((Object)new String(var20_7));
                        return;
                    }
                    var2_2.resolve((Object)new String(var20_7));
                    return;
                }
                var30_18 = Arguments.createArray();
                var31_19 = var20_7.length;
            } else {
                var2_2.resolve((Object)Base64.encodeToString((byte[])var20_7, (int)2));
                return;
            }
            while (var4_4 < var31_19) {
                var30_18.pushInt((int)var20_7[var4_4]);
                ++var4_4;
            }
            var2_2.resolve((Object)var30_18);
            return;
        }
        catch (Exception var17_20) {
            var2_2.reject("EUNSPECIFIED", var17_20.getLocalizedMessage());
            return;
        }
        catch (FileNotFoundException var5_21) {
            var6_22 = var5_21.getLocalizedMessage();
            if (var6_22.contains((CharSequence)"EISDIR")) {
                var7_23 = new StringBuilder();
                var7_23.append("Expecting a file but '");
                var7_23.append(var0);
                var7_23.append("' is a directory; ");
                var7_23.append(var6_22);
                var2_2.reject("EISDIR", var7_23.toString());
                return;
            }
            var12_24 = new StringBuilder();
            var12_24.append("No such file '");
            var12_24.append(var0);
            var12_24.append("'; ");
            var12_24.append(var6_22);
            var2_2.reject("ENOENT", var12_24.toString());
            return;
        }
    }

    static void removeSession(ReadableArray readableArray, final Callback callback) {
        new AsyncTask<ReadableArray, Integer, Integer>(){

            protected /* varargs */ Integer doInBackground(ReadableArray ... arrreadableArray) {
                ArrayList arrayList = new ArrayList();
                int n = 0;
                do {
                    block9 : {
                        try {
                            if (n < arrreadableArray[0].size()) {
                                String string2 = arrreadableArray[0].getString(n);
                                File file = new File(string2);
                                if (file.exists() && !file.delete()) {
                                    arrayList.add((Object)string2);
                                }
                                break block9;
                            }
                            if (arrayList.isEmpty()) {
                                Callback callback2 = callback;
                                Object[] arrobject = new Object[]{null, true};
                                callback2.invoke(arrobject);
                            } else {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Failed to delete: ");
                                Iterator iterator = arrayList.iterator();
                                while (iterator.hasNext()) {
                                    stringBuilder.append((String)iterator.next());
                                    stringBuilder.append(", ");
                                }
                                Callback callback3 = callback;
                                Object[] arrobject = new Object[]{stringBuilder.toString()};
                                callback3.invoke(arrobject);
                            }
                        }
                        catch (Exception exception) {
                            Callback callback4 = callback;
                            Object[] arrobject = new Object[]{exception.getLocalizedMessage()};
                            callback4.invoke(arrobject);
                        }
                        return arrreadableArray[0].size();
                    }
                    ++n;
                } while (true);
            }
        }.execute((Object[])new ReadableArray[]{readableArray});
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static void slice(String var0, String var1_1, int var2_2, int var3_3, String var4_4, Promise var5_5) {
        var7_6 = RNFetchBlobFS.normalizePath(var0);
        var8_7 = new File(var7_6);
        if (var8_7.isDirectory()) {
            var9_8 = new StringBuilder();
            var9_8.append("Expecting a file but '");
            var9_8.append(var7_6);
            var9_8.append("' is a directory");
            var5_5.reject("EISDIR", var9_8.toString());
            return;
        }
        if (!var8_7.exists()) {
            var13_9 = new StringBuilder();
            var13_9.append("No such file '");
            var13_9.append(var7_6);
            var13_9.append("'");
            var5_5.reject("ENOENT", var13_9.toString());
            return;
        }
        var17_10 = (int)var8_7.length();
        var18_11 = Math.min((int)var17_10, (int)var3_3) - var2_2;
        var19_12 = new FileInputStream(new File(var7_6));
        var20_13 = new FileOutputStream(new File(var1_1));
        var21_14 = (int)var19_12.skip((long)var2_2);
        if (var21_14 == var2_2) ** GOTO lbl34
        var22_15 = new StringBuilder();
        var22_15.append("Skipped ");
        var22_15.append(var21_14);
        var22_15.append(" instead of the specified ");
        var22_15.append(var2_2);
        var22_15.append(" bytes, size is ");
        var22_15.append(var17_10);
        var5_5.reject("EUNSPECIFIED", var22_15.toString());
        return;
lbl34: // 1 sources:
        var29_16 = new byte[10240];
        for (var30_17 = 0; var30_17 < var18_11; var30_17 += var31_19) {
            var31_19 = var19_12.read(var29_16, 0, 10240);
            var32_18 = var18_11 - var30_17;
            if (var31_19 <= 0) break;
            var20_13.write(var29_16, 0, Math.min((int)var32_18, (int)var31_19));
        }
        try {
            var19_12.close();
            var20_13.flush();
            var20_13.close();
            var5_5.resolve((Object)var1_1);
            return;
        }
        catch (Exception var6_20) {
            var6_20.printStackTrace();
            var5_5.reject("EUNSPECIFIED", var6_20.getLocalizedMessage());
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void stat(String string2, Callback callback) {
        try {
            String string3 = RNFetchBlobFS.normalizePath(string2);
            WritableMap writableMap = RNFetchBlobFS.statFile(string3);
            if (writableMap == null) {
                Object[] arrobject = new Object[2];
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("failed to stat path `");
                stringBuilder.append(string3);
                stringBuilder.append("` because it does not exist or it is not a folder");
                arrobject[0] = stringBuilder.toString();
                arrobject[1] = null;
                callback.invoke(arrobject);
                return;
            }
            callback.invoke(new Object[]{null, writableMap});
            return;
        }
        catch (Exception exception) {
            Object[] arrobject = new Object[]{exception.getLocalizedMessage()};
            callback.invoke(arrobject);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static WritableMap statFile(String string2) {
        try {
            String string3 = RNFetchBlobFS.normalizePath(string2);
            WritableMap writableMap = Arguments.createMap();
            boolean bl = RNFetchBlobFS.isAsset(string3);
            if (bl) {
                String string4 = string3.replace((CharSequence)"bundle-assets://", (CharSequence)"");
                AssetFileDescriptor assetFileDescriptor = RNFetchBlob.RCTContext.getAssets().openFd(string4);
                writableMap.putString("filename", string4);
                writableMap.putString("path", string3);
                writableMap.putString("type", "asset");
                writableMap.putString("size", String.valueOf((long)assetFileDescriptor.getLength()));
                writableMap.putInt("lastModified", 0);
                return writableMap;
            }
            File file = new File(string3);
            if (!file.exists()) {
                return null;
            }
            writableMap.putString("filename", file.getName());
            writableMap.putString("path", file.getPath());
            String string5 = file.isDirectory() ? "directory" : "file";
            writableMap.putString("type", string5);
            writableMap.putString("size", String.valueOf((long)file.length()));
            writableMap.putString("lastModified", String.valueOf((long)file.lastModified()));
            return writableMap;
        }
        catch (Exception exception) {
            return null;
        }
    }

    private static byte[] stringToBytes(String string2, String string3) {
        if (string3.equalsIgnoreCase("ascii")) {
            return string2.getBytes(Charset.forName((String)"US-ASCII"));
        }
        if (string3.toLowerCase().contains((CharSequence)"base64")) {
            return Base64.decode((String)string2, (int)2);
        }
        if (string3.equalsIgnoreCase("utf8")) {
            return string2.getBytes(Charset.forName((String)"UTF-8"));
        }
        return string2.getBytes(Charset.forName((String)"US-ASCII"));
    }

    static void unlink(String string2, Callback callback) {
        try {
            RNFetchBlobFS.deleteRecursive(new File(RNFetchBlobFS.normalizePath(string2)));
            Object[] arrobject = new Object[]{null, true};
            callback.invoke(arrobject);
            return;
        }
        catch (Exception exception) {
            Object[] arrobject = new Object[]{exception.getLocalizedMessage(), false};
            callback.invoke(arrobject);
            return;
        }
    }

    static void writeArrayChunk(String string2, ReadableArray readableArray, Callback callback) {
        OutputStream outputStream = ((RNFetchBlobFS)RNFetchBlobFS.fileStreams.get((Object)string2)).writeStreamInstance;
        byte[] arrby = new byte[readableArray.size()];
        int n = 0;
        do {
            if (n >= readableArray.size()) break;
            arrby[n] = (byte)readableArray.getInt(n);
            ++n;
        } while (true);
        try {
            outputStream.write(arrby);
            callback.invoke(new Object[0]);
            return;
        }
        catch (Exception exception) {
            Object[] arrobject = new Object[]{exception.getLocalizedMessage()};
            callback.invoke(arrobject);
            return;
        }
    }

    static void writeChunk(String string2, String string3, Callback callback) {
        RNFetchBlobFS rNFetchBlobFS = (RNFetchBlobFS)fileStreams.get((Object)string2);
        OutputStream outputStream = rNFetchBlobFS.writeStreamInstance;
        byte[] arrby = RNFetchBlobFS.stringToBytes(string3, rNFetchBlobFS.encoding);
        try {
            outputStream.write(arrby);
            callback.invoke(new Object[0]);
            return;
        }
        catch (Exception exception) {
            Object[] arrobject = new Object[]{exception.getLocalizedMessage()};
            callback.invoke(arrobject);
            return;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static void writeFile(String string2, ReadableArray readableArray, boolean bl, Promise promise) {
        File file = new File(string2);
        File file2 = file.getParentFile();
        if (!file.exists()) {
            if (file2 != null && !file2.exists() && !file2.mkdirs()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Failed to create parent directory of '");
                stringBuilder.append(string2);
                stringBuilder.append("'");
                promise.reject("ENOTDIR", stringBuilder.toString());
                return;
            }
            if (!file.createNewFile()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("File '");
                stringBuilder.append(string2);
                stringBuilder.append("' does not exist and could not be created");
                promise.reject("ENOENT", stringBuilder.toString());
                return;
            }
        }
        FileOutputStream fileOutputStream = new FileOutputStream(file, bl);
        byte[] arrby = new byte[readableArray.size()];
        for (int i = 0; i < readableArray.size(); ++i) {
            arrby[i] = (byte)readableArray.getInt(i);
        }
        fileOutputStream.write(arrby);
        {
            catch (Throwable throwable) {
                fileOutputStream.close();
                throw throwable;
            }
        }
        try {
            fileOutputStream.close();
            promise.resolve((Object)readableArray.size());
            return;
        }
        catch (Exception exception) {
            promise.reject("EUNSPECIFIED", exception.getLocalizedMessage());
            return;
        }
        catch (FileNotFoundException fileNotFoundException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("File '");
            stringBuilder.append(string2);
            stringBuilder.append("' does not exist and could not be created");
            promise.reject("ENOENT", stringBuilder.toString());
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    static void writeFile(String var0, String var1_1, String var2_2, boolean var3_3, Promise var4_4) {
        var5_5 = new File(var0);
        var11_6 = var5_5.getParentFile();
        if (!var5_5.exists()) {
            if (var11_6 != null && !var11_6.exists() && !var11_6.mkdirs()) {
                var34_7 = new StringBuilder();
                var34_7.append("Failed to create parent directory of '");
                var34_7.append(var0);
                var34_7.append("'");
                var4_4.reject("EUNSPECIFIED", var34_7.toString());
                return;
            }
            if (!var5_5.createNewFile()) {
                var12_8 = new StringBuilder();
                var12_8.append("File '");
                var12_8.append(var0);
                var12_8.append("' does not exist and could not be created");
                var4_4.reject("ENOENT", var12_8.toString());
                return;
            }
        }
        if (!var1_1.equalsIgnoreCase("uri")) ** GOTO lbl54
        var20_9 = RNFetchBlobFS.normalizePath(var2_2);
        var21_10 = new File(var20_9);
        if (!var21_10.exists()) {
            var22_11 = new StringBuilder();
            var22_11.append("No such file '");
            var22_11.append(var0);
            var22_11.append("' ('");
            var22_11.append(var20_9);
            var22_11.append("')");
            var4_4.reject("ENOENT", var22_11.toString());
            return;
        }
        var28_12 = new byte[10240];
        var29_13 = new FileInputStream(var21_10);
        var30_14 = new FileOutputStream(var5_5, var3_3);
        var19_15 = 0;
        do {
            var33_16 = var29_13.read(var28_12);
            if (var33_16 <= 0) break;
            var30_14.write(var28_12, 0, var33_16);
            var19_15 += var33_16;
        } while (true);
        var29_13.close();
        var30_14.close();
        ** GOTO lbl64
lbl48: // 3 sources:
        do {
            if (var29_13 != null) {
                var29_13.close();
            }
            if (var32_17 != null) {
                var32_17.close();
            }
            throw var31_18;
            break;
        } while (true);
lbl54: // 1 sources:
        var16_22 = RNFetchBlobFS.stringToBytes(var2_2, var1_1);
        var17_23 = new FileOutputStream(var5_5, var3_3);
        var17_23.write(var16_22);
        var19_15 = var16_22.length;
        {
            catch (Throwable var18_24) {
                var17_23.close();
                throw var18_24;
            }
        }
        try {
            var17_23.close();
lbl64: // 2 sources:
            var4_4.resolve((Object)var19_15);
            return;
        }
        catch (Exception var10_25) {
            var4_4.reject("EUNSPECIFIED", var10_25.getLocalizedMessage());
            return;
        }
        catch (FileNotFoundException v0) {
            var6_26 = new StringBuilder();
            var6_26.append("File '");
            var6_26.append(var0);
            var6_26.append("' does not exist and could not be created, or it is a directory");
            var4_4.reject("ENOENT", var6_26.toString());
            return;
        }
        catch (Throwable var31_19) {
            var32_17 = var30_14;
            ** GOTO lbl48
        }
        catch (Throwable var31_20) {
            var32_17 = null;
            ** GOTO lbl48
        }
        catch (Throwable var31_21) {
            var32_17 = null;
            var29_13 = null;
            ** continue;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void readStream(String string2, String string3, int n, int n2, String string4) {
        Object object;
        boolean bl;
        block16 : {
            block14 : {
                String string5;
                int n3;
                int n4;
                int n5;
                byte[] arrby;
                block15 : {
                    String string6 = RNFetchBlobFS.normalizePath(string2);
                    String string7 = string6 != null ? string6 : string2;
                    try {
                        int n6;
                        boolean bl2 = string3.equalsIgnoreCase("base64");
                        n4 = bl2 ? 4095 : 4096;
                        if (n > 0) {
                            n4 = n;
                        }
                        object = string6 != null && string7.startsWith("bundle-assets://") ? RNFetchBlob.RCTContext.getAssets().open(string7.replace((CharSequence)"bundle-assets://", (CharSequence)"")) : (string6 == null ? RNFetchBlob.RCTContext.getContentResolver().openInputStream(Uri.parse((String)string7)) : new FileInputStream(new File(string7)));
                        arrby = new byte[n4];
                        boolean bl3 = string3.equalsIgnoreCase("utf8");
                        n3 = -1;
                        string5 = "data";
                        if (bl3) {
                            int n7;
                            CharsetEncoder charsetEncoder = Charset.forName((String)"UTF-8").newEncoder();
                            while ((n7 = object.read(arrby)) != n3) {
                                charsetEncoder.encode(ByteBuffer.wrap((byte[])arrby).asCharBuffer());
                                this.emitStreamEvent(string4, string5, new String(arrby, 0, n7));
                                if (n2 <= 0) continue;
                                SystemClock.sleep((long)n2);
                            }
                            break block14;
                        }
                        if (!string3.equalsIgnoreCase("ascii")) {
                            if (string3.equalsIgnoreCase("base64")) break block15;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Unrecognized encoding `");
                            stringBuilder.append(string3);
                            stringBuilder.append("`, should be one of `base64`, `utf8`, `ascii`");
                            this.emitStreamEvent(string4, "error", "EINVAL", stringBuilder.toString());
                            bl = true;
                            break block16;
                        }
                        while ((n6 = object.read(arrby)) != n3) {
                            WritableArray writableArray = Arguments.createArray();
                            for (int i = 0; i < n6; ++i) {
                                writableArray.pushInt((int)arrby[i]);
                            }
                            this.emitStreamEvent(string4, string5, writableArray);
                            if (n2 <= 0) continue;
                            SystemClock.sleep((long)n2);
                        }
                        break block14;
                    }
                    catch (Exception exception) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Failed to convert data to ");
                        stringBuilder.append(string3);
                        stringBuilder.append(" encoded string. This might be because this encoding cannot be used for this data.");
                        this.emitStreamEvent(string4, "error", "EUNSPECIFIED", stringBuilder.toString());
                        exception.printStackTrace();
                        return;
                    }
                    catch (FileNotFoundException fileNotFoundException) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("No such file '");
                        stringBuilder.append(string7);
                        stringBuilder.append("'");
                        this.emitStreamEvent(string4, "error", "ENOENT", stringBuilder.toString());
                        return;
                    }
                }
                while ((n5 = object.read(arrby)) != n3) {
                    if (n5 < n4) {
                        byte[] arrby2 = new byte[n5];
                        System.arraycopy((Object)arrby, (int)0, (Object)arrby2, (int)0, (int)n5);
                        this.emitStreamEvent(string4, string5, Base64.encodeToString((byte[])arrby2, (int)2));
                    } else {
                        this.emitStreamEvent(string4, string5, Base64.encodeToString((byte[])arrby, (int)2));
                    }
                    if (n2 <= 0) continue;
                    String string8 = string5;
                    SystemClock.sleep((long)n2);
                    string5 = string8;
                    n3 = -1;
                }
            }
            bl = false;
        }
        if (!bl) {
            this.emitStreamEvent(string4, "end", "");
        }
        object.close();
    }

    void scanFile(String[] arrstring, String[] arrstring2, final Callback callback) {
        try {
            MediaScannerConnection.scanFile((Context)this.mCtx, (String[])arrstring, (String[])arrstring2, (MediaScannerConnection.OnScanCompletedListener)new MediaScannerConnection.OnScanCompletedListener(){

                public void onScanCompleted(String string2, Uri uri) {
                    Callback callback2 = callback;
                    Object[] arrobject = new Object[]{null, true};
                    callback2.invoke(arrobject);
                }
            });
            return;
        }
        catch (Exception exception) {
            Object[] arrobject = new Object[]{exception.getLocalizedMessage(), null};
            callback.invoke(arrobject);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void writeStream(String string2, String string3, boolean bl, Callback callback) {
        try {
            File file = new File(string2);
            File file2 = file.getParentFile();
            if (!file.exists()) {
                if (file2 != null && !file2.exists() && !file2.mkdirs()) {
                    Object[] arrobject = new Object[2];
                    arrobject[0] = "ENOTDIR";
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Failed to create parent directory of '");
                    stringBuilder.append(string2);
                    stringBuilder.append("'");
                    arrobject[1] = stringBuilder.toString();
                    callback.invoke(arrobject);
                    return;
                }
                if (!file.createNewFile()) {
                    Object[] arrobject = new Object[2];
                    arrobject[0] = "ENOENT";
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("File '");
                    stringBuilder.append(string2);
                    stringBuilder.append("' does not exist and could not be created");
                    arrobject[1] = stringBuilder.toString();
                    callback.invoke(arrobject);
                    return;
                }
            } else if (file.isDirectory()) {
                Object[] arrobject = new Object[2];
                arrobject[0] = "EISDIR";
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Expecting a file but '");
                stringBuilder.append(string2);
                stringBuilder.append("' is a directory");
                arrobject[1] = stringBuilder.toString();
                callback.invoke(arrobject);
                return;
            }
            FileOutputStream fileOutputStream = new FileOutputStream(string2, bl);
            this.encoding = string3;
            String string4 = UUID.randomUUID().toString();
            fileStreams.put((Object)string4, (Object)this);
            this.writeStreamInstance = fileOutputStream;
            callback.invoke(new Object[]{null, null, string4});
            return;
        }
        catch (Exception exception) {
            Object[] arrobject = new Object[2];
            arrobject[0] = "EUNSPECIFIED";
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to create write stream at path `");
            stringBuilder.append(string2);
            stringBuilder.append("`; ");
            stringBuilder.append(exception.getLocalizedMessage());
            arrobject[1] = stringBuilder.toString();
            callback.invoke(arrobject);
            return;
        }
    }

}

