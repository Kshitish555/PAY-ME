/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.DownloadManager
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.util.SparseArray
 *  androidx.core.content.FileProvider
 *  com.facebook.react.bridge.ActivityEventListener
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.LifecycleEventListener
 *  com.facebook.react.bridge.Promise
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.modules.network.CookieJarContainer
 *  com.facebook.react.modules.network.ForwardingCookieHandler
 *  com.facebook.react.modules.network.OkHttpClientProvider
 *  java.io.File
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.net.CookieHandler
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 *  okhttp3.CookieJar
 *  okhttp3.JavaNetCookieJar
 *  okhttp3.OkHttpClient
 */
package com.RNFetchBlob;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseArray;
import androidx.core.content.FileProvider;
import com.RNFetchBlob.RNFetchBlob;
import com.RNFetchBlob.RNFetchBlobConst;
import com.RNFetchBlob.RNFetchBlobFS;
import com.RNFetchBlob.RNFetchBlobProgressConfig;
import com.RNFetchBlob.RNFetchBlobReq;
import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.network.CookieJarContainer;
import com.facebook.react.modules.network.ForwardingCookieHandler;
import com.facebook.react.modules.network.OkHttpClientProvider;
import java.io.File;
import java.net.CookieHandler;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import okhttp3.CookieJar;
import okhttp3.JavaNetCookieJar;
import okhttp3.OkHttpClient;

public class RNFetchBlob
extends ReactContextBaseJavaModule {
    private static boolean ActionViewVisible;
    static ReactApplicationContext RCTContext;
    static LinkedBlockingQueue<Runnable> fsTaskQueue;
    private static ThreadPoolExecutor fsThreadPool;
    private static SparseArray<Promise> promiseTable;
    private static LinkedBlockingQueue<Runnable> taskQueue;
    private static ThreadPoolExecutor threadPool;
    private final OkHttpClient mClient = OkHttpClientProvider.getOkHttpClient();

    static {
        ThreadPoolExecutor threadPoolExecutor;
        ThreadPoolExecutor threadPoolExecutor2;
        taskQueue = new LinkedBlockingQueue();
        threadPool = threadPoolExecutor2 = new ThreadPoolExecutor(5, 10, 5000L, TimeUnit.MILLISECONDS, taskQueue);
        fsTaskQueue = new LinkedBlockingQueue();
        fsThreadPool = threadPoolExecutor = new ThreadPoolExecutor(2, 10, 5000L, TimeUnit.MILLISECONDS, taskQueue);
        ActionViewVisible = false;
        promiseTable = new SparseArray();
    }

    public RNFetchBlob(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        ForwardingCookieHandler forwardingCookieHandler = new ForwardingCookieHandler((ReactContext)reactApplicationContext);
        ((CookieJarContainer)this.mClient.cookieJar()).setCookieJar((CookieJar)new JavaNetCookieJar((CookieHandler)forwardingCookieHandler));
        RCTContext = reactApplicationContext;
        reactApplicationContext.addActivityEventListener(new ActivityEventListener(this){
            final /* synthetic */ RNFetchBlob this$0;
            {
                this.this$0 = rNFetchBlob;
            }

            public void onActivityResult(Activity activity, int n, int n2, Intent intent) {
                if (n == RNFetchBlobConst.GET_CONTENT_INTENT && n2 == -1) {
                    Uri uri = intent.getData();
                    ((Promise)RNFetchBlob.access$000().get(RNFetchBlobConst.GET_CONTENT_INTENT.intValue())).resolve((Object)uri.toString());
                    RNFetchBlob.access$000().remove(RNFetchBlobConst.GET_CONTENT_INTENT.intValue());
                }
            }

            public void onNewIntent(Intent intent) {
            }
        });
    }

    static /* synthetic */ SparseArray access$000() {
        return promiseTable;
    }

    static /* synthetic */ boolean access$100() {
        return ActionViewVisible;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @ReactMethod
    public void actionViewIntent(String string, String string2, Promise promise) {
        try {
            Activity activity = this.getCurrentActivity();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.getReactApplicationContext().getPackageName());
            stringBuilder.append(".provider");
            Uri uri = FileProvider.getUriForFile((Context)activity, (String)stringBuilder.toString(), (File)new File(string));
            int n = Build.VERSION.SDK_INT;
            if (n >= 24) {
                Intent intent = new Intent("android.intent.action.VIEW").setDataAndType(uri, string2);
                intent.setFlags(1);
                intent.addFlags(268435456);
                if (intent.resolveActivity(this.getCurrentActivity().getPackageManager()) != null) {
                    this.getReactApplicationContext().startActivity(intent);
                }
            } else {
                Intent intent = new Intent("android.intent.action.VIEW");
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("file://");
                stringBuilder2.append(string);
                Intent intent2 = intent.setDataAndType(Uri.parse((String)stringBuilder2.toString()), string2).setFlags(268435456);
                this.getReactApplicationContext().startActivity(intent2);
            }
            ActionViewVisible = true;
            LifecycleEventListener lifecycleEventListener = new LifecycleEventListener(this, promise){
                final /* synthetic */ RNFetchBlob this$0;
                final /* synthetic */ Promise val$promise;
                {
                    this.this$0 = rNFetchBlob;
                    this.val$promise = promise;
                }

                public void onHostDestroy() {
                }

                public void onHostPause() {
                }

                public void onHostResume() {
                    if (RNFetchBlob.access$100()) {
                        this.val$promise.resolve(null);
                    }
                    RNFetchBlob.RCTContext.removeLifecycleEventListener((LifecycleEventListener)this);
                }
            };
            RCTContext.addLifecycleEventListener(lifecycleEventListener);
            return;
        }
        catch (Exception exception) {
            promise.reject("EUNSPECIFIED", exception.getLocalizedMessage());
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @ReactMethod
    public void addCompleteDownload(ReadableMap readableMap, Promise promise) {
        DownloadManager downloadManager = (DownloadManager)RCTContext.getSystemService("download");
        if (readableMap != null && readableMap.hasKey("path")) {
            String string = RNFetchBlobFS.normalizePath(readableMap.getString("path"));
            if (string == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("RNFetchblob.addCompleteDownload can not resolve URI:");
                stringBuilder.append(readableMap.getString("path"));
                promise.reject("EINVAL", stringBuilder.toString());
                return;
            }
            try {
                WritableMap writableMap = RNFetchBlobFS.statFile(string);
                boolean bl = readableMap.hasKey("title");
                String string2 = "";
                String string3 = bl ? readableMap.getString("title") : string2;
                if (readableMap.hasKey("description")) {
                    string2 = readableMap.getString("description");
                }
                String string4 = readableMap.hasKey("mime") ? readableMap.getString("mime") : null;
                long l = Long.valueOf((String)writableMap.getString("size"));
                boolean bl2 = readableMap.hasKey("showNotification") && readableMap.getBoolean("showNotification");
                downloadManager.addCompletedDownload(string3, string2, true, string4, string, l, bl2);
                promise.resolve(null);
                return;
            }
            catch (Exception exception) {
                promise.reject("EUNSPECIFIED", exception.getLocalizedMessage());
                return;
            }
        }
        promise.reject("EINVAL", "RNFetchblob.addCompleteDownload config or path missing.");
    }

    @ReactMethod
    public void cancelRequest(String string, Callback callback) {
        try {
            RNFetchBlobReq.cancelTask(string);
            callback.invoke(new Object[]{null, string});
            return;
        }
        catch (Exception exception) {
            Object[] arrobject = new Object[]{exception.getLocalizedMessage(), null};
            callback.invoke(arrobject);
            return;
        }
    }

    @ReactMethod
    public void closeStream(String string, Callback callback) {
        RNFetchBlobFS.closeStream(string, callback);
    }

    @ReactMethod
    public void cp(String string, String string2, Callback callback) {
        threadPool.execute(new Runnable(this, string, string2, callback){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ Callback val$callback;
            final /* synthetic */ String val$dest;
            final /* synthetic */ String val$path;
            {
                this.this$0 = rNFetchBlob;
                this.val$path = string;
                this.val$dest = string2;
                this.val$callback = callback;
            }

            public void run() {
                RNFetchBlobFS.cp(this.val$path, this.val$dest, this.val$callback);
            }
        });
    }

    @ReactMethod
    public void createFile(String string, String string2, String string3, Promise promise) {
        ThreadPoolExecutor threadPoolExecutor = threadPool;
        Runnable runnable = new Runnable(this, string, string2, string3, promise){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ String val$content;
            final /* synthetic */ String val$encode;
            final /* synthetic */ String val$path;
            final /* synthetic */ Promise val$promise;
            {
                this.this$0 = rNFetchBlob;
                this.val$path = string;
                this.val$content = string2;
                this.val$encode = string3;
                this.val$promise = promise;
            }

            public void run() {
                RNFetchBlobFS.createFile(this.val$path, this.val$content, this.val$encode, this.val$promise);
            }
        };
        threadPoolExecutor.execute(runnable);
    }

    @ReactMethod
    public void createFileASCII(String string, ReadableArray readableArray, Promise promise) {
        threadPool.execute(new Runnable(this, string, readableArray, promise){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ ReadableArray val$dataArray;
            final /* synthetic */ String val$path;
            final /* synthetic */ Promise val$promise;
            {
                this.this$0 = rNFetchBlob;
                this.val$path = string;
                this.val$dataArray = readableArray;
                this.val$promise = promise;
            }

            public void run() {
                RNFetchBlobFS.createFileASCII(this.val$path, this.val$dataArray, this.val$promise);
            }
        });
    }

    @ReactMethod
    public void df(Callback callback) {
        fsThreadPool.execute(new Runnable(this, callback){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ Callback val$callback;
            {
                this.this$0 = rNFetchBlob;
                this.val$callback = callback;
            }

            public void run() {
                RNFetchBlobFS.df(this.val$callback);
            }
        });
    }

    @ReactMethod
    public void enableProgressReport(String string, int n, int n2) {
        RNFetchBlobProgressConfig rNFetchBlobProgressConfig = new RNFetchBlobProgressConfig(true, n, n2, RNFetchBlobProgressConfig.ReportType.Download);
        RNFetchBlobReq.progressReport.put((Object)string, (Object)rNFetchBlobProgressConfig);
    }

    @ReactMethod
    public void enableUploadProgressReport(String string, int n, int n2) {
        RNFetchBlobProgressConfig rNFetchBlobProgressConfig = new RNFetchBlobProgressConfig(true, n, n2, RNFetchBlobProgressConfig.ReportType.Upload);
        RNFetchBlobReq.uploadProgressReport.put((Object)string, (Object)rNFetchBlobProgressConfig);
    }

    @ReactMethod
    public void exists(String string, Callback callback) {
        RNFetchBlobFS.exists(string, callback);
    }

    @ReactMethod
    public void fetchBlob(ReadableMap readableMap, String string, String string2, String string3, ReadableMap readableMap2, String string4, Callback callback) {
        RNFetchBlobReq rNFetchBlobReq = new RNFetchBlobReq(readableMap, string, string2, string3, readableMap2, string4, null, this.mClient, callback);
        rNFetchBlobReq.run();
    }

    @ReactMethod
    public void fetchBlobForm(ReadableMap readableMap, String string, String string2, String string3, ReadableMap readableMap2, ReadableArray readableArray, Callback callback) {
        RNFetchBlobReq rNFetchBlobReq = new RNFetchBlobReq(readableMap, string, string2, string3, readableMap2, null, readableArray, this.mClient, callback);
        rNFetchBlobReq.run();
    }

    public Map<String, Object> getConstants() {
        return RNFetchBlobFS.getSystemfolders(this.getReactApplicationContext());
    }

    @ReactMethod
    public void getContentIntent(String string, Promise promise) {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        if (string != null) {
            intent.setType(string);
        } else {
            intent.setType("*/*");
        }
        promiseTable.put(RNFetchBlobConst.GET_CONTENT_INTENT.intValue(), (Object)promise);
        this.getReactApplicationContext().startActivityForResult(intent, RNFetchBlobConst.GET_CONTENT_INTENT.intValue(), null);
    }

    public String getName() {
        return "RNFetchBlob";
    }

    @ReactMethod
    public void getSDCardApplicationDir(Promise promise) {
        RNFetchBlobFS.getSDCardApplicationDir(this.getReactApplicationContext(), promise);
    }

    @ReactMethod
    public void getSDCardDir(Promise promise) {
        RNFetchBlobFS.getSDCardDir(promise);
    }

    @ReactMethod
    public void hash(String string, String string2, Promise promise) {
        threadPool.execute(new Runnable(this, string, string2, promise){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ String val$algorithm;
            final /* synthetic */ String val$path;
            final /* synthetic */ Promise val$promise;
            {
                this.this$0 = rNFetchBlob;
                this.val$path = string;
                this.val$algorithm = string2;
                this.val$promise = promise;
            }

            public void run() {
                RNFetchBlobFS.hash(this.val$path, this.val$algorithm, this.val$promise);
            }
        });
    }

    @ReactMethod
    public void ls(String string, Promise promise) {
        RNFetchBlobFS.ls(string, promise);
    }

    @ReactMethod
    public void lstat(String string, Callback callback) {
        RNFetchBlobFS.lstat(string, callback);
    }

    @ReactMethod
    public void mkdir(String string, Promise promise) {
        RNFetchBlobFS.mkdir(string, promise);
    }

    @ReactMethod
    public void mv(String string, String string2, Callback callback) {
        RNFetchBlobFS.mv(string, string2, callback);
    }

    @ReactMethod
    public void readFile(String string, String string2, Promise promise) {
        threadPool.execute(new Runnable(this, string, string2, promise){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ String val$encoding;
            final /* synthetic */ String val$path;
            final /* synthetic */ Promise val$promise;
            {
                this.this$0 = rNFetchBlob;
                this.val$path = string;
                this.val$encoding = string2;
                this.val$promise = promise;
            }

            public void run() {
                RNFetchBlobFS.readFile(this.val$path, this.val$encoding, this.val$promise);
            }
        });
    }

    @ReactMethod
    public void readStream(String string, String string2, int n, int n2, String string3) {
        ReactApplicationContext reactApplicationContext = this.getReactApplicationContext();
        ThreadPoolExecutor threadPoolExecutor = fsThreadPool;
        Runnable runnable = new Runnable(this, reactApplicationContext, string, string2, n, n2, string3){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ int val$bufferSize;
            final /* synthetic */ ReactApplicationContext val$ctx;
            final /* synthetic */ String val$encoding;
            final /* synthetic */ String val$path;
            final /* synthetic */ String val$streamId;
            final /* synthetic */ int val$tick;
            {
                this.this$0 = rNFetchBlob;
                this.val$ctx = reactApplicationContext;
                this.val$path = string;
                this.val$encoding = string2;
                this.val$bufferSize = n;
                this.val$tick = n2;
                this.val$streamId = string3;
            }

            public void run() {
                new RNFetchBlobFS(this.val$ctx).readStream(this.val$path, this.val$encoding, this.val$bufferSize, this.val$tick, this.val$streamId);
            }
        };
        threadPoolExecutor.execute(runnable);
    }

    @ReactMethod
    public void removeSession(ReadableArray readableArray, Callback callback) {
        RNFetchBlobFS.removeSession(readableArray, callback);
    }

    @ReactMethod
    public void scanFile(ReadableArray readableArray, Callback callback) {
        ReactApplicationContext reactApplicationContext = this.getReactApplicationContext();
        threadPool.execute(new Runnable(this, readableArray, reactApplicationContext, callback){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ Callback val$callback;
            final /* synthetic */ ReactApplicationContext val$ctx;
            final /* synthetic */ ReadableArray val$pairs;
            {
                this.this$0 = rNFetchBlob;
                this.val$pairs = readableArray;
                this.val$ctx = reactApplicationContext;
                this.val$callback = callback;
            }

            public void run() {
                int n = this.val$pairs.size();
                String[] arrstring = new String[n];
                String[] arrstring2 = new String[n];
                for (int i = 0; i < n; ++i) {
                    ReadableMap readableMap = this.val$pairs.getMap(i);
                    if (!readableMap.hasKey("path")) continue;
                    arrstring[i] = readableMap.getString("path");
                    arrstring2[i] = readableMap.hasKey("mime") ? readableMap.getString("mime") : null;
                }
                new RNFetchBlobFS(this.val$ctx).scanFile(arrstring, arrstring2, this.val$callback);
            }
        });
    }

    @ReactMethod
    public void slice(String string, String string2, int n, int n2, Promise promise) {
        RNFetchBlobFS.slice(string, string2, n, n2, "", promise);
    }

    @ReactMethod
    public void stat(String string, Callback callback) {
        RNFetchBlobFS.stat(string, callback);
    }

    @ReactMethod
    public void unlink(String string, Callback callback) {
        RNFetchBlobFS.unlink(string, callback);
    }

    @ReactMethod
    public void writeArrayChunk(String string, ReadableArray readableArray, Callback callback) {
        RNFetchBlobFS.writeArrayChunk(string, readableArray, callback);
    }

    @ReactMethod
    public void writeChunk(String string, String string2, Callback callback) {
        RNFetchBlobFS.writeChunk(string, string2, callback);
    }

    @ReactMethod
    public void writeFile(String string, String string2, String string3, boolean bl, Promise promise) {
        ThreadPoolExecutor threadPoolExecutor = threadPool;
        Runnable runnable = new Runnable(this, string, string2, string3, bl, promise){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ boolean val$append;
            final /* synthetic */ String val$data;
            final /* synthetic */ String val$encoding;
            final /* synthetic */ String val$path;
            final /* synthetic */ Promise val$promise;
            {
                this.this$0 = rNFetchBlob;
                this.val$path = string;
                this.val$encoding = string2;
                this.val$data = string3;
                this.val$append = bl;
                this.val$promise = promise;
            }

            public void run() {
                RNFetchBlobFS.writeFile(this.val$path, this.val$encoding, this.val$data, this.val$append, this.val$promise);
            }
        };
        threadPoolExecutor.execute(runnable);
    }

    @ReactMethod
    public void writeFileArray(String string, ReadableArray readableArray, boolean bl, Promise promise) {
        ThreadPoolExecutor threadPoolExecutor = threadPool;
        Runnable runnable = new Runnable(this, string, readableArray, bl, promise){
            final /* synthetic */ RNFetchBlob this$0;
            final /* synthetic */ boolean val$append;
            final /* synthetic */ ReadableArray val$data;
            final /* synthetic */ String val$path;
            final /* synthetic */ Promise val$promise;
            {
                this.this$0 = rNFetchBlob;
                this.val$path = string;
                this.val$data = readableArray;
                this.val$append = bl;
                this.val$promise = promise;
            }

            public void run() {
                RNFetchBlobFS.writeFile(this.val$path, this.val$data, this.val$append, this.val$promise);
            }
        };
        threadPoolExecutor.execute(runnable);
    }

    @ReactMethod
    public void writeStream(String string, String string2, boolean bl, Callback callback) {
        new RNFetchBlobFS(this.getReactApplicationContext()).writeStream(string, string2, bl, callback);
    }
}

