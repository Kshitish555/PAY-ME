/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.RNFetchBlob.RNFetchBlobProgressConfig
 *  com.RNFetchBlob.RNFetchBlobReq
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.modules.core.DeviceEventManagerModule
 *  com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 *  okhttp3.MediaType
 *  okhttp3.ResponseBody
 *  okio.Buffer
 *  okio.BufferedSource
 *  okio.Okio
 *  okio.Source
 *  okio.Timeout
 */
package com.RNFetchBlob.Response;

import com.RNFetchBlob.RNFetchBlobProgressConfig;
import com.RNFetchBlob.RNFetchBlobReq;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import java.io.IOException;
import java.nio.charset.Charset;
import okhttp3.MediaType;
import okhttp3.ResponseBody;
import okio.Buffer;
import okio.BufferedSource;
import okio.Okio;
import okio.Source;
import okio.Timeout;

public class RNFetchBlobDefaultResp
extends ResponseBody {
    boolean isIncrement = false;
    String mTaskId;
    ResponseBody originalBody;
    ReactApplicationContext rctContext;

    public RNFetchBlobDefaultResp(ReactApplicationContext reactApplicationContext, String string2, ResponseBody responseBody, boolean bl) {
        this.rctContext = reactApplicationContext;
        this.mTaskId = string2;
        this.originalBody = responseBody;
        this.isIncrement = bl;
    }

    public long contentLength() {
        return this.originalBody.contentLength();
    }

    public MediaType contentType() {
        return this.originalBody.contentType();
    }

    public BufferedSource source() {
        return Okio.buffer((Source)new ProgressReportingSource(this.originalBody.source()));
    }

    private class ProgressReportingSource
    implements Source {
        long bytesRead = 0L;
        BufferedSource mOriginalSource;

        ProgressReportingSource(BufferedSource bufferedSource) {
            this.mOriginalSource = bufferedSource;
        }

        public void close() throws IOException {
        }

        public long read(Buffer buffer, long l2) throws IOException {
            long l3 = this.mOriginalSource.read(buffer, l2);
            long l4 = this.bytesRead;
            long l5 = l3 > 0L ? l3 : 0L;
            this.bytesRead = l4 + l5;
            RNFetchBlobProgressConfig rNFetchBlobProgressConfig = RNFetchBlobReq.getReportProgress((String)RNFetchBlobDefaultResp.this.mTaskId);
            long l6 = RNFetchBlobDefaultResp.this.contentLength();
            if (rNFetchBlobProgressConfig != null && l6 != 0L && rNFetchBlobProgressConfig.shouldReport((float)(this.bytesRead / RNFetchBlobDefaultResp.this.contentLength()))) {
                WritableMap writableMap = Arguments.createMap();
                writableMap.putString("taskId", RNFetchBlobDefaultResp.this.mTaskId);
                writableMap.putString("written", String.valueOf((long)this.bytesRead));
                writableMap.putString("total", String.valueOf((long)RNFetchBlobDefaultResp.this.contentLength()));
                if (RNFetchBlobDefaultResp.this.isIncrement) {
                    writableMap.putString("chunk", buffer.readString(Charset.defaultCharset()));
                } else {
                    writableMap.putString("chunk", "");
                }
                ((DeviceEventManagerModule.RCTDeviceEventEmitter)RNFetchBlobDefaultResp.this.rctContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)).emit("RNFetchBlobProgress", (Object)writableMap);
            }
            return l3;
        }

        public Timeout timeout() {
            return null;
        }
    }

}

