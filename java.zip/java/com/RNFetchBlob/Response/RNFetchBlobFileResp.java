/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.RNFetchBlob.RNFetchBlobProgressConfig
 *  com.RNFetchBlob.RNFetchBlobReq
 *  com.RNFetchBlob.Response.RNFetchBlobFileResp$1
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.modules.core.DeviceEventManagerModule
 *  com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  okhttp3.MediaType
 *  okhttp3.ResponseBody
 *  okio.Buffer
 *  okio.BufferedSource
 *  okio.Okio
 *  okio.Source
 *  okio.Timeout
 */
package com.RNFetchBlob.Response;

import com.RNFetchBlob.RNFetchBlobProgressConfig;
import com.RNFetchBlob.RNFetchBlobReq;
import com.RNFetchBlob.Response.RNFetchBlobFileResp;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import okhttp3.MediaType;
import okhttp3.ResponseBody;
import okio.Buffer;
import okio.BufferedSource;
import okio.Okio;
import okio.Source;
import okio.Timeout;

public class RNFetchBlobFileResp
extends ResponseBody {
    static final /* synthetic */ boolean $assertionsDisabled;
    long bytesDownloaded = 0L;
    boolean isEndMarkerReceived;
    String mPath;
    String mTaskId;
    FileOutputStream ofStream;
    ResponseBody originalBody;
    ReactApplicationContext rctContext;

    public RNFetchBlobFileResp(ReactApplicationContext reactApplicationContext, String string2, ResponseBody responseBody, String string3, boolean bl) throws IOException {
        this.rctContext = reactApplicationContext;
        this.mTaskId = string2;
        this.originalBody = responseBody;
        this.mPath = string3;
        this.isEndMarkerReceived = false;
        if (string3 != null) {
            String string4;
            boolean bl2 = bl ^ true;
            this.mPath = string4 = string3.replace((CharSequence)"?append=true", (CharSequence)"");
            File file = new File(string4);
            File file2 = file.getParentFile();
            if (file2 != null && !file2.exists() && !file2.mkdirs()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Couldn't create dir: ");
                stringBuilder.append((Object)file2);
                throw new IllegalStateException(stringBuilder.toString());
            }
            if (!file.exists()) {
                file.createNewFile();
            }
            this.ofStream = new FileOutputStream(new File(string4), bl2);
        }
    }

    public long contentLength() {
        return this.originalBody.contentLength();
    }

    public MediaType contentType() {
        return this.originalBody.contentType();
    }

    public boolean isDownloadComplete() {
        return this.bytesDownloaded == this.contentLength() || this.contentLength() == -1L && this.isEndMarkerReceived;
        {
        }
    }

    public BufferedSource source() {
        return Okio.buffer((Source)new ProgressReportingSource());
    }

    private class ProgressReportingSource
    implements Source {
        private ProgressReportingSource() {
        }

        private void reportProgress(String string2, long l2, long l3) {
            WritableMap writableMap = Arguments.createMap();
            writableMap.putString("taskId", string2);
            writableMap.putString("written", String.valueOf((long)l2));
            writableMap.putString("total", String.valueOf((long)l3));
            ((DeviceEventManagerModule.RCTDeviceEventEmitter)RNFetchBlobFileResp.this.rctContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)).emit("RNFetchBlobProgress", (Object)writableMap);
        }

        public void close() throws IOException {
            RNFetchBlobFileResp.this.ofStream.close();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public long read(Buffer buffer, long l2) throws IOException {
            int n2 = (int)l2;
            try {
                byte[] arrby = new byte[n2];
                long l3 = RNFetchBlobFileResp.this.originalBody.byteStream().read(arrby, 0, n2);
                RNFetchBlobFileResp rNFetchBlobFileResp = RNFetchBlobFileResp.this;
                long l4 = rNFetchBlobFileResp.bytesDownloaded;
                long l5 = l3 > 0L ? l3 : 0L;
                rNFetchBlobFileResp.bytesDownloaded = l4 + l5;
                if (l3 > 0L) {
                    RNFetchBlobFileResp.this.ofStream.write(arrby, 0, (int)l3);
                } else if (RNFetchBlobFileResp.this.contentLength() == -1L && l3 == -1L) {
                    RNFetchBlobFileResp.this.isEndMarkerReceived = true;
                }
                RNFetchBlobProgressConfig rNFetchBlobProgressConfig = RNFetchBlobReq.getReportProgress((String)RNFetchBlobFileResp.this.mTaskId);
                if (RNFetchBlobFileResp.this.contentLength() != 0L) {
                    float f2 = RNFetchBlobFileResp.this.contentLength() != -1L ? (float)(RNFetchBlobFileResp.this.bytesDownloaded / RNFetchBlobFileResp.this.contentLength()) : (float)RNFetchBlobFileResp.this.isEndMarkerReceived;
                    if (rNFetchBlobProgressConfig != null && rNFetchBlobProgressConfig.shouldReport(f2)) {
                        if (RNFetchBlobFileResp.this.contentLength() != -1L) {
                            this.reportProgress(RNFetchBlobFileResp.this.mTaskId, RNFetchBlobFileResp.this.bytesDownloaded, RNFetchBlobFileResp.this.contentLength());
                            return l3;
                        }
                        if (!RNFetchBlobFileResp.this.isEndMarkerReceived) {
                            this.reportProgress(RNFetchBlobFileResp.this.mTaskId, 0L, RNFetchBlobFileResp.this.contentLength());
                            return l3;
                        }
                        this.reportProgress(RNFetchBlobFileResp.this.mTaskId, RNFetchBlobFileResp.this.bytesDownloaded, RNFetchBlobFileResp.this.bytesDownloaded);
                    }
                }
                return l3;
            }
            catch (Exception exception) {
                return -1L;
            }
        }

        public Timeout timeout() {
            return null;
        }
    }

}

