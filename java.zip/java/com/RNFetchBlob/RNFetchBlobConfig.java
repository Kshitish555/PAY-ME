/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.RNFetchBlob;

import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;

class RNFetchBlobConfig {
    public ReadableMap addAndroidDownloads;
    public String appendExt;
    public Boolean auto;
    public ReadableArray binaryContentTypes;
    public Boolean fileCache;
    public Boolean followRedirect;
    public Boolean increment;
    public String key;
    public String mime;
    public Boolean overwrite;
    public String path;
    public long timeout;
    public Boolean trusty;
    public Boolean wifiOnly;

    RNFetchBlobConfig(ReadableMap readableMap) {
        Boolean bl;
        String string2;
        Boolean bl2;
        this.wifiOnly = bl2 = Boolean.valueOf((boolean)false);
        this.overwrite = bl = Boolean.valueOf((boolean)true);
        this.timeout = 60000L;
        this.increment = bl2;
        this.followRedirect = bl;
        this.binaryContentTypes = null;
        if (readableMap == null) {
            return;
        }
        boolean bl3 = readableMap.hasKey("fileCache") ? readableMap.getBoolean("fileCache") : false;
        this.fileCache = bl3;
        String string3 = readableMap.hasKey("path") ? readableMap.getString("path") : null;
        this.path = string3;
        String string4 = readableMap.hasKey("appendExt") ? readableMap.getString("appendExt") : "";
        this.appendExt = string4;
        boolean bl4 = readableMap.hasKey("trusty") ? readableMap.getBoolean("trusty") : false;
        this.trusty = bl4;
        boolean bl5 = readableMap.hasKey("wifiOnly") ? readableMap.getBoolean("wifiOnly") : false;
        this.wifiOnly = bl5;
        if (readableMap.hasKey("addAndroidDownloads")) {
            this.addAndroidDownloads = readableMap.getMap("addAndroidDownloads");
        }
        if (readableMap.hasKey("binaryContentTypes")) {
            this.binaryContentTypes = readableMap.getArray("binaryContentTypes");
        }
        if ((string2 = this.path) != null && string2.toLowerCase().contains((CharSequence)"?append=true")) {
            this.overwrite = bl2;
        }
        if (readableMap.hasKey("overwrite")) {
            this.overwrite = readableMap.getBoolean("overwrite");
        }
        if (readableMap.hasKey("followRedirect")) {
            this.followRedirect = readableMap.getBoolean("followRedirect");
        }
        String string5 = readableMap.hasKey("key") ? readableMap.getString("key") : null;
        this.key = string5;
        boolean bl6 = readableMap.hasKey("contentType");
        String string6 = null;
        if (bl6) {
            string6 = readableMap.getString("contentType");
        }
        this.mime = string6;
        boolean bl7 = readableMap.hasKey("increment") ? readableMap.getBoolean("increment") : false;
        this.increment = bl7;
        boolean bl8 = readableMap.hasKey("auto");
        boolean bl9 = false;
        if (bl8) {
            bl9 = readableMap.getBoolean("auto");
        }
        this.auto = bl9;
        if (readableMap.hasKey("timeout")) {
            this.timeout = readableMap.getInt("timeout");
        }
    }
}

