/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.provider.DocumentsContract
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Audio
 *  android.provider.MediaStore$Audio$Media
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.provider.MediaStore$Video
 *  android.provider.MediaStore$Video$Media
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.InputStream
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.RNFetchBlob.Utils;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import com.RNFetchBlob.RNFetchBlobUtils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class PathResolver {
    private static String getContentName(ContentResolver contentResolver, Uri uri) {
        Cursor cursor = contentResolver.query(uri, null, null, null, null);
        cursor.moveToFirst();
        int n = cursor.getColumnIndex("_display_name");
        if (n >= 0) {
            String string2 = cursor.getString(n);
            cursor.close();
            return string2;
        }
        return null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String getDataColumn(Context context, Uri uri, String string2, String[] arrstring) {
        Cursor cursor;
        void var7_13;
        block9 : {
            block8 : {
                String string3;
                block7 : {
                    String[] arrstring2 = new String[]{"_data"};
                    cursor = context.getContentResolver().query(uri, arrstring2, string2, arrstring, null);
                    string3 = null;
                    if (cursor == null) break block7;
                    try {
                        boolean bl = cursor.moveToFirst();
                        string3 = null;
                        if (!bl) break block7;
                        string3 = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
                    }
                    catch (Exception exception) {
                        break block8;
                    }
                }
                if (cursor == null) return string3;
                cursor.close();
                return string3;
                catch (Throwable throwable) {
                    cursor = null;
                    break block9;
                }
                catch (Exception exception) {
                    cursor = null;
                }
            }
            try {
                void var5_10;
                var5_10.printStackTrace();
                if (cursor == null) return null;
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            cursor.close();
            return null;
        }
        if (cursor == null) throw var7_13;
        cursor.close();
        throw var7_13;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String getRealPathFromURI(Context context, Uri uri) {
        boolean bl = Build.VERSION.SDK_INT >= 19;
        if (bl && DocumentsContract.isDocumentUri((Context)context, (Uri)uri)) {
            if (PathResolver.isExternalStorageDocument(uri)) {
                String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
                if (!"primary".equalsIgnoreCase(arrstring[0])) return null;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append((Object)Environment.getExternalStorageDirectory());
                stringBuilder.append("/");
                stringBuilder.append(arrstring[1]);
                return stringBuilder.toString();
            }
            if (PathResolver.isDownloadsDocument(uri)) {
                String string2;
                try {
                    string2 = DocumentsContract.getDocumentId((Uri)uri);
                    if (string2 == null) return PathResolver.getDataColumn(context, ContentUris.withAppendedId((Uri)Uri.parse((String)"content://downloads/public_downloads"), (long)Long.valueOf((String)string2)), null, null);
                }
                catch (Exception exception) {
                    return null;
                }
                if (!string2.startsWith("raw:/")) return PathResolver.getDataColumn(context, ContentUris.withAppendedId((Uri)Uri.parse((String)"content://downloads/public_downloads"), (long)Long.valueOf((String)string2)), null, null);
                return Uri.parse((String)string2).getPath();
            }
            if (PathResolver.isMediaDocument(uri)) {
                Uri uri2;
                String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
                String string3 = arrstring[0];
                if ("image".equals((Object)string3)) {
                    uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals((Object)string3)) {
                    uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else {
                    boolean bl2 = "audio".equals((Object)string3);
                    uri2 = null;
                    if (bl2) {
                        uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    }
                }
                String[] arrstring2 = new String[]{arrstring[1]};
                return PathResolver.getDataColumn(context, uri2, "_id=?", arrstring2);
            }
            if ("content".equalsIgnoreCase(uri.getScheme())) {
                if (!PathResolver.isGooglePhotosUri(uri)) return PathResolver.getDataColumn(context, uri, null, null);
                return uri.getLastPathSegment();
            }
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            String string4 = PathResolver.getContentName(context.getContentResolver(), uri);
            if (string4 == null) return null;
            try {
                File file = new File(context.getCacheDir(), string4);
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                byte[] arrby = new byte[1024];
                while (inputStream.read(arrby) > 0) {
                    fileOutputStream.write(arrby);
                }
                fileOutputStream.close();
                inputStream.close();
                return file.getAbsolutePath();
            }
            catch (Exception exception) {
                RNFetchBlobUtils.emitWarningEvent(exception.toString());
                return null;
            }
        }
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            if (!PathResolver.isGooglePhotosUri(uri)) return PathResolver.getDataColumn(context, uri, null, null);
            return uri.getLastPathSegment();
        }
        if (!"file".equalsIgnoreCase(uri.getScheme())) return null;
        return uri.getPath();
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals((Object)uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals((Object)uri.getAuthority());
    }
}

