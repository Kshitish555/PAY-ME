/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.RNFetchBlob;

public class RNFetchBlobProgressConfig {
    private int count = -1;
    private boolean enable = false;
    private int interval = -1;
    private long lastTick = 0L;
    private int tick = 0;
    private ReportType type = ReportType.Download;

    RNFetchBlobProgressConfig(boolean bl, int n, int n2, ReportType reportType) {
        this.enable = bl;
        this.interval = n;
        this.type = reportType;
        this.count = n2;
    }

    public boolean shouldReport(float f) {
        int n = this.count;
        boolean bl = n <= 0 || !(f > 0.0f) || Math.floor((double)(f * (float)n)) > (double)this.tick;
        long l = System.currentTimeMillis() - this.lastTick LCMP (long)this.interval;
        boolean bl2 = false;
        if (l > 0) {
            boolean bl3 = this.enable;
            bl2 = false;
            if (bl3) {
                bl2 = false;
                if (bl) {
                    bl2 = true;
                }
            }
        }
        if (bl2) {
            this.tick = 1 + this.tick;
            this.lastTick = System.currentTimeMillis();
        }
        return bl2;
    }

    static final class ReportType
    extends Enum<ReportType> {
        private static final /* synthetic */ ReportType[] $VALUES;
        public static final /* enum */ ReportType Download;
        public static final /* enum */ ReportType Upload;

        static {
            Upload = new ReportType();
            Download = new ReportType();
            ReportType[] arrreportType = new ReportType[]{Upload, Download};
            $VALUES = arrreportType;
        }

        public static ReportType valueOf(String string2) {
            return (ReportType)Enum.valueOf(ReportType.class, (String)string2);
        }

        public static ReportType[] values() {
            return (ReportType[])$VALUES.clone();
        }
    }

}

