/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.res.AssetManager
 *  android.net.Uri
 *  android.util.Base64
 *  com.RNFetchBlob.RNFetchBlob
 *  com.RNFetchBlob.RNFetchBlobBody$1
 *  com.RNFetchBlob.RNFetchBlobBody$FormField
 *  com.RNFetchBlob.RNFetchBlobFS
 *  com.RNFetchBlob.RNFetchBlobProgressConfig
 *  com.RNFetchBlob.RNFetchBlobReq
 *  com.RNFetchBlob.RNFetchBlobReq$RequestType
 *  com.RNFetchBlob.RNFetchBlobUtils
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.modules.core.DeviceEventManagerModule
 *  com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter
 *  java.io.ByteArrayInputStream
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  okhttp3.MediaType
 *  okhttp3.RequestBody
 *  okio.BufferedSink
 */
package com.RNFetchBlob;

import android.content.ContentResolver;
import android.content.res.AssetManager;
import android.net.Uri;
import android.util.Base64;
import com.RNFetchBlob.RNFetchBlob;
import com.RNFetchBlob.RNFetchBlobBody;
import com.RNFetchBlob.RNFetchBlobFS;
import com.RNFetchBlob.RNFetchBlobProgressConfig;
import com.RNFetchBlob.RNFetchBlobReq;
import com.RNFetchBlob.RNFetchBlobUtils;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.BufferedSink;

/*
 * Exception performing whole class analysis.
 */
class RNFetchBlobBody
extends RequestBody {
    private File bodyCache;
    private Boolean chunkedEncoding;
    private long contentLength;
    private ReadableArray form;
    private String mTaskId;
    private MediaType mime;
    private String rawBody;
    int reported;
    private InputStream requestStream;
    private RNFetchBlobReq.RequestType requestType;

    RNFetchBlobBody(String string2) {
        this.contentLength = 0L;
        this.reported = 0;
        this.chunkedEncoding = false;
        this.mTaskId = string2;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private ArrayList<FormField> countFormDataLength() throws IOException {
        var1_1 = new ArrayList();
        var2_2 = RNFetchBlob.RCTContext;
        var3_3 = 0L;
        var5_4 = 0;
        do {
            block13 : {
                block14 : {
                    block18 : {
                        block12 : {
                            block16 : {
                                block17 : {
                                    block15 : {
                                        if (var5_4 >= this.form.size()) {
                                            this.contentLength = var3_3;
                                            return var1_1;
                                        }
                                        var6_5 = new /* Unavailable Anonymous Inner Class!! */;
                                        var1_1.add((Object)var6_5);
                                        if (var6_5.data != null) break block15;
                                        var8_6 = new StringBuilder();
                                        var8_6.append("RNFetchBlob multipart request builder has found a field without `data` property, the field `");
                                        var8_6.append(var6_5.name);
                                        var8_6.append("` will be removed implicitly.");
                                        RNFetchBlobUtils.emitWarningEvent((String)var8_6.toString());
                                        break block13;
                                    }
                                    if (var6_5.filename == null) break block16;
                                    var15_9 = var6_5.data;
                                    if (!var15_9.startsWith("RNFetchBlob-file://")) break block17;
                                    var26_15 = RNFetchBlobFS.normalizePath((String)var15_9.substring(19));
                                    if (RNFetchBlobFS.isAsset((String)var26_15)) {
                                        try {
                                            var28_17 = var26_15.replace((CharSequence)"bundle-assets://", (CharSequence)"");
                                            var12_7 = var2_2.getAssets().open(var28_17).available();
                                            break block12;
                                        }
                                        catch (IOException var27_16) {
                                            RNFetchBlobUtils.emitWarningEvent((String)var27_16.getLocalizedMessage());
                                            break block13;
                                        }
                                    }
                                    var13_8 = new File(RNFetchBlobFS.normalizePath((String)var26_15)).length();
                                    break block18;
                                }
                                if (var15_9.startsWith("RNFetchBlob-content://")) {
                                    var16_10 = var15_9.substring(22);
                                    var17_11 = null;
                                    var17_11 = var2_2.getContentResolver().openInputStream(Uri.parse((String)var16_10));
                                    var25_14 = var17_11.available();
                                    var3_3 += (long)var25_14;
                                    if (var17_11 == null) break block13;
                                    break block14;
                                }
                                var12_7 = Base64.decode((String)var15_9, (int)0).length;
                                break block12;
                            }
                            var12_7 = var6_5.data.getBytes().length;
                        }
                        var13_8 = var12_7;
                    }
                    var3_3 += var13_8;
                    break block13;
                }
lbl53: // 2 sources:
                do {
                    var17_11.close();
                    break block13;
                    break;
                } while (true);
                {
                    catch (Throwable var24_18) {
                    }
                    catch (Exception var18_12) {}
                    {
                        var19_13 = new StringBuilder();
                        var19_13.append("Failed to estimate form data length from content URI:");
                        var19_13.append(var16_10);
                        var19_13.append(", ");
                        var19_13.append(var18_12.getLocalizedMessage());
                        RNFetchBlobUtils.emitWarningEvent((String)var19_13.toString());
                        if (var17_11 != null) {
                            ** continue;
                        }
                        break block13;
                    }
                }
                if (var17_11 == null) throw var24_18;
                var17_11.close();
                throw var24_18;
            }
            ++var5_4;
        } while (true);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private File createMultipartBodyCache() throws IOException {
        var1_1 = new StringBuilder();
        var1_1.append("RNFetchBlob-");
        var1_1.append(this.mTaskId);
        var4_2 = var1_1.toString();
        var5_3 = File.createTempFile((String)"rnfb-form-tmp", (String)"", (File)RNFetchBlob.RCTContext.getCacheDir());
        var6_4 = new FileOutputStream(var5_3);
        var7_5 = this.countFormDataLength();
        var8_6 = RNFetchBlob.RCTContext;
        var9_7 = var7_5.iterator();
        do {
            block19 : {
                block20 : {
                    if (!var9_7.hasNext()) {
                        var10_32 = new StringBuilder();
                        var10_32.append("--");
                        var10_32.append(var4_2);
                        var10_32.append("--\r\n");
                        var6_4.write(var10_32.toString().getBytes());
                        var6_4.flush();
                        var6_4.close();
                        return var5_3;
                    }
                    var14_10 = var9_7.next();
                    var15_11 = var14_10.data;
                    var16_12 = var14_10.name;
                    if (var16_12 == null || var15_11 == null) continue;
                    var17_13 = new StringBuilder();
                    var17_13.append("--");
                    var17_13.append(var4_2);
                    var17_13.append("\r\n");
                    var21_14 = var17_13.toString();
                    var22_15 = var14_10.filename;
                    var23_16 = var9_7;
                    if (var22_15 != null) {
                        var24_17 = new StringBuilder();
                        var24_17.append(var21_14);
                        var24_17.append("Content-Disposition: form-data; name=\"");
                        var24_17.append(var16_12);
                        var24_17.append("\"; filename=\"");
                        var24_17.append(var14_10.filename);
                        var24_17.append("\"\r\n");
                        var31_18 = var24_17.toString();
                        var32_19 = new StringBuilder();
                        var32_19.append(var31_18);
                        var32_19.append("Content-Type: ");
                        var32_19.append(var14_10.mime);
                        var32_19.append("\r\n\r\n");
                        var6_4.write(var32_19.toString().getBytes());
                        if (var15_11.startsWith("RNFetchBlob-file://")) {
                            var46_24 = RNFetchBlobFS.normalizePath((String)var15_11.substring(19));
                            if (RNFetchBlobFS.isAsset((String)var46_24)) {
                                try {
                                    var58_29 = var46_24.replace((CharSequence)"bundle-assets://", (CharSequence)"");
                                    this.pipeStreamToFileStream(var8_6.getAssets().open(var58_29), var6_4);
                                }
                                catch (IOException var52_27) {
                                    var53_28 = new StringBuilder();
                                    var53_28.append("Failed to create form data asset :");
                                    var53_28.append(var46_24);
                                    var53_28.append(", ");
                                    var53_28.append(var52_27.getLocalizedMessage());
                                    RNFetchBlobUtils.emitWarningEvent((String)var53_28.toString());
                                }
                            } else {
                                var47_25 = new File(RNFetchBlobFS.normalizePath((String)var46_24));
                                if (var47_25.exists()) {
                                    this.pipeStreamToFileStream((InputStream)new FileInputStream(var47_25), var6_4);
                                } else {
                                    var48_26 = new StringBuilder();
                                    var48_26.append("Failed to create form data from path :");
                                    var48_26.append(var46_24);
                                    var48_26.append(", file not exists.");
                                    RNFetchBlobUtils.emitWarningEvent((String)var48_26.toString());
                                }
                            }
                        } else {
                            if (var15_11.startsWith("RNFetchBlob-content://")) {
                                var37_20 = var15_11.substring(22);
                                var38_21 = null;
                                var38_21 = var8_6.getContentResolver().openInputStream(Uri.parse((String)var37_20));
                                this.pipeStreamToFileStream(var38_21, var6_4);
                                if (var38_21 == null) break block19;
                                break block20;
                            }
                            var6_4.write(Base64.decode((String)var15_11, (int)0));
                        }
                    } else {
                        var59_30 = new StringBuilder();
                        var59_30.append(var21_14);
                        var59_30.append("Content-Disposition: form-data; name=\"");
                        var59_30.append(var16_12);
                        var59_30.append("\"\r\n");
                        var64_8 = var59_30.toString();
                        var65_9 = new StringBuilder();
                        var65_9.append(var64_8);
                        var65_9.append("Content-Type: ");
                        var65_9.append(var14_10.mime);
                        var65_9.append("\r\n\r\n");
                        var6_4.write(var65_9.toString().getBytes());
                        var6_4.write(var14_10.data.getBytes());
                    }
                    break block19;
                }
lbl96: // 2 sources:
                do {
                    var38_21.close();
                    break block19;
                    break;
                } while (true);
                {
                    catch (Throwable var45_31) {
                    }
                    catch (Exception var39_22) {}
                    {
                        var40_23 = new StringBuilder();
                        var40_23.append("Failed to create form data from content URI:");
                        var40_23.append(var37_20);
                        var40_23.append(", ");
                        var40_23.append(var39_22.getLocalizedMessage());
                        RNFetchBlobUtils.emitWarningEvent((String)var40_23.toString());
                        if (var38_21 != null) {
                            ** continue;
                        }
                        break block19;
                    }
                }
                if (var38_21 == null) throw var45_31;
                var38_21.close();
                throw var45_31;
            }
            var6_4.write("\r\n".getBytes());
            var9_7 = var23_16;
        } while (true);
    }

    private void emitUploadProgress(long l2) {
        long l3;
        RNFetchBlobProgressConfig rNFetchBlobProgressConfig = RNFetchBlobReq.getReportUploadProgress((String)this.mTaskId);
        if (rNFetchBlobProgressConfig != null && (l3 = this.contentLength) != 0L && rNFetchBlobProgressConfig.shouldReport((float)l2 / (float)l3)) {
            WritableMap writableMap = Arguments.createMap();
            writableMap.putString("taskId", this.mTaskId);
            writableMap.putString("written", String.valueOf((long)l2));
            writableMap.putString("total", String.valueOf((long)this.contentLength));
            ((DeviceEventManagerModule.RCTDeviceEventEmitter)RNFetchBlob.RCTContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)).emit("RNFetchBlobProgress-upload", (Object)writableMap);
        }
    }

    private InputStream getRequestStream() throws Exception {
        if (this.rawBody.startsWith("RNFetchBlob-file://")) {
            String string2 = RNFetchBlobFS.normalizePath((String)this.rawBody.substring(19));
            if (RNFetchBlobFS.isAsset((String)string2)) {
                try {
                    String string3 = string2.replace((CharSequence)"bundle-assets://", (CharSequence)"");
                    InputStream inputStream = RNFetchBlob.RCTContext.getAssets().open(string3);
                    return inputStream;
                }
                catch (Exception exception) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("error when getting request stream from asset : ");
                    stringBuilder.append(exception.getLocalizedMessage());
                    throw new Exception(stringBuilder.toString());
                }
            }
            File file = new File(RNFetchBlobFS.normalizePath((String)string2));
            try {
                if (!file.exists()) {
                    file.createNewFile();
                }
                FileInputStream fileInputStream = new FileInputStream(file);
                return fileInputStream;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error when getting request stream: ");
                stringBuilder.append(exception.getLocalizedMessage());
                throw new Exception(stringBuilder.toString());
            }
        }
        if (this.rawBody.startsWith("RNFetchBlob-content://")) {
            String string4 = this.rawBody.substring(22);
            try {
                InputStream inputStream = RNFetchBlob.RCTContext.getContentResolver().openInputStream(Uri.parse((String)string4));
                return inputStream;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error when getting request stream for content URI: ");
                stringBuilder.append(string4);
                throw new Exception(stringBuilder.toString(), (Throwable)exception);
            }
        }
        try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(Base64.decode((String)this.rawBody, (int)0));
            return byteArrayInputStream;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("error when getting request stream: ");
            stringBuilder.append(exception.getLocalizedMessage());
            throw new Exception(stringBuilder.toString());
        }
    }

    private void pipeStreamToFileStream(InputStream inputStream, FileOutputStream fileOutputStream) throws IOException {
        int n2;
        byte[] arrby = new byte[10240];
        while ((n2 = inputStream.read(arrby)) > 0) {
            fileOutputStream.write(arrby, 0, n2);
        }
        inputStream.close();
    }

    private void pipeStreamToSink(InputStream inputStream, BufferedSink bufferedSink) throws IOException {
        int n2;
        byte[] arrby = new byte[10240];
        long l2 = 0L;
        while ((n2 = inputStream.read(arrby, 0, 10240)) > 0) {
            bufferedSink.write(arrby, 0, n2);
            this.emitUploadProgress(l2 += (long)n2);
        }
        inputStream.close();
    }

    RNFetchBlobBody chunkedEncoding(boolean bl) {
        this.chunkedEncoding = bl;
        return this;
    }

    boolean clearRequestBody() {
        try {
            if (this.bodyCache != null && this.bodyCache.exists()) {
                this.bodyCache.delete();
            }
            return true;
        }
        catch (Exception exception) {
            RNFetchBlobUtils.emitWarningEvent((String)exception.getLocalizedMessage());
            return false;
        }
    }

    public long contentLength() {
        if (this.chunkedEncoding.booleanValue()) {
            return -1L;
        }
        return this.contentLength;
    }

    public MediaType contentType() {
        return this.mime;
    }

    RNFetchBlobBody setBody(ReadableArray readableArray) {
        this.form = readableArray;
        try {
            this.bodyCache = this.createMultipartBodyCache();
            this.requestStream = new FileInputStream(this.bodyCache);
            this.contentLength = this.bodyCache.length();
            return this;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("RNFetchBlob failed to create request multipart body :");
            stringBuilder.append(exception.getLocalizedMessage());
            RNFetchBlobUtils.emitWarningEvent((String)stringBuilder.toString());
            return this;
        }
    }

    RNFetchBlobBody setBody(String string2) {
        block5 : {
            block6 : {
                this.rawBody = string2;
                if (this.rawBody == null) {
                    this.rawBody = "";
                    this.requestType = RNFetchBlobReq.RequestType.AsIs;
                }
                try {
                    int n2 = 1.$SwitchMap$com$RNFetchBlob$RNFetchBlobReq$RequestType[this.requestType.ordinal()];
                    if (n2 == 1) break block5;
                    if (n2 == 2) break block6;
                    return this;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("RNFetchBlob failed to create single content request body :");
                    stringBuilder.append(exception.getLocalizedMessage());
                    stringBuilder.append("\r\n");
                    RNFetchBlobUtils.emitWarningEvent((String)stringBuilder.toString());
                    return this;
                }
            }
            this.contentLength = this.rawBody.getBytes().length;
            this.requestStream = new ByteArrayInputStream(this.rawBody.getBytes());
            return this;
        }
        this.requestStream = this.getRequestStream();
        this.contentLength = this.requestStream.available();
        return this;
    }

    RNFetchBlobBody setMIME(MediaType mediaType) {
        this.mime = mediaType;
        return this;
    }

    RNFetchBlobBody setRequestType(RNFetchBlobReq.RequestType requestType) {
        this.requestType = requestType;
        return this;
    }

    public void writeTo(BufferedSink bufferedSink) {
        try {
            this.pipeStreamToSink(this.requestStream, bufferedSink);
            return;
        }
        catch (Exception exception) {
            RNFetchBlobUtils.emitWarningEvent((String)exception.getLocalizedMessage());
            exception.printStackTrace();
            return;
        }
    }
}

