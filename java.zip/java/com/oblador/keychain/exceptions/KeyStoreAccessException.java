/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.oblador.keychain.exceptions;

public class KeyStoreAccessException
extends Exception {
    public KeyStoreAccessException(String string2, Throwable throwable) {
        super(string2, throwable);
    }
}

