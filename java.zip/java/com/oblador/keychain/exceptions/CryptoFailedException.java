/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.oblador.keychain.exceptions;

public class CryptoFailedException
extends Exception {
    public CryptoFailedException(String string2) {
        super(string2);
    }

    public CryptoFailedException(String string2, Throwable throwable) {
        super(string2, throwable);
    }
}

