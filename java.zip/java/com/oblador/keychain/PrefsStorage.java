/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.util.Base64
 *  com.facebook.react.bridge.ReactApplicationContext
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.oblador.keychain;

import android.content.SharedPreferences;
import android.util.Base64;
import com.facebook.react.bridge.ReactApplicationContext;
import com.oblador.keychain.cipherStorage.CipherStorage;

public class PrefsStorage {
    public static final String KEYCHAIN_DATA = "RN_KEYCHAIN";
    private final SharedPreferences prefs;

    public PrefsStorage(ReactApplicationContext reactApplicationContext) {
        this.prefs = reactApplicationContext.getSharedPreferences(KEYCHAIN_DATA, 0);
    }

    private byte[] getBytes(String string2) {
        String string3 = this.prefs.getString(string2, null);
        if (string3 != null) {
            return Base64.decode((String)string3, (int)0);
        }
        return null;
    }

    private byte[] getBytesForPassword(String string2) {
        return this.getBytes(this.getKeyForPassword(string2));
    }

    private byte[] getBytesForUsername(String string2) {
        return this.getBytes(this.getKeyForUsername(string2));
    }

    private String getCipherStorageName(String string2) {
        String string3 = this.getKeyForCipherStorage(string2);
        return this.prefs.getString(string3, null);
    }

    private String getKeyForCipherStorage(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(":c");
        return stringBuilder.toString();
    }

    private String getKeyForPassword(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(":p");
        return stringBuilder.toString();
    }

    private String getKeyForUsername(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(":u");
        return stringBuilder.toString();
    }

    public ResultSet getEncryptedEntry(String string2) {
        byte[] arrby = this.getBytesForUsername(string2);
        byte[] arrby2 = this.getBytesForPassword(string2);
        String string3 = this.getCipherStorageName(string2);
        if (arrby != null && arrby2 != null) {
            if (string3 == null) {
                string3 = "FacebookConceal";
            }
            return new ResultSet(string3, arrby, arrby2);
        }
        return null;
    }

    public void removeEntry(String string2) {
        String string3 = this.getKeyForUsername(string2);
        String string4 = this.getKeyForPassword(string2);
        String string5 = this.getKeyForCipherStorage(string2);
        this.prefs.edit().remove(string3).remove(string4).remove(string5).apply();
    }

    public void storeEncryptedEntry(String string2, CipherStorage.EncryptionResult encryptionResult) {
        String string3 = this.getKeyForUsername(string2);
        String string4 = this.getKeyForPassword(string2);
        String string5 = this.getKeyForCipherStorage(string2);
        this.prefs.edit().putString(string3, Base64.encodeToString((byte[])((byte[])encryptionResult.username), (int)0)).putString(string4, Base64.encodeToString((byte[])((byte[])encryptionResult.password), (int)0)).putString(string5, encryptionResult.cipherStorage.getCipherStorageName()).apply();
    }

    public static class ResultSet {
        public final String cipherStorageName;
        public final byte[] passwordBytes;
        public final byte[] usernameBytes;

        public ResultSet(String string2, byte[] arrby, byte[] arrby2) {
            this.cipherStorageName = string2;
            this.usernameBytes = arrby;
            this.passwordBytes = arrby2;
        }
    }

}

