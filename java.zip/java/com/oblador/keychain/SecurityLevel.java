/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.oblador.keychain;

public final class SecurityLevel
extends Enum<SecurityLevel> {
    private static final /* synthetic */ SecurityLevel[] $VALUES;
    public static final /* enum */ SecurityLevel ANY = new SecurityLevel();
    public static final /* enum */ SecurityLevel SECURE_HARDWARE;
    public static final /* enum */ SecurityLevel SECURE_SOFTWARE;

    static {
        SECURE_SOFTWARE = new SecurityLevel();
        SECURE_HARDWARE = new SecurityLevel();
        SecurityLevel[] arrsecurityLevel = new SecurityLevel[]{ANY, SECURE_SOFTWARE, SECURE_HARDWARE};
        $VALUES = arrsecurityLevel;
    }

    public static SecurityLevel valueOf(String string2) {
        return (SecurityLevel)Enum.valueOf(SecurityLevel.class, (String)string2);
    }

    public static SecurityLevel[] values() {
        return (SecurityLevel[])$VALUES.clone();
    }

    public String jsName() {
        Object[] arrobject = new Object[]{this.name()};
        return String.format((String)"SECURITY_LEVEL_%s", (Object[])arrobject);
    }

    public boolean satisfiesSafetyThreshold(SecurityLevel securityLevel) {
        return this.compareTo((Enum)securityLevel) >= 0;
    }
}

