/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.security.keystore.KeyGenParameterSpec
 *  android.security.keystore.KeyGenParameterSpec$Builder
 *  android.security.keystore.KeyInfo
 *  android.security.keystore.StrongBoxUnavailableException
 *  android.util.Log
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.security.InvalidAlgorithmParameterException
 *  java.security.Key
 *  java.security.KeyStore
 *  java.security.KeyStore$LoadStoreParameter
 *  java.security.KeyStoreException
 *  java.security.NoSuchAlgorithmException
 *  java.security.NoSuchProviderException
 *  java.security.UnrecoverableKeyException
 *  java.security.cert.CertificateException
 *  java.security.spec.AlgorithmParameterSpec
 *  java.security.spec.InvalidKeySpecException
 *  java.security.spec.KeySpec
 *  javax.crypto.Cipher
 *  javax.crypto.CipherInputStream
 *  javax.crypto.CipherOutputStream
 *  javax.crypto.KeyGenerator
 *  javax.crypto.SecretKey
 *  javax.crypto.SecretKeyFactory
 *  javax.crypto.spec.IvParameterSpec
 */
package com.oblador.keychain.cipherStorage;

import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyInfo;
import android.security.keystore.StrongBoxUnavailableException;
import android.util.Log;
import com.oblador.keychain.SecurityLevel;
import com.oblador.keychain.cipherStorage.CipherStorage;
import com.oblador.keychain.exceptions.CryptoFailedException;
import com.oblador.keychain.exceptions.KeyStoreAccessException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;

public class CipherStorageKeystoreAESCBC
implements CipherStorage {
    public static final String CIPHER_STORAGE_NAME = "KeystoreAESCBC";
    public static final String DEFAULT_SERVICE = "RN_KEYCHAIN_DEFAULT_ALIAS";
    public static final String ENCRYPTION_ALGORITHM = "AES";
    public static final String ENCRYPTION_BLOCK_MODE = "CBC";
    public static final int ENCRYPTION_KEY_SIZE = 256;
    public static final String ENCRYPTION_PADDING = "PKCS7Padding";
    public static final String ENCRYPTION_TRANSFORMATION = "AES/CBC/PKCS7Padding";
    public static final String KEYSTORE_TYPE = "AndroidKeyStore";
    public static final String TAG = "KeystoreAESCBC";
    private boolean retry = true;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String decryptBytes(Key key, byte[] arrby) throws CryptoFailedException {
        try {
            Cipher cipher = Cipher.getInstance((String)ENCRYPTION_TRANSFORMATION);
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrby);
            cipher.init(2, key, (AlgorithmParameterSpec)this.readIvFromStream(byteArrayInputStream));
            CipherInputStream cipherInputStream = new CipherInputStream((InputStream)byteArrayInputStream, cipher);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] arrby2 = new byte[1024];
            do {
                int n2;
                if ((n2 = cipherInputStream.read(arrby2, 0, arrby2.length)) <= 0) {
                    return new String(byteArrayOutputStream.toByteArray(), Charset.forName((String)"UTF-8"));
                }
                byteArrayOutputStream.write(arrby2, 0, n2);
            } while (true);
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Could not decrypt bytes: ");
            stringBuilder.append(exception.getMessage());
            CryptoFailedException cryptoFailedException = new CryptoFailedException(stringBuilder.toString(), exception);
            throw cryptoFailedException;
        }
    }

    private byte[] encryptString(Key key, String string2, String string3) throws CryptoFailedException {
        try {
            Cipher cipher = Cipher.getInstance((String)ENCRYPTION_TRANSFORMATION);
            cipher.init(1, key);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] arrby = cipher.getIV();
            byteArrayOutputStream.write(arrby, 0, arrby.length);
            CipherOutputStream cipherOutputStream = new CipherOutputStream((OutputStream)byteArrayOutputStream, cipher);
            cipherOutputStream.write(string3.getBytes("UTF-8"));
            cipherOutputStream.close();
            byte[] arrby2 = byteArrayOutputStream.toByteArray();
            return arrby2;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Could not encrypt value for service ");
            stringBuilder.append(string2);
            stringBuilder.append(", message: ");
            stringBuilder.append(exception.getMessage());
            throw new CryptoFailedException(stringBuilder.toString(), exception);
        }
    }

    private SecretKey generateKey(KeyGenParameterSpec keyGenParameterSpec) throws NoSuchProviderException, NoSuchAlgorithmException, InvalidAlgorithmParameterException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance((String)ENCRYPTION_ALGORITHM, (String)KEYSTORE_TYPE);
        keyGenerator.init((AlgorithmParameterSpec)keyGenParameterSpec);
        return keyGenerator.generateKey();
    }

    private void generateKeyAndStoreUnderAlias(String string2, SecurityLevel securityLevel) throws NoSuchAlgorithmException, NoSuchProviderException, InvalidAlgorithmParameterException, CryptoFailedException {
        SecretKey secretKey = this.tryGenerateStrongBoxSecurityKey(string2);
        if (secretKey == null) {
            secretKey = this.tryGenerateRegularSecurityKey(string2);
        }
        if (this.validateKeySecurityLevel(securityLevel, secretKey)) {
            return;
        }
        throw new CryptoFailedException("Cannot generate keys with required security guarantees");
    }

    private String getDefaultServiceIfEmpty(String string2) {
        if (string2.isEmpty()) {
            string2 = DEFAULT_SERVICE;
        }
        return string2;
    }

    private KeyGenParameterSpec.Builder getKeyGenSpecBuilder(String string2) {
        return new KeyGenParameterSpec.Builder(string2, 3).setBlockModes(new String[]{ENCRYPTION_BLOCK_MODE}).setEncryptionPaddings(new String[]{ENCRYPTION_PADDING}).setRandomizedEncryptionRequired(true).setKeySize(256);
    }

    private KeyStore getKeyStoreAndLoad() throws KeyStoreException, KeyStoreAccessException {
        void var1_5;
        try {
            KeyStore keyStore = KeyStore.getInstance((String)KEYSTORE_TYPE);
            keyStore.load(null);
            return keyStore;
        }
        catch (IOException iOException) {
        }
        catch (CertificateException certificateException) {
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            // empty catch block
        }
        throw new KeyStoreAccessException("Could not access Keystore", (Throwable)var1_5);
    }

    private SecurityLevel getSecurityLevel(SecretKey secretKey) {
        try {
            if (((KeyInfo)SecretKeyFactory.getInstance((String)secretKey.getAlgorithm(), (String)KEYSTORE_TYPE).getKeySpec(secretKey, KeyInfo.class)).isInsideSecureHardware()) {
                return SecurityLevel.SECURE_HARDWARE;
            }
            SecurityLevel securityLevel = SecurityLevel.SECURE_SOFTWARE;
            return securityLevel;
        }
        catch (NoSuchAlgorithmException | NoSuchProviderException | InvalidKeySpecException throwable) {
            return SecurityLevel.ANY;
        }
    }

    private IvParameterSpec readIvFromStream(ByteArrayInputStream byteArrayInputStream) {
        byte[] arrby = new byte[16];
        byteArrayInputStream.read(arrby, 0, arrby.length);
        return new IvParameterSpec(arrby);
    }

    private SecretKey tryGenerateRegularSecurityKey(String string2) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException, NoSuchProviderException {
        return this.generateKey(this.getKeyGenSpecBuilder(string2).build());
    }

    private SecretKey tryGenerateStrongBoxSecurityKey(String string2) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException, NoSuchProviderException {
        if (Build.VERSION.SDK_INT < 28) {
            return null;
        }
        try {
            SecretKey secretKey = this.generateKey(this.getKeyGenSpecBuilder(string2).setIsStrongBoxBacked(true).build());
            return secretKey;
        }
        catch (Exception exception) {
            if (exception instanceof StrongBoxUnavailableException) {
                Log.i((String)"KeystoreAESCBC", (String)"StrongBox is unavailable on this device");
                return null;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("An error occurred when trying to generate a StrongBoxSecurityKey: ");
            stringBuilder.append(exception.getMessage());
            Log.e((String)"KeystoreAESCBC", (String)stringBuilder.toString());
            return null;
        }
    }

    private boolean validateKeySecurityLevel(SecurityLevel securityLevel, SecretKey secretKey) {
        return this.getSecurityLevel(secretKey).satisfiesSafetyThreshold(securityLevel);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public CipherStorage.DecryptionResult decrypt(String string2, byte[] arrby, byte[] arrby2) throws CryptoFailedException {
        void var5_12;
        String string3 = this.getDefaultServiceIfEmpty(string2);
        Key key = this.getKeyStoreAndLoad().getKey(string3, null);
        if (key == null) throw new CryptoFailedException("The provided service/key could not be found in the Keystore");
        try {
            return new CipherStorage.DecryptionResult(this.decryptBytes(key, arrby), this.decryptBytes(key, arrby2), this.getSecurityLevel((SecretKey)key));
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown error: ");
            stringBuilder.append(exception.getMessage());
            throw new CryptoFailedException(stringBuilder.toString(), exception);
        }
        catch (KeyStoreAccessException keyStoreAccessException) {
            throw new CryptoFailedException("Could not access Keystore", (Throwable)keyStoreAccessException);
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            throw new CryptoFailedException("Could not get key from Keystore", (Throwable)var5_12);
        }
        catch (UnrecoverableKeyException unrecoverableKeyException) {
            throw new CryptoFailedException("Could not get key from Keystore", (Throwable)var5_12);
        }
        catch (KeyStoreException keyStoreException) {
            // empty catch block
        }
        throw new CryptoFailedException("Could not get key from Keystore", (Throwable)var5_12);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public CipherStorage.EncryptionResult encrypt(String string2, String string3, String string4, SecurityLevel securityLevel) throws CryptoFailedException {
        void var6_21;
        String string5;
        block13 : {
            void var10_15;
            string5 = this.getDefaultServiceIfEmpty(string2);
            try {
                KeyStore keyStore;
                block12 : {
                    keyStore = this.getKeyStoreAndLoad();
                    if (keyStore.containsAlias(string5)) break block12;
                    this.generateKeyAndStoreUnderAlias(string5, securityLevel);
                }
                Key key = keyStore.getKey(string5, null);
                {
                    catch (UnrecoverableKeyException unrecoverableKeyException) {
                        unrecoverableKeyException.printStackTrace();
                        if (!this.retry) throw unrecoverableKeyException;
                        this.retry = false;
                        keyStore.deleteEntry(string5);
                        return this.encrypt(string5, string3, string4, securityLevel);
                    }
                }
                byte[] arrby = this.encryptString(key, string5, string3);
                byte[] arrby2 = this.encryptString(key, string5, string4);
                this.retry = true;
                return new CipherStorage.EncryptionResult(arrby, arrby2, this);
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unknown error: ");
                stringBuilder.append(exception.getMessage());
                throw new CryptoFailedException(stringBuilder.toString(), exception);
            }
            catch (KeyStoreAccessException keyStoreAccessException) {
            }
            catch (KeyStoreException keyStoreException) {
                // empty catch block
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Could not access Keystore for service ");
            stringBuilder.append(string5);
            throw new CryptoFailedException(stringBuilder.toString(), (Throwable)var10_15);
            catch (UnrecoverableKeyException unrecoverableKeyException) {
                break block13;
            }
            catch (NoSuchProviderException noSuchProviderException) {
            }
            catch (InvalidAlgorithmParameterException invalidAlgorithmParameterException) {
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                // empty catch block
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not encrypt data for service ");
        stringBuilder.append(string5);
        throw new CryptoFailedException(stringBuilder.toString(), (Throwable)var6_21);
    }

    @Override
    public String getCipherStorageName() {
        return "KeystoreAESCBC";
    }

    @Override
    public int getMinSupportedApiLevel() {
        return 23;
    }

    @Override
    public void removeKey(String string2) throws KeyStoreAccessException {
        String string3 = this.getDefaultServiceIfEmpty(string2);
        try {
            KeyStore keyStore = this.getKeyStoreAndLoad();
            if (keyStore.containsAlias(string3)) {
                keyStore.deleteEntry(string3);
            }
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown error ");
            stringBuilder.append(exception.getMessage());
            throw new KeyStoreAccessException(stringBuilder.toString(), exception);
        }
        catch (KeyStoreException keyStoreException) {
            throw new KeyStoreAccessException("Failed to access Keystore", keyStoreException);
        }
    }

    @Override
    public SecurityLevel securityLevel() {
        return SecurityLevel.SECURE_HARDWARE;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public boolean supportsSecureHardware() {
        SecretKey secretKey = this.tryGenerateRegularSecurityKey("AndroidKeyStore#supportsSecureHardware");
        boolean bl = this.validateKeySecurityLevel(SecurityLevel.SECURE_HARDWARE, secretKey);
        try {
            this.removeKey("AndroidKeyStore#supportsSecureHardware");
            return bl;
        }
        catch (KeyStoreAccessException keyStoreAccessException) {
            Log.e((String)"KeystoreAESCBC", (String)"Unable to remove temp key from keychain", (Throwable)keyStoreAccessException);
            return bl;
        }
        catch (Throwable throwable) {
            try {
                this.removeKey("AndroidKeyStore#supportsSecureHardware");
                throw throwable;
            }
            catch (KeyStoreAccessException keyStoreAccessException) {
                Log.e((String)"KeystoreAESCBC", (String)"Unable to remove temp key from keychain", (Throwable)keyStoreAccessException);
            }
            throw throwable;
        }
        catch (InvalidAlgorithmParameterException | NoSuchAlgorithmException | NoSuchProviderException throwable) {
            try {
                this.removeKey("AndroidKeyStore#supportsSecureHardware");
                return false;
            }
            catch (KeyStoreAccessException keyStoreAccessException) {
                Log.e((String)"KeystoreAESCBC", (String)"Unable to remove temp key from keychain", (Throwable)keyStoreAccessException);
                return false;
            }
        }
    }
}

