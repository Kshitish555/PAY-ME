/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.facebook.android.crypto.keychain.AndroidConceal
 *  com.facebook.android.crypto.keychain.SharedPrefsBackedKeyChain
 *  com.facebook.crypto.Crypto
 *  com.facebook.crypto.CryptoConfig
 *  com.facebook.crypto.Entity
 *  com.facebook.crypto.keychain.KeyChain
 *  com.facebook.react.bridge.ReactApplicationContext
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 */
package com.oblador.keychain.cipherStorage;

import android.content.Context;
import com.facebook.android.crypto.keychain.AndroidConceal;
import com.facebook.android.crypto.keychain.SharedPrefsBackedKeyChain;
import com.facebook.crypto.Crypto;
import com.facebook.crypto.CryptoConfig;
import com.facebook.crypto.Entity;
import com.facebook.crypto.keychain.KeyChain;
import com.facebook.react.bridge.ReactApplicationContext;
import com.oblador.keychain.SecurityLevel;
import com.oblador.keychain.cipherStorage.CipherStorage;
import com.oblador.keychain.exceptions.CryptoFailedException;
import java.nio.charset.Charset;

public class CipherStorageFacebookConceal
implements CipherStorage {
    public static final String CIPHER_STORAGE_NAME = "FacebookConceal";
    public static final String KEYCHAIN_DATA = "RN_KEYCHAIN";
    private final Crypto crypto;

    public CipherStorageFacebookConceal(ReactApplicationContext reactApplicationContext) {
        SharedPrefsBackedKeyChain sharedPrefsBackedKeyChain = new SharedPrefsBackedKeyChain((Context)reactApplicationContext, CryptoConfig.KEY_256);
        this.crypto = AndroidConceal.get().createDefaultCrypto((KeyChain)sharedPrefsBackedKeyChain);
    }

    private Entity createPasswordEntity(String string2) {
        String string3 = this.getEntityPrefix(string2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string3);
        stringBuilder.append("pass");
        return Entity.create((String)stringBuilder.toString());
    }

    private Entity createUsernameEntity(String string2) {
        String string3 = this.getEntityPrefix(string2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string3);
        stringBuilder.append("user");
        return Entity.create((String)stringBuilder.toString());
    }

    private String getEntityPrefix(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RN_KEYCHAIN:");
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    @Override
    public CipherStorage.DecryptionResult decrypt(String string2, byte[] arrby, byte[] arrby2) throws CryptoFailedException {
        if (this.crypto.isAvailable()) {
            Entity entity = this.createUsernameEntity(string2);
            Entity entity2 = this.createPasswordEntity(string2);
            try {
                byte[] arrby3 = this.crypto.decrypt(arrby, entity);
                byte[] arrby4 = this.crypto.decrypt(arrby2, entity2);
                CipherStorage.DecryptionResult decryptionResult = new CipherStorage.DecryptionResult(new String(arrby3, Charset.forName((String)"UTF-8")), new String(arrby4, Charset.forName((String)"UTF-8")), SecurityLevel.ANY);
                return decryptionResult;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Decryption failed for service ");
                stringBuilder.append(string2);
                throw new CryptoFailedException(stringBuilder.toString(), exception);
            }
        }
        throw new CryptoFailedException("Crypto is missing");
    }

    @Override
    public CipherStorage.EncryptionResult encrypt(String string2, String string3, String string4, SecurityLevel securityLevel) throws CryptoFailedException {
        if (this.securityLevel().satisfiesSafetyThreshold(securityLevel)) {
            if (this.crypto.isAvailable()) {
                Entity entity = this.createUsernameEntity(string2);
                Entity entity2 = this.createPasswordEntity(string2);
                try {
                    CipherStorage.EncryptionResult encryptionResult = new CipherStorage.EncryptionResult(this.crypto.encrypt(string3.getBytes(Charset.forName((String)"UTF-8")), entity), this.crypto.encrypt(string4.getBytes(Charset.forName((String)"UTF-8")), entity2), this);
                    return encryptionResult;
                }
                catch (Exception exception) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Encryption failed for service ");
                    stringBuilder.append(string2);
                    throw new CryptoFailedException(stringBuilder.toString(), exception);
                }
            }
            throw new CryptoFailedException("Crypto is missing");
        }
        Object[] arrobject = new Object[]{securityLevel, this.securityLevel()};
        throw new CryptoFailedException(String.format((String)"Insufficient security level (wants %s; got %s)", (Object[])arrobject));
    }

    @Override
    public String getCipherStorageName() {
        return CIPHER_STORAGE_NAME;
    }

    @Override
    public int getMinSupportedApiLevel() {
        return 16;
    }

    @Override
    public void removeKey(String string2) {
    }

    @Override
    public SecurityLevel securityLevel() {
        return SecurityLevel.ANY;
    }

    @Override
    public boolean supportsSecureHardware() {
        return false;
    }
}

