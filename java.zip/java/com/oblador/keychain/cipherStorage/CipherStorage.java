/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.oblador.keychain.cipherStorage;

import com.oblador.keychain.SecurityLevel;
import com.oblador.keychain.exceptions.CryptoFailedException;
import com.oblador.keychain.exceptions.KeyStoreAccessException;

public interface CipherStorage {
    public DecryptionResult decrypt(String var1, byte[] var2, byte[] var3) throws CryptoFailedException;

    public EncryptionResult encrypt(String var1, String var2, String var3, SecurityLevel var4) throws CryptoFailedException;

    public String getCipherStorageName();

    public int getMinSupportedApiLevel();

    public void removeKey(String var1) throws KeyStoreAccessException;

    public SecurityLevel securityLevel();

    public boolean supportsSecureHardware();

    public static abstract class CipherResult<T> {
        public final T password;
        public final T username;

        public CipherResult(T t2, T t3) {
            this.username = t2;
            this.password = t3;
        }
    }

    public static class DecryptionResult
    extends CipherResult<String> {
        private SecurityLevel securityLevel;

        public DecryptionResult(String string2, String string3, SecurityLevel securityLevel) {
            super(string2, string3);
            this.securityLevel = securityLevel;
        }

        public SecurityLevel getSecurityLevel() {
            return this.securityLevel;
        }
    }

    public static class EncryptionResult
    extends CipherResult<byte[]> {
        public CipherStorage cipherStorage;

        public EncryptionResult(byte[] arrby, byte[] arrby2, CipherStorage cipherStorage) {
            super(arrby, arrby2);
            this.cipherStorage = cipherStorage;
        }
    }

}

