/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.KeyguardManager
 *  android.content.Context
 *  android.hardware.fingerprint.FingerprintManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Object
 *  java.lang.String
 */
package com.oblador.keychain;

import android.app.KeyguardManager;
import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;

public class DeviceAvailability {
    public static boolean isDeviceSecure(Context context) {
        KeyguardManager keyguardManager = (KeyguardManager)context.getSystemService("keyguard");
        return Build.VERSION.SDK_INT >= 23 && keyguardManager != null && keyguardManager.isDeviceSecure();
    }

    public static boolean isFingerprintAuthAvailable(Context context) {
        int n2 = Build.VERSION.SDK_INT;
        boolean bl = false;
        if (n2 >= 23) {
            FingerprintManager fingerprintManager = (FingerprintManager)context.getSystemService("fingerprint");
            bl = false;
            if (fingerprintManager != null) {
                boolean bl2 = fingerprintManager.isHardwareDetected();
                bl = false;
                if (bl2) {
                    boolean bl3 = fingerprintManager.hasEnrolledFingerprints();
                    bl = false;
                    if (bl3) {
                        bl = true;
                    }
                }
            }
        }
        return bl;
    }
}

