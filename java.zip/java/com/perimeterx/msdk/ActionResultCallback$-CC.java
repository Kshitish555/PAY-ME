/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.perimeterx.msdk;

import com.perimeterx.msdk.ActionResultCallback;

public final class ActionResultCallback$-CC {
    public static void $default$onBlockWindowClosed(ActionResultCallback actionResultCallback) {
    }
}

