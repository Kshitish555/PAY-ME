/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.perimeterx.msdk.a;

import android.os.Parcel;
import android.os.Parcelable;
import com.perimeterx.msdk.a.k;
import org.json.JSONObject;

public class l
implements Parcelable {
    public static final Parcelable.Creator<l> CREATOR = new k();
    private String a;
    private String b;
    private String c;
    private String d;
    private String e;
    private String f;

    l() {
    }

    public l(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
        this.d = parcel.readString();
        this.e = parcel.readString();
        this.f = parcel.readString();
    }

    static l a(JSONObject jSONObject) {
        l l2 = new l();
        l2.a = jSONObject.optString("appId");
        l2.b = jSONObject.optString("vid");
        l2.c = jSONObject.optString("uuid");
        l2.d = jSONObject.optString("collectorURL");
        l2.e = jSONObject.optString("page");
        l2.f = jSONObject.optString("action");
        return l2;
    }

    public String a() {
        return this.f;
    }

    public String b() {
        return this.e;
    }

    public int describeContents() {
        return 0;
    }

    public int hashCode() {
        return this.a.hashCode() ^ this.b.hashCode() ^ this.c.hashCode() ^ this.d.hashCode() ^ this.e.hashCode() ^ this.f.hashCode();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeString(this.f);
    }
}

