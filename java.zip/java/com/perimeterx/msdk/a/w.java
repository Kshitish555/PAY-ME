/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.perimeterx.msdk.a;

import android.text.TextUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class w {
    public final int a;
    public final String b;
    private final int c;
    public final long d;
    public final boolean e;

    public w(int n2, String string2, int n3, boolean bl, int n4) {
        this.a = n2;
        this.b = string2;
        this.c = n3;
        this.e = bl;
        double d2 = n4;
        Double.isNaN((double)d2);
        double d3 = d2 * 0.8;
        double d4 = System.currentTimeMillis() / 1000L;
        Double.isNaN((double)d4);
        this.d = (long)(d4 + d3);
    }

    public w(long l2, int n2, String string2, int n3, boolean bl) {
        this.a = n2;
        this.b = string2;
        this.c = n3;
        this.e = bl;
        this.d = l2;
    }

    public static w a(JSONObject jSONObject) {
        try {
            int n2 = jSONObject.getInt("mVersion");
            String string2 = jSONObject.getString("mBakedHeader");
            int n3 = jSONObject.getInt("mTtl");
            boolean bl = jSONObject.getBoolean("mDomain");
            long l2 = jSONObject.getLong("mValidityFireDateUnixTime");
            w w2 = new w(l2, n2, string2, n3, bl);
            return w2;
        }
        catch (JSONException jSONException) {
            return null;
        }
    }

    private JSONObject c() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("mVersion", this.a);
            jSONObject.put("mBakedHeader", (Object)this.b);
            jSONObject.put("mTtl", this.c);
            jSONObject.put("mDomain", this.e);
            jSONObject.put("mValidityFireDateUnixTime", this.d);
            return jSONObject;
        }
        catch (JSONException jSONException) {
            return null;
        }
    }

    public String a() {
        if (TextUtils.isEmpty((CharSequence)this.b)) {
            return String.valueOf((int)this.a);
        }
        Object[] arrobject = new Object[]{this.a, this.b};
        return String.format((String)"%s:%s", (Object[])arrobject);
    }

    public String b() {
        JSONObject jSONObject = this.c();
        if (jSONObject != null) {
            return jSONObject.toString();
        }
        return null;
    }
}

