/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.pm.ApplicationInfo
 *  android.os.Build
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Locale
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.perimeterx.msdk.a.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import com.perimeterx.msdk.a.c;
import com.perimeterx.msdk.a.d.d;
import com.perimeterx.msdk.a.d.e;
import com.perimeterx.msdk.a.g;
import com.perimeterx.msdk.a.m;
import com.perimeterx.msdk.a.v;
import com.perimeterx.msdk.a.x;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class a
implements c {
    public static String a = "missing_value";
    private final d b = d.a(this.getClass().getSimpleName());
    protected final a c;
    protected final Handler d;
    protected final String e;
    protected final String f;
    protected final String g;
    protected final String h;
    protected final String i;
    protected final String j;
    protected final int k;
    protected final int l;
    protected int m;
    protected int n;
    private final String o;
    private final String p;
    private final int q;
    private final String r;
    private final String s;
    private final float t;
    private final float u;
    private final String[] v = new String[]{"", "unknown", "good", "overheat", "dead", "over voltage", "unspecified failure", "cold"};
    private final String[] w = new String[]{"None", "AC", "USB"};
    private final String[] x = new String[]{"", "unknown", "charging", "discharging", "not charging", "full"};

    public a(String string2) {
        String[] arrstring;
        v v2 = v.l();
        Context context = v2.i();
        this.k = v2.o();
        this.l = v2.q();
        this.m = 0;
        this.n = 1;
        this.c = new a(string2, v2.d());
        this.d = new Handler(Looper.getMainLooper());
        this.g = v2.e();
        this.e = this.a(context);
        this.f = context.getApplicationContext().getPackageName();
        this.h = e.b(context);
        String string3 = e.d(context);
        if (string3 == null || TextUtils.isEmpty((CharSequence)string3.trim())) {
            string3 = a;
        }
        this.i = string3;
        this.j = Locale.getDefault().toString();
        Intent intent = context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        int n2 = intent.getIntExtra("health", 0);
        String[] arrstring2 = this.v;
        int n3 = arrstring2.length;
        String string4 = "";
        String string5 = n2 < n3 ? arrstring2[n2] : string4;
        this.o = string5;
        this.q = intent.getIntExtra("level", 0);
        int n4 = intent.getIntExtra("plugged", 0);
        String[] arrstring3 = this.w;
        String string6 = n4 < arrstring3.length ? arrstring3[n4] : string4;
        this.r = string6;
        int n5 = intent.getIntExtra("status", 0);
        if (n5 < (arrstring = this.x).length) {
            string4 = arrstring[n5];
        }
        this.p = string4;
        this.s = intent.getExtras().getString("technology");
        this.t = (float)intent.getIntExtra("temperature", 0) / 10.0f;
        this.u = (float)intent.getIntExtra("voltage", 0) / 1000.0f;
    }

    private String a(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        int n2 = applicationInfo.labelRes;
        if (n2 == 0) {
            return applicationInfo.nonLocalizedLabel.toString();
        }
        return context.getString(n2);
    }

    public void a() {
        try {
            JSONArray jSONArray = new JSONArray();
            String string2 = this.j;
            if (TextUtils.isEmpty((CharSequence)string2)) {
                string2 = a;
            }
            jSONArray.put((Object)string2);
            String string3 = Build.MANUFACTURER;
            if (TextUtils.isEmpty((CharSequence)string3)) {
                string3 = a;
            }
            a a2 = this.c.a(m.C, string3);
            String string4 = m.n;
            a2.a(string4, "Android").a(m.D, x.a()).a(m.E, this.e).a(m.F, this.g).a(m.K, this.f).a(m.G, this.h).a(m.H, this.i).a(m.J, (Object)jSONArray).a(m.O, this.o).a(m.P, this.p).a(m.Q, this.q).a(m.R, this.r).a(m.S, this.s).a(m.T, (Object)Float.valueOf((float)this.t)).a(m.U, (Object)Float.valueOf((float)this.u));
        }
        catch (JSONException jSONException) {
            this.b.a(5, "Failed to build app init activity").a(5, (Exception)((Object)jSONException));
        }
        v.l().h().b(this);
    }

    public void b() {
        this.m = 1 + this.m;
        this.n = 2 * this.n;
    }

    @Override
    public JSONObject build() {
        return this.c.a();
    }

    class a {
        private JSONObject a;
        private String b;

        public a(String string2, JSONObject jSONObject) {
            this.b = string2;
            this.a = jSONObject;
        }

        public a a(String string2, Object object) {
            this.a.put(string2, object);
            return this;
        }

        public JSONObject a() {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("t", (Object)this.b);
                jSONObject.put("d", (Object)this.a);
                return jSONObject;
            }
            catch (JSONException jSONException) {
                throw new RuntimeException("failed to create JSONObject", (Throwable)jSONException);
            }
        }
    }

}

