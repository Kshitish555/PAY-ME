/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Handler
 *  android.text.TextUtils
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  org.json.JSONException
 */
package com.perimeterx.msdk.a.a;

import android.os.Build;
import android.os.Handler;
import android.text.TextUtils;
import com.perimeterx.msdk.a.a.a;
import com.perimeterx.msdk.a.a.b;
import com.perimeterx.msdk.a.d.d;
import com.perimeterx.msdk.a.m;
import com.perimeterx.msdk.a.v;
import java.io.IOException;
import org.json.JSONException;

public class c
extends a {
    private String A;
    private String B;
    private String C = Build.MODEL.trim();
    private final d y = d.a(c.class.getSimpleName());
    private long z;

    public c(long l2, String string2, String string3) {
        super(m.t);
        if (TextUtils.isEmpty((CharSequence)this.C)) {
            this.C = a.a;
        }
        this.z = l2;
        this.A = string2;
        this.B = string3;
        this.a();
    }

    @Override
    public void a() {
        try {
            this.c.a(m.m, this.C).a(m.g, this.z).a(m.e, this.A).a(m.f, this.B);
        }
        catch (JSONException jSONException) {
            this.y.a(5, "Failed to build app challenge activity").a(5, (Exception)((Object)jSONException));
        }
        super.a();
    }

    @Override
    public void onFailure(IOException iOException) {
        int n2 = v.l().a(this.m, this.n);
        if (n2 > -1) {
            this.d.postDelayed((Runnable)new b(this), (long)n2);
            this.b();
        }
    }
}

