/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  org.json.JSONObject
 */
package com.perimeterx.msdk.a;

import java.io.IOException;
import org.json.JSONObject;

public interface c {
    public JSONObject build();

    public void onFailure(IOException var1);
}

