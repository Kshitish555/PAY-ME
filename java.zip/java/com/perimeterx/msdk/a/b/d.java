/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.perimeterx.msdk.a.b;

import com.perimeterx.msdk.a.h;

abstract class d
implements h {
    public String[] a;

    public d(String[] arrstring) {
        this.a = arrstring;
    }
}

