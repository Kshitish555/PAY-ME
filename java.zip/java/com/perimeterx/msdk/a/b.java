/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.lang.String
 */
package com.perimeterx.msdk.a;

import android.content.Context;
import com.perimeterx.msdk.a.a;
import com.perimeterx.msdk.a.d.c;
import com.perimeterx.msdk.a.d.d;
import com.perimeterx.msdk.a.v;

class b {
    private final d a = d.a(b.class.getSimpleName());
    private c.a b = new a(this);

    public b() {
        c.a(v.l().i()).a(this.b);
    }

    static /* synthetic */ d a(b b2) {
        return b2.a;
    }

    public void a() {
        b b2 = this;
        synchronized (b2) {
            c.a().b(this.b);
            return;
        }
    }
}

