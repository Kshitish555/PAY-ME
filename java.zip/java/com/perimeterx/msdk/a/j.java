/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.perimeterx.msdk.internal.enforcers.e
 *  com.perimeterx.msdk.internal.enforcers.h
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.perimeterx.msdk.a;

import com.perimeterx.msdk.PXResponse;
import com.perimeterx.msdk.a.l;
import com.perimeterx.msdk.internal.enforcers.e;
import com.perimeterx.msdk.internal.enforcers.h;
import com.perimeterx.msdk.internal.enforcers.i;
import org.json.JSONException;
import org.json.JSONObject;

class j {
    j() {
    }

    PXResponse a(String string2) {
        l l2;
        try {
            l2 = l.a(new JSONObject(string2));
        }
        catch (JSONException jSONException) {
            return new i();
        }
        String string3 = l2.a();
        int n2 = -1;
        int n3 = string3.hashCode();
        if (n3 != 93832333) {
            if (n3 != 552567418) {
                if (n3 == 1402633315 && string3.equals((Object)"challenge")) {
                    n2 = 1;
                }
            } else if (string3.equals((Object)"captcha")) {
                n2 = 2;
            }
        } else if (string3.equals((Object)"block")) {
            n2 = 0;
        }
        if (n2 != 0) {
            if (n2 != 1 && n2 != 2) {
                return new i();
            }
            return new h(l2);
        }
        return new e(l2);
    }
}

