/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.perimeterx.msdk.a;

public final class x {
    public static String a() {
        Object[] arrobject = new Object[]{x.c()};
        return String.format((String)"v%s", (Object[])arrobject);
    }

    public static String b() {
        Object[] arrobject = new Object[]{x.c()};
        return String.format((String)"PerimeterX Android SDK/%s", (Object[])arrobject);
    }

    public static String c() {
        return "1.9.1";
    }
}

