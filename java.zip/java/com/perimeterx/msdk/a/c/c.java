/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.perimeterx.msdk.a.c;

import com.perimeterx.msdk.a.h;
import com.perimeterx.msdk.a.i;

public class c
implements i {
    private h[] a;

    public c(h[] arrh) {
        this.a = arrh;
    }

    public void a() {
        this.a[0].execute();
    }
}

