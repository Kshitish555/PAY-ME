/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.perimeterx.msdk.a.b.b
 *  java.lang.Object
 *  java.util.Arrays
 */
package com.perimeterx.msdk.a.c;

import com.perimeterx.msdk.a.b.b;
import com.perimeterx.msdk.a.h;
import com.perimeterx.msdk.a.i;
import java.util.Arrays;

public class a
implements i {
    private b[] a;

    public a(h[] arrh) {
        this.a = (b[])Arrays.copyOf((Object[])arrh, (int)arrh.length, b[].class);
    }

    public void a() {
        Object[] arrobject = this.a;
        b b2 = arrobject[0];
        for (b b3 : (b[])Arrays.copyOfRange((Object[])arrobject, (int)1, (int)arrobject.length)) {
            if (b3.h() <= b2.h()) continue;
            b2 = b3;
        }
        b2.execute();
    }
}

