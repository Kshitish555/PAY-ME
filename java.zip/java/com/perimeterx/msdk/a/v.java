/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Looper
 *  android.text.TextUtils
 *  com.perimeterx.msdk.a.a.g
 *  java.io.PrintWriter
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.net.MalformedURLException
 *  java.net.URL
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Set
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  okhttp3.Call
 *  okhttp3.Callback
 *  okhttp3.MediaType
 *  okhttp3.OkHttpClient
 *  okhttp3.Request
 *  okhttp3.Request$Builder
 *  okhttp3.RequestBody
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.perimeterx.msdk.a;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import com.perimeterx.msdk.ActionResultCallback;
import com.perimeterx.msdk.BackButtonPressedCallBack;
import com.perimeterx.msdk.ManagerReadyCallback;
import com.perimeterx.msdk.NewHeadersCallback;
import com.perimeterx.msdk.PXResponse;
import com.perimeterx.msdk.a.a.g;
import com.perimeterx.msdk.a.b;
import com.perimeterx.msdk.a.d.d;
import com.perimeterx.msdk.a.d.g;
import com.perimeterx.msdk.a.d.h;
import com.perimeterx.msdk.a.g;
import com.perimeterx.msdk.a.j;
import com.perimeterx.msdk.a.m;
import com.perimeterx.msdk.a.o;
import com.perimeterx.msdk.a.p;
import com.perimeterx.msdk.a.r;
import com.perimeterx.msdk.a.s;
import com.perimeterx.msdk.a.t;
import com.perimeterx.msdk.a.u;
import com.perimeterx.msdk.a.w;
import com.perimeterx.msdk.a.x;
import com.perimeterx.msdk.internal.enforcers.i;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import org.json.JSONException;
import org.json.JSONObject;

public class v {
    private static final Pattern a = Pattern.compile((String)"custom_param([0-9]|10)");
    private static final MediaType b = MediaType.parse((String)"application/json; charset=utf-8");
    public static final String c = new Integer(Build.VERSION.SDK_INT).toString();
    private static v d;
    private static boolean e;
    private static boolean f;
    private ManagerReadyCallback A;
    private Handler B;
    private Handler C;
    private long D;
    private JSONObject E;
    private String F;
    private String G;
    private ActionResultCallback H;
    private Boolean I;
    private BackButtonPressedCallBack J;
    private Boolean K;
    private final d g = d.a(v.class.getSimpleName());
    private Context h;
    private h i;
    private String j;
    private URL k;
    private URL l;
    private Long m;
    private int n = 60000;
    private int o = 3;
    private int p;
    private int q;
    private boolean r;
    private com.perimeterx.msdk.a.g s;
    private j t;
    private b u;
    private Map<String, String> v;
    private HashMap<String, String> w;
    private Map<String, String> x;
    private int y;
    private NewHeadersCallback z;

    static {
        e = false;
        f = false;
    }

    protected v() {
        Boolean bl = false;
        this.p = 0;
        this.q = 1;
        this.r = false;
        this.v = new HashMap();
        this.w = new HashMap();
        this.x = new HashMap();
        this.y = 5;
        this.z = null;
        this.A = new o(this);
        this.C = new Handler();
        this.E = new JSONObject();
        this.F = "";
        this.G = "";
        this.H = null;
        this.I = bl;
        this.J = null;
        this.K = bl;
        this.B = new Handler();
        this.B.postDelayed((Runnable)new p(this), 10000L);
        this.B();
    }

    private static v A() {
        if (e) {
            return v.l();
        }
        throw new RuntimeException((Throwable)new IllegalStateException("called before init"));
    }

    private void B() {
        this.x.put((Object)"entitlement", (Object)"PerimeterX Bot Defender Mobile license is invalid. Please contact PerimeterX for further support. SDK will now enter bypass mode.");
    }

    private void C() {
        URL uRL;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)this.l);
            stringBuilder.append("/api/v1/mobile");
            uRL = new URL(stringBuilder.toString());
        }
        catch (MalformedURLException malformedURLException) {
            this.a((Exception)((Object)malformedURLException));
            return;
        }
        try {
            String string2 = this.j;
            this.a(uRL, string2, "Android", c, x.a(), this.F, new r(this));
            return;
        }
        catch (JSONException jSONException) {
            this.a((Exception)((Object)jSONException));
            return;
        }
    }

    private void D() {
        this.B.removeCallbacksAndMessages(null);
        this.B = null;
        ManagerReadyCallback managerReadyCallback = this.n();
        if (managerReadyCallback != null) {
            managerReadyCallback.onManagerReady(this.k());
        }
        this.b(System.currentTimeMillis() - this.D);
        d d2 = this.g;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SDK ready time: ");
        stringBuilder.append(System.currentTimeMillis() - this.D);
        d2.a(4, stringBuilder.toString());
    }

    private boolean E() {
        if (this.r() == null && this.i.h()) {
            this.g.a(4, "sync flow check - vid is missing.");
            return true;
        }
        return false;
    }

    static /* synthetic */ int a(v v2, int n2) {
        v2.q = n2;
        return n2;
    }

    public static PXResponse a(String string2) {
        try {
            PXResponse pXResponse = v.A().j().a(string2);
            return pXResponse;
        }
        catch (Exception exception) {
            v.l().a(exception);
            return new i();
        }
    }

    static /* synthetic */ b a(v v2, b b2) {
        v2.u = b2;
        return b2;
    }

    static /* synthetic */ d a(v v2) {
        return v2.g;
    }

    public static void a(PXResponse pXResponse, ActionResultCallback actionResultCallback) {
        try {
            v.l().H = actionResultCallback;
            pXResponse.enforce(actionResultCallback);
            return;
        }
        catch (Exception exception) {
            v.l().a(exception);
            return;
        }
    }

    static /* synthetic */ boolean a(boolean bl) {
        e = bl;
        return bl;
    }

    static /* synthetic */ h b(v v2) {
        return v2.i;
    }

    static /* synthetic */ int c(v v2) {
        return v2.p;
    }

    static /* synthetic */ int d(v v2) {
        int n2 = v2.p;
        v2.p = n2 + 1;
        return n2;
    }

    static /* synthetic */ int e(v v2) {
        return v2.q;
    }

    static /* synthetic */ void f(v v2) {
        v2.C();
    }

    static /* synthetic */ Handler g(v v2) {
        return v2.C;
    }

    static /* synthetic */ Map h(v v2) {
        return v2.x;
    }

    public static v l() {
        if (d == null) {
            if (Looper.myLooper() == null) {
                Looper.prepare();
            }
            d = new v();
        }
        return d;
    }

    public static void v() {
        try {
            v.A().c();
            return;
        }
        catch (Exception exception) {
            v.l().a(exception);
            return;
        }
    }

    public int a(int n2, int n3) {
        int n4 = this.o;
        if (n4 != 0 && n2 >= n4) {
            return -1;
        }
        return n3 * this.n;
    }

    public v a(int n2) {
        this.o = n2;
        return this;
    }

    public v a(BackButtonPressedCallBack backButtonPressedCallBack) {
        this.J = backButtonPressedCallBack;
        return this;
    }

    public v a(ManagerReadyCallback managerReadyCallback) {
        this.A = managerReadyCallback;
        return this;
    }

    public v a(NewHeadersCallback newHeadersCallback) {
        this.z = newHeadersCallback;
        return this;
    }

    public v a(Map<String, String> map) {
        IllegalArgumentException illegalArgumentException;
        if (e) {
            return this;
        }
        Set set = map.keySet();
        if (set.size() <= 10) {
            for (String string2 : set) {
                if (a.matcher((CharSequence)string2).matches()) continue;
                throw new IllegalArgumentException(String.format((String)"custom param key must be of the form custom_param<1-10>, got %s", (Object[])new Object[]{string2}));
            }
            this.v = map;
            return this;
        }
        Object[] arrobject = new Object[]{10};
        illegalArgumentException = new IllegalArgumentException(String.format((String)"cannot exceed %s customParams", (Object[])arrobject));
        throw illegalArgumentException;
    }

    @Deprecated
    public v a(String[] arrstring) {
        IllegalArgumentException illegalArgumentException;
        if (e) {
            return this;
        }
        int n2 = arrstring.length;
        int n3 = 0;
        if (n2 <= 10) {
            HashMap hashMap = new HashMap();
            while (n3 < arrstring.length) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("custom_param");
                int n4 = n3 + 1;
                stringBuilder.append(n4);
                hashMap.put((Object)stringBuilder.toString(), (Object)arrstring[n3]);
                n3 = n4;
            }
            this.v = hashMap;
            return this;
        }
        Object[] arrobject = new Object[]{10};
        illegalArgumentException = new IllegalArgumentException(String.format((String)"cannot exceed %s customParams", (Object[])arrobject));
        throw illegalArgumentException;
    }

    public void a() {
        this.w.put((Object)"X-PX-SIMULATE", (Object)"block");
    }

    public void a(long l2) {
        try {
            this.E.put(m.L, l2);
            return;
        }
        catch (JSONException jSONException) {
            this.a((Exception)((Object)jSONException));
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(Context context, String string2) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2)) {
            this.g.a(3, "SDK start()");
            this.D = System.currentTimeMillis();
            if (e) {
                this.g.a(3, "PerimeterX SDK has already been initialized.");
                return;
            }
            try {
                com.perimeterx.msdk.a.g g2;
                String string3;
                this.j = string2;
                this.h = context.getApplicationContext();
                this.i = h.a(this.h);
                string3 = this.r();
                try {
                    PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                    String string4 = packageInfo != null && packageInfo.versionName != null ? packageInfo.versionName : "null";
                    this.F = string4;
                }
                catch (PackageManager.NameNotFoundException nameNotFoundException) {}
                if (this.k == null) {
                    Object[] arrobject = new Object[]{this.j};
                    this.k = new URL(String.format((String)"https://collector-%s.perimeterx.net", (Object[])arrobject));
                }
                if (this.l == null) {
                    this.l = new URL("https://px-conf.perimeterx.net");
                }
                if (string3 != null) {
                    d d2 = this.g;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Existing VID is: ");
                    stringBuilder.append(string3);
                    d2.a(3, stringBuilder.toString());
                }
                this.s = g2 = new com.perimeterx.msdk.a.g(this.j, this.k, this.v, this.w, this.y);
                this.t = new j();
                if (this.E()) {
                    d d3 = this.g;
                    d3.a(3, "SDK checking for sync flow");
                } else {
                    d d4 = this.g;
                    d4.a(3, "SDK should return managerReady immediately");
                    this.t();
                }
                this.C();
                return;
            }
            catch (Exception exception) {
                this.a(exception);
                return;
            }
        }
        f = true;
        this.g.a(6, "PerimeterX SDK cannot be initialized. You must pass two parameters - an instance of activity and a string containing the PerimeterX AppID. SDK will now enter bypass mode.");
    }

    public void a(Boolean bl) {
        this.I = bl;
    }

    public void a(Exception exception) {
        this.a(exception, true);
    }

    public void a(Exception exception, boolean bl) {
        if (bl) {
            this.g.a(5, "reporting crash").a(5, exception);
        }
        StringWriter stringWriter = new StringWriter();
        exception.printStackTrace(new PrintWriter((Writer)stringWriter));
        Object[] arrobject = new Object[]{this.j, x.c(), stringWriter.toString()};
        String string2 = String.format((String)"?appId=%s&tag=%s&stack=%s", (Object[])arrobject);
        URL uRL = null;
        try {
            URL uRL2;
            URL uRL3 = this.k;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("api/v1/collector/clientError");
            stringBuilder.append(string2);
            uRL = uRL2 = new URL(uRL3, stringBuilder.toString());
        }
        catch (MalformedURLException malformedURLException) {
            malformedURLException.printStackTrace();
        }
        if (uRL == null) {
            return;
        }
        Request request = new Request.Builder().url(uRL).get().build();
        new OkHttpClient().newCall(request).enqueue((Callback)new t(this));
    }

    public void a(URL uRL, String string2, String string3, String string4, String string5, String string6, a a2) {
        this.g.a(4, "checkSDKEnabled...");
        JSONObject jSONObject = new JSONObject().put("app_id", (Object)string2).put("device_os_name", (Object)string3).put("device_os_version", (Object)string4).put("sdk_version", (Object)string5).put("app_version", (Object)string6);
        RequestBody requestBody = RequestBody.create((MediaType)b, (String)jSONObject.toString());
        Request request = new Request.Builder().url(uRL).post(requestBody).build();
        g.a(new OkHttpClient().newCall(request), new u(this, a2));
    }

    public v b(int n2) {
        this.y = n2;
        return this;
    }

    public v b(Boolean bl) {
        this.K = bl;
        return this;
    }

    public v b(String string2) {
        this.G = string2;
        return this;
    }

    public void b() {
        this.w.put((Object)"X-PX-SIMULATE", (Object)"captcha");
    }

    public void b(long l2) {
        try {
            this.E.put(m.M, l2);
            return;
        }
        catch (JSONException jSONException) {
            this.a((Exception)((Object)jSONException));
            return;
        }
    }

    public v c(int n2) {
        this.n = n2;
        return this;
    }

    public void c() {
        this.u.a();
        this.u = new b();
        new com.perimeterx.msdk.a.a.g(g.a.a);
    }

    public JSONObject d() {
        try {
            JSONObject jSONObject = this.E;
            return jSONObject;
        }
        finally {
            this.E = new JSONObject();
        }
    }

    public String e() {
        return this.F;
    }

    public BackButtonPressedCallBack f() {
        return this.J;
    }

    public String g() {
        return this.G;
    }

    public com.perimeterx.msdk.a.g h() {
        return this.s;
    }

    public Context i() {
        return this.h;
    }

    public j j() {
        return this.t;
    }

    public HashMap<String, String> k() {
        HashMap hashMap = new HashMap();
        h h2 = this.i;
        if (h2 != null && !f) {
            w w2 = h2.f();
            if (!this.i.h()) {
                hashMap.put((Object)"X-PX-AUTHORIZATION", (Object)"4");
                String string2 = this.i.b();
                if (string2 != null && !string2.isEmpty()) {
                    hashMap.put((Object)"X-PX-BYPASS-REASON", (Object)string2);
                }
                if (w2 != null && w2.b != null) {
                    hashMap.put((Object)"X-PX-ORIGINAL-TOKEN", (Object)w2.a());
                }
                return hashMap;
            }
            g.a a2 = this.i.d();
            if (a2 != g.a.a) {
                String string3 = a2 == g.a.c ? "3" : "2";
                if (w2 != null && w2.b != null) {
                    hashMap.put((Object)"X-PX-ORIGINAL-TOKEN", (Object)w2.a());
                }
                hashMap.put((Object)"X-PX-AUTHORIZATION", (Object)string3);
                return hashMap;
            }
            if (w2 != null) {
                hashMap.put((Object)"X-PX-AUTHORIZATION", (Object)w2.a());
            }
            if (hashMap.get((Object)"X-PX-AUTHORIZATION") == null) {
                hashMap.put((Object)"X-PX-AUTHORIZATION", (Object)"1");
            }
            return hashMap;
        }
        hashMap.put((Object)"X-PX-AUTHORIZATION", (Object)"4");
        hashMap.put((Object)"X-PX-BYPASS-REASON", (Object)"Invalid SDK initialization");
        this.g.a(6, "PerimeterX SDK cannot be initialized. You must pass two parameters - an instance of activity and a string containing the PerimeterX AppID. SDK will now enter bypass mode.");
        return hashMap;
    }

    public Boolean m() {
        return this.K;
    }

    public ManagerReadyCallback n() {
        return this.A;
    }

    public int o() {
        return this.o;
    }

    public NewHeadersCallback p() {
        return this.z;
    }

    public int q() {
        return this.n;
    }

    public String r() {
        try {
            String string2 = this.i.g();
            return string2;
        }
        catch (NullPointerException nullPointerException) {
            this.g.a(3, "PerimeterX SDK is not properly initialized, all the function calls will return null.");
            return null;
        }
    }

    public Boolean s() {
        return this.I;
    }

    public void t() {
        if (!this.r) {
            this.r = true;
            this.D();
            return;
        }
        this.z();
        NewHeadersCallback newHeadersCallback = this.p();
        if (newHeadersCallback != null) {
            newHeadersCallback.onNewHeaders(this.k());
        }
    }

    public void u() {
        this.H = null;
    }

    public void w() {
        this.g.a(3, "Running app init activity");
        new Handler(this.h.getMainLooper()).post((Runnable)new s(this, this));
        e = true;
    }

    public void x() {
        this.m = System.currentTimeMillis();
    }

    public void y() {
        long l2 = System.currentTimeMillis() - this.m;
        d d2 = this.g;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("App is active for - ");
        stringBuilder.append(l2);
        d2.a(4, stringBuilder.toString());
        this.i.a(l2);
    }

    public void z() {
        if (this.H != null && this.i.c()) {
            this.H.onSuccess();
            this.H = null;
            this.i.a(false);
        }
    }

    private static interface a {
        public void a();

        public void a(Boolean var1);
    }

}

