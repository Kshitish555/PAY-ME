/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Base64
 *  com.perimeterx.msdk.a.b.b
 *  com.perimeterx.msdk.a.b.c
 *  com.perimeterx.msdk.a.b.e
 *  com.perimeterx.msdk.a.b.f
 *  com.perimeterx.msdk.a.c.b
 *  com.perimeterx.msdk.a.c.d
 *  com.perimeterx.msdk.a.c.e
 *  java.io.IOException
 *  java.io.UnsupportedEncodingException
 *  java.lang.CharSequence
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.net.URL
 *  java.security.KeyManagementException
 *  java.security.NoSuchAlgorithmException
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.TimeUnit
 *  javax.net.ssl.SSLSocketFactory
 *  javax.net.ssl.X509TrustManager
 *  okhttp3.Call
 *  okhttp3.CertificatePinner
 *  okhttp3.CertificatePinner$Builder
 *  okhttp3.FormBody
 *  okhttp3.FormBody$Builder
 *  okhttp3.OkHttpClient
 *  okhttp3.OkHttpClient$Builder
 *  okhttp3.Request
 *  okhttp3.Request$Builder
 *  okhttp3.RequestBody
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.perimeterx.msdk.a;

import android.content.Context;
import android.util.Base64;
import com.perimeterx.msdk.a.b.b;
import com.perimeterx.msdk.a.b.c;
import com.perimeterx.msdk.a.b.e;
import com.perimeterx.msdk.a.b.f;
import com.perimeterx.msdk.a.d.d;
import com.perimeterx.msdk.a.d.h;
import com.perimeterx.msdk.a.d.i;
import com.perimeterx.msdk.a.h;
import com.perimeterx.msdk.a.m;
import com.perimeterx.msdk.a.n;
import com.perimeterx.msdk.a.v;
import com.perimeterx.msdk.a.w;
import com.perimeterx.msdk.a.x;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import okhttp3.Call;
import okhttp3.CertificatePinner;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class g {
    private final d a = d.a(g.class.getSimpleName());
    private w b;
    private String c;
    private String d;
    private String e;
    private h f = h.a(v.l().i());
    private final String g;
    private final URL h;
    private final Map<String, String> i;
    private final OkHttpClient j;
    private final HashMap<String, String> k;

    protected g(String string2, URL uRL, Map<String, String> map, HashMap<String, String> hashMap, int n2) {
        this.g = string2;
        this.e = this.f.g();
        this.b = this.f.f();
        this.h = new URL(uRL, "/api/v1/collector/mobile");
        this.i = map;
        this.k = hashMap;
        this.j = this.a(uRL, n2);
    }

    static /* synthetic */ d a(g g2) {
        return g2.a;
    }

    private HashMap<String, String> a(com.perimeterx.msdk.a.c c2, Map<String, String> map) {
        String string2;
        JSONArray jSONArray = new JSONArray();
        HashMap hashMap = new HashMap();
        jSONArray.put((Object)c2.build());
        for (String string3 : map.keySet()) {
            hashMap.put((Object)string3.replace((CharSequence)"custom_param", (CharSequence)"p"), map.get((Object)string3));
        }
        hashMap.put((Object)"appId", (Object)this.g);
        hashMap.put((Object)"tag", (Object)"mobile");
        hashMap.put((Object)"ftag", (Object)m.a);
        hashMap.put((Object)"uuid", (Object)this.d);
        String string4 = this.c;
        if (string4 != null) {
            hashMap.put((Object)"sid", (Object)string4);
        }
        if ((string2 = this.e) != null) {
            hashMap.put((Object)"vid", (Object)string2);
        }
        hashMap.put((Object)"payload", (Object)Base64.encodeToString((byte[])jSONArray.toString().getBytes("UTF-8"), (int)2));
        return hashMap;
    }

    private OkHttpClient a(URL uRL, int n2) {
        i i2;
        CertificatePinner certificatePinner;
        block4 : {
            void var10_7;
            certificatePinner = new CertificatePinner.Builder().add(uRL.getHost(), new String[]{"sha256/Kjni8NhH9mp+IQsRrfXJqyl0jlct9ieWePBA/DcS/1w="}).add(uRL.getHost(), new String[]{"sha256/grX4Ta9HpZx6tSHkmCrvpApTQGo67CYDnvprLg5yRME="}).add(uRL.getHost(), new String[]{"sha256/V5L96iSCz0XLFgvKi7YVo6M4SIkOP9zSkDjZ0EoU6b8="}).add(uRL.getHost(), new String[]{"sha256/r/mIkG3eEpVdm+u/ko/cwxzOMo1bk4TyHIlByibiA5E="}).add(uRL.getHost(), new String[]{"sha256/YLh1dUR9y6Kja30RrAn7JKnbQG/uEtLMkBgFF2Fuihg="}).add(uRL.getHost(), new String[]{"sha256/baHWPQeCjK/t6GB+okH73C13ZXVDr2QAVt6jQTsq2Ys="}).build();
            try {
                i2 = new i();
                break block4;
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            }
            catch (KeyManagementException keyManagementException) {
                // empty catch block
            }
            this.a.a(3, "Failed to create Socket connection");
            v.l().a((Exception)var10_7);
            i2 = null;
        }
        OkHttpClient.Builder builder = new OkHttpClient.Builder().certificatePinner(certificatePinner);
        long l2 = n2;
        OkHttpClient.Builder builder2 = builder.connectTimeout(l2, TimeUnit.SECONDS).writeTimeout(l2, TimeUnit.SECONDS).readTimeout(l2, TimeUnit.SECONDS);
        if (i2 != null) {
            builder2.sslSocketFactory((SSLSocketFactory)i2, i2.a());
        }
        return builder2.build();
    }

    private Request a(URL uRL, com.perimeterx.msdk.a.c c2, Map<String, String> map, HashMap<String, String> hashMap) {
        HashMap<String, String> hashMap2 = this.a(c2, map);
        FormBody.Builder builder = new FormBody.Builder();
        for (String string2 : hashMap2.keySet()) {
            builder.add(string2, (String)hashMap2.get((Object)string2));
        }
        FormBody formBody = builder.build();
        Request.Builder builder2 = new Request.Builder().url(uRL).post((RequestBody)formBody);
        for (Map.Entry entry : hashMap.entrySet()) {
            builder2.addHeader((String)entry.getKey(), (String)entry.getValue());
        }
        builder2.addHeader("User-Agent", x.b());
        return builder2.build();
    }

    private void a(com.perimeterx.msdk.a.c c2, n n2) {
        void var3_9;
        Request request;
        try {
            request = this.a(this.h, c2, this.i, this.k);
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
        }
        catch (JSONException jSONException) {
            // empty catch block
        }
        long l2 = System.currentTimeMillis();
        Call call = this.j.newCall(request);
        com.perimeterx.msdk.a.e e2 = new com.perimeterx.msdk.a.e(this, l2, n2, c2);
        com.perimeterx.msdk.a.d.g.a(call, e2);
        return;
        n2.a(new IOException("Failed generate collector request", (Throwable)var3_9), c2);
    }

    static /* synthetic */ void a(g g2, h.a a2, com.perimeterx.msdk.a.h[] arrh) {
        g2.a(a2, arrh);
    }

    private void a(h.a a2, com.perimeterx.msdk.a.h[] arrh) {
        int n2 = com.perimeterx.msdk.a.f.a[a2.ordinal()];
        if (n2 != 1) {
            com.perimeterx.msdk.a.c.e e2;
            if (n2 != 2) {
                if (n2 != 3) {
                    if (n2 != 4) {
                        return;
                    }
                    e2 = new com.perimeterx.msdk.a.c.d(arrh);
                } else {
                    e2 = new com.perimeterx.msdk.a.c.b(arrh);
                }
            } else {
                e2 = new com.perimeterx.msdk.a.c.e(arrh);
            }
            e2.a();
            return;
        }
        new com.perimeterx.msdk.a.c.a(arrh).a();
    }

    static /* synthetic */ com.perimeterx.msdk.a.h[] a(JSONObject jSONObject) {
        return g.b(jSONObject);
    }

    static /* synthetic */ h b(g g2) {
        return g2.f;
    }

    private static com.perimeterx.msdk.a.h[] b(JSONObject jSONObject) {
        JSONArray jSONArray = jSONObject.getJSONArray("do");
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < jSONArray.length(); ++i2) {
            Object object;
            h.a a2;
            Object[] arrobject = jSONArray.getString(i2).split("\\|", -1);
            String string2 = arrobject[0];
            String[] arrstring = (String[])Arrays.copyOfRange((Object[])arrobject, (int)1, (int)arrobject.length);
            try {
                a2 = h.a.a(string2);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                v.l().a((Exception)((Object)illegalArgumentException), false);
            }
            int n2 = com.perimeterx.msdk.a.f.a[a2.ordinal()];
            if (n2 != 1) {
                if (n2 != 2) {
                    if (n2 != 3) {
                        object = n2 != 4 ? null : new e(arrstring);
                    } else {
                        object = new c(arrstring);
                        if (object.b() == 1L) {
                            continue;
                        }
                    }
                } else {
                    object = new f(arrstring);
                }
            } else {
                object = new b(arrstring);
            }
            arrayList.add(object);
            continue;
        }
        Object[] arrobject = new com.perimeterx.msdk.a.h[arrayList.size()];
        arrayList.toArray(arrobject);
        return arrobject;
    }

    public String a() {
        return this.c;
    }

    void a(com.perimeterx.msdk.a.c c2) {
        this.a(c2, new com.perimeterx.msdk.a.d(this));
    }

    public void a(w w2) {
        if (w2 != null) {
            this.b = w2;
            this.f.a(this.b);
        }
    }

    public void a(String string2) {
        this.c = string2;
    }

    public void b(com.perimeterx.msdk.a.c c2) {
        this.a(c2);
    }

    public void b(String string2) {
        this.d = string2;
    }

    public void c(String string2) {
        this.e = string2;
        this.f.a(string2);
        d d2 = this.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("New VID is: ");
        stringBuilder.append(string2);
        d2.a(3, stringBuilder.toString());
    }

    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a();
        public static final /* enum */ a b = new a();
        public static final /* enum */ a c = new a();
        private static final /* synthetic */ a[] d;

        static {
            a[] arra = new a[]{a, b, c};
            d = arra;
        }

        public static a a(String string2) {
            try {
                a a2 = a.valueOf(string2);
                return a2;
            }
            catch (Exception exception) {
                return a;
            }
        }

        public static a valueOf(String string2) {
            return (a)Enum.valueOf(a.class, (String)string2);
        }

        public static a[] values() {
            return (a[])d.clone();
        }
    }

}

