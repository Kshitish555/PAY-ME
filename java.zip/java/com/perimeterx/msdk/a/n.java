/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package com.perimeterx.msdk.a;

import com.perimeterx.msdk.a.c;
import com.perimeterx.msdk.a.h;
import java.io.IOException;

interface n {
    public void a(IOException var1);

    public void a(IOException var1, c var2);

    public void a(h[] var1);

    public void b(IOException var1, c var2);
}

