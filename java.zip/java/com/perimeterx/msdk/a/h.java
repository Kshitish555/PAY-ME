/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package com.perimeterx.msdk.a;

public interface h {
    public void execute();

    public a type();

    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a("appc");
        public static final /* enum */ a b = new a("sid");
        public static final /* enum */ a c = new a("vid");
        public static final /* enum */ a d = new a("bake");
        private static final /* synthetic */ a[] e;
        private String f;

        static {
            a[] arra = new a[]{a, b, c, d};
            e = arra;
        }

        private a(String string3) {
            this.f = string3;
        }

        public static a a(String string2) {
            IllegalArgumentException illegalArgumentException;
            for (a a2 : a.values()) {
                if (!a2.f.equalsIgnoreCase(string2)) continue;
                return a2;
            }
            illegalArgumentException = new IllegalArgumentException(String.format((String)"No constant with text %s found", (Object[])new Object[]{string2}));
            throw illegalArgumentException;
        }

        public static a valueOf(String string2) {
            return (a)Enum.valueOf(a.class, (String)string2);
        }

        public static a[] values() {
            return (a[])e.clone();
        }
    }

}

