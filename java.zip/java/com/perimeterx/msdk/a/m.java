/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.perimeterx.msdk.a;

public class m {
    public static String A = "PX336";
    public static String B = "PX337";
    public static String C = "PX339";
    public static String D = "PX340";
    public static String E = "PX341";
    public static String F = "PX342";
    public static String G = "PX343";
    public static String H = "PX344";
    public static String I = "PX345";
    public static String J = "PX347";
    public static String K = "PX348";
    public static String L = "PX349";
    public static String M = "PX350";
    public static String N = "PX351";
    public static String O = "PX413";
    public static String P = "PX414";
    public static String Q = "PX415";
    public static String R = "PX416";
    public static String S = "PX419";
    public static String T = "PX418";
    public static String U = "PX420";
    public static String V = "PX421";
    public static String W = "PX442";
    public static String a = "22";
    public static String b = "PX91";
    public static String c = "PX92";
    public static String d = "PX204";
    public static String e = "PX256";
    public static String f = "PX257";
    public static String g = "PX259";
    public static String h = "PX315";
    public static String i = "PX316";
    public static String j = "PX317";
    public static String k = "PX318";
    public static String l = "PX319";
    public static String m = "PX320";
    public static String n = "PX322";
    public static String o = "PX323";
    public static String p = "PX325";
    public static String q = "PX326";
    public static String r = "PX327";
    public static String s = "PX328";
    public static String t = "PX329";
    public static String u = "PX330";
    public static String v = "PX331";
    public static String w = "PX332";
    public static String x = "PX333";
    public static String y = "PX334";
    public static String z = "PX335";
}

