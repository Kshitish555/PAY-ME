/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.perimeterx.msdk.a.d;

public class d {
    private final String a;

    private d(String string2) {
        this.a = string2;
    }

    public static d a(String string2) {
        return new d(string2);
    }

    public d a(int n2, String string2) {
        return this;
    }

    public void a(int n2, Exception exception) {
    }
}

