/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.perimeterx.msdk.a.d;

import android.content.Context;
import android.content.SharedPreferences;
import com.perimeterx.msdk.a.g;
import com.perimeterx.msdk.a.w;
import org.json.JSONObject;

public class h {
    private static h a;
    private SharedPreferences b;

    private h() {
    }

    public static h a(Context context) {
        if (a == null) {
            a = new h();
            h.a.b = context.getSharedPreferences("PXStorage", 0);
        }
        return a;
    }

    public long a() {
        return this.b.getLong("APP_IS_ACTIVE_TIME_INTERVAL", 0L);
    }

    public void a(int n2) {
        SharedPreferences.Editor editor = this.b.edit();
        editor.putInt("RESUME_COUNTER", n2);
        editor.apply();
    }

    public void a(long l2) {
        SharedPreferences.Editor editor = this.b.edit();
        editor.putLong("APP_IS_ACTIVE_TIME_INTERVAL", l2);
        editor.apply();
    }

    public void a(g.a a2) {
        SharedPreferences.Editor editor = this.b.edit();
        editor.putString("LAST_COLLECTOR_RESPONSE_STATUS_PREF", a2.toString());
        editor.apply();
    }

    public void a(w w2) {
        SharedPreferences.Editor editor = this.b.edit();
        editor.putString("risk_token", w2.b());
        editor.apply();
    }

    public void a(String string2) {
        SharedPreferences.Editor editor = this.b.edit();
        editor.putString("vid", string2);
        editor.apply();
    }

    public void a(boolean bl) {
        SharedPreferences.Editor editor = this.b.edit();
        editor.putBoolean("captcha_success", bl);
        editor.apply();
    }

    public String b() {
        return this.b.getString("bypass_error", null);
    }

    public void b(String string2) {
        SharedPreferences.Editor editor = this.b.edit();
        editor.putString("bypass_error", string2);
        editor.apply();
    }

    public void b(boolean bl) {
        SharedPreferences.Editor editor = this.b.edit();
        editor.putBoolean("SDK_ENABLED", bl);
        editor.apply();
    }

    public boolean c() {
        return this.b.getBoolean("captcha_success", false);
    }

    public g.a d() {
        return g.a.a(this.b.getString("LAST_COLLECTOR_RESPONSE_STATUS_PREF", g.a.a.toString()));
    }

    public int e() {
        return this.b.getInt("RESUME_COUNTER", 0);
    }

    public w f() {
        String string2 = this.b.getString("risk_token", null);
        try {
            w w2 = w.a(new JSONObject(string2));
            return w2;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public String g() {
        return this.b.getString("vid", null);
    }

    public boolean h() {
        return this.b.getBoolean("SDK_ENABLED", true);
    }
}

