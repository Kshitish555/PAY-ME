/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Random
 *  java.util.concurrent.atomic.AtomicLong
 */
package com.perimeterx.msdk.a.d.a;

import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

public final class b {
    private static AtomicLong a = new AtomicLong(Long.MIN_VALUE);
    private static String b = null;
    private static long c = Long.MIN_VALUE;

    static {
        Random random = new Random();
        String string2 = b;
        if (string2 != null) {
            c |= Long.parseLong((String)string2, (int)16);
        } else {
            byte[] arrby = b.b();
            c |= 0xFF000000L & (long)(arrby[0] << 24);
            c |= (long)(16711680 & arrby[1] << 16);
            c |= (long)(65280 & arrby[2] << 8);
            c |= (long)(255 & arrby[3]);
        }
        c |= (long)(16383.0 * random.nextDouble()) << 48;
    }

    static long a() {
        return c;
    }

    private static byte[] b() {
        byte[] arrby = new byte[4];
        new Random().nextBytes(arrby);
        return arrby;
    }
}

