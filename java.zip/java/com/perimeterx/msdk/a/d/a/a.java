/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.System
 *  java.util.UUID
 */
package com.perimeterx.msdk.a.d.a;

import com.perimeterx.msdk.a.d.a.b;
import java.util.UUID;

public final class a {
    private static long a = Long.MIN_VALUE;

    public static UUID a() {
        return a.a(System.currentTimeMillis());
    }

    private static UUID a(long l2) {
        return new UUID(a.d(a.b(a.c(l2))), b.a());
    }

    private static long b(long l2) {
        Class<a> class_ = a.class;
        synchronized (a.class) {
            long l3;
            block5 : {
                l3 = a;
                if (l2 <= l3) break block5;
                a = l2;
                // ** MonitorExit[var7_1] (shouldn't be in output)
                return l2;
            }
            long l4 = l3 + 1L;
            a = l4;
            // ** MonitorExit[var7_1] (shouldn't be in output)
            return l4;
        }
    }

    private static long c(long l2) {
        return 122192928000000000L + l2 * 10000L;
    }

    private static long d(long l2) {
        return 4096L | l2 << 32 | (0xFFFF00000000L & l2) >>> 16 | (l2 & -281474976710656L) >>> 48;
    }
}

