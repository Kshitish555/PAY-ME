/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.net.InetAddress
 *  java.net.Socket
 *  java.security.GeneralSecurityException
 *  java.security.KeyStore
 *  java.security.SecureRandom
 *  java.util.Arrays
 *  javax.net.ssl.KeyManager
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSocket
 *  javax.net.ssl.SSLSocketFactory
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.TrustManagerFactory
 *  javax.net.ssl.X509TrustManager
 */
package com.perimeterx.msdk.a.d;

import java.net.InetAddress;
import java.net.Socket;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

public class i
extends SSLSocketFactory {
    private SSLSocketFactory a;

    public i() {
        SSLContext sSLContext = SSLContext.getInstance((String)"TLS");
        TrustManager[] arrtrustManager = new TrustManager[]{this.a()};
        sSLContext.init(null, arrtrustManager, null);
        this.a = sSLContext.getSocketFactory();
    }

    private Socket a(Socket socket) {
        if (socket != null && socket instanceof SSLSocket) {
            ((SSLSocket)socket).setEnabledProtocols(new String[]{"TLSv1.1", "TLSv1.2"});
        }
        return socket;
    }

    public X509TrustManager a() {
        try {
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance((String)TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init(null);
            Object[] arrobject = trustManagerFactory.getTrustManagers();
            if (arrobject.length == 1 && arrobject[0] instanceof X509TrustManager) {
                return (X509TrustManager)arrobject[0];
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unexpected default trust managers:");
            stringBuilder.append(Arrays.toString((Object[])arrobject));
            throw new IllegalStateException(stringBuilder.toString());
        }
        catch (GeneralSecurityException generalSecurityException) {
            throw new AssertionError();
        }
    }

    public Socket createSocket(String string2, int n2) {
        return this.a(this.a.createSocket(string2, n2));
    }

    public Socket createSocket(String string2, int n2, InetAddress inetAddress, int n3) {
        return this.a(this.a.createSocket(string2, n2, inetAddress, n3));
    }

    public Socket createSocket(InetAddress inetAddress, int n2) {
        return this.a(this.a.createSocket(inetAddress, n2));
    }

    public Socket createSocket(InetAddress inetAddress, int n2, InetAddress inetAddress2, int n3) {
        return this.a(this.a.createSocket(inetAddress, n2, inetAddress2, n3));
    }

    public Socket createSocket(Socket socket, String string2, int n2, boolean bl) {
        return this.a(this.a.createSocket(socket, string2, n2, bl));
    }

    public String[] getDefaultCipherSuites() {
        return this.a.getDefaultCipherSuites();
    }

    public String[] getSupportedCipherSuites() {
        return this.a.getSupportedCipherSuites();
    }
}

