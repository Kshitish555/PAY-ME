/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.UnsupportedEncodingException
 *  java.lang.Object
 *  java.lang.String
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 */
package com.perimeterx.msdk.a.d;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class a {
    protected static final char[] a = "0123456789ABCDEF".toCharArray();

    public static String a(String string2) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance((String)"SHA-1");
            byte[] arrby = string2.getBytes("UTF-8");
            messageDigest.update(arrby, 0, arrby.length);
            String string3 = a.a(messageDigest.digest());
            return string3;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            noSuchAlgorithmException.printStackTrace();
        }
        return null;
    }

    public static String a(byte[] arrby) {
        char[] arrc = new char[2 * arrby.length];
        for (int i2 = 0; i2 < arrby.length; ++i2) {
            int n2 = 255 & arrby[i2];
            int n3 = i2 * 2;
            char[] arrc2 = a;
            arrc[n3] = arrc2[n2 >>> 4];
            arrc[n3 + 1] = arrc2[n2 & 15];
        }
        return new String(arrc);
    }
}

