/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 *  java.util.concurrent.CopyOnWriteArrayList
 */
package com.perimeterx.msdk.a.d;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import com.perimeterx.msdk.a.d.b;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class c
implements Application.ActivityLifecycleCallbacks {
    private static c a;
    private boolean b = false;
    private boolean c = true;
    private Handler d = new Handler();
    private List<a> e = new CopyOnWriteArrayList();
    private Runnable f;

    public static c a() {
        c c2 = a;
        if (c2 != null) {
            return c2;
        }
        throw new IllegalStateException("Foreground is not initialised - invoke at least once with parameterised init/get");
    }

    public static c a(Application application) {
        if (a == null) {
            a = new c();
            application.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)a);
        }
        return a;
    }

    public static c a(Context context) {
        if (a == null) {
            Context context2 = context.getApplicationContext();
            if (context2 instanceof Application) {
                c c2 = a = c.a((Application)context2);
                c2.b = true;
                c2.c = false;
            } else {
                throw new IllegalStateException("Foreground is not initialised and cannot obtain the Application object");
            }
        }
        return a;
    }

    static /* synthetic */ boolean a(c c2) {
        return c2.b;
    }

    static /* synthetic */ boolean a(c c2, boolean bl) {
        c2.b = bl;
        return bl;
    }

    static /* synthetic */ boolean b(c c2) {
        return c2.c;
    }

    static /* synthetic */ List c(c c2) {
        return c2.e;
    }

    public void a(a a2) {
        Log.i((String)"Foreground", (String)"addListener");
        this.e.add((Object)a2);
    }

    public void b(a a2) {
        this.e.remove((Object)a2);
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
        Log.i((String)"Foreground", (String)"onActivityPaused");
        this.c = true;
        Runnable runnable = this.f;
        if (runnable != null) {
            this.d.removeCallbacks(runnable);
        }
        Handler handler = this.d;
        b b2 = new b(this);
        this.f = b2;
        handler.postDelayed((Runnable)b2, 500L);
    }

    public void onActivityResumed(Activity activity) {
        Log.i((String)"Foreground", (String)"onActivityResumed");
        this.c = false;
        boolean bl = true ^ this.b;
        this.b = true;
        Runnable runnable = this.f;
        if (runnable != null) {
            this.d.removeCallbacks(runnable);
        }
        if (bl) {
            Log.i((String)"Foreground", (String)"went foreground");
            for (a a2 : this.e) {
                try {
                    a2.b();
                }
                catch (Exception exception) {
                    Log.e((String)"Foreground", (String)"Listener threw exception!", (Throwable)exception);
                }
            }
        } else {
            Log.i((String)"Foreground", (String)"still foreground");
        }
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivityStopped(Activity activity) {
    }

    public static interface a {
        public void a();

        public void b();
    }

}

