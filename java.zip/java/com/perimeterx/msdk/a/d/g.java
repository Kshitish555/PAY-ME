/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  okhttp3.Call
 *  okhttp3.Callback
 *  org.json.JSONObject
 */
package com.perimeterx.msdk.a.d;

import com.perimeterx.msdk.a.d.d;
import com.perimeterx.msdk.a.d.f;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import org.json.JSONObject;

public class g {
    private static final d a = d.a(g.class.getSimpleName());

    public static void a(Call call, a a2) {
        a.a(4, "OKHTTP call is starting...");
        call.enqueue((Callback)new f(a2));
    }

    public static interface a {
        public void a(IOException var1);

        public void a(JSONObject var1);

        public void b(IOException var1);

        public void onFailure(IOException var1);
    }

}

