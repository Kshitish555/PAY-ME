/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.telephony.TelephonyManager
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 */
package com.perimeterx.msdk.a.d;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

public class e {
    public static a a(Context context) {
        NetworkInfo networkInfo;
        try {
            networkInfo = e.c(context);
        }
        catch (SecurityException securityException) {
            return a.d;
        }
        if (networkInfo != null && networkInfo.isConnected()) {
            if (networkInfo.getType() == 0) {
                return a.b;
            }
            if (networkInfo.getType() == 1) {
                return a.a;
            }
            return a.c;
        }
        return a.c;
    }

    public static String b(Context context) {
        switch (((TelephonyManager)context.getSystemService("phone")).getNetworkType()) {
            default: {
                return "Unknown";
            }
            case 13: {
                return "4G";
            }
            case 3: 
            case 5: 
            case 6: 
            case 8: 
            case 9: 
            case 10: 
            case 12: 
            case 14: 
            case 15: {
                return "3G";
            }
            case 1: 
            case 2: 
            case 4: 
            case 7: 
            case 11: 
        }
        return "2G";
    }

    public static NetworkInfo c(Context context) {
        return ((ConnectivityManager)context.getSystemService("connectivity")).getActiveNetworkInfo();
    }

    public static String d(Context context) {
        return ((TelephonyManager)context.getSystemService("phone")).getNetworkOperatorName();
    }

    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a("wifi");
        public static final /* enum */ a b = new a("mobile");
        public static final /* enum */ a c = new a("disconnected");
        public static final /* enum */ a d = new a("permission denied");
        private static final /* synthetic */ a[] e;
        private String f;

        static {
            a[] arra = new a[]{a, b, c, d};
            e = arra;
        }

        private a(String string3) {
            this.f = string3;
        }

        public static a valueOf(String string2) {
            return (a)Enum.valueOf(a.class, (String)string2);
        }

        public static a[] values() {
            return (a[])e.clone();
        }

        public String a() {
            return this.f;
        }
    }

}

