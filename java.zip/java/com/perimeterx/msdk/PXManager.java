/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.perimeterx.msdk;

import android.content.Context;
import com.perimeterx.msdk.ActionResultCallback;
import com.perimeterx.msdk.BackButtonPressedCallBack;
import com.perimeterx.msdk.ManagerReadyCallback;
import com.perimeterx.msdk.NewHeadersCallback;
import com.perimeterx.msdk.PXResponse;
import com.perimeterx.msdk.a.v;
import java.util.HashMap;
import java.util.Map;

public class PXManager {
    private static PXManager a;

    protected PXManager() {
    }

    public static PXResponse checkError(String string2) {
        v.l();
        return v.a(string2);
    }

    public static PXResponse checkError(byte[] arrby) {
        return PXManager.checkError(new String(arrby));
    }

    public static PXManager getInstance() {
        if (a == null) {
            a = new PXManager();
        }
        return a;
    }

    public static void handleResponse(PXResponse pXResponse, ActionResultCallback actionResultCallback) {
        v.l();
        v.a(pXResponse, actionResultCallback);
    }

    public static HashMap<String, String> httpHeaders() {
        return v.l().k();
    }

    public static void refreshToken() {
        try {
            v.l().c();
            return;
        }
        catch (Exception exception) {
            v.l().a(exception);
            return;
        }
    }

    public PXManager forceBlock() {
        v.l().a();
        return this;
    }

    public PXManager forceCaptcha() {
        v.l().b();
        return this;
    }

    public String getVid() {
        return v.l().r();
    }

    public PXManager setBackButtonDisabled(Boolean bl) {
        v.l().a(bl);
        return this;
    }

    public PXManager setBackButtonPressedCallback(BackButtonPressedCallBack backButtonPressedCallBack) {
        v.l().a(backButtonPressedCallBack);
        return this;
    }

    public PXManager setChallengeLocale(String string2) {
        v.l().b(string2);
        return this;
    }

    public PXManager setCustomParameters(Map<String, String> map) {
        v.l().a(map);
        return this;
    }

    @Deprecated
    public PXManager setCustomParameters(String[] arrstring) {
        v.l().a(arrstring);
        return this;
    }

    public PXManager setIsCutoutFullScreen(Boolean bl) {
        v.l().b(bl);
        return this;
    }

    public PXManager setManagerReadyCallback(ManagerReadyCallback managerReadyCallback) {
        v.l().a(managerReadyCallback);
        return this;
    }

    public PXManager setMaxRetryCount(int n2) {
        v.l().a(n2);
        return this;
    }

    public PXManager setNewHeadersCallback(NewHeadersCallback newHeadersCallback) {
        v.l().a(newHeadersCallback);
        return this;
    }

    public PXManager setTimeoutInterval(int n2) {
        v.l().b(n2);
        return this;
    }

    public PXManager setTimerValue(int n2) {
        v.l().c(n2);
        return this;
    }

    public void start(Context context, String string2) {
        try {
            v.l().a(context, string2);
            return;
        }
        catch (RuntimeException runtimeException) {
            v.l().a((Exception)((Object)runtimeException));
            return;
        }
    }
}

