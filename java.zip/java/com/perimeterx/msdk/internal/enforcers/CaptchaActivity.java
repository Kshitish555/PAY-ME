/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  java.io.Serializable
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package com.perimeterx.msdk.internal.enforcers;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.perimeterx.msdk.a.l;
import com.perimeterx.msdk.a.v;
import com.perimeterx.msdk.internal.enforcers.d;
import java.io.Serializable;

public class CaptchaActivity
extends com.perimeterx.msdk.internal.enforcers.a {
    private final com.perimeterx.msdk.a.d.d b = com.perimeterx.msdk.a.d.d.a(CaptchaActivity.class.getSimpleName());

    static /* synthetic */ com.perimeterx.msdk.a.d.d a(CaptchaActivity captchaActivity) {
        return captchaActivity.b;
    }

    static void a(l l2) {
        com.perimeterx.msdk.internal.enforcers.a.a(l2, CaptchaActivity.class);
    }

    private void a(a a2, String string2) {
        Intent intent = new Intent("com.perimeterx.msdk.internal.action.CAPTCHA_RESULT").putExtra("webViewResult", (Serializable)a2).putExtra("webViewError", string2);
        LocalBroadcastManager.getInstance((Context)this).sendBroadcast(intent);
        this.finish();
    }

    static /* synthetic */ void a(CaptchaActivity captchaActivity, a a2, String string2) {
        captchaActivity.a(a2, string2);
    }

    private void b() {
        this.a.setWebViewClient((WebViewClient)new d(this));
    }

    @Override
    protected void onCreate(Bundle bundle) {
        try {
            super.onCreate(bundle);
            this.b();
            return;
        }
        catch (Exception exception) {
            v.l().a(exception);
            this.finish();
            return;
        }
    }

    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a("-1");
        public static final /* enum */ a b = new a("0");
        public static final /* enum */ a c = new a("1");
        public static final /* enum */ a d = new a("2");
        public static final /* enum */ a e = new a("3");
        private static final /* synthetic */ a[] f;
        private String g;

        static {
            a[] arra = new a[]{a, b, c, d, e};
            f = arra;
        }

        private a(String string3) {
            this.g = string3;
        }

        public static a a(String string2) {
            IllegalArgumentException illegalArgumentException;
            for (a a2 : a.values()) {
                if (!a2.g.equalsIgnoreCase(string2)) continue;
                return a2;
            }
            illegalArgumentException = new IllegalArgumentException(String.format((String)"No constant with text %s found", (Object[])new Object[]{string2}));
            throw illegalArgumentException;
        }

        public static a valueOf(String string2) {
            return (a)Enum.valueOf(a.class, (String)string2);
        }

        public static a[] values() {
            return (a[])f.clone();
        }
    }

}

