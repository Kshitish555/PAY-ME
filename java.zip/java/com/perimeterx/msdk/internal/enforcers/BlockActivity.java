/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  java.lang.Exception
 */
package com.perimeterx.msdk.internal.enforcers;

import android.os.Bundle;
import android.view.KeyEvent;
import com.perimeterx.msdk.a.l;
import com.perimeterx.msdk.a.v;
import com.perimeterx.msdk.internal.enforcers.a;

public class BlockActivity
extends a {
    public static void a(l l2) {
        a.a(l2, BlockActivity.class);
    }

    @Override
    protected void onCreate(Bundle bundle) {
        try {
            super.onCreate(bundle);
            return;
        }
        catch (Exception exception) {
            v.l().a(exception);
            return;
        }
    }
}

