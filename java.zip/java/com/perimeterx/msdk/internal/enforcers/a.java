/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.util.Base64
 *  android.view.KeyEvent
 *  android.view.View
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.perimeterx.msdk.internal.enforcers;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.perimeterx.msdk.BackButtonPressedCallBack;
import com.perimeterx.msdk.a.l;
import com.perimeterx.msdk.a.v;
import com.perimeterx.msdk.a.x;

class a
extends Activity {
    protected WebView a;

    a() {
    }

    private void a() {
        this.getWindow().getDecorView().setSystemUiVisibility(1024);
    }

    public static void a(l l2, Class<?> class_) {
        Context context = v.l().i();
        Intent intent = new Intent(context, class_);
        intent.setFlags(268435456);
        intent.putExtra("enforcerResponse", (Parcelable)l2);
        context.startActivity(intent);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        l l2 = (l)this.getIntent().getParcelableExtra("enforcerResponse");
        if (Build.VERSION.SDK_INT >= 28 && v.l().m().booleanValue()) {
            this.getWindow().getAttributes().layoutInDisplayCutoutMode = 1;
        }
        this.a = new WebView(this.getBaseContext());
        WebSettings webSettings = this.a.getSettings();
        webSettings.setUserAgentString(x.b());
        webSettings.setJavaScriptEnabled(true);
        String string2 = new String(Base64.decode((String)l2.b(), (int)0));
        this.setContentView((View)this.a);
        String string3 = v.l().g();
        if (!string3.isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("<script>window._pxSelectedLocale='");
            stringBuilder.append(string3);
            stringBuilder.append("'</script></head>");
            string2 = string2.replaceFirst("</head>", stringBuilder.toString());
        }
        String string4 = string2;
        this.a.loadDataWithBaseURL("https://www.perimeterx.com", string4, "text/html", "UTF-8", "");
    }

    public boolean onKeyDown(int n2, KeyEvent keyEvent) {
        if (n2 == 4) {
            if (v.l().s().booleanValue()) {
                return true;
            }
            if (v.l().f() != null) {
                v.l().f().onBackButtonPressed();
            }
        }
        return super.onKeyDown(n2, keyEvent);
    }

    protected void onStop() {
        try {
            LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance((Context)this);
            localBroadcastManager.sendBroadcast(new Intent("com.perimeterx.msdk.internal.action.ENFORCE_FINISH"));
        }
        catch (Exception exception) {
            v.l().a(exception);
        }
        super.onStop();
    }

    public void onWindowFocusChanged(boolean bl) {
        super.onWindowFocusChanged(bl);
        if (Build.VERSION.SDK_INT >= 28 && v.l().m().booleanValue() && bl) {
            this.a();
        }
    }
}

