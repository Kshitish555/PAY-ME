/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package com.perimeterx.msdk.internal.enforcers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.perimeterx.msdk.ActionResultCallback;
import com.perimeterx.msdk.PXResponse;
import com.perimeterx.msdk.a.l;
import com.perimeterx.msdk.a.v;
import com.perimeterx.msdk.internal.enforcers.b;
import java.util.concurrent.atomic.AtomicBoolean;

abstract class c
implements PXResponse {
    private static final AtomicBoolean a = new AtomicBoolean(false);
    protected final l b;

    c(l l2) {
        this.b = l2;
    }

    protected boolean a() {
        return a.compareAndSet(false, true);
    }

    protected void b() {
        a.set(false);
    }

    @Override
    public void enforce(ActionResultCallback actionResultCallback) {
        v.l().i().registerReceiver((BroadcastReceiver)new b(this, this), new IntentFilter("com.perimeterx.msdk.internal.action.ENFORCE_FINISH"));
    }

    @Override
    public l response() {
        return this.b;
    }
}

