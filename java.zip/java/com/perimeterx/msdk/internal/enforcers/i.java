/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.perimeterx.msdk.internal.enforcers;

import com.perimeterx.msdk.ActionResultCallback;
import com.perimeterx.msdk.PXResponse;
import com.perimeterx.msdk.a.l;

public class i
implements PXResponse {
    @Override
    public void enforce(ActionResultCallback actionResultCallback) {
        actionResultCallback.onSuccess();
    }

    @Override
    public PXResponse.EnforcementType enforcement() {
        return PXResponse.EnforcementType.NOT_PX_BLOCK;
    }

    @Override
    public l response() {
        return null;
    }
}

