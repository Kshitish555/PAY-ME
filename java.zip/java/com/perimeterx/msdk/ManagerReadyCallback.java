/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 */
package com.perimeterx.msdk;

import java.util.HashMap;

public interface ManagerReadyCallback {
    public void onManagerReady(HashMap<String, String> var1);
}

