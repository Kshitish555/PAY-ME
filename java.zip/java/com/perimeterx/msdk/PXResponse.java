/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.perimeterx.msdk;

import com.perimeterx.msdk.ActionResultCallback;
import com.perimeterx.msdk.a.l;

public interface PXResponse {
    public void enforce(ActionResultCallback var1);

    public EnforcementType enforcement();

    public l response();

    public static final class EnforcementType
    extends Enum<EnforcementType> {
        private static final /* synthetic */ EnforcementType[] $VALUES;
        public static final /* enum */ EnforcementType BLOCK = new EnforcementType();
        public static final /* enum */ EnforcementType CAPTCHA = new EnforcementType();
        public static final /* enum */ EnforcementType NOT_PX_BLOCK = new EnforcementType();

        static {
            EnforcementType[] arrenforcementType = new EnforcementType[]{BLOCK, CAPTCHA, NOT_PX_BLOCK};
            $VALUES = arrenforcementType;
        }

        public static EnforcementType valueOf(String string2) {
            return (EnforcementType)Enum.valueOf(EnforcementType.class, (String)string2);
        }

        public static EnforcementType[] values() {
            return (EnforcementType[])$VALUES.clone();
        }
    }

}

