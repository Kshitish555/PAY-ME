/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Deprecated
 *  java.lang.Object
 */
package com.perimeterx.msdk;

import java.io.IOException;

public interface ActionResultCallback {
    public void onBlockWindowClosed();

    @Deprecated
    public void onFailure(IOException var1);

    public void onSuccess();
}

