/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Calendar
 *  java.util.TimeZone
 */
package com.henninghall.date_picker;

import com.henninghall.date_picker.Utils;
import java.util.Calendar;
import java.util.TimeZone;

public class DateBoundary {
    private Calendar date;

    DateBoundary(TimeZone timeZone, String string2) {
        if (string2 == null) {
            return;
        }
        this.date = Utils.getTruncatedCalendarOrNull(Utils.isoToCalendar(string2, timeZone));
    }

    protected Calendar get() {
        return this.date;
    }
}

