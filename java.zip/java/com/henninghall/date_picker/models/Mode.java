/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.henninghall.date_picker.models;

public final class Mode
extends Enum<Mode> {
    private static final /* synthetic */ Mode[] $VALUES;
    public static final /* enum */ Mode date = new Mode();
    public static final /* enum */ Mode datetime;
    public static final /* enum */ Mode time;

    static {
        time = new Mode();
        datetime = new Mode();
        Mode[] arrmode = new Mode[]{date, time, datetime};
        $VALUES = arrmode;
    }

    public static Mode valueOf(String string2) {
        return (Mode)Enum.valueOf(Mode.class, (String)string2);
    }

    public static Mode[] values() {
        return (Mode[])$VALUES.clone();
    }
}

