/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.henninghall.date_picker.models;

public final class WheelType
extends Enum<WheelType> {
    private static final /* synthetic */ WheelType[] $VALUES;
    public static final /* enum */ WheelType AM_PM;
    public static final /* enum */ WheelType DATE;
    public static final /* enum */ WheelType DAY;
    public static final /* enum */ WheelType HOUR;
    public static final /* enum */ WheelType MINUTE;
    public static final /* enum */ WheelType MONTH;
    public static final /* enum */ WheelType YEAR;

    static {
        DAY = new WheelType();
        DATE = new WheelType();
        MONTH = new WheelType();
        YEAR = new WheelType();
        HOUR = new WheelType();
        MINUTE = new WheelType();
        AM_PM = new WheelType();
        WheelType[] arrwheelType = new WheelType[]{DAY, DATE, MONTH, YEAR, HOUR, MINUTE, AM_PM};
        $VALUES = arrwheelType;
    }

    public static WheelType valueOf(String string2) {
        return (WheelType)Enum.valueOf(WheelType.class, (String)string2);
    }

    public static WheelType[] values() {
        return (WheelType[])$VALUES.clone();
    }
}

