/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.uimanager.ThemedReactContext
 *  com.facebook.react.uimanager.events.RCTEventEmitter
 *  com.henninghall.date_picker.DatePickerManager
 *  com.henninghall.date_picker.State
 *  com.henninghall.date_picker.Utils
 *  com.henninghall.date_picker.ui.UIManager
 *  com.henninghall.date_picker.ui.WheelChangeListener
 *  com.henninghall.date_picker.ui.Wheels
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.TimeZone
 */
package com.henninghall.date_picker.ui;

import android.view.View;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.events.RCTEventEmitter;
import com.henninghall.date_picker.DatePickerManager;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.Utils;
import com.henninghall.date_picker.ui.UIManager;
import com.henninghall.date_picker.ui.WheelChangeListener;
import com.henninghall.date_picker.ui.Wheels;
import com.henninghall.date_picker.wheels.Wheel;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class WheelChangeListenerImpl
implements WheelChangeListener {
    private final View rootView;
    private final State state;
    private final UIManager uiManager;
    private final Wheels wheels;

    WheelChangeListenerImpl(Wheels wheels, State state, UIManager uIManager, View view) {
        this.wheels = wheels;
        this.uiManager = uIManager;
        this.state = state;
        this.rootView = view;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onChange(Wheel wheel) {
        WritableMap writableMap = Arguments.createMap();
        TimeZone timeZone = this.state.getTimeZone();
        SimpleDateFormat simpleDateFormat = this.uiManager.getDateFormat();
        Calendar calendar = this.state.getMinimumDate();
        Calendar calendar2 = this.state.getMaximumDate();
        try {
            simpleDateFormat.setTimeZone(timeZone);
            Calendar calendar3 = Calendar.getInstance((TimeZone)timeZone);
            calendar3.setTime(simpleDateFormat.parse(this.wheels.getDateString()));
            if (calendar != null && calendar3.before((Object)calendar)) {
                this.uiManager.animateToDate(calendar);
                return;
            }
            if (calendar2 != null && calendar3.after((Object)calendar2)) {
                this.uiManager.animateToDate(calendar2);
                return;
            }
            writableMap.putString("date", Utils.dateToIso((Calendar)calendar3));
            writableMap.putString("dateString", this.uiManager.getDateString());
            ((RCTEventEmitter)DatePickerManager.context.getJSModule(RCTEventEmitter.class)).receiveEvent(this.rootView.getId(), "dateChange", writableMap);
            return;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return;
        }
    }
}

