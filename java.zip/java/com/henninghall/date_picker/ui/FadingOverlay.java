/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.view.View
 *  android.widget.ImageView
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.henninghall.date_picker.ui;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.ImageView;
import com.henninghall.date_picker.R;
import com.henninghall.date_picker.State;

public class FadingOverlay {
    private final GradientDrawable gradientBottom;
    private final GradientDrawable gradientTop;
    private final State state;

    FadingOverlay(State state, View view) {
        this.state = state;
        ImageView imageView = (ImageView)view.findViewById(R.id.overlay_top);
        ImageView imageView2 = (ImageView)view.findViewById(R.id.overlay_bottom);
        this.gradientTop = (GradientDrawable)imageView.getDrawable();
        this.gradientBottom = (GradientDrawable)imageView2.getDrawable();
    }

    private boolean validColor(String string2) {
        return string2 != null && string2.length() == 7;
    }

    void updateColor() {
        String string2 = this.state.getFadeToColor();
        int n = this.validColor(string2) ? 255 : 0;
        this.gradientTop.setAlpha(n);
        this.gradientBottom.setAlpha(n);
        if (this.validColor(string2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("#FF");
            stringBuilder.append(string2.substring(1));
            int n2 = Color.parseColor((String)stringBuilder.toString());
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("#00");
            stringBuilder2.append(string2.substring(1));
            int n3 = Color.parseColor((String)stringBuilder2.toString());
            this.gradientTop.setColors(new int[]{n2, n3});
            this.gradientBottom.setColors(new int[]{n2, n3});
        }
    }
}

