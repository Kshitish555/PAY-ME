/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.henninghall.date_picker.ui;

import com.henninghall.date_picker.wheels.Wheel;

public interface WheelChangeListener {
    public void onChange(Wheel var1);
}

