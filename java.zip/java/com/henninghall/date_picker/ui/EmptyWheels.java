/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.henninghall.date_picker.ui;

import android.view.View;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.DerivedData;
import com.henninghall.date_picker.R;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.models.WheelType;
import com.henninghall.date_picker.ui.PickerWrapper;
import java.util.ArrayList;

class EmptyWheels {
    private int[] emptyWheelIds;
    private final PickerWrapper pickerWrapper;
    private View rootView;
    private State state;
    private final ArrayList<NumberPickerView> views;

    EmptyWheels(View view, PickerWrapper pickerWrapper, State state) {
        int[] arrn = new int[]{R.id.emptyStart, R.id.empty1, R.id.empty2, R.id.empty3, R.id.emptyEnd};
        this.emptyWheelIds = arrn;
        this.pickerWrapper = pickerWrapper;
        this.rootView = view;
        this.state = state;
        this.views = this.getAll();
    }

    private ArrayList<NumberPickerView> getAll() {
        ArrayList arrayList = new ArrayList();
        for (int n : this.emptyWheelIds) {
            arrayList.add((Object)((NumberPickerView)this.rootView.findViewById(n)));
        }
        return arrayList;
    }

    void add() {
        int n = 1 + this.state.derived.getVisibleWheels().size();
        for (int i = 0; i < n; ++i) {
            int n2 = i * 2;
            this.pickerWrapper.addPicker((View)this.views.get(i), n2);
        }
    }

    void setShownCount(int n) {
        for (int n2 : this.emptyWheelIds) {
            NumberPickerView numberPickerView = (NumberPickerView)this.rootView.findViewById(n2);
            if (numberPickerView == null) continue;
            numberPickerView.setShownCount(n);
        }
    }
}

