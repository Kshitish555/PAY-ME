/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.henninghall.date_picker.ui;

import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.wheels.Wheel;

public class WheelScroller {
    public void scroll(Wheel wheel, int n) {
        NumberPickerView numberPickerView = wheel.picker;
        int n2 = numberPickerView.getValue();
        int n3 = numberPickerView.getMaxValue();
        boolean bl = numberPickerView.getWrapSelectorWheel();
        int n4 = n2 + n;
        if (n4 <= n3 || bl) {
            numberPickerView.smoothScrollToValue(n4 % (n3 + 1));
        }
    }
}

