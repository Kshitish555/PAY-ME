/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.LinearLayout
 *  java.lang.Object
 */
package com.henninghall.date_picker.ui;

import android.view.View;
import android.widget.LinearLayout;
import com.henninghall.date_picker.R;

class PickerWrapper {
    private final LinearLayout view;

    PickerWrapper(View view) {
        this.view = (LinearLayout)view.findViewById(R.id.pickerWrapper);
        this.view.setWillNotDraw(false);
    }

    void addPicker(View view) {
        this.view.addView(view);
    }

    void addPicker(View view, int n) {
        this.view.addView(view, n);
    }

    void removeAll() {
        this.view.removeAllViews();
    }
}

