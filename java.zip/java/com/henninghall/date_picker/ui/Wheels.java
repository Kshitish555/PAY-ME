/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 */
package com.henninghall.date_picker.ui;

import android.view.View;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.DerivedData;
import com.henninghall.date_picker.R;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.models.Mode;
import com.henninghall.date_picker.models.WheelType;
import com.henninghall.date_picker.ui.EmptyWheels;
import com.henninghall.date_picker.ui.PickerWrapper;
import com.henninghall.date_picker.ui.Wheels;
import com.henninghall.date_picker.wheelFunctions.SetShowCount;
import com.henninghall.date_picker.wheelFunctions.WheelFunction;
import com.henninghall.date_picker.wheels.AmPmWheel;
import com.henninghall.date_picker.wheels.DateWheel;
import com.henninghall.date_picker.wheels.DayWheel;
import com.henninghall.date_picker.wheels.HourWheel;
import com.henninghall.date_picker.wheels.MinutesWheel;
import com.henninghall.date_picker.wheels.MonthWheel;
import com.henninghall.date_picker.wheels.Wheel;
import com.henninghall.date_picker.wheels.YearWheel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class Wheels {
    private AmPmWheel ampmWheel;
    private DateWheel dateWheel;
    private DayWheel dayWheel;
    private final EmptyWheels emptyWheels;
    private HourWheel hourWheel;
    private MinutesWheel minutesWheel;
    private MonthWheel monthWheel;
    private final PickerWrapper pickerWrapper;
    private View rootView;
    private final State state;
    private HashMap<WheelType, Wheel> wheelPerWheelType;
    private YearWheel yearWheel;

    Wheels(State state, View view) {
        this.state = state;
        this.rootView = view;
        this.pickerWrapper = new PickerWrapper(view);
        this.yearWheel = new YearWheel(this.getPickerWithId(R.id.year), state);
        this.monthWheel = new MonthWheel(this.getPickerWithId(R.id.month), state);
        this.dateWheel = new DateWheel(this.getPickerWithId(R.id.date), state);
        this.dayWheel = new DayWheel(this.getPickerWithId(R.id.day), state);
        this.minutesWheel = new MinutesWheel(this.getPickerWithId(R.id.minutes), state);
        this.ampmWheel = new AmPmWheel(this.getPickerWithId(R.id.ampm), state);
        this.hourWheel = new HourWheel(this.getPickerWithId(R.id.hour), state);
        this.wheelPerWheelType = this.getWheelPerType();
        this.emptyWheels = new EmptyWheels(view, this.pickerWrapper, state);
        this.changeAmPmWhenPassingMidnightOrNoon();
    }

    private void addEmpty() {
        this.emptyWheels.add();
    }

    private void addInOrder() {
        Iterator iterator = this.state.derived.getOrderedVisibleWheels().iterator();
        while (iterator.hasNext()) {
            Wheel wheel = this.getWheel((WheelType)((Object)iterator.next()));
            this.pickerWrapper.addPicker(wheel.picker);
        }
    }

    private void changeAmPmWhenPassingMidnightOrNoon() {
        this.hourWheel.picker.setOnValueChangeListenerInScrolling(new NumberPickerView.OnValueChangeListenerInScrolling(this){
            final /* synthetic */ Wheels this$0;
            {
                this.this$0 = wheels;
            }

            public void onValueChangeInScrolling(NumberPickerView numberPickerView, int n, int n2) {
                if (com.henninghall.date_picker.Utils.usesAmPm()) {
                    String string2 = Wheels.access$000(this.this$0).getValueAtIndex(n);
                    String string3 = Wheels.access$000(this.this$0).getValueAtIndex(n2);
                    boolean bl = string2.equals((Object)"12") && string3.equals((Object)"11") || string2.equals((Object)"11") && string3.equals((Object)"12");
                    if (bl) {
                        Wheels.access$100((Wheels)this.this$0).picker.smoothScrollToValue((1 + Wheels.access$100((Wheels)this.this$0).picker.getValue()) % 2, false);
                    }
                }
            }
        });
    }

    private List<Wheel> getAll() {
        Object[] arrobject = new Wheel[]{this.yearWheel, this.monthWheel, this.dateWheel, this.dayWheel, this.hourWheel, this.minutesWheel, this.ampmWheel};
        return new ArrayList((Collection)Arrays.asList((Object[])arrobject));
    }

    private String getDateFormatPattern() {
        ArrayList<Wheel> arrayList = this.getOrderedVisibleWheels();
        if (this.state.getMode() == Mode.date) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(((Wheel)arrayList.get(0)).getFormatPattern());
            stringBuilder.append(" ");
            stringBuilder.append(((Wheel)arrayList.get(1)).getFormatPattern());
            stringBuilder.append(" ");
            stringBuilder.append(((Wheel)arrayList.get(2)).getFormatPattern());
            return stringBuilder.toString();
        }
        return this.dayWheel.getFormatPattern();
    }

    private ArrayList<Wheel> getOrderedVisibleWheels() {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.state.derived.getOrderedVisibleWheels().iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)this.getWheel((WheelType)((Object)iterator.next())));
        }
        return arrayList;
    }

    private NumberPickerView getPickerWithId(int n) {
        return (NumberPickerView)this.rootView.findViewById(n);
    }

    private Collection<Wheel> getVisible() {
        ArrayList<WheelType> arrayList = this.state.derived.getVisibleWheels();
        ArrayList arrayList2 = new ArrayList();
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            arrayList2.add((Object)this.getWheel((WheelType)((Object)iterator.next())));
        }
        return arrayList2;
    }

    private HashMap<WheelType, Wheel> getWheelPerType() {
        return new HashMap<WheelType, Wheel>(){
            {
                this.put((Object)WheelType.DAY, (Object)Wheels.this.dayWheel);
                this.put((Object)WheelType.YEAR, (Object)Wheels.this.yearWheel);
                this.put((Object)WheelType.MONTH, (Object)Wheels.this.monthWheel);
                this.put((Object)WheelType.DATE, (Object)Wheels.this.dateWheel);
                this.put((Object)WheelType.HOUR, (Object)Wheels.this.hourWheel);
                this.put((Object)WheelType.MINUTE, (Object)Wheels.this.minutesWheel);
                this.put((Object)WheelType.AM_PM, (Object)Wheels.this.ampmWheel);
            }
        };
    }

    void applyOnAll(WheelFunction wheelFunction) {
        Iterator iterator = this.getAll().iterator();
        while (iterator.hasNext()) {
            wheelFunction.apply((Wheel)iterator.next());
        }
    }

    void applyOnVisible(WheelFunction wheelFunction) {
        Iterator iterator = this.getVisible().iterator();
        while (iterator.hasNext()) {
            wheelFunction.apply((Wheel)iterator.next());
        }
    }

    String getDateString() {
        String string2;
        ArrayList<Wheel> arrayList = this.getOrderedVisibleWheels();
        if (this.state.getMode() == Mode.date) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(((Wheel)arrayList.get(0)).getValue());
            stringBuilder.append(" ");
            stringBuilder.append(((Wheel)arrayList.get(1)).getValue());
            stringBuilder.append(" ");
            stringBuilder.append(((Wheel)arrayList.get(2)).getValue());
            string2 = stringBuilder.toString();
        } else {
            string2 = this.dayWheel.getValue();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(" ");
        stringBuilder.append(this.hourWheel.getValue());
        stringBuilder.append(" ");
        stringBuilder.append(this.minutesWheel.getValue());
        stringBuilder.append(this.ampmWheel.getValue());
        return stringBuilder.toString();
    }

    String getDisplayValue() {
        StringBuilder stringBuilder = new StringBuilder();
        Iterator iterator = this.getOrderedVisibleWheels().iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(((Wheel)iterator.next()).getDisplayValue());
        }
        return stringBuilder.toString();
    }

    public String getFormatPattern() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getDateFormatPattern());
        stringBuilder.append(" ");
        stringBuilder.append(this.hourWheel.getFormatPattern());
        stringBuilder.append(" ");
        stringBuilder.append(this.minutesWheel.getFormatPattern());
        stringBuilder.append(this.ampmWheel.getFormatPattern());
        return stringBuilder.toString();
    }

    Wheel getWheel(WheelType wheelType) {
        return (Wheel)this.wheelPerWheelType.get((Object)wheelType);
    }

    void updateHeight() {
        int n = this.state.derived.getShownCount();
        this.applyOnAll(new SetShowCount(n));
        this.emptyWheels.setShownCount(n);
    }

    void updateWheelOrder() {
        this.pickerWrapper.removeAll();
        this.addInOrder();
        this.addEmpty();
    }

}

