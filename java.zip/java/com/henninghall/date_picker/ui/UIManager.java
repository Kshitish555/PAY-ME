/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Locale
 */
package com.henninghall.date_picker.ui;

import android.view.View;
import com.henninghall.date_picker.DerivedData;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.models.WheelType;
import com.henninghall.date_picker.ui.FadingOverlay;
import com.henninghall.date_picker.ui.WheelChangeListener;
import com.henninghall.date_picker.ui.WheelChangeListenerImpl;
import com.henninghall.date_picker.ui.WheelScroller;
import com.henninghall.date_picker.ui.Wheels;
import com.henninghall.date_picker.wheelFunctions.AddOnChangeListener;
import com.henninghall.date_picker.wheelFunctions.AnimateToDate;
import com.henninghall.date_picker.wheelFunctions.Refresh;
import com.henninghall.date_picker.wheelFunctions.SetDate;
import com.henninghall.date_picker.wheelFunctions.TextColor;
import com.henninghall.date_picker.wheelFunctions.UpdateVisibility;
import com.henninghall.date_picker.wheelFunctions.WheelFunction;
import com.henninghall.date_picker.wheels.Wheel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class UIManager {
    private FadingOverlay fadingOverlay;
    private final View rootView;
    private final State state;
    private WheelScroller wheelScroller = new WheelScroller();
    private Wheels wheels;

    public UIManager(State state, View view) {
        this.state = state;
        this.rootView = view;
        this.wheels = new Wheels(state, view);
        this.fadingOverlay = new FadingOverlay(state, view);
        this.addOnChangeListener();
    }

    private void addOnChangeListener() {
        WheelChangeListenerImpl wheelChangeListenerImpl = new WheelChangeListenerImpl(this.wheels, this.state, this, this.rootView);
        this.wheels.applyOnAll(new AddOnChangeListener(wheelChangeListenerImpl));
    }

    void animateToDate(Calendar calendar) {
        this.wheels.applyOnVisible(new AnimateToDate(calendar));
    }

    SimpleDateFormat getDateFormat() {
        return new SimpleDateFormat(this.wheels.getFormatPattern(), this.state.getLocale());
    }

    String getDateString() {
        return this.wheels.getDisplayValue();
    }

    public void scroll(int n, int n2) {
        Wheel wheel = this.wheels.getWheel((WheelType)((Object)this.state.derived.getOrderedVisibleWheels().get(n)));
        this.wheelScroller.scroll(wheel, n2);
    }

    public void setWheelsToDate() {
        this.wheels.applyOnAll(new SetDate(this.state.getDate()));
    }

    public void updateDisplayValues() {
        this.wheels.applyOnAll(new Refresh());
    }

    public void updateFadeToColor() {
        this.fadingOverlay.updateColor();
    }

    public void updateHeight() {
        this.wheels.updateHeight();
    }

    public void updateTextColor() {
        this.wheels.applyOnAll(new TextColor(this.state.getTextColor()));
    }

    public void updateWheelOrder() {
        this.wheels.updateWheelOrder();
    }

    public void updateWheelVisibility() {
        this.wheels.applyOnAll(new UpdateVisibility());
    }
}

