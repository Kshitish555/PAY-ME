/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.Dynamic
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Calendar
 *  java.util.HashMap
 *  java.util.Locale
 *  java.util.TimeZone
 */
package com.henninghall.date_picker;

import com.facebook.react.bridge.Dynamic;
import com.henninghall.date_picker.DateBoundary;
import com.henninghall.date_picker.DerivedData;
import com.henninghall.date_picker.Utils;
import com.henninghall.date_picker.models.Mode;
import com.henninghall.date_picker.props.DateProp;
import com.henninghall.date_picker.props.FadeToColorProp;
import com.henninghall.date_picker.props.HeightProp;
import com.henninghall.date_picker.props.LocaleProp;
import com.henninghall.date_picker.props.MaximumDateProp;
import com.henninghall.date_picker.props.MinimumDateProp;
import com.henninghall.date_picker.props.MinuteIntervalProp;
import com.henninghall.date_picker.props.ModeProp;
import com.henninghall.date_picker.props.Prop;
import com.henninghall.date_picker.props.TextColorProp;
import com.henninghall.date_picker.props.UtcProp;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

public class State {
    private final DateProp dateProp = new DateProp();
    public DerivedData derived = new DerivedData(this);
    private final FadeToColorProp fadeToColorProp = new FadeToColorProp();
    private final HeightProp heightProp = new HeightProp();
    private final LocaleProp localeProp = new LocaleProp();
    private final MaximumDateProp maximumDateProp = new MaximumDateProp();
    private final MinimumDateProp minimumDateProp = new MinimumDateProp();
    private final MinuteIntervalProp minuteIntervalProp = new MinuteIntervalProp();
    private final Prop modeProp = new ModeProp();
    private final HashMap props = new HashMap<String, Prop>(){
        {
            this.put((Object)"date", (Object)State.this.dateProp);
            this.put((Object)"mode", (Object)State.this.modeProp);
            this.put((Object)"locale", (Object)State.this.localeProp);
            this.put((Object)"fadeToColor", (Object)State.this.fadeToColorProp);
            this.put((Object)"textColor", (Object)State.this.textColorProp);
            this.put((Object)"minuteInterval", (Object)State.this.minuteIntervalProp);
            this.put((Object)"minimumDate", (Object)State.this.minimumDateProp);
            this.put((Object)"maximumDate", (Object)State.this.maximumDateProp);
            this.put((Object)"utc", (Object)State.this.utcProp);
            this.put((Object)"height", (Object)State.this.heightProp);
        }
    };
    private final TextColorProp textColorProp = new TextColorProp();
    private final UtcProp utcProp = new UtcProp();

    private Prop getProp(String string2) {
        return (Prop)this.props.get((Object)string2);
    }

    public Calendar getDate() {
        return Utils.isoToCalendar((String)this.dateProp.getValue(), this.getTimeZone());
    }

    public String getFadeToColor() {
        return (String)this.fadeToColorProp.getValue();
    }

    public Integer getHeight() {
        return (Integer)this.heightProp.getValue();
    }

    public Locale getLocale() {
        return (Locale)this.localeProp.getValue();
    }

    public String getLocaleLanguageTag() {
        return this.localeProp.getLanguageTag();
    }

    public Calendar getMaximumDate() {
        return new DateBoundary(this.getTimeZone(), (String)this.maximumDateProp.getValue()).get();
    }

    public Calendar getMinimumDate() {
        return new DateBoundary(this.getTimeZone(), (String)this.minimumDateProp.getValue()).get();
    }

    public int getMinuteInterval() {
        return (Integer)this.minuteIntervalProp.getValue();
    }

    public Mode getMode() {
        return (Mode)((Object)this.modeProp.getValue());
    }

    public String getTextColor() {
        return (String)this.textColorProp.getValue();
    }

    public TimeZone getTimeZone() {
        if (((Boolean)this.utcProp.getValue()).booleanValue()) {
            return TimeZone.getTimeZone((String)"UTC");
        }
        return TimeZone.getDefault();
    }

    void setProp(String string2, Dynamic dynamic) {
        this.getProp(string2).setValue(dynamic);
    }

}

