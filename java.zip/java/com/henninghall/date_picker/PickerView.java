/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.widget.RelativeLayout
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.uimanager.ThemedReactContext
 *  com.henninghall.date_picker.DatePickerManager
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 */
package com.henninghall.date_picker;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.uimanager.ThemedReactContext;
import com.henninghall.date_picker.DatePickerManager;
import com.henninghall.date_picker.R;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.ui.UIManager;
import java.util.ArrayList;
import java.util.Collection;

public class PickerView
extends RelativeLayout {
    private final Runnable measureAndLayout = new Runnable(){

        public void run() {
            PickerView pickerView = PickerView.this;
            pickerView.measure(View.MeasureSpec.makeMeasureSpec((int)pickerView.getWidth(), (int)1073741824), View.MeasureSpec.makeMeasureSpec((int)PickerView.this.getHeight(), (int)1073741824));
            PickerView pickerView2 = PickerView.this;
            pickerView2.layout(pickerView2.getLeft(), PickerView.this.getTop(), PickerView.this.getRight(), PickerView.this.getBottom());
        }
    };
    private final View rootView = PickerView.inflate((Context)this.getContext(), (int)R.layout.datepicker_view, (ViewGroup)this);
    private State state = new State();
    private final UIManager uiManager = new UIManager(this.state, (View)this);
    private ArrayList<String> updatedProps = new ArrayList();

    public PickerView() {
        super((Context)DatePickerManager.context);
    }

    public View getRootView() {
        return this.rootView;
    }

    public void requestLayout() {
        super.requestLayout();
        this.post(this.measureAndLayout);
    }

    public void scroll(int n, int n2) {
        this.uiManager.scroll(n, n2);
    }

    public void update() {
        if (this.updatedProps.contains((Object)"fadeToColor")) {
            this.uiManager.updateFadeToColor();
        }
        if (this.updatedProps.contains((Object)"textColor")) {
            this.uiManager.updateTextColor();
        }
        if (this.updatedProps.contains((Object)"mode")) {
            this.uiManager.updateWheelVisibility();
        }
        if (this.updatedProps.contains((Object)"height")) {
            this.uiManager.updateHeight();
        }
        if (this.updatedProps.contains((Object)"mode") || this.updatedProps.contains((Object)"locale")) {
            this.uiManager.updateWheelOrder();
        }
        ArrayList<String> arrayList = new ArrayList<String>(){
            {
                this.add((Object)"date");
                this.add((Object)"fadeToColor");
                this.add((Object)"textColor");
            }
        };
        this.updatedProps.removeAll((Collection)arrayList);
        if (this.updatedProps.size() != 0) {
            this.uiManager.updateDisplayValues();
        }
        this.uiManager.setWheelsToDate();
        this.updatedProps = new ArrayList();
    }

    public void updateProp(String string2, Dynamic dynamic) {
        this.state.setProp(string2, dynamic);
        this.updatedProps.add((Object)string2);
    }

}

