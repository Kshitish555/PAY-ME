/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.format.DateFormat
 *  android.text.format.DateUtils
 *  com.facebook.react.uimanager.ThemedReactContext
 *  com.henninghall.date_picker.DatePickerManager
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Date
 *  java.util.Locale
 *  java.util.TimeZone
 *  net.time4j.PrettyTime
 *  org.apache.commons.lang3.time.DateUtils
 */
package com.henninghall.date_picker;

import android.content.Context;
import android.text.format.DateFormat;
import android.text.format.DateUtils;
import com.facebook.react.uimanager.ThemedReactContext;
import com.henninghall.date_picker.DatePickerManager;
import com.henninghall.date_picker.models.WheelType;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import net.time4j.PrettyTime;

public class Utils {
    public static String capitalize(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2.substring(0, 1).toUpperCase());
        stringBuilder.append(string2.substring(1));
        return stringBuilder.toString();
    }

    public static String dateToIso(Calendar calendar) {
        return Utils.getIsoUTCFormat().format(calendar.getTime());
    }

    private static SimpleDateFormat getIsoUTCFormat() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone((String)"UTC"));
        return simpleDateFormat;
    }

    public static Calendar getTruncatedCalendarOrNull(Calendar calendar) {
        try {
            Calendar calendar2 = org.apache.commons.lang3.time.DateUtils.truncate((Calendar)calendar, (int)12);
            return calendar2;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public static boolean isToday(Calendar calendar) {
        return DateUtils.isToday((long)calendar.getTimeInMillis());
    }

    public static Calendar isoToCalendar(String string2, TimeZone timeZone) {
        if (string2 == null) {
            return null;
        }
        try {
            Calendar calendar = Calendar.getInstance((TimeZone)timeZone);
            calendar.setTime(Utils.getIsoUTCFormat().parse(string2));
            return calendar;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static WheelType patternCharToWheelType(char c) throws Exception {
        if (c == 'H') return WheelType.HOUR;
        if (c == 'M') return WheelType.MONTH;
        if (c == 'a') return WheelType.AM_PM;
        if (c == 'd') return WheelType.DATE;
        if (c == 'h') return WheelType.HOUR;
        if (c == 'm') return WheelType.MINUTE;
        if (c == 'y') {
            return WheelType.YEAR;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid pattern char: ");
        stringBuilder.append(c);
        throw new Exception(stringBuilder.toString());
    }

    public static String printToday(Locale locale) {
        return PrettyTime.of((Locale)locale).printToday();
    }

    public static ArrayList<String> splitOnSpace(String string2) {
        Object[] arrobject = string2.split(" ");
        ArrayList arrayList = new ArrayList();
        Collections.addAll((Collection)arrayList, (Object[])arrobject);
        return arrayList;
    }

    public static boolean usesAmPm() {
        return true ^ DateFormat.is24HourFormat((Context)DatePickerManager.context);
    }
}

