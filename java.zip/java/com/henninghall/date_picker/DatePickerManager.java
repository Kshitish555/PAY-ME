/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  com.facebook.react.bridge.Dynamic
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.common.MapBuilder
 *  com.facebook.react.common.MapBuilder$Builder
 *  com.facebook.react.uimanager.SimpleViewManager
 *  com.facebook.react.uimanager.ThemedReactContext
 *  com.facebook.react.uimanager.annotations.ReactPropGroup
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Method
 *  java.util.Map
 *  net.time4j.android.ApplicationStarter
 */
package com.henninghall.date_picker;

import android.content.Context;
import android.view.View;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.common.MapBuilder;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.annotations.ReactPropGroup;
import com.henninghall.date_picker.PickerView;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Map;
import net.time4j.android.ApplicationStarter;

public class DatePickerManager
extends SimpleViewManager<PickerView> {
    private static final String REACT_CLASS = "DatePickerManager";
    private static final int SCROLL = 1;
    public static ThemedReactContext context;

    private ReactPropGroup getMethodAnnotation(String string) {
        Method[] arrmethod = this.getClass().getMethods();
        int n = arrmethod.length;
        Method method = null;
        for (int i = 0; i < n; ++i) {
            Method method2 = arrmethod[i];
            if (!method2.getName().equals((Object)string)) continue;
            method = method2;
        }
        return (ReactPropGroup)method.getAnnotation(ReactPropGroup.class);
    }

    private void updateProp(String string, PickerView pickerView, int n, Dynamic dynamic) {
        pickerView.updateProp(this.getMethodAnnotation(string).names()[n], dynamic);
    }

    public PickerView createViewInstance(ThemedReactContext themedReactContext) {
        context = themedReactContext;
        ApplicationStarter.initialize((Context)themedReactContext, (boolean)false);
        return new PickerView();
    }

    public Map<String, Integer> getCommandsMap() {
        return MapBuilder.of((Object)"scroll", (Object)1);
    }

    public Map getExportedCustomBubblingEventTypeConstants() {
        return MapBuilder.builder().put((Object)"dateChange", (Object)MapBuilder.of((Object)"phasedRegistrationNames", (Object)MapBuilder.of((Object)"bubbled", (Object)"onChange"))).build();
    }

    public String getName() {
        return REACT_CLASS;
    }

    protected void onAfterUpdateTransaction(PickerView pickerView) {
        super.onAfterUpdateTransaction((View)pickerView);
        try {
            pickerView.update();
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void receiveCommand(PickerView pickerView, int n, ReadableArray readableArray) {
        if (n == 1) {
            pickerView.scroll(readableArray.getInt(0), readableArray.getInt(1));
        }
    }

    @ReactPropGroup(names={"date", "mode", "locale", "maximumDate", "minimumDate", "fadeToColor", "textColor", "utc", "minuteInterval"})
    public void setProps(PickerView pickerView, int n, Dynamic dynamic) {
        this.updateProp("setProps", pickerView, n, dynamic);
    }

    @ReactPropGroup(customType="Style", names={"height"})
    public void setStyle(PickerView pickerView, int n, Dynamic dynamic) {
        this.updateProp("setStyle", pickerView, n, dynamic);
    }
}

