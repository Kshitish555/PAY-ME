/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.Dynamic
 *  com.henninghall.date_picker.props.Prop
 *  java.lang.Object
 *  java.lang.String
 */
package com.henninghall.date_picker.props;

import com.facebook.react.bridge.Dynamic;
import com.henninghall.date_picker.props.Prop;

public class MinimumDateProp
extends Prop<String> {
    public static final String name = "minimumDate";

    public String toValue(Dynamic dynamic) {
        return dynamic.asString();
    }
}

