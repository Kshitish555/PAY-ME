/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  com.facebook.react.bridge.Dynamic
 *  com.henninghall.date_picker.LocaleUtils
 *  com.henninghall.date_picker.props.Prop
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 */
package com.henninghall.date_picker.props;

import android.os.Build;
import com.facebook.react.bridge.Dynamic;
import com.henninghall.date_picker.LocaleUtils;
import com.henninghall.date_picker.props.Prop;
import java.util.Locale;

public class LocaleProp
extends Prop<Locale> {
    public static final String name = "locale";
    private String languageTag = LocaleProp.getDefaultLanguageTag();

    public LocaleProp() {
        super((Object)LocaleProp.getDefaultLocale());
    }

    private static String getDefaultLanguageTag() {
        if (Build.VERSION.SDK_INT >= 21) {
            return Locale.getDefault().toLanguageTag().replace('-', '_');
        }
        return "en";
    }

    private static Locale getDefaultLocale() {
        return LocaleUtils.getLocale((String)LocaleProp.getDefaultLanguageTag());
    }

    public String getLanguageTag() {
        return this.languageTag;
    }

    public Locale toValue(Dynamic dynamic) {
        this.languageTag = dynamic.asString().replace('-', '_');
        return LocaleUtils.getLocale((String)this.languageTag);
    }
}

