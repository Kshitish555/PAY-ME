/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.Dynamic
 *  com.henninghall.date_picker.models.Mode
 *  com.henninghall.date_picker.props.Prop
 *  java.lang.Object
 *  java.lang.String
 */
package com.henninghall.date_picker.props;

import com.facebook.react.bridge.Dynamic;
import com.henninghall.date_picker.models.Mode;
import com.henninghall.date_picker.props.Prop;

public class ModeProp
extends Prop<Mode> {
    public static final String name = "mode";

    public Mode toValue(Dynamic dynamic) {
        return Mode.valueOf((String)dynamic.asString());
    }
}

