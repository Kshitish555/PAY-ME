/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.Dynamic
 *  com.henninghall.date_picker.props.Prop
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 */
package com.henninghall.date_picker.props;

import com.facebook.react.bridge.Dynamic;
import com.henninghall.date_picker.props.Prop;

public class MinuteIntervalProp
extends Prop<Integer> {
    public static final String name = "minuteInterval";

    public MinuteIntervalProp() {
        super((Object)1);
    }

    public Integer toValue(Dynamic dynamic) {
        return dynamic.asInt();
    }
}

