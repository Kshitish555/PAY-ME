/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.Dynamic
 *  java.lang.Object
 */
package com.henninghall.date_picker.props;

import com.facebook.react.bridge.Dynamic;

public abstract class Prop<T> {
    private T value;

    public Prop() {
    }

    public Prop(T t) {
        this.value = t;
    }

    public T getValue() {
        return this.value;
    }

    public void setValue(Dynamic dynamic) {
        this.value = this.toValue(dynamic);
    }

    public void setValue(T t) {
        this.value = t;
    }

    abstract T toValue(Dynamic var1);
}

