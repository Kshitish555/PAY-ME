/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView
 *  com.henninghall.date_picker.wheelFunctions.WheelFunction
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.henninghall.date_picker.wheelFunctions;

import android.graphics.Color;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.wheelFunctions.WheelFunction;
import com.henninghall.date_picker.wheels.Wheel;

public class TextColor
implements WheelFunction {
    private final String color;

    public TextColor(String string2) {
        this.color = string2;
    }

    public void apply(Wheel wheel) {
        int n2 = Color.parseColor((String)this.color);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("#70");
        stringBuilder.append(this.color.substring(1));
        int n3 = Color.parseColor((String)stringBuilder.toString());
        wheel.picker.setNormalTextColor(n3);
        wheel.picker.setSelectedTextColor(n2);
    }
}

