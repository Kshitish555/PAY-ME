/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView
 *  com.henninghall.date_picker.wheelFunctions.WheelFunction
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Object
 */
package com.henninghall.date_picker.wheelFunctions;

import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.wheelFunctions.WheelFunction;
import com.henninghall.date_picker.wheels.Wheel;

public class SetShowCount
implements WheelFunction {
    private final int count;

    public SetShowCount(int n2) {
        this.count = n2;
    }

    public void apply(Wheel wheel) {
        wheel.picker.setShownCount(this.count);
    }
}

