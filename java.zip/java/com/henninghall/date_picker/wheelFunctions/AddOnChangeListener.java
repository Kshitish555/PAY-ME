/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView$OnValueChangeListener
 *  com.henninghall.date_picker.ui.WheelChangeListener
 *  com.henninghall.date_picker.wheelFunctions.WheelFunction
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Object
 */
package com.henninghall.date_picker.wheelFunctions;

import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.ui.WheelChangeListener;
import com.henninghall.date_picker.wheelFunctions.WheelFunction;
import com.henninghall.date_picker.wheels.Wheel;

public class AddOnChangeListener
implements WheelFunction {
    private final WheelChangeListener onChangeListener;

    public AddOnChangeListener(WheelChangeListener wheelChangeListener) {
        this.onChangeListener = wheelChangeListener;
    }

    public void apply(final Wheel wheel) {
        wheel.picker.setOnValueChangedListener(new NumberPickerView.OnValueChangeListener(){

            public void onValueChange(NumberPickerView numberPickerView, int n2, int n3) {
                AddOnChangeListener.this.onChangeListener.onChange(wheel);
            }
        });
    }

}

