/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.henninghall.date_picker.wheelFunctions.WheelFunction
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Object
 */
package com.henninghall.date_picker.wheelFunctions;

import com.henninghall.date_picker.wheelFunctions.WheelFunction;
import com.henninghall.date_picker.wheels.Wheel;

public class UpdateVisibility
implements WheelFunction {
    public void apply(Wheel wheel) {
        wheel.updateVisibility();
    }
}

