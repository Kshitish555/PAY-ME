/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.text.DateFormat
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Locale
 *  org.apache.commons.lang3.LocaleUtils
 */
package com.henninghall.date_picker;

import com.henninghall.date_picker.Utils;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class LocaleUtils {
    public static String getDatePattern(Locale locale) {
        return ((SimpleDateFormat)DateFormat.getDateInstance((int)0, (Locale)locale)).toLocalizedPattern().replace((CharSequence)",", (CharSequence)"");
    }

    static String getDateTimePattern(Locale locale) {
        return ((SimpleDateFormat)DateFormat.getDateTimeInstance((int)0, (int)0, (Locale)locale)).toLocalizedPattern().replace((CharSequence)",", (CharSequence)"");
    }

    private static ArrayList<String> getFullPatternPieces(Locale locale) {
        return Utils.splitOnSpace(LocaleUtils.getDatePattern(locale));
    }

    public static Locale getLocale(String string2) {
        try {
            Locale locale = org.apache.commons.lang3.LocaleUtils.toLocale((String)string2);
            return locale;
        }
        catch (Exception exception) {
            return org.apache.commons.lang3.LocaleUtils.toLocale((String)string2.substring(0, string2.indexOf("")));
        }
    }

    public static String getPatternIncluding(String string2, Locale locale) {
        for (String string3 : LocaleUtils.getFullPatternPieces(locale)) {
            if (!string3.contains((CharSequence)string2)) continue;
            return string3;
        }
        return null;
    }
}

