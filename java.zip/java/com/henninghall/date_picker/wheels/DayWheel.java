/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView
 *  com.henninghall.date_picker.DayFormats
 *  com.henninghall.date_picker.LocaleUtils
 *  com.henninghall.date_picker.State
 *  com.henninghall.date_picker.Utils
 *  com.henninghall.date_picker.models.Mode
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Locale
 */
package com.henninghall.date_picker.wheels;

import android.graphics.Paint;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.DayFormats;
import com.henninghall.date_picker.LocaleUtils;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.Utils;
import com.henninghall.date_picker.models.Mode;
import com.henninghall.date_picker.wheels.Wheel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class DayWheel
extends Wheel {
    private static int defaultNumberOfDays = Calendar.getInstance().getActualMaximum(6);
    private HashMap<String, String> displayValues;
    private String todayValue;

    public DayWheel(NumberPickerView numberPickerView, State state) {
        super(numberPickerView, state);
    }

    private String getDisplayValue(Calendar calendar) {
        return this.getDisplayValueFormat().format(calendar.getTime());
    }

    private SimpleDateFormat getDisplayValueFormat() {
        return new SimpleDateFormat(this.getDisplayValueFormatPattern(), this.state.getLocale());
    }

    private String getDisplayValueFormatPattern() {
        return DayFormats.get((String)this.state.getLocaleLanguageTag());
    }

    private Calendar getEndCal() {
        Calendar calendar = this.state.getMaximumDate();
        Calendar calendar2 = this.state.getMinimumDate();
        if (calendar != null) {
            Calendar calendar3 = (Calendar)calendar.clone();
            this.resetToMidnight(calendar3);
            return calendar3;
        }
        if (calendar2 != null) {
            Calendar calendar4 = (Calendar)calendar2.clone();
            this.resetToMidnight(calendar4);
            calendar4.add(5, calendar4.getActualMaximum(6) / 2);
            return calendar4;
        }
        Calendar calendar5 = (Calendar)this.getInitialDate().clone();
        calendar5.setTime(new Date());
        calendar5.add(5, defaultNumberOfDays / 2);
        return calendar5;
    }

    private Calendar getInitialDate() {
        int n2;
        Calendar calendar = Calendar.getInstance();
        int n3 = this.state.getMinuteInterval();
        if (n3 <= (n2 = 1)) {
            return calendar;
        }
        int n4 = Integer.valueOf((String)new SimpleDateFormat("mm", this.state.getLocale()).format(calendar.getTime())) % n3;
        int n5 = n3 - n4;
        int n6 = -n4;
        if (n3 / 2 <= n4) {
            n2 = 0;
        }
        if (n2 != 0) {
            n5 = n6;
        }
        calendar.add(12, n5);
        return (Calendar)calendar.clone();
    }

    private Calendar getStartCal() {
        Calendar calendar = this.state.getMaximumDate();
        Calendar calendar2 = this.state.getMinimumDate();
        if (calendar2 != null) {
            Calendar calendar3 = (Calendar)calendar2.clone();
            this.resetToMidnight(calendar3);
            return calendar3;
        }
        if (calendar != null) {
            Calendar calendar4 = (Calendar)calendar.clone();
            this.resetToMidnight(calendar4);
            calendar4.add(5, -calendar4.getActualMaximum(6) / 2);
            return calendar4;
        }
        Calendar calendar5 = (Calendar)this.getInitialDate().clone();
        calendar5.add(5, -defaultNumberOfDays / 2);
        return calendar5;
    }

    private String getValue(Calendar calendar) {
        return this.format.format(calendar.getTime());
    }

    private void resetToMidnight(Calendar calendar) {
        calendar.set(11, 0);
        calendar.set(12, 0);
        calendar.set(13, 0);
        calendar.set(14, 0);
    }

    private String toTodayString(String string2) {
        String string3 = Utils.printToday((Locale)this.state.getLocale());
        if (Character.isUpperCase((char)string2.charAt(0))) {
            string3 = Utils.capitalize((String)string3);
        }
        return string3;
    }

    public String getFormatPattern() {
        return LocaleUtils.getDatePattern((Locale)this.state.getLocale()).replace((CharSequence)"EEEE", (CharSequence)"EEE").replace((CharSequence)"MMMM", (CharSequence)"MMM");
    }

    public Paint.Align getTextAlign() {
        return Paint.Align.RIGHT;
    }

    public ArrayList<String> getValues() {
        ArrayList arrayList = new ArrayList();
        this.displayValues = new HashMap();
        Calendar calendar = this.getStartCal();
        Calendar calendar2 = this.getEndCal();
        while (!calendar.after((Object)calendar2)) {
            String string2 = this.getValue(calendar);
            arrayList.add((Object)string2);
            this.displayValues.put((Object)string2, (Object)this.getDisplayValue(calendar));
            if (Utils.isToday((Calendar)calendar)) {
                this.todayValue = string2;
            }
            calendar.add(5, 1);
        }
        return arrayList;
    }

    public String toDisplayValue(String string2) {
        if (string2.equals((Object)this.todayValue)) {
            return this.toTodayString(string2);
        }
        return (String)this.displayValues.get((Object)string2);
    }

    public boolean visible() {
        return this.state.getMode() == Mode.datetime;
    }
}

