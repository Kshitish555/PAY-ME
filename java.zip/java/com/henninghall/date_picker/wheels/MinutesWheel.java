/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView
 *  com.henninghall.date_picker.State
 *  com.henninghall.date_picker.Utils
 *  com.henninghall.date_picker.models.Mode
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 */
package com.henninghall.date_picker.wheels;

import android.graphics.Paint;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.Utils;
import com.henninghall.date_picker.models.Mode;
import com.henninghall.date_picker.wheels.Wheel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MinutesWheel
extends Wheel {
    public MinutesWheel(NumberPickerView numberPickerView, State state) {
        super(numberPickerView, state);
    }

    public String getFormatPattern() {
        return "mm";
    }

    public Paint.Align getTextAlign() {
        if (Utils.usesAmPm()) {
            return Paint.Align.RIGHT;
        }
        return Paint.Align.LEFT;
    }

    public ArrayList<String> getValues() {
        Calendar calendar = Calendar.getInstance();
        ArrayList arrayList = new ArrayList();
        calendar.set(12, 0);
        for (int i2 = 0; i2 < 60; i2 += this.state.getMinuteInterval()) {
            arrayList.add((Object)this.format.format(calendar.getTime()));
            calendar.add(12, this.state.getMinuteInterval());
        }
        return arrayList;
    }

    public boolean visible() {
        return this.state.getMode() != Mode.date;
    }
}

