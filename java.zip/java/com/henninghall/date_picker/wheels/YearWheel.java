/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView
 *  com.henninghall.date_picker.LocaleUtils
 *  com.henninghall.date_picker.State
 *  com.henninghall.date_picker.models.Mode
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Locale
 */
package com.henninghall.date_picker.wheels;

import android.graphics.Paint;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.LocaleUtils;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.models.Mode;
import com.henninghall.date_picker.wheels.Wheel;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class YearWheel
extends Wheel {
    private int defaultEndYear = 2100;
    private int defaultStartYear = 1900;

    public YearWheel(NumberPickerView numberPickerView, State state) {
        super(numberPickerView, state);
    }

    private int getEndYear() {
        if (this.state.getMaximumDate() == null) {
            return this.defaultEndYear;
        }
        return this.state.getMaximumDate().get(1);
    }

    private int getStartYear() {
        if (this.state.getMinimumDate() == null) {
            return this.defaultStartYear;
        }
        return this.state.getMinimumDate().get(1);
    }

    public String getFormatPattern() {
        return LocaleUtils.getPatternIncluding((String)"y", (Locale)this.state.getLocale());
    }

    public Paint.Align getTextAlign() {
        return Paint.Align.RIGHT;
    }

    public ArrayList<String> getValues() {
        ArrayList arrayList = new ArrayList();
        Calendar calendar = Calendar.getInstance();
        int n2 = this.getStartYear();
        int n3 = this.getEndYear() - n2;
        calendar.set(1, n2);
        for (int i2 = 0; i2 <= n3; ++i2) {
            arrayList.add((Object)this.getLocaleString(calendar));
            calendar.add(1, 1);
        }
        return arrayList;
    }

    public boolean visible() {
        return this.state.getMode() == Mode.date;
    }
}

