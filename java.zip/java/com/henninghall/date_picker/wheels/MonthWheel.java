/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView
 *  com.henninghall.date_picker.State
 *  com.henninghall.date_picker.models.Mode
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Calendar
 */
package com.henninghall.date_picker.wheels;

import android.graphics.Paint;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.models.Mode;
import com.henninghall.date_picker.wheels.Wheel;
import java.util.ArrayList;
import java.util.Calendar;

public class MonthWheel
extends Wheel {
    public MonthWheel(NumberPickerView numberPickerView, State state) {
        super(numberPickerView, state);
    }

    public String getFormatPattern() {
        return "LLLL";
    }

    public Paint.Align getTextAlign() {
        return Paint.Align.LEFT;
    }

    public ArrayList<String> getValues() {
        ArrayList arrayList = new ArrayList();
        Calendar calendar = Calendar.getInstance();
        calendar.set(2, 0);
        for (int i2 = 0; i2 <= 11; ++i2) {
            arrayList.add((Object)this.getLocaleString(calendar));
            calendar.add(2, 1);
        }
        return arrayList;
    }

    public boolean visible() {
        return this.state.getMode() == Mode.date;
    }
}

