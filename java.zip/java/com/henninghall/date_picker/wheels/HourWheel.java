/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView
 *  com.henninghall.date_picker.State
 *  com.henninghall.date_picker.Utils
 *  com.henninghall.date_picker.models.Mode
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 */
package com.henninghall.date_picker.wheels;

import android.graphics.Paint;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.Utils;
import com.henninghall.date_picker.models.Mode;
import com.henninghall.date_picker.wheels.Wheel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class HourWheel
extends Wheel {
    public HourWheel(NumberPickerView numberPickerView, State state) {
        super(numberPickerView, state);
    }

    public String getFormatPattern() {
        if (Utils.usesAmPm()) {
            return "h";
        }
        return "HH";
    }

    public Paint.Align getTextAlign() {
        return Paint.Align.RIGHT;
    }

    public ArrayList<String> getValues() {
        Calendar calendar = Calendar.getInstance();
        ArrayList arrayList = new ArrayList();
        int n2 = Utils.usesAmPm() ? 12 : 24;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)this.format.format(calendar.getTime()));
            calendar.add(11, 1);
        }
        return arrayList;
    }

    public boolean visible() {
        return this.state.getMode() != Mode.date;
    }
}

