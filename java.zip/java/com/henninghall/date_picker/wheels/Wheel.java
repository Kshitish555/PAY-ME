/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.Locale
 *  java.util.TimeZone
 */
package com.henninghall.date_picker.wheels;

import android.graphics.Paint;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.State;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;

public abstract class Wheel {
    public SimpleDateFormat format;
    public NumberPickerView picker;
    protected final State state;
    private Calendar userSetValue;
    private ArrayList<String> values = new ArrayList();

    public Wheel(NumberPickerView numberPickerView, State state) {
        this.state = state;
        this.picker = numberPickerView;
        this.format = new SimpleDateFormat(this.getFormatPattern(), state.getLocale());
        numberPickerView.setTextAlign(this.getTextAlign());
    }

    private String[] getDisplayValues(ArrayList<String> arrayList) {
        ArrayList arrayList2 = new ArrayList();
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            arrayList2.add((Object)this.toDisplayValue((String)iterator.next()));
        }
        return (String[])arrayList2.toArray((Object[])new String[0]);
    }

    private SimpleDateFormat getFormat(Locale locale) {
        return new SimpleDateFormat(this.getFormatPattern(), locale);
    }

    private int getIndex() {
        return this.picker.getValue();
    }

    private int getIndexOfDate(Calendar calendar) {
        this.format.setTimeZone(this.state.getTimeZone());
        return this.values.indexOf((Object)this.format.format(calendar.getTime()));
    }

    private String getString(Calendar calendar, Locale locale) {
        return this.getFormat(locale).format(calendar.getTime());
    }

    private void init() {
        this.picker.setMinValue(0);
        this.picker.setMaxValue(0);
        this.values = this.getValues();
        this.picker.setDisplayedValues(this.getDisplayValues(this.values));
        this.picker.setMaxValue(-1 + this.values.size());
    }

    public void animateToDate(Calendar calendar) {
        this.picker.smoothScrollToValue(this.getIndexOfDate(calendar));
    }

    public String getDisplayValue() {
        return this.toDisplayValue(this.getValueAtIndex(this.getIndex()));
    }

    public abstract String getFormatPattern();

    String getLocaleString(Calendar calendar) {
        return this.getString(calendar, this.state.getLocale());
    }

    public abstract Paint.Align getTextAlign();

    public String getValue() {
        if (!this.visible()) {
            return this.format.format(this.userSetValue.getTime());
        }
        return this.getValueAtIndex(this.getIndex());
    }

    public String getValueAtIndex(int n) {
        return (String)this.values.get(n);
    }

    public abstract ArrayList<String> getValues();

    public void refresh() {
        this.format = new SimpleDateFormat(this.getFormatPattern(), this.state.getLocale());
        if (!this.visible()) {
            return;
        }
        this.init();
    }

    public void setValue(Calendar calendar) {
        this.format.setTimeZone(this.state.getTimeZone());
        this.userSetValue = calendar;
        int n = this.getIndexOfDate(calendar);
        if (n > -1) {
            if (this.picker.getValue() == 0) {
                this.picker.setValue(n);
                return;
            }
            this.picker.smoothScrollToValue(n);
        }
    }

    public String toDisplayValue(String string2) {
        return string2;
    }

    public void updateVisibility() {
        int n = this.visible() ? 0 : 8;
        this.picker.setVisibility(n);
    }

    public abstract boolean visible();
}

