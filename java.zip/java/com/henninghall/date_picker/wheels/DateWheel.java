/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  cn.carbswang.android.numberpickerview.library.NumberPickerView
 *  com.henninghall.date_picker.LocaleUtils
 *  com.henninghall.date_picker.State
 *  com.henninghall.date_picker.models.Mode
 *  com.henninghall.date_picker.wheels.Wheel
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Locale
 */
package com.henninghall.date_picker.wheels;

import android.graphics.Paint;
import cn.carbswang.android.numberpickerview.library.NumberPickerView;
import com.henninghall.date_picker.LocaleUtils;
import com.henninghall.date_picker.State;
import com.henninghall.date_picker.models.Mode;
import com.henninghall.date_picker.wheels.Wheel;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class DateWheel
extends Wheel {
    public DateWheel(NumberPickerView numberPickerView, State state) {
        super(numberPickerView, state);
    }

    public String getFormatPattern() {
        return LocaleUtils.getPatternIncluding((String)"d", (Locale)this.state.getLocale());
    }

    public Paint.Align getTextAlign() {
        return Paint.Align.RIGHT;
    }

    public ArrayList<String> getValues() {
        Calendar calendar = Calendar.getInstance();
        ArrayList arrayList = new ArrayList();
        calendar.set(2, 0);
        calendar.set(5, 0);
        for (int i2 = 1; i2 <= 31; ++i2) {
            arrayList.add((Object)this.getLocaleString(calendar));
            calendar.add(5, 1);
        }
        return arrayList;
    }

    public boolean visible() {
        return this.state.getMode() == Mode.date;
    }
}

