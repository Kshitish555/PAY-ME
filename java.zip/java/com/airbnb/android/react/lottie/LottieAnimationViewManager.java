/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.content.Context
 *  android.content.ContextWrapper
 *  android.os.Handler
 *  android.os.Looper
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.common.MapBuilder
 *  com.facebook.react.common.MapBuilder$Builder
 *  com.facebook.react.uimanager.SimpleViewManager
 *  com.facebook.react.uimanager.ThemedReactContext
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.facebook.react.uimanager.events.RCTEventEmitter
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Map
 *  java.util.WeakHashMap
 */
package com.airbnb.android.react.lottie;

import android.animation.Animator;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import com.airbnb.android.react.lottie.LottieAnimationViewManager;
import com.airbnb.android.react.lottie.LottieAnimationViewPropertyManager;
import com.airbnb.lottie.LottieAnimationView;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.common.MapBuilder;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.uimanager.events.RCTEventEmitter;
import java.util.Map;
import java.util.WeakHashMap;

class LottieAnimationViewManager
extends SimpleViewManager<LottieAnimationView> {
    private static final int COMMAND_PLAY = 1;
    private static final int COMMAND_RESET = 2;
    private static final String REACT_CLASS = "LottieAnimationView";
    private static final String TAG = LottieAnimationViewManager.class.getSimpleName();
    private static final int VERSION = 1;
    private Map<LottieAnimationView, LottieAnimationViewPropertyManager> propManagersMap = new WeakHashMap();

    LottieAnimationViewManager() {
    }

    static /* synthetic */ void access$000(LottieAnimationViewManager lottieAnimationViewManager, LottieAnimationView lottieAnimationView, boolean bl) {
        lottieAnimationViewManager.sendOnAnimationFinishEvent(lottieAnimationView, bl);
    }

    private LottieAnimationViewPropertyManager getOrCreatePropertyManager(LottieAnimationView lottieAnimationView) {
        LottieAnimationViewPropertyManager lottieAnimationViewPropertyManager = (LottieAnimationViewPropertyManager)this.propManagersMap.get((Object)lottieAnimationView);
        if (lottieAnimationViewPropertyManager == null) {
            lottieAnimationViewPropertyManager = new LottieAnimationViewPropertyManager(lottieAnimationView);
            this.propManagersMap.put((Object)lottieAnimationView, (Object)lottieAnimationViewPropertyManager);
        }
        return lottieAnimationViewPropertyManager;
    }

    private void sendOnAnimationFinishEvent(LottieAnimationView lottieAnimationView, boolean bl) {
        ReactContext reactContext;
        WritableMap writableMap;
        block3 : {
            writableMap = Arguments.createMap();
            writableMap.putBoolean("isCancelled", bl);
            Context context = lottieAnimationView.getContext();
            while (context instanceof ContextWrapper) {
                if (context instanceof ReactContext) {
                    reactContext = (ReactContext)context;
                    break block3;
                }
                context = ((ContextWrapper)context).getBaseContext();
            }
            reactContext = null;
        }
        if (reactContext != null) {
            ((RCTEventEmitter)reactContext.getJSModule(RCTEventEmitter.class)).receiveEvent(lottieAnimationView.getId(), "animationFinish", writableMap);
        }
    }

    public LottieAnimationView createViewInstance(ThemedReactContext themedReactContext) {
        LottieAnimationView lottieAnimationView = new LottieAnimationView((Context)themedReactContext);
        lottieAnimationView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        lottieAnimationView.addAnimatorListener(new Animator.AnimatorListener(this, lottieAnimationView){
            final /* synthetic */ LottieAnimationViewManager this$0;
            final /* synthetic */ LottieAnimationView val$view;
            {
                this.this$0 = lottieAnimationViewManager;
                this.val$view = lottieAnimationView;
            }

            public void onAnimationCancel(Animator animator) {
                LottieAnimationViewManager.access$000(this.this$0, this.val$view, true);
            }

            public void onAnimationEnd(Animator animator) {
                LottieAnimationViewManager.access$000(this.this$0, this.val$view, false);
            }

            public void onAnimationRepeat(Animator animator) {
            }

            public void onAnimationStart(Animator animator) {
            }
        });
        return lottieAnimationView;
    }

    public Map<String, Integer> getCommandsMap() {
        return MapBuilder.of((Object)"play", (Object)1, (Object)"reset", (Object)2);
    }

    public Map getExportedCustomBubblingEventTypeConstants() {
        return MapBuilder.builder().put((Object)"animationFinish", (Object)MapBuilder.of((Object)"phasedRegistrationNames", (Object)MapBuilder.of((Object)"bubbled", (Object)"onAnimationFinish"))).build();
    }

    public Map<String, Object> getExportedViewConstants() {
        return MapBuilder.builder().put((Object)"VERSION", (Object)1).build();
    }

    public String getName() {
        return REACT_CLASS;
    }

    protected void onAfterUpdateTransaction(LottieAnimationView lottieAnimationView) {
        super.onAfterUpdateTransaction((View)lottieAnimationView);
        this.getOrCreatePropertyManager(lottieAnimationView).commitChanges();
    }

    public void receiveCommand(LottieAnimationView lottieAnimationView, int n, ReadableArray readableArray) {
        if (n != 1) {
            if (n != 2) {
                return;
            }
            new Handler(Looper.getMainLooper()).post(new Runnable(this, lottieAnimationView){
                final /* synthetic */ LottieAnimationViewManager this$0;
                final /* synthetic */ LottieAnimationView val$view;
                {
                    this.this$0 = lottieAnimationViewManager;
                    this.val$view = lottieAnimationView;
                }

                public void run() {
                    if (androidx.core.view.ViewCompat.isAttachedToWindow((View)this.val$view)) {
                        this.val$view.cancelAnimation();
                        this.val$view.setProgress(0.0f);
                    }
                }
            });
            return;
        }
        new Handler(Looper.getMainLooper()).post(new Runnable(this, readableArray, lottieAnimationView){
            final /* synthetic */ LottieAnimationViewManager this$0;
            final /* synthetic */ ReadableArray val$args;
            final /* synthetic */ LottieAnimationView val$view;
            {
                this.this$0 = lottieAnimationViewManager;
                this.val$args = readableArray;
                this.val$view = lottieAnimationView;
            }

            public void run() {
                int n = this.val$args.getInt(0);
                int n2 = this.val$args.getInt(1);
                if (n != -1 && n2 != -1) {
                    if (n > n2) {
                        this.val$view.setMinAndMaxFrame(n2, n);
                        this.val$view.reverseAnimationSpeed();
                    } else {
                        this.val$view.setMinAndMaxFrame(n, n2);
                    }
                }
                if (androidx.core.view.ViewCompat.isAttachedToWindow((View)this.val$view)) {
                    this.val$view.setProgress(0.0f);
                    this.val$view.playAnimation();
                    return;
                }
                this.val$view.addOnAttachStateChangeListener(new android.view.View$OnAttachStateChangeListener(this){
                    final /* synthetic */ 2 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void onViewAttachedToWindow(View view) {
                        LottieAnimationView lottieAnimationView = (LottieAnimationView)view;
                        lottieAnimationView.setProgress(0.0f);
                        lottieAnimationView.playAnimation();
                        lottieAnimationView.removeOnAttachStateChangeListener((android.view.View$OnAttachStateChangeListener)this);
                    }

                    public void onViewDetachedFromWindow(View view) {
                        this.this$1.val$view.removeOnAttachStateChangeListener((android.view.View$OnAttachStateChangeListener)this);
                    }
                });
            }
        });
    }

    @ReactProp(name="colorFilters")
    public void setColorFilters(LottieAnimationView lottieAnimationView, ReadableArray readableArray) {
        this.getOrCreatePropertyManager(lottieAnimationView).setColorFilters(readableArray);
    }

    @ReactProp(name="enableMergePathsAndroidForKitKatAndAbove")
    public void setEnableMergePaths(LottieAnimationView lottieAnimationView, boolean bl) {
        this.getOrCreatePropertyManager(lottieAnimationView).setEnableMergePaths(bl);
    }

    @ReactProp(name="imageAssetsFolder")
    public void setImageAssetsFolder(LottieAnimationView lottieAnimationView, String string) {
        this.getOrCreatePropertyManager(lottieAnimationView).setImageAssetsFolder(string);
    }

    @ReactProp(name="loop")
    public void setLoop(LottieAnimationView lottieAnimationView, boolean bl) {
        this.getOrCreatePropertyManager(lottieAnimationView).setLoop(bl);
    }

    @ReactProp(name="progress")
    public void setProgress(LottieAnimationView lottieAnimationView, float f) {
        this.getOrCreatePropertyManager(lottieAnimationView).setProgress(Float.valueOf((float)f));
    }

    @ReactProp(name="resizeMode")
    public void setResizeMode(LottieAnimationView lottieAnimationView, String string) {
        Object object = "cover".equals((Object)string) ? ImageView.ScaleType.CENTER_CROP : ("contain".equals((Object)string) ? ImageView.ScaleType.CENTER_INSIDE : ("center".equals((Object)string) ? ImageView.ScaleType.CENTER : null));
        this.getOrCreatePropertyManager(lottieAnimationView).setScaleType((ImageView.ScaleType)object);
    }

    @ReactProp(name="sourceJson")
    public void setSourceJson(LottieAnimationView lottieAnimationView, String string) {
        this.getOrCreatePropertyManager(lottieAnimationView).setAnimationJson(string);
    }

    @ReactProp(name="sourceName")
    public void setSourceName(LottieAnimationView lottieAnimationView, String string) {
        if (!string.contains((CharSequence)".")) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string);
            stringBuilder.append(".json");
            string = stringBuilder.toString();
        }
        this.getOrCreatePropertyManager(lottieAnimationView).setAnimationName(string);
    }

    @ReactProp(name="speed")
    public void setSpeed(LottieAnimationView lottieAnimationView, double d) {
        this.getOrCreatePropertyManager(lottieAnimationView).setSpeed((float)d);
    }
}

