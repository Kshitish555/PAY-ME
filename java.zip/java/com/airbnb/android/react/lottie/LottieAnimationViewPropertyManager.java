/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  android.graphics.ColorFilter
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  java.lang.Boolean
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 */
package com.airbnb.android.react.lottie;

import android.graphics.Color;
import android.graphics.ColorFilter;
import android.widget.ImageView;
import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.SimpleColorFilter;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.value.LottieValueCallback;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import java.lang.ref.WeakReference;

public class LottieAnimationViewPropertyManager {
    private String animationJson;
    private String animationName;
    private boolean animationNameDirty;
    private ReadableArray colorFilters;
    private Boolean enableMergePaths;
    private String imageAssetsFolder;
    private Boolean loop;
    private Float progress;
    private ImageView.ScaleType scaleType;
    private Float speed;
    private final WeakReference<LottieAnimationView> viewWeakReference;

    public LottieAnimationViewPropertyManager(LottieAnimationView lottieAnimationView) {
        this.viewWeakReference = new WeakReference((Object)lottieAnimationView);
    }

    public void commitChanges() {
        Boolean bl;
        ReadableArray readableArray;
        Float f;
        String string2;
        Float f2;
        Boolean bl2;
        ImageView.ScaleType scaleType;
        LottieAnimationView lottieAnimationView = (LottieAnimationView)((Object)this.viewWeakReference.get());
        if (lottieAnimationView == null) {
            return;
        }
        String string3 = this.animationJson;
        if (string3 != null) {
            lottieAnimationView.setAnimationFromJson(string3, Integer.toString((int)string3.hashCode()));
            this.animationJson = null;
        }
        if (this.animationNameDirty) {
            lottieAnimationView.setAnimation(this.animationName);
            this.animationNameDirty = false;
        }
        if ((f2 = this.progress) != null) {
            lottieAnimationView.setProgress(f2.floatValue());
            this.progress = null;
        }
        if ((bl2 = this.loop) != null) {
            int n = bl2 != false ? -1 : 0;
            lottieAnimationView.setRepeatCount(n);
            this.loop = null;
        }
        if ((f = this.speed) != null) {
            lottieAnimationView.setSpeed(f.floatValue());
            this.speed = null;
        }
        if ((scaleType = this.scaleType) != null) {
            lottieAnimationView.setScaleType(scaleType);
            this.scaleType = null;
        }
        if ((string2 = this.imageAssetsFolder) != null) {
            lottieAnimationView.setImageAssetsFolder(string2);
            this.imageAssetsFolder = null;
        }
        if ((bl = this.enableMergePaths) != null) {
            lottieAnimationView.enableMergePathsForKitKatAndAbove(bl);
            this.enableMergePaths = null;
        }
        if ((readableArray = this.colorFilters) != null && readableArray.size() > 0) {
            for (int i = 0; i < this.colorFilters.size(); ++i) {
                ReadableMap readableMap = this.colorFilters.getMap(i);
                String string4 = readableMap.getString("color");
                String string5 = readableMap.getString("keypath");
                SimpleColorFilter simpleColorFilter = new SimpleColorFilter(Color.parseColor((String)string4));
                KeyPath keyPath = new KeyPath(string5, "**");
                LottieValueCallback<SimpleColorFilter> lottieValueCallback = new LottieValueCallback<SimpleColorFilter>(simpleColorFilter);
                lottieAnimationView.addValueCallback(keyPath, LottieProperty.COLOR_FILTER, lottieValueCallback);
            }
        }
    }

    public void setAnimationJson(String string2) {
        this.animationJson = string2;
    }

    public void setAnimationName(String string2) {
        this.animationName = string2;
        this.animationNameDirty = true;
    }

    public void setColorFilters(ReadableArray readableArray) {
        this.colorFilters = readableArray;
    }

    public void setEnableMergePaths(boolean bl) {
        this.enableMergePaths = bl;
    }

    public void setImageAssetsFolder(String string2) {
        this.imageAssetsFolder = string2;
    }

    public void setLoop(boolean bl) {
        this.loop = bl;
    }

    public void setProgress(Float f) {
        this.progress = f;
    }

    public void setScaleType(ImageView.ScaleType scaleType) {
        this.scaleType = scaleType;
    }

    public void setSpeed(float f) {
        this.speed = Float.valueOf((float)f);
    }
}

