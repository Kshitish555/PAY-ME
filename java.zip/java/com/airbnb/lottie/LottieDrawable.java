/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.Matrix
 *  android.graphics.Rect
 *  android.graphics.Typeface
 *  android.graphics.drawable.Animatable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$Callback
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  androidx.collection.SparseArrayCompat
 *  com.airbnb.lottie.model.layer.CompositionLayer
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.annotation.Annotation
 *  java.lang.annotation.Retention
 *  java.lang.annotation.RetentionPolicy
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 */
package com.airbnb.lottie;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import androidx.collection.SparseArrayCompat;
import com.airbnb.lottie.FontAssetDelegate;
import com.airbnb.lottie.ImageAssetDelegate;
import com.airbnb.lottie.L;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieImageAsset;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.PerformanceTracker;
import com.airbnb.lottie.TextDelegate;
import com.airbnb.lottie.manager.FontAssetManager;
import com.airbnb.lottie.manager.ImageAssetManager;
import com.airbnb.lottie.model.FontCharacter;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.KeyPathElement;
import com.airbnb.lottie.model.Marker;
import com.airbnb.lottie.model.layer.CompositionLayer;
import com.airbnb.lottie.model.layer.Layer;
import com.airbnb.lottie.parser.LayerParser;
import com.airbnb.lottie.utils.Logger;
import com.airbnb.lottie.utils.LottieValueAnimator;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieValueCallback;
import com.airbnb.lottie.value.SimpleLottieValueCallback;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class LottieDrawable
extends Drawable
implements Drawable.Callback,
Animatable {
    public static final int INFINITE = -1;
    public static final int RESTART = 1;
    public static final int REVERSE = 2;
    private static final String TAG = LottieDrawable.class.getSimpleName();
    private int alpha = 255;
    private final LottieValueAnimator animator = new LottieValueAnimator();
    private final Set<ColorFilterData> colorFilterData = new HashSet();
    private LottieComposition composition;
    private CompositionLayer compositionLayer;
    private boolean enableMergePaths;
    FontAssetDelegate fontAssetDelegate;
    private FontAssetManager fontAssetManager;
    private ImageAssetDelegate imageAssetDelegate;
    private ImageAssetManager imageAssetManager;
    private String imageAssetsFolder;
    private boolean isDirty = false;
    private final ArrayList<LazyCompositionTask> lazyCompositionTasks = new ArrayList();
    private final Matrix matrix = new Matrix();
    private boolean performanceTrackingEnabled;
    private float scale = 1.0f;
    private boolean systemAnimationsEnabled = true;
    TextDelegate textDelegate;

    public LottieDrawable() {
        this.animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                if (LottieDrawable.this.compositionLayer != null) {
                    LottieDrawable.this.compositionLayer.setProgress(LottieDrawable.this.animator.getAnimatedValueAbsolute());
                }
            }
        });
    }

    private void buildCompositionLayer() {
        this.compositionLayer = new CompositionLayer(this, LayerParser.parse(this.composition), this.composition.getLayers(), this.composition);
    }

    private Context getContext() {
        Drawable.Callback callback = this.getCallback();
        if (callback == null) {
            return null;
        }
        if (callback instanceof View) {
            return ((View)callback).getContext();
        }
        return null;
    }

    private FontAssetManager getFontAssetManager() {
        if (this.getCallback() == null) {
            return null;
        }
        if (this.fontAssetManager == null) {
            this.fontAssetManager = new FontAssetManager(this.getCallback(), this.fontAssetDelegate);
        }
        return this.fontAssetManager;
    }

    private ImageAssetManager getImageAssetManager() {
        if (this.getCallback() == null) {
            return null;
        }
        ImageAssetManager imageAssetManager = this.imageAssetManager;
        if (imageAssetManager != null && !imageAssetManager.hasSameContext(this.getContext())) {
            this.imageAssetManager = null;
        }
        if (this.imageAssetManager == null) {
            this.imageAssetManager = new ImageAssetManager(this.getCallback(), this.imageAssetsFolder, this.imageAssetDelegate, this.composition.getImages());
        }
        return this.imageAssetManager;
    }

    private float getMaxScale(Canvas canvas) {
        return Math.min((float)((float)canvas.getWidth() / (float)this.composition.getBounds().width()), (float)((float)canvas.getHeight() / (float)this.composition.getBounds().height()));
    }

    private void updateBounds() {
        if (this.composition == null) {
            return;
        }
        float f = this.getScale();
        this.setBounds(0, 0, (int)(f * (float)this.composition.getBounds().width()), (int)(f * (float)this.composition.getBounds().height()));
    }

    public void addAnimatorListener(Animator.AnimatorListener animatorListener) {
        this.animator.addListener(animatorListener);
    }

    public void addAnimatorUpdateListener(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.animator.addUpdateListener(animatorUpdateListener);
    }

    public <T> void addValueCallback(KeyPath keyPath, T t, LottieValueCallback<T> lottieValueCallback) {
        if (this.compositionLayer == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, keyPath, t, lottieValueCallback){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ LottieValueCallback val$callback;
                final /* synthetic */ KeyPath val$keyPath;
                final /* synthetic */ Object val$property;
                {
                    this.this$0 = lottieDrawable;
                    this.val$keyPath = keyPath;
                    this.val$property = object;
                    this.val$callback = lottieValueCallback;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.addValueCallback(this.val$keyPath, this.val$property, this.val$callback);
                }
            });
            return;
        }
        KeyPathElement keyPathElement = keyPath.getResolvedElement();
        boolean bl = true;
        if (keyPathElement != null) {
            keyPath.getResolvedElement().addValueCallback(t, lottieValueCallback);
        } else {
            List<KeyPath> list = this.resolveKeyPath(keyPath);
            for (int i = 0; i < list.size(); ++i) {
                ((KeyPath)list.get(i)).getResolvedElement().addValueCallback(t, lottieValueCallback);
            }
            bl ^= list.isEmpty();
        }
        if (bl) {
            this.invalidateSelf();
            if (t == LottieProperty.TIME_REMAP) {
                this.setProgress(this.getProgress());
            }
        }
    }

    public <T> void addValueCallback(KeyPath keyPath, T t, SimpleLottieValueCallback<T> simpleLottieValueCallback) {
        this.addValueCallback(keyPath, t, new LottieValueCallback<T>(this, simpleLottieValueCallback){
            final /* synthetic */ LottieDrawable this$0;
            final /* synthetic */ SimpleLottieValueCallback val$callback;
            {
                this.this$0 = lottieDrawable;
                this.val$callback = simpleLottieValueCallback;
            }

            public T getValue(com.airbnb.lottie.value.LottieFrameInfo<T> lottieFrameInfo) {
                return this.val$callback.getValue(lottieFrameInfo);
            }
        });
    }

    public void cancelAnimation() {
        this.lazyCompositionTasks.clear();
        this.animator.cancel();
    }

    public void clearComposition() {
        if (this.animator.isRunning()) {
            this.animator.cancel();
        }
        this.composition = null;
        this.compositionLayer = null;
        this.imageAssetManager = null;
        this.animator.clearComposition();
        this.invalidateSelf();
    }

    public void draw(Canvas canvas) {
        float f;
        this.isDirty = false;
        L.beginSection("Drawable#draw");
        if (this.compositionLayer == null) {
            return;
        }
        float f2 = this.scale;
        float f3 = this.getMaxScale(canvas);
        if (f2 > f3) {
            f = this.scale / f3;
        } else {
            f3 = f2;
            f = 1.0f;
        }
        int n = -1;
        if (f > 1.0f) {
            n = canvas.save();
            float f4 = (float)this.composition.getBounds().width() / 2.0f;
            float f5 = (float)this.composition.getBounds().height() / 2.0f;
            float f6 = f4 * f3;
            float f7 = f5 * f3;
            canvas.translate(f4 * this.getScale() - f6, f5 * this.getScale() - f7);
            canvas.scale(f, f, f6, f7);
        }
        this.matrix.reset();
        this.matrix.preScale(f3, f3);
        this.compositionLayer.draw(canvas, this.matrix, this.alpha);
        L.endSection("Drawable#draw");
        if (n > 0) {
            canvas.restoreToCount(n);
        }
    }

    public void enableMergePathsForKitKatAndAbove(boolean bl) {
        if (this.enableMergePaths == bl) {
            return;
        }
        if (Build.VERSION.SDK_INT < 19) {
            Logger.warning("Merge paths are not supported pre-Kit Kat.");
            return;
        }
        this.enableMergePaths = bl;
        if (this.composition != null) {
            this.buildCompositionLayer();
        }
    }

    public boolean enableMergePathsForKitKatAndAbove() {
        return this.enableMergePaths;
    }

    public void endAnimation() {
        this.lazyCompositionTasks.clear();
        this.animator.endAnimation();
    }

    public int getAlpha() {
        return this.alpha;
    }

    public LottieComposition getComposition() {
        return this.composition;
    }

    public int getFrame() {
        return (int)this.animator.getFrame();
    }

    public Bitmap getImageAsset(String string2) {
        ImageAssetManager imageAssetManager = this.getImageAssetManager();
        if (imageAssetManager != null) {
            return imageAssetManager.bitmapForId(string2);
        }
        return null;
    }

    public String getImageAssetsFolder() {
        return this.imageAssetsFolder;
    }

    public int getIntrinsicHeight() {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            return -1;
        }
        return (int)((float)lottieComposition.getBounds().height() * this.getScale());
    }

    public int getIntrinsicWidth() {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            return -1;
        }
        return (int)((float)lottieComposition.getBounds().width() * this.getScale());
    }

    public float getMaxFrame() {
        return this.animator.getMaxFrame();
    }

    public float getMinFrame() {
        return this.animator.getMinFrame();
    }

    public int getOpacity() {
        return -3;
    }

    public PerformanceTracker getPerformanceTracker() {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition != null) {
            return lottieComposition.getPerformanceTracker();
        }
        return null;
    }

    public float getProgress() {
        return this.animator.getAnimatedValueAbsolute();
    }

    public int getRepeatCount() {
        return this.animator.getRepeatCount();
    }

    public int getRepeatMode() {
        return this.animator.getRepeatMode();
    }

    public float getScale() {
        return this.scale;
    }

    public float getSpeed() {
        return this.animator.getSpeed();
    }

    public TextDelegate getTextDelegate() {
        return this.textDelegate;
    }

    public Typeface getTypeface(String string2, String string3) {
        FontAssetManager fontAssetManager = this.getFontAssetManager();
        if (fontAssetManager != null) {
            return fontAssetManager.getTypeface(string2, string3);
        }
        return null;
    }

    public boolean hasMasks() {
        CompositionLayer compositionLayer = this.compositionLayer;
        return compositionLayer != null && compositionLayer.hasMasks();
    }

    public boolean hasMatte() {
        CompositionLayer compositionLayer = this.compositionLayer;
        return compositionLayer != null && compositionLayer.hasMatte();
    }

    public void invalidateDrawable(Drawable drawable2) {
        Drawable.Callback callback = this.getCallback();
        if (callback == null) {
            return;
        }
        callback.invalidateDrawable((Drawable)this);
    }

    public void invalidateSelf() {
        if (this.isDirty) {
            return;
        }
        this.isDirty = true;
        Drawable.Callback callback = this.getCallback();
        if (callback != null) {
            callback.invalidateDrawable((Drawable)this);
        }
    }

    public boolean isAnimating() {
        return this.animator.isRunning();
    }

    public boolean isLooping() {
        return this.animator.getRepeatCount() == -1;
    }

    public boolean isMergePathsEnabledForKitKatAndAbove() {
        return this.enableMergePaths;
    }

    public boolean isRunning() {
        return this.isAnimating();
    }

    @Deprecated
    public void loop(boolean bl) {
        LottieValueAnimator lottieValueAnimator = this.animator;
        int n = bl ? -1 : 0;
        lottieValueAnimator.setRepeatCount(n);
    }

    public void pauseAnimation() {
        this.lazyCompositionTasks.clear();
        this.animator.pauseAnimation();
    }

    public void playAnimation() {
        if (this.compositionLayer == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this){
                final /* synthetic */ LottieDrawable this$0;
                {
                    this.this$0 = lottieDrawable;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.playAnimation();
                }
            });
            return;
        }
        if (this.systemAnimationsEnabled || this.getRepeatCount() == 0) {
            this.animator.playAnimation();
        }
        if (!this.systemAnimationsEnabled) {
            float f = this.getSpeed() < 0.0f ? this.getMinFrame() : this.getMaxFrame();
            this.setFrame((int)f);
        }
    }

    public void removeAllAnimatorListeners() {
        this.animator.removeAllListeners();
    }

    public void removeAllUpdateListeners() {
        this.animator.removeAllUpdateListeners();
    }

    public void removeAnimatorListener(Animator.AnimatorListener animatorListener) {
        this.animator.removeListener(animatorListener);
    }

    public void removeAnimatorUpdateListener(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.animator.removeUpdateListener(animatorUpdateListener);
    }

    public List<KeyPath> resolveKeyPath(KeyPath keyPath) {
        if (this.compositionLayer == null) {
            Logger.warning("Cannot resolve KeyPath. Composition is not set yet.");
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        this.compositionLayer.resolveKeyPath(keyPath, 0, (List)arrayList, new KeyPath(new String[0]));
        return arrayList;
    }

    public void resumeAnimation() {
        if (this.compositionLayer == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this){
                final /* synthetic */ LottieDrawable this$0;
                {
                    this.this$0 = lottieDrawable;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.resumeAnimation();
                }
            });
            return;
        }
        this.animator.resumeAnimation();
    }

    public void reverseAnimationSpeed() {
        this.animator.reverseAnimationSpeed();
    }

    public void scheduleDrawable(Drawable drawable2, Runnable runnable, long l) {
        Drawable.Callback callback = this.getCallback();
        if (callback == null) {
            return;
        }
        callback.scheduleDrawable((Drawable)this, runnable, l);
    }

    public void setAlpha(int n) {
        this.alpha = n;
        this.invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        Logger.warning("Use addColorFilter instead.");
    }

    public boolean setComposition(LottieComposition lottieComposition) {
        if (this.composition == lottieComposition) {
            return false;
        }
        this.isDirty = false;
        this.clearComposition();
        this.composition = lottieComposition;
        this.buildCompositionLayer();
        this.animator.setComposition(lottieComposition);
        this.setProgress(this.animator.getAnimatedFraction());
        this.setScale(this.scale);
        this.updateBounds();
        Iterator iterator = new ArrayList(this.lazyCompositionTasks).iterator();
        while (iterator.hasNext()) {
            ((LazyCompositionTask)iterator.next()).run(lottieComposition);
            iterator.remove();
        }
        this.lazyCompositionTasks.clear();
        lottieComposition.setPerformanceTrackingEnabled(this.performanceTrackingEnabled);
        return true;
    }

    public void setFontAssetDelegate(FontAssetDelegate fontAssetDelegate) {
        this.fontAssetDelegate = fontAssetDelegate;
        FontAssetManager fontAssetManager = this.fontAssetManager;
        if (fontAssetManager != null) {
            fontAssetManager.setDelegate(fontAssetDelegate);
        }
    }

    public void setFrame(int n) {
        if (this.composition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, n){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ int val$frame;
                {
                    this.this$0 = lottieDrawable;
                    this.val$frame = n;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setFrame(this.val$frame);
                }
            });
            return;
        }
        this.animator.setFrame(n);
    }

    public void setImageAssetDelegate(ImageAssetDelegate imageAssetDelegate) {
        this.imageAssetDelegate = imageAssetDelegate;
        ImageAssetManager imageAssetManager = this.imageAssetManager;
        if (imageAssetManager != null) {
            imageAssetManager.setDelegate(imageAssetDelegate);
        }
    }

    public void setImagesAssetsFolder(String string2) {
        this.imageAssetsFolder = string2;
    }

    public void setMaxFrame(int n) {
        if (this.composition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, n){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ int val$maxFrame;
                {
                    this.this$0 = lottieDrawable;
                    this.val$maxFrame = n;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setMaxFrame(this.val$maxFrame);
                }
            });
            return;
        }
        this.animator.setMaxFrame(0.99f + (float)n);
    }

    public void setMaxFrame(String string2) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, string2){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ String val$markerName;
                {
                    this.this$0 = lottieDrawable;
                    this.val$markerName = string2;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setMaxFrame(this.val$markerName);
                }
            });
            return;
        }
        Marker marker = lottieComposition.getMarker(string2);
        if (marker != null) {
            this.setMaxFrame((int)(marker.startFrame + marker.durationFrames));
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find marker with name ");
        stringBuilder.append(string2);
        stringBuilder.append(".");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public void setMaxProgress(float f) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, f){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ float val$maxProgress;
                {
                    this.this$0 = lottieDrawable;
                    this.val$maxProgress = f;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setMaxProgress(this.val$maxProgress);
                }
            });
            return;
        }
        this.setMaxFrame((int)MiscUtils.lerp(lottieComposition.getStartFrame(), this.composition.getEndFrame(), f));
    }

    public void setMinAndMaxFrame(int n, int n2) {
        if (this.composition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, n, n2){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ int val$maxFrame;
                final /* synthetic */ int val$minFrame;
                {
                    this.this$0 = lottieDrawable;
                    this.val$minFrame = n;
                    this.val$maxFrame = n2;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setMinAndMaxFrame(this.val$minFrame, this.val$maxFrame);
                }
            });
            return;
        }
        this.animator.setMinAndMaxFrames(n, 0.99f + (float)n2);
    }

    public void setMinAndMaxFrame(String string2) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, string2){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ String val$markerName;
                {
                    this.this$0 = lottieDrawable;
                    this.val$markerName = string2;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setMinAndMaxFrame(this.val$markerName);
                }
            });
            return;
        }
        Marker marker = lottieComposition.getMarker(string2);
        if (marker != null) {
            int n = (int)marker.startFrame;
            this.setMinAndMaxFrame(n, n + (int)marker.durationFrames);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find marker with name ");
        stringBuilder.append(string2);
        stringBuilder.append(".");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public void setMinAndMaxProgress(float f, float f2) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, f, f2){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ float val$maxProgress;
                final /* synthetic */ float val$minProgress;
                {
                    this.this$0 = lottieDrawable;
                    this.val$minProgress = f;
                    this.val$maxProgress = f2;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setMinAndMaxProgress(this.val$minProgress, this.val$maxProgress);
                }
            });
            return;
        }
        this.setMinAndMaxFrame((int)MiscUtils.lerp(lottieComposition.getStartFrame(), this.composition.getEndFrame(), f), (int)MiscUtils.lerp(this.composition.getStartFrame(), this.composition.getEndFrame(), f2));
    }

    public void setMinFrame(int n) {
        if (this.composition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, n){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ int val$minFrame;
                {
                    this.this$0 = lottieDrawable;
                    this.val$minFrame = n;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setMinFrame(this.val$minFrame);
                }
            });
            return;
        }
        this.animator.setMinFrame(n);
    }

    public void setMinFrame(String string2) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, string2){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ String val$markerName;
                {
                    this.this$0 = lottieDrawable;
                    this.val$markerName = string2;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setMinFrame(this.val$markerName);
                }
            });
            return;
        }
        Marker marker = lottieComposition.getMarker(string2);
        if (marker != null) {
            this.setMinFrame((int)marker.startFrame);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find marker with name ");
        stringBuilder.append(string2);
        stringBuilder.append(".");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public void setMinProgress(float f) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, f){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ float val$minProgress;
                {
                    this.this$0 = lottieDrawable;
                    this.val$minProgress = f;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setMinProgress(this.val$minProgress);
                }
            });
            return;
        }
        this.setMinFrame((int)MiscUtils.lerp(lottieComposition.getStartFrame(), this.composition.getEndFrame(), f));
    }

    public void setPerformanceTrackingEnabled(boolean bl) {
        this.performanceTrackingEnabled = bl;
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition != null) {
            lottieComposition.setPerformanceTrackingEnabled(bl);
        }
    }

    public void setProgress(float f) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LazyCompositionTask(this, f){
                final /* synthetic */ LottieDrawable this$0;
                final /* synthetic */ float val$progress;
                {
                    this.this$0 = lottieDrawable;
                    this.val$progress = f;
                }

                public void run(LottieComposition lottieComposition) {
                    this.this$0.setProgress(this.val$progress);
                }
            });
            return;
        }
        this.animator.setFrame(MiscUtils.lerp(lottieComposition.getStartFrame(), this.composition.getEndFrame(), f));
    }

    public void setRepeatCount(int n) {
        this.animator.setRepeatCount(n);
    }

    public void setRepeatMode(int n) {
        this.animator.setRepeatMode(n);
    }

    public void setScale(float f) {
        this.scale = f;
        this.updateBounds();
    }

    public void setSpeed(float f) {
        this.animator.setSpeed(f);
    }

    void setSystemAnimationsAreEnabled(Boolean bl) {
        this.systemAnimationsEnabled = bl;
    }

    public void setTextDelegate(TextDelegate textDelegate) {
        this.textDelegate = textDelegate;
    }

    public void start() {
        this.playAnimation();
    }

    public void stop() {
        this.endAnimation();
    }

    public void unscheduleDrawable(Drawable drawable2, Runnable runnable) {
        Drawable.Callback callback = this.getCallback();
        if (callback == null) {
            return;
        }
        callback.unscheduleDrawable((Drawable)this, runnable);
    }

    public Bitmap updateBitmap(String string2, Bitmap bitmap) {
        ImageAssetManager imageAssetManager = this.getImageAssetManager();
        if (imageAssetManager == null) {
            Logger.warning("Cannot update bitmap. Most likely the drawable is not added to a View which prevents Lottie from getting a Context.");
            return null;
        }
        Bitmap bitmap2 = imageAssetManager.updateBitmap(string2, bitmap);
        this.invalidateSelf();
        return bitmap2;
    }

    public boolean useTextGlyphs() {
        return this.textDelegate == null && this.composition.getCharacters().size() > 0;
    }

    private static class ColorFilterData {
        final ColorFilter colorFilter;
        final String contentName;
        final String layerName;

        ColorFilterData(String string2, String string3, ColorFilter colorFilter) {
            this.layerName = string2;
            this.contentName = string3;
            this.colorFilter = colorFilter;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (!(object instanceof ColorFilterData)) {
                return false;
            }
            ColorFilterData colorFilterData = (ColorFilterData)object;
            return this.hashCode() == colorFilterData.hashCode() && this.colorFilter == colorFilterData.colorFilter;
        }

        public int hashCode() {
            String string2 = this.layerName;
            int n = string2 != null ? 527 * string2.hashCode() : 17;
            String string3 = this.contentName;
            if (string3 != null) {
                n = n * 31 * string3.hashCode();
            }
            return n;
        }
    }

    private static interface LazyCompositionTask {
        public void run(LottieComposition var1);
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface RepeatMode {
    }

}

