/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.model;

public class DocumentData {
    public final double baselineShift;
    public final int color;
    public final String fontName;
    public final Justification justification;
    public final double lineHeight;
    public final double size;
    public final int strokeColor;
    public final boolean strokeOverFill;
    public final double strokeWidth;
    public final String text;
    public final int tracking;

    public DocumentData(String string2, String string3, double d, Justification justification, int n, double d2, double d3, int n2, int n3, double d4, boolean bl) {
        this.text = string2;
        this.fontName = string3;
        this.size = d;
        this.justification = justification;
        this.tracking = n;
        this.lineHeight = d2;
        this.baselineShift = d3;
        this.color = n2;
        this.strokeColor = n3;
        this.strokeWidth = d4;
        this.strokeOverFill = bl;
    }

    public int hashCode() {
        double d = 31 * (31 * this.text.hashCode() + this.fontName.hashCode());
        double d2 = this.size;
        Double.isNaN((double)d);
        int n = 31 * (31 * (int)(d + d2) + this.justification.ordinal()) + this.tracking;
        long l = Double.doubleToLongBits((double)this.lineHeight);
        return 31 * (n * 31 + (int)(l ^ l >>> 32)) + this.color;
    }

    public static final class Justification
    extends Enum<Justification> {
        private static final /* synthetic */ Justification[] $VALUES;
        public static final /* enum */ Justification CENTER;
        public static final /* enum */ Justification LEFT_ALIGN;
        public static final /* enum */ Justification RIGHT_ALIGN;

        static {
            LEFT_ALIGN = new Justification();
            RIGHT_ALIGN = new Justification();
            CENTER = new Justification();
            Justification[] arrjustification = new Justification[]{LEFT_ALIGN, RIGHT_ALIGN, CENTER};
            $VALUES = arrjustification;
        }

        public static Justification valueOf(String string2) {
            return (Justification)Enum.valueOf(Justification.class, (String)string2);
        }

        public static Justification[] values() {
            return (Justification[])$VALUES.clone();
        }
    }

}

