/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Typeface
 *  androidx.collection.LongSparseArray
 *  androidx.collection.SparseArrayCompat
 *  java.lang.Character
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package com.airbnb.lottie.model.layer;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import androidx.collection.LongSparseArray;
import androidx.collection.SparseArrayCompat;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.TextDelegate;
import com.airbnb.lottie.animation.content.ContentGroup;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.TextKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.TransformKeyframeAnimation;
import com.airbnb.lottie.model.DocumentData;
import com.airbnb.lottie.model.Font;
import com.airbnb.lottie.model.FontCharacter;
import com.airbnb.lottie.model.animatable.AnimatableColorValue;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableTextFrame;
import com.airbnb.lottie.model.animatable.AnimatableTextProperties;
import com.airbnb.lottie.model.content.ShapeGroup;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.model.layer.Layer;
import com.airbnb.lottie.model.layer.TextLayer;
import com.airbnb.lottie.utils.Utils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TextLayer
extends BaseLayer {
    private final LongSparseArray<String> codePointCache = new LongSparseArray();
    private BaseKeyframeAnimation<Integer, Integer> colorAnimation;
    private final LottieComposition composition;
    private final Map<FontCharacter, List<ContentGroup>> contentsForCharacter = new HashMap();
    private final Paint fillPaint = new Paint(this, 1){
        final /* synthetic */ TextLayer this$0;
        {
            this.this$0 = textLayer;
            super(n);
            this.setStyle(Paint.Style.FILL);
        }
    };
    private final LottieDrawable lottieDrawable;
    private final Matrix matrix = new Matrix();
    private final RectF rectF = new RectF();
    private final StringBuilder stringBuilder = new StringBuilder(2);
    private BaseKeyframeAnimation<Integer, Integer> strokeColorAnimation;
    private final Paint strokePaint = new Paint(this, 1){
        final /* synthetic */ TextLayer this$0;
        {
            this.this$0 = textLayer;
            super(n);
            this.setStyle(Paint.Style.STROKE);
        }
    };
    private BaseKeyframeAnimation<Float, Float> strokeWidthAnimation;
    private final TextKeyframeAnimation textAnimation;
    private BaseKeyframeAnimation<Float, Float> trackingAnimation;

    TextLayer(LottieDrawable lottieDrawable, Layer layer) {
        super(lottieDrawable, layer);
        this.lottieDrawable = lottieDrawable;
        this.composition = layer.getComposition();
        this.textAnimation = layer.getText().createAnimation();
        this.textAnimation.addUpdateListener(this);
        this.addAnimation(this.textAnimation);
        AnimatableTextProperties animatableTextProperties = layer.getTextProperties();
        if (animatableTextProperties != null && animatableTextProperties.color != null) {
            this.colorAnimation = animatableTextProperties.color.createAnimation();
            this.colorAnimation.addUpdateListener(this);
            this.addAnimation(this.colorAnimation);
        }
        if (animatableTextProperties != null && animatableTextProperties.stroke != null) {
            this.strokeColorAnimation = animatableTextProperties.stroke.createAnimation();
            this.strokeColorAnimation.addUpdateListener(this);
            this.addAnimation(this.strokeColorAnimation);
        }
        if (animatableTextProperties != null && animatableTextProperties.strokeWidth != null) {
            this.strokeWidthAnimation = animatableTextProperties.strokeWidth.createAnimation();
            this.strokeWidthAnimation.addUpdateListener(this);
            this.addAnimation(this.strokeWidthAnimation);
        }
        if (animatableTextProperties != null && animatableTextProperties.tracking != null) {
            this.trackingAnimation = animatableTextProperties.tracking.createAnimation();
            this.trackingAnimation.addUpdateListener(this);
            this.addAnimation(this.trackingAnimation);
        }
    }

    private void applyJustification(DocumentData.Justification justification, Canvas canvas, float f) {
        int n = 3.$SwitchMap$com$airbnb$lottie$model$DocumentData$Justification[justification.ordinal()];
        if (n != 1) {
            if (n != 2) {
                if (n != 3) {
                    return;
                }
                canvas.translate(-f / 2.0f, 0.0f);
                return;
            }
            canvas.translate(-f, 0.0f);
        }
    }

    private String codePointToString(String string, int n) {
        int n2;
        int n3;
        int n4 = string.codePointAt(n);
        for (n2 = n + Character.charCount((int)n4); n2 < string.length() && this.isModifier(n3 = string.codePointAt(n2)); n2 += Character.charCount((int)n3)) {
            n4 = n3 + n4 * 31;
        }
        LongSparseArray<String> longSparseArray = this.codePointCache;
        long l = n4;
        if (longSparseArray.containsKey(l)) {
            return (String)this.codePointCache.get(l);
        }
        this.stringBuilder.setLength(0);
        while (n < n2) {
            int n5 = string.codePointAt(n);
            this.stringBuilder.appendCodePoint(n5);
            n += Character.charCount((int)n5);
        }
        String string2 = this.stringBuilder.toString();
        this.codePointCache.put(l, (Object)string2);
        return string2;
    }

    private void drawCharacter(String string, Paint paint, Canvas canvas) {
        if (paint.getColor() == 0) {
            return;
        }
        if (paint.getStyle() == Paint.Style.STROKE && paint.getStrokeWidth() == 0.0f) {
            return;
        }
        canvas.drawText(string, 0, string.length(), 0.0f, 0.0f, paint);
    }

    private void drawCharacterAsGlyph(FontCharacter fontCharacter, Matrix matrix, float f, DocumentData documentData, Canvas canvas) {
        List<ContentGroup> list = this.getContentsForCharacter(fontCharacter);
        for (int i = 0; i < list.size(); ++i) {
            Path path = ((ContentGroup)list.get(i)).getPath();
            path.computeBounds(this.rectF, false);
            this.matrix.set(matrix);
            this.matrix.preTranslate(0.0f, (float)(-documentData.baselineShift) * Utils.dpScale());
            this.matrix.preScale(f, f);
            path.transform(this.matrix);
            if (documentData.strokeOverFill) {
                this.drawGlyph(path, this.fillPaint, canvas);
                this.drawGlyph(path, this.strokePaint, canvas);
                continue;
            }
            this.drawGlyph(path, this.strokePaint, canvas);
            this.drawGlyph(path, this.fillPaint, canvas);
        }
    }

    private void drawCharacterFromFont(String string, DocumentData documentData, Canvas canvas) {
        if (documentData.strokeOverFill) {
            this.drawCharacter(string, this.fillPaint, canvas);
            this.drawCharacter(string, this.strokePaint, canvas);
            return;
        }
        this.drawCharacter(string, this.strokePaint, canvas);
        this.drawCharacter(string, this.fillPaint, canvas);
    }

    private void drawFontTextLine(String string, DocumentData documentData, Canvas canvas, float f) {
        int n = 0;
        while (n < string.length()) {
            String string2 = this.codePointToString(string, n);
            n += string2.length();
            this.drawCharacterFromFont(string2, documentData, canvas);
            float f2 = this.fillPaint.measureText(string2, 0, 1);
            float f3 = (float)documentData.tracking / 10.0f;
            BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.trackingAnimation;
            if (baseKeyframeAnimation != null) {
                f3 += baseKeyframeAnimation.getValue().floatValue();
            }
            canvas.translate(f2 + f3 * f, 0.0f);
        }
    }

    private void drawGlyph(Path path, Paint paint, Canvas canvas) {
        if (paint.getColor() == 0) {
            return;
        }
        if (paint.getStyle() == Paint.Style.STROKE && paint.getStrokeWidth() == 0.0f) {
            return;
        }
        canvas.drawPath(path, paint);
    }

    private void drawGlyphTextLine(String string, DocumentData documentData, Matrix matrix, Font font, Canvas canvas, float f, float f2) {
        for (int i = 0; i < string.length(); ++i) {
            int n = FontCharacter.hashFor(string.charAt(i), font.getFamily(), font.getStyle());
            FontCharacter fontCharacter = (FontCharacter)this.composition.getCharacters().get(n);
            if (fontCharacter == null) continue;
            this.drawCharacterAsGlyph(fontCharacter, matrix, f2, documentData, canvas);
            float f3 = f * (f2 * (float)fontCharacter.getWidth() * Utils.dpScale());
            float f4 = (float)documentData.tracking / 10.0f;
            BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.trackingAnimation;
            if (baseKeyframeAnimation != null) {
                f4 += baseKeyframeAnimation.getValue().floatValue();
            }
            canvas.translate(f3 + f4 * f, 0.0f);
        }
    }

    private void drawTextGlyphs(DocumentData documentData, Matrix matrix, Font font, Canvas canvas) {
        float f = (float)documentData.size / 100.0f;
        float f2 = Utils.getScale(matrix);
        String string = documentData.text;
        float f3 = (float)documentData.lineHeight * Utils.dpScale();
        List<String> list = this.getTextLines(string);
        int n = list.size();
        int n2 = 0;
        while (n2 < n) {
            String string2 = (String)list.get(n2);
            float f4 = this.getTextLineWidthForGlyphs(string2, font, f, f2);
            canvas.save();
            this.applyJustification(documentData.justification, canvas, f4);
            float f5 = f3 * (float)(n - 1) / 2.0f;
            canvas.translate(0.0f, f3 * (float)n2 - f5);
            int n3 = n2;
            this.drawGlyphTextLine(string2, documentData, matrix, font, canvas, f2, f);
            canvas.restore();
            n2 = n3 + 1;
        }
    }

    private void drawTextWithFont(DocumentData documentData, Font font, Matrix matrix, Canvas canvas) {
        float f = Utils.getScale(matrix);
        Typeface typeface = this.lottieDrawable.getTypeface(font.getFamily(), font.getStyle());
        if (typeface == null) {
            return;
        }
        String string = documentData.text;
        TextDelegate textDelegate = this.lottieDrawable.getTextDelegate();
        if (textDelegate != null) {
            string = textDelegate.getTextInternal(string);
        }
        this.fillPaint.setTypeface(typeface);
        Paint paint = this.fillPaint;
        double d = documentData.size;
        double d2 = Utils.dpScale();
        Double.isNaN((double)d2);
        paint.setTextSize((float)(d * d2));
        this.strokePaint.setTypeface(this.fillPaint.getTypeface());
        this.strokePaint.setTextSize(this.fillPaint.getTextSize());
        float f2 = (float)documentData.lineHeight * Utils.dpScale();
        List<String> list = this.getTextLines(string);
        int n = list.size();
        for (int i = 0; i < n; ++i) {
            String string2 = (String)list.get(i);
            float f3 = this.strokePaint.measureText(string2);
            this.applyJustification(documentData.justification, canvas, f3);
            float f4 = f2 * (float)(n - 1) / 2.0f;
            canvas.translate(0.0f, f2 * (float)i - f4);
            this.drawFontTextLine(string2, documentData, canvas, f);
            canvas.setMatrix(matrix);
        }
    }

    private List<ContentGroup> getContentsForCharacter(FontCharacter fontCharacter) {
        if (this.contentsForCharacter.containsKey((Object)fontCharacter)) {
            return (List)this.contentsForCharacter.get((Object)fontCharacter);
        }
        List<ShapeGroup> list = fontCharacter.getShapes();
        int n = list.size();
        ArrayList arrayList = new ArrayList(n);
        for (int i = 0; i < n; ++i) {
            ShapeGroup shapeGroup = (ShapeGroup)list.get(i);
            arrayList.add((Object)new ContentGroup(this.lottieDrawable, this, shapeGroup));
        }
        this.contentsForCharacter.put((Object)fontCharacter, (Object)arrayList);
        return arrayList;
    }

    private float getTextLineWidthForGlyphs(String string, Font font, float f, float f2) {
        float f3 = 0.0f;
        for (int i = 0; i < string.length(); ++i) {
            int n = FontCharacter.hashFor(string.charAt(i), font.getFamily(), font.getStyle());
            FontCharacter fontCharacter = (FontCharacter)this.composition.getCharacters().get(n);
            if (fontCharacter == null) continue;
            double d = f3;
            double d2 = fontCharacter.getWidth();
            double d3 = f;
            Double.isNaN((double)d3);
            double d4 = d2 * d3;
            double d5 = Utils.dpScale();
            Double.isNaN((double)d5);
            double d6 = d4 * d5;
            double d7 = f2;
            Double.isNaN((double)d7);
            double d8 = d6 * d7;
            Double.isNaN((double)d);
            f3 = (float)(d + d8);
        }
        return f3;
    }

    private List<String> getTextLines(String string) {
        return Arrays.asList((Object[])string.replaceAll("\r\n", "\r").replaceAll("\n", "\r").split("\r"));
    }

    private boolean isModifier(int n) {
        return Character.getType((int)n) == 16 || Character.getType((int)n) == 27 || Character.getType((int)n) == 6 || Character.getType((int)n) == 28 || Character.getType((int)n) == 19;
        {
        }
    }

    @Override
    public <T> void addValueCallback(T t, LottieValueCallback<T> lottieValueCallback) {
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation2;
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation3;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation4;
        super.addValueCallback(t, lottieValueCallback);
        if (t == LottieProperty.COLOR && (baseKeyframeAnimation3 = this.colorAnimation) != null) {
            baseKeyframeAnimation3.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.STROKE_COLOR && (baseKeyframeAnimation = this.strokeColorAnimation) != null) {
            baseKeyframeAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.STROKE_WIDTH && (baseKeyframeAnimation4 = this.strokeWidthAnimation) != null) {
            baseKeyframeAnimation4.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.TEXT_TRACKING && (baseKeyframeAnimation2 = this.trackingAnimation) != null) {
            baseKeyframeAnimation2.setValueCallback(lottieValueCallback);
        }
    }

    @Override
    void drawLayer(Canvas canvas, Matrix matrix, int n) {
        canvas.save();
        if (!this.lottieDrawable.useTextGlyphs()) {
            canvas.setMatrix(matrix);
        }
        DocumentData documentData = (DocumentData)this.textAnimation.getValue();
        Font font = (Font)this.composition.getFonts().get((Object)documentData.fontName);
        if (font == null) {
            canvas.restore();
            return;
        }
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation = this.colorAnimation;
        if (baseKeyframeAnimation != null) {
            this.fillPaint.setColor(baseKeyframeAnimation.getValue().intValue());
        } else {
            this.fillPaint.setColor(documentData.color);
        }
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation2 = this.strokeColorAnimation;
        if (baseKeyframeAnimation2 != null) {
            this.strokePaint.setColor(baseKeyframeAnimation2.getValue().intValue());
        } else {
            this.strokePaint.setColor(documentData.strokeColor);
        }
        int n2 = this.transform.getOpacity() == null ? 100 : this.transform.getOpacity().getValue();
        int n3 = n2 * 255 / 100;
        this.fillPaint.setAlpha(n3);
        this.strokePaint.setAlpha(n3);
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation3 = this.strokeWidthAnimation;
        if (baseKeyframeAnimation3 != null) {
            this.strokePaint.setStrokeWidth(baseKeyframeAnimation3.getValue().floatValue());
        } else {
            float f = Utils.getScale(matrix);
            Paint paint = this.strokePaint;
            double d = documentData.strokeWidth;
            double d2 = Utils.dpScale();
            Double.isNaN((double)d2);
            double d3 = d * d2;
            double d4 = f;
            Double.isNaN((double)d4);
            paint.setStrokeWidth((float)(d3 * d4));
        }
        if (this.lottieDrawable.useTextGlyphs()) {
            this.drawTextGlyphs(documentData, matrix, font, canvas);
        } else {
            this.drawTextWithFont(documentData, font, matrix, canvas);
        }
        canvas.restore();
    }

    @Override
    public void getBounds(RectF rectF, Matrix matrix, boolean bl) {
        super.getBounds(rectF, matrix, bl);
        rectF.set(0.0f, 0.0f, (float)this.composition.getBounds().width(), (float)this.composition.getBounds().height());
    }
}

