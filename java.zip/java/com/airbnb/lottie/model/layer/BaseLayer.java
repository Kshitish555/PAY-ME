/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffXfermode
 *  android.graphics.RectF
 *  android.graphics.Xfermode
 *  android.os.Build
 *  android.os.Build$VERSION
 *  com.airbnb.lottie.L
 *  com.airbnb.lottie.LottieComposition
 *  com.airbnb.lottie.LottieDrawable
 *  com.airbnb.lottie.PerformanceTracker
 *  com.airbnb.lottie.animation.LPaint
 *  com.airbnb.lottie.animation.content.Content
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation$AnimationListener
 *  com.airbnb.lottie.animation.keyframe.MaskKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.TransformKeyframeAnimation
 *  com.airbnb.lottie.model.KeyPath
 *  com.airbnb.lottie.model.KeyPathElement
 *  com.airbnb.lottie.model.content.Mask
 *  com.airbnb.lottie.model.content.Mask$MaskMode
 *  com.airbnb.lottie.model.content.ShapeData
 *  com.airbnb.lottie.model.layer.BaseLayer$2
 *  com.airbnb.lottie.model.layer.CompositionLayer
 *  com.airbnb.lottie.model.layer.ImageLayer
 *  com.airbnb.lottie.model.layer.Layer
 *  com.airbnb.lottie.model.layer.Layer$LayerType
 *  com.airbnb.lottie.model.layer.Layer$MatteType
 *  com.airbnb.lottie.model.layer.NullLayer
 *  com.airbnb.lottie.model.layer.ShapeLayer
 *  com.airbnb.lottie.model.layer.SolidLayer
 *  com.airbnb.lottie.model.layer.TextLayer
 *  com.airbnb.lottie.utils.Logger
 *  com.airbnb.lottie.value.Keyframe
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 */
package com.airbnb.lottie.model.layer;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Xfermode;
import android.os.Build;
import com.airbnb.lottie.L;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.PerformanceTracker;
import com.airbnb.lottie.animation.LPaint;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.DrawingContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.FloatKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.MaskKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.TransformKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.KeyPathElement;
import com.airbnb.lottie.model.animatable.AnimatableTransform;
import com.airbnb.lottie.model.content.Mask;
import com.airbnb.lottie.model.content.ShapeData;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.model.layer.CompositionLayer;
import com.airbnb.lottie.model.layer.ImageLayer;
import com.airbnb.lottie.model.layer.Layer;
import com.airbnb.lottie.model.layer.NullLayer;
import com.airbnb.lottie.model.layer.ShapeLayer;
import com.airbnb.lottie.model.layer.SolidLayer;
import com.airbnb.lottie.model.layer.TextLayer;
import com.airbnb.lottie.utils.Logger;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public abstract class BaseLayer
implements DrawingContent,
BaseKeyframeAnimation.AnimationListener,
KeyPathElement {
    private static final int CLIP_SAVE_FLAG = 2;
    private static final int CLIP_TO_LAYER_SAVE_FLAG = 16;
    private static final int MATRIX_SAVE_FLAG = 1;
    private static final int SAVE_FLAGS = 19;
    private final List<BaseKeyframeAnimation<?, ?>> animations = new ArrayList();
    final Matrix boundsMatrix = new Matrix();
    private final Paint clearPaint = new LPaint(PorterDuff.Mode.CLEAR);
    private final Paint contentPaint = new LPaint(1);
    private final String drawTraceName;
    private final Paint dstInPaint = new LPaint(1, PorterDuff.Mode.DST_IN);
    private final Paint dstOutPaint = new LPaint(1, PorterDuff.Mode.DST_OUT);
    final Layer layerModel;
    final LottieDrawable lottieDrawable;
    private MaskKeyframeAnimation mask;
    private final RectF maskBoundsRect = new RectF();
    private final Matrix matrix = new Matrix();
    private final RectF matteBoundsRect = new RectF();
    private BaseLayer matteLayer;
    private final Paint mattePaint = new LPaint(1);
    private BaseLayer parentLayer;
    private List<BaseLayer> parentLayers;
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final RectF tempMaskBoundsRect = new RectF();
    final TransformKeyframeAnimation transform;
    private boolean visible = true;

    BaseLayer(LottieDrawable lottieDrawable, Layer layer) {
        this.lottieDrawable = lottieDrawable;
        this.layerModel = layer;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(layer.getName());
        stringBuilder.append("#draw");
        this.drawTraceName = stringBuilder.toString();
        if (layer.getMatteType() == Layer.MatteType.INVERT) {
            this.mattePaint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        } else {
            this.mattePaint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        }
        this.transform = layer.getTransform().createAnimation();
        this.transform.addListener((BaseKeyframeAnimation.AnimationListener)this);
        if (layer.getMasks() != null && !layer.getMasks().isEmpty()) {
            this.mask = new MaskKeyframeAnimation(layer.getMasks());
            Iterator iterator = this.mask.getMaskAnimations().iterator();
            while (iterator.hasNext()) {
                ((BaseKeyframeAnimation)iterator.next()).addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            }
            for (BaseKeyframeAnimation baseKeyframeAnimation : this.mask.getOpacityAnimations()) {
                this.addAnimation(baseKeyframeAnimation);
                baseKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            }
        }
        this.setupInOutAnimations();
    }

    private void applyAddMask(Canvas canvas, Matrix matrix, Mask mask, BaseKeyframeAnimation<ShapeData, Path> baseKeyframeAnimation, BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation2) {
        Path path = (Path)baseKeyframeAnimation.getValue();
        this.path.set(path);
        this.path.transform(matrix);
        this.contentPaint.setAlpha((int)(2.55f * (float)((Integer)baseKeyframeAnimation2.getValue()).intValue()));
        canvas.drawPath(this.path, this.contentPaint);
    }

    private void applyIntersectMask(Canvas canvas, Matrix matrix, Mask mask, BaseKeyframeAnimation<ShapeData, Path> baseKeyframeAnimation, BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation2) {
        this.saveLayerCompat(canvas, this.rect, this.dstInPaint, true);
        Path path = (Path)baseKeyframeAnimation.getValue();
        this.path.set(path);
        this.path.transform(matrix);
        this.contentPaint.setAlpha((int)(2.55f * (float)((Integer)baseKeyframeAnimation2.getValue()).intValue()));
        canvas.drawPath(this.path, this.contentPaint);
        canvas.restore();
    }

    private void applyInvertedAddMask(Canvas canvas, Matrix matrix, Mask mask, BaseKeyframeAnimation<ShapeData, Path> baseKeyframeAnimation, BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation2) {
        this.saveLayerCompat(canvas, this.rect, this.contentPaint, true);
        canvas.drawRect(this.rect, this.contentPaint);
        Path path = (Path)baseKeyframeAnimation.getValue();
        this.path.set(path);
        this.path.transform(matrix);
        this.contentPaint.setAlpha((int)(2.55f * (float)((Integer)baseKeyframeAnimation2.getValue()).intValue()));
        canvas.drawPath(this.path, this.dstOutPaint);
        canvas.restore();
    }

    private void applyInvertedIntersectMask(Canvas canvas, Matrix matrix, Mask mask, BaseKeyframeAnimation<ShapeData, Path> baseKeyframeAnimation, BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation2) {
        this.saveLayerCompat(canvas, this.rect, this.dstInPaint, true);
        canvas.drawRect(this.rect, this.contentPaint);
        this.dstOutPaint.setAlpha((int)(2.55f * (float)((Integer)baseKeyframeAnimation2.getValue()).intValue()));
        Path path = (Path)baseKeyframeAnimation.getValue();
        this.path.set(path);
        this.path.transform(matrix);
        canvas.drawPath(this.path, this.dstOutPaint);
        canvas.restore();
    }

    private void applyInvertedSubtractMask(Canvas canvas, Matrix matrix, Mask mask, BaseKeyframeAnimation<ShapeData, Path> baseKeyframeAnimation, BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation2) {
        this.saveLayerCompat(canvas, this.rect, this.dstOutPaint, true);
        canvas.drawRect(this.rect, this.contentPaint);
        this.dstOutPaint.setAlpha((int)(2.55f * (float)((Integer)baseKeyframeAnimation2.getValue()).intValue()));
        Path path = (Path)baseKeyframeAnimation.getValue();
        this.path.set(path);
        this.path.transform(matrix);
        canvas.drawPath(this.path, this.dstOutPaint);
        canvas.restore();
    }

    private void applyMasks(Canvas canvas, Matrix matrix) {
        L.beginSection((String)"Layer#saveLayer");
        RectF rectF = this.rect;
        Paint paint = this.dstInPaint;
        this.saveLayerCompat(canvas, rectF, paint, false);
        L.endSection((String)"Layer#saveLayer");
        for (int i2 = 0; i2 < this.mask.getMasks().size(); ++i2) {
            Mask mask = (Mask)this.mask.getMasks().get(i2);
            BaseKeyframeAnimation baseKeyframeAnimation = (BaseKeyframeAnimation)this.mask.getMaskAnimations().get(i2);
            BaseKeyframeAnimation baseKeyframeAnimation2 = (BaseKeyframeAnimation)this.mask.getOpacityAnimations().get(i2);
            int n2 = 2.$SwitchMap$com$airbnb$lottie$model$content$Mask$MaskMode[mask.getMaskMode().ordinal()];
            if (n2 != 1) {
                if (n2 != 2) {
                    if (n2 != 3) continue;
                    if (mask.isInverted()) {
                        this.applyInvertedAddMask(canvas, matrix, mask, (BaseKeyframeAnimation<ShapeData, Path>)baseKeyframeAnimation, (BaseKeyframeAnimation<Integer, Integer>)baseKeyframeAnimation2);
                        continue;
                    }
                    this.applyAddMask(canvas, matrix, mask, (BaseKeyframeAnimation<ShapeData, Path>)baseKeyframeAnimation, (BaseKeyframeAnimation<Integer, Integer>)baseKeyframeAnimation2);
                    continue;
                }
                if (mask.isInverted()) {
                    this.applyInvertedIntersectMask(canvas, matrix, mask, (BaseKeyframeAnimation<ShapeData, Path>)baseKeyframeAnimation, (BaseKeyframeAnimation<Integer, Integer>)baseKeyframeAnimation2);
                    continue;
                }
                this.applyIntersectMask(canvas, matrix, mask, (BaseKeyframeAnimation<ShapeData, Path>)baseKeyframeAnimation, (BaseKeyframeAnimation<Integer, Integer>)baseKeyframeAnimation2);
                continue;
            }
            if (i2 == 0) {
                Paint paint2 = new Paint();
                paint2.setColor(-16777216);
                canvas.drawRect(this.rect, paint2);
            }
            if (mask.isInverted()) {
                this.applyInvertedSubtractMask(canvas, matrix, mask, (BaseKeyframeAnimation<ShapeData, Path>)baseKeyframeAnimation, (BaseKeyframeAnimation<Integer, Integer>)baseKeyframeAnimation2);
                continue;
            }
            this.applySubtractMask(canvas, matrix, mask, (BaseKeyframeAnimation<ShapeData, Path>)baseKeyframeAnimation, (BaseKeyframeAnimation<Integer, Integer>)baseKeyframeAnimation2);
        }
        L.beginSection((String)"Layer#restoreLayer");
        canvas.restore();
        L.endSection((String)"Layer#restoreLayer");
    }

    private void applySubtractMask(Canvas canvas, Matrix matrix, Mask mask, BaseKeyframeAnimation<ShapeData, Path> baseKeyframeAnimation, BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation2) {
        Path path = (Path)baseKeyframeAnimation.getValue();
        this.path.set(path);
        this.path.transform(matrix);
        canvas.drawPath(this.path, this.dstOutPaint);
    }

    private void buildParentLayerListIfNeeded() {
        if (this.parentLayers != null) {
            return;
        }
        if (this.parentLayer == null) {
            this.parentLayers = Collections.emptyList();
            return;
        }
        this.parentLayers = new ArrayList();
        BaseLayer baseLayer = this.parentLayer;
        while (baseLayer != null) {
            this.parentLayers.add((Object)baseLayer);
            baseLayer = baseLayer.parentLayer;
        }
    }

    private void clearCanvas(Canvas canvas) {
        L.beginSection((String)"Layer#clearLayer");
        canvas.drawRect(this.rect.left - 1.0f, this.rect.top - 1.0f, 1.0f + this.rect.right, 1.0f + this.rect.bottom, this.clearPaint);
        L.endSection((String)"Layer#clearLayer");
    }

    static BaseLayer forModel(Layer layer, LottieDrawable lottieDrawable, LottieComposition lottieComposition) {
        switch (2.$SwitchMap$com$airbnb$lottie$model$layer$Layer$LayerType[layer.getLayerType().ordinal()]) {
            default: {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unknown layer type ");
                stringBuilder.append((Object)layer.getLayerType());
                Logger.warning((String)stringBuilder.toString());
                return null;
            }
            case 6: {
                return new TextLayer(lottieDrawable, layer);
            }
            case 5: {
                return new NullLayer(lottieDrawable, layer);
            }
            case 4: {
                return new ImageLayer(lottieDrawable, layer);
            }
            case 3: {
                return new SolidLayer(lottieDrawable, layer);
            }
            case 2: {
                return new CompositionLayer(lottieDrawable, layer, lottieComposition.getPrecomps(layer.getRefId()), lottieComposition);
            }
            case 1: 
        }
        return new ShapeLayer(lottieDrawable, layer);
    }

    private void intersectBoundsWithMask(RectF rectF, Matrix matrix) {
        this.maskBoundsRect.set(0.0f, 0.0f, 0.0f, 0.0f);
        if (!this.hasMasksOnThisLayer()) {
            return;
        }
        int n2 = this.mask.getMasks().size();
        for (int i2 = 0; i2 < n2; ++i2) {
            Mask mask = (Mask)this.mask.getMasks().get(i2);
            Path path = (Path)((BaseKeyframeAnimation)this.mask.getMaskAnimations().get(i2)).getValue();
            this.path.set(path);
            this.path.transform(matrix);
            int n3 = 2.$SwitchMap$com$airbnb$lottie$model$content$Mask$MaskMode[mask.getMaskMode().ordinal()];
            if (n3 != 1) {
                if ((n3 == 2 || n3 == 3) && mask.isInverted()) {
                    return;
                }
                this.path.computeBounds(this.tempMaskBoundsRect, false);
                if (i2 == 0) {
                    this.maskBoundsRect.set(this.tempMaskBoundsRect);
                    continue;
                }
                RectF rectF2 = this.maskBoundsRect;
                rectF2.set(Math.min((float)rectF2.left, (float)this.tempMaskBoundsRect.left), Math.min((float)this.maskBoundsRect.top, (float)this.tempMaskBoundsRect.top), Math.max((float)this.maskBoundsRect.right, (float)this.tempMaskBoundsRect.right), Math.max((float)this.maskBoundsRect.bottom, (float)this.tempMaskBoundsRect.bottom));
                continue;
            }
            return;
        }
        if (!rectF.intersect(this.maskBoundsRect)) {
            rectF.set(0.0f, 0.0f, 0.0f, 0.0f);
        }
    }

    private void intersectBoundsWithMatte(RectF rectF, Matrix matrix) {
        if (!this.hasMatteOnThisLayer()) {
            return;
        }
        if (this.layerModel.getMatteType() == Layer.MatteType.INVERT) {
            return;
        }
        this.matteBoundsRect.set(0.0f, 0.0f, 0.0f, 0.0f);
        this.matteLayer.getBounds(this.matteBoundsRect, matrix, true);
        if (!rectF.intersect(this.matteBoundsRect)) {
            rectF.set(0.0f, 0.0f, 0.0f, 0.0f);
        }
    }

    private void invalidateSelf() {
        this.lottieDrawable.invalidateSelf();
    }

    private void recordRenderTime(float f2) {
        this.lottieDrawable.getComposition().getPerformanceTracker().recordRenderTime(this.layerModel.getName(), f2);
    }

    private void saveLayerCompat(Canvas canvas, RectF rectF, Paint paint, boolean bl) {
        if (Build.VERSION.SDK_INT < 23) {
            int n2 = bl ? 31 : 19;
            canvas.saveLayer(rectF, paint, n2);
            return;
        }
        canvas.saveLayer(rectF, paint);
    }

    private void setVisible(boolean bl) {
        if (bl != this.visible) {
            this.visible = bl;
            this.invalidateSelf();
        }
    }

    private void setupInOutAnimations() {
        boolean bl = this.layerModel.getInOutKeyframes().isEmpty();
        boolean bl2 = true;
        if (!bl) {
            final FloatKeyframeAnimation floatKeyframeAnimation = new FloatKeyframeAnimation((List<Keyframe<Float>>)this.layerModel.getInOutKeyframes());
            floatKeyframeAnimation.setIsDiscrete();
            floatKeyframeAnimation.addUpdateListener(new BaseKeyframeAnimation.AnimationListener(){

                public void onValueChanged() {
                    BaseLayer baseLayer = BaseLayer.this;
                    boolean bl = floatKeyframeAnimation.getFloatValue() == 1.0f;
                    baseLayer.setVisible(bl);
                }
            });
            if (((Float)floatKeyframeAnimation.getValue()).floatValue() != 1.0f) {
                bl2 = false;
            }
            this.setVisible(bl2);
            this.addAnimation(floatKeyframeAnimation);
            return;
        }
        this.setVisible(bl2);
    }

    public void addAnimation(BaseKeyframeAnimation<?, ?> baseKeyframeAnimation) {
        if (baseKeyframeAnimation == null) {
            return;
        }
        this.animations.add(baseKeyframeAnimation);
    }

    public <T> void addValueCallback(T t2, LottieValueCallback<T> lottieValueCallback) {
        this.transform.applyValueCallback(t2, lottieValueCallback);
    }

    @Override
    public void draw(Canvas canvas, Matrix matrix, int n2) {
        L.beginSection((String)this.drawTraceName);
        if (this.visible && !this.layerModel.isHidden()) {
            this.buildParentLayerListIfNeeded();
            L.beginSection((String)"Layer#parentMatrix");
            this.matrix.reset();
            this.matrix.set(matrix);
            for (int i2 = this.parentLayers.size() - 1; i2 >= 0; --i2) {
                this.matrix.preConcat(((BaseLayer)this.parentLayers.get((int)i2)).transform.getMatrix());
            }
            L.endSection((String)"Layer#parentMatrix");
            int n3 = this.transform.getOpacity() == null ? 100 : (Integer)this.transform.getOpacity().getValue();
            int n4 = (int)(255.0f * ((float)n2 / 255.0f * (float)n3 / 100.0f));
            if (!this.hasMatteOnThisLayer() && !this.hasMasksOnThisLayer()) {
                this.matrix.preConcat(this.transform.getMatrix());
                L.beginSection((String)"Layer#drawLayer");
                this.drawLayer(canvas, this.matrix, n4);
                L.endSection((String)"Layer#drawLayer");
                this.recordRenderTime(L.endSection((String)this.drawTraceName));
                return;
            }
            L.beginSection((String)"Layer#computeBounds");
            this.getBounds(this.rect, this.matrix, false);
            this.intersectBoundsWithMatte(this.rect, matrix);
            this.matrix.preConcat(this.transform.getMatrix());
            this.intersectBoundsWithMask(this.rect, this.matrix);
            if (!this.rect.intersect(0.0f, 0.0f, (float)canvas.getWidth(), (float)canvas.getHeight())) {
                this.rect.set(0.0f, 0.0f, 0.0f, 0.0f);
            }
            L.endSection((String)"Layer#computeBounds");
            if (!this.rect.isEmpty()) {
                L.beginSection((String)"Layer#saveLayer");
                this.saveLayerCompat(canvas, this.rect, this.contentPaint, true);
                L.endSection((String)"Layer#saveLayer");
                this.clearCanvas(canvas);
                L.beginSection((String)"Layer#drawLayer");
                this.drawLayer(canvas, this.matrix, n4);
                L.endSection((String)"Layer#drawLayer");
                if (this.hasMasksOnThisLayer()) {
                    this.applyMasks(canvas, this.matrix);
                }
                if (this.hasMatteOnThisLayer()) {
                    L.beginSection((String)"Layer#drawMatte");
                    L.beginSection((String)"Layer#saveLayer");
                    this.saveLayerCompat(canvas, this.rect, this.mattePaint, false);
                    L.endSection((String)"Layer#saveLayer");
                    this.clearCanvas(canvas);
                    this.matteLayer.draw(canvas, matrix, n4);
                    L.beginSection((String)"Layer#restoreLayer");
                    canvas.restore();
                    L.endSection((String)"Layer#restoreLayer");
                    L.endSection((String)"Layer#drawMatte");
                }
                L.beginSection((String)"Layer#restoreLayer");
                canvas.restore();
                L.endSection((String)"Layer#restoreLayer");
            }
            this.recordRenderTime(L.endSection((String)this.drawTraceName));
            return;
        }
        L.endSection((String)this.drawTraceName);
    }

    abstract void drawLayer(Canvas var1, Matrix var2, int var3);

    @Override
    public void getBounds(RectF rectF, Matrix matrix, boolean bl) {
        this.rect.set(0.0f, 0.0f, 0.0f, 0.0f);
        this.buildParentLayerListIfNeeded();
        this.boundsMatrix.set(matrix);
        if (bl) {
            List<BaseLayer> list = this.parentLayers;
            if (list != null) {
                for (int i2 = -1 + list.size(); i2 >= 0; --i2) {
                    this.boundsMatrix.preConcat(((BaseLayer)this.parentLayers.get((int)i2)).transform.getMatrix());
                }
            } else {
                BaseLayer baseLayer = this.parentLayer;
                if (baseLayer != null) {
                    this.boundsMatrix.preConcat(baseLayer.transform.getMatrix());
                }
            }
        }
        this.boundsMatrix.preConcat(this.transform.getMatrix());
    }

    Layer getLayerModel() {
        return this.layerModel;
    }

    public String getName() {
        return this.layerModel.getName();
    }

    boolean hasMasksOnThisLayer() {
        MaskKeyframeAnimation maskKeyframeAnimation = this.mask;
        return maskKeyframeAnimation != null && !maskKeyframeAnimation.getMaskAnimations().isEmpty();
    }

    boolean hasMatteOnThisLayer() {
        return this.matteLayer != null;
    }

    public void onValueChanged() {
        this.invalidateSelf();
    }

    public void removeAnimation(BaseKeyframeAnimation<?, ?> baseKeyframeAnimation) {
        this.animations.remove(baseKeyframeAnimation);
    }

    void resolveChildKeyPath(KeyPath keyPath, int n2, List<KeyPath> list, KeyPath keyPath2) {
    }

    public void resolveKeyPath(KeyPath keyPath, int n2, List<KeyPath> list, KeyPath keyPath2) {
        if (!keyPath.matches(this.getName(), n2)) {
            return;
        }
        if (!"__container".equals((Object)this.getName())) {
            keyPath2 = keyPath2.addKey(this.getName());
            if (keyPath.fullyResolvesTo(this.getName(), n2)) {
                list.add((Object)keyPath2.resolve((KeyPathElement)this));
            }
        }
        if (keyPath.propagateToChildren(this.getName(), n2)) {
            this.resolveChildKeyPath(keyPath, n2 + keyPath.incrementDepthBy(this.getName(), n2), list, keyPath2);
        }
    }

    public void setContents(List<Content> list, List<Content> list2) {
    }

    void setMatteLayer(BaseLayer baseLayer) {
        this.matteLayer = baseLayer;
    }

    void setParentLayer(BaseLayer baseLayer) {
        this.parentLayer = baseLayer;
    }

    void setProgress(float f2) {
        this.transform.setProgress(f2);
        if (this.mask != null) {
            for (int i2 = 0; i2 < this.mask.getMaskAnimations().size(); ++i2) {
                ((BaseKeyframeAnimation)this.mask.getMaskAnimations().get(i2)).setProgress(f2);
            }
        }
        if (this.layerModel.getTimeStretch() != 0.0f) {
            f2 /= this.layerModel.getTimeStretch();
        }
        BaseLayer baseLayer = this.matteLayer;
        int n2 = 0;
        if (baseLayer != null) {
            float f3 = baseLayer.layerModel.getTimeStretch();
            this.matteLayer.setProgress(f3 * f2);
        }
        while (n2 < this.animations.size()) {
            ((BaseKeyframeAnimation)this.animations.get(n2)).setProgress(f2);
            ++n2;
        }
    }

}

