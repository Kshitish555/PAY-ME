/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 */
package com.airbnb.lottie;

@Deprecated
public interface Cancellable {
    public void cancel();
}

