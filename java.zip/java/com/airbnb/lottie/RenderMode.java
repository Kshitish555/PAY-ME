/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie;

public final class RenderMode
extends Enum<RenderMode> {
    private static final /* synthetic */ RenderMode[] $VALUES;
    public static final /* enum */ RenderMode AUTOMATIC = new RenderMode();
    public static final /* enum */ RenderMode HARDWARE = new RenderMode();
    public static final /* enum */ RenderMode SOFTWARE = new RenderMode();

    static {
        RenderMode[] arrrenderMode = new RenderMode[]{AUTOMATIC, HARDWARE, SOFTWARE};
        $VALUES = arrrenderMode;
    }

    public static RenderMode valueOf(String string2) {
        return (RenderMode)Enum.valueOf(RenderMode.class, (String)string2);
    }

    public static RenderMode[] values() {
        return (RenderMode[])$VALUES.clone();
    }
}

