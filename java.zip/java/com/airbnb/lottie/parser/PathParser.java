/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  com.airbnb.lottie.parser.JsonUtils
 *  com.airbnb.lottie.parser.ValueParser
 *  com.airbnb.lottie.parser.moshi.JsonReader
 *  java.io.IOException
 *  java.lang.Object
 */
package com.airbnb.lottie.parser;

import android.graphics.PointF;
import com.airbnb.lottie.parser.JsonUtils;
import com.airbnb.lottie.parser.ValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import java.io.IOException;

public class PathParser
implements ValueParser<PointF> {
    public static final PathParser INSTANCE = new PathParser();

    private PathParser() {
    }

    public PointF parse(JsonReader jsonReader, float f2) throws IOException {
        return JsonUtils.jsonToPoint((JsonReader)jsonReader, (float)f2);
    }
}

