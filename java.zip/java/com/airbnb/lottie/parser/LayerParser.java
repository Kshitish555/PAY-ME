/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  android.graphics.Rect
 *  android.view.animation.Interpolator
 *  java.io.IOException
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 */
package com.airbnb.lottie.parser;

import android.graphics.Color;
import android.graphics.Rect;
import android.view.animation.Interpolator;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableTextFrame;
import com.airbnb.lottie.model.animatable.AnimatableTextProperties;
import com.airbnb.lottie.model.animatable.AnimatableTransform;
import com.airbnb.lottie.model.content.ContentModel;
import com.airbnb.lottie.model.content.Mask;
import com.airbnb.lottie.model.layer.Layer;
import com.airbnb.lottie.parser.AnimatableTextPropertiesParser;
import com.airbnb.lottie.parser.AnimatableTransformParser;
import com.airbnb.lottie.parser.AnimatableValueParser;
import com.airbnb.lottie.parser.ContentModelParser;
import com.airbnb.lottie.parser.MaskParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.utils.Utils;
import com.airbnb.lottie.value.Keyframe;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LayerParser {
    private static final JsonReader.Options EFFECTS_NAMES;
    private static final JsonReader.Options NAMES;
    private static final JsonReader.Options TEXT_NAMES;

    static {
        NAMES = JsonReader.Options.of("nm", "ind", "refId", "ty", "parent", "sw", "sh", "sc", "ks", "tt", "masksProperties", "shapes", "t", "ef", "sr", "st", "w", "h", "ip", "op", "tm", "cl", "hd");
        TEXT_NAMES = JsonReader.Options.of("d", "a");
        EFFECTS_NAMES = JsonReader.Options.of("nm");
    }

    private LayerParser() {
    }

    public static Layer parse(LottieComposition lottieComposition) {
        Rect rect = lottieComposition.getBounds();
        Layer layer = new Layer((List<ContentModel>)Collections.emptyList(), lottieComposition, "__container", -1L, Layer.LayerType.PRE_COMP, -1L, null, (List<Mask>)Collections.emptyList(), new AnimatableTransform(), 0, 0, 0, 0.0f, 0.0f, rect.width(), rect.height(), null, null, (List<Keyframe<Float>>)Collections.emptyList(), Layer.MatteType.NONE, null, false);
        return layer;
    }

    public static Layer parse(JsonReader jsonReader, LottieComposition lottieComposition) throws IOException {
        float f;
        ArrayList arrayList;
        Layer.MatteType matteType = Layer.MatteType.NONE;
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        jsonReader.beginObject();
        Float f2 = Float.valueOf((float)1.0f);
        Float f3 = Float.valueOf((float)0.0f);
        Layer.MatteType matteType2 = matteType;
        Layer.LayerType layerType = null;
        String string2 = null;
        AnimatableTransform animatableTransform = null;
        AnimatableTextFrame animatableTextFrame = null;
        AnimatableTextProperties animatableTextProperties = null;
        AnimatableFloatValue animatableFloatValue = null;
        long l = -1L;
        float f4 = 0.0f;
        float f5 = 0.0f;
        float f6 = 1.0f;
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        float f7 = 0.0f;
        boolean bl = false;
        long l2 = 0L;
        String string3 = null;
        String string4 = "UNSET";
        block25 : while (jsonReader.hasNext()) {
            switch (jsonReader.selectName(NAMES)) {
                default: {
                    jsonReader.skipName();
                    jsonReader.skipValue();
                    continue block25;
                }
                case 22: {
                    bl = jsonReader.nextBoolean();
                    continue block25;
                }
                case 21: {
                    string3 = jsonReader.nextString();
                    continue block25;
                }
                case 20: {
                    animatableFloatValue = AnimatableValueParser.parseFloat(jsonReader, lottieComposition, false);
                    continue block25;
                }
                case 19: {
                    f5 = (float)jsonReader.nextDouble();
                    continue block25;
                }
                case 18: {
                    f4 = (float)jsonReader.nextDouble();
                    continue block25;
                }
                case 17: {
                    n5 = (int)((float)jsonReader.nextInt() * Utils.dpScale());
                    continue block25;
                }
                case 16: {
                    n4 = (int)((float)jsonReader.nextInt() * Utils.dpScale());
                    continue block25;
                }
                case 15: {
                    f7 = (float)jsonReader.nextDouble();
                    continue block25;
                }
                case 14: {
                    f6 = (float)jsonReader.nextDouble();
                    continue block25;
                }
                case 13: {
                    jsonReader.beginArray();
                    ArrayList arrayList4 = new ArrayList();
                    while (jsonReader.hasNext()) {
                        jsonReader.beginObject();
                        while (jsonReader.hasNext()) {
                            if (jsonReader.selectName(EFFECTS_NAMES) != 0) {
                                jsonReader.skipName();
                                jsonReader.skipValue();
                                continue;
                            }
                            arrayList4.add((Object)jsonReader.nextString());
                        }
                        jsonReader.endObject();
                    }
                    jsonReader.endArray();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Lottie doesn't support layer effects. If you are using them for  fills, strokes, trim paths etc. then try adding them directly as contents  in your shape. Found: ");
                    stringBuilder.append((Object)arrayList4);
                    lottieComposition.addWarning(stringBuilder.toString());
                    continue block25;
                }
                case 12: {
                    jsonReader.beginObject();
                    while (jsonReader.hasNext()) {
                        int n6 = jsonReader.selectName(TEXT_NAMES);
                        if (n6 != 0) {
                            if (n6 != 1) {
                                jsonReader.skipName();
                                jsonReader.skipValue();
                                continue;
                            }
                            jsonReader.beginArray();
                            if (jsonReader.hasNext()) {
                                animatableTextProperties = AnimatableTextPropertiesParser.parse(jsonReader, lottieComposition);
                            }
                            while (jsonReader.hasNext()) {
                                jsonReader.skipValue();
                            }
                            jsonReader.endArray();
                            continue;
                        }
                        animatableTextFrame = AnimatableValueParser.parseDocumentData(jsonReader, lottieComposition);
                    }
                    jsonReader.endObject();
                    continue block25;
                }
                case 11: {
                    jsonReader.beginArray();
                    while (jsonReader.hasNext()) {
                        ContentModel contentModel = ContentModelParser.parse(jsonReader, lottieComposition);
                        if (contentModel == null) continue;
                        arrayList3.add((Object)contentModel);
                    }
                    jsonReader.endArray();
                    continue block25;
                }
                case 10: {
                    jsonReader.beginArray();
                    while (jsonReader.hasNext()) {
                        arrayList2.add((Object)MaskParser.parse(jsonReader, lottieComposition));
                    }
                    lottieComposition.incrementMatteOrMaskCount(arrayList2.size());
                    jsonReader.endArray();
                    continue block25;
                }
                case 9: {
                    matteType2 = Layer.MatteType.values()[jsonReader.nextInt()];
                    lottieComposition.incrementMatteOrMaskCount(1);
                    continue block25;
                }
                case 8: {
                    animatableTransform = AnimatableTransformParser.parse(jsonReader, lottieComposition);
                    continue block25;
                }
                case 7: {
                    n3 = Color.parseColor((String)jsonReader.nextString());
                    continue block25;
                }
                case 6: {
                    n2 = (int)((float)jsonReader.nextInt() * Utils.dpScale());
                    continue block25;
                }
                case 5: {
                    n = (int)((float)jsonReader.nextInt() * Utils.dpScale());
                    continue block25;
                }
                case 4: {
                    l = jsonReader.nextInt();
                    continue block25;
                }
                case 3: {
                    int n7 = jsonReader.nextInt();
                    if (n7 < Layer.LayerType.UNKNOWN.ordinal()) {
                        layerType = Layer.LayerType.values()[n7];
                        continue block25;
                    }
                    layerType = Layer.LayerType.UNKNOWN;
                    continue block25;
                }
                case 2: {
                    string2 = jsonReader.nextString();
                    continue block25;
                }
                case 1: {
                    l2 = jsonReader.nextInt();
                    continue block25;
                }
                case 0: 
            }
            string4 = jsonReader.nextString();
        }
        jsonReader.endObject();
        float f8 = f4 / f6;
        float f9 = f5 / f6;
        ArrayList arrayList5 = new ArrayList();
        if (f8 > 0.0f) {
            Float f10 = Float.valueOf((float)f8);
            f = f6;
            arrayList = arrayList5;
            Keyframe<Float> keyframe = new Keyframe<Float>(lottieComposition, f3, f3, null, 0.0f, f10);
            arrayList.add(keyframe);
        } else {
            f = f6;
            arrayList = arrayList5;
        }
        if (!(f9 > 0.0f)) {
            f9 = lottieComposition.getEndFrame();
        }
        Keyframe<Float> keyframe = new Keyframe<Float>(lottieComposition, f2, f2, null, f8, Float.valueOf((float)f9));
        arrayList.add(keyframe);
        Float f11 = Float.valueOf((float)Float.MAX_VALUE);
        Keyframe<Float> keyframe2 = new Keyframe<Float>(lottieComposition, f3, f3, null, f9, f11);
        arrayList.add(keyframe2);
        if (string4.endsWith(".ai") || "ai".equals((Object)string3)) {
            lottieComposition.addWarning("Convert your Illustrator layers to shape layers.");
        }
        String string5 = string4;
        long l3 = l2;
        Layer.LayerType layerType2 = layerType;
        long l4 = l;
        String string6 = string2;
        AnimatableTransform animatableTransform2 = animatableTransform;
        int n8 = n;
        int n9 = n2;
        int n10 = n3;
        ArrayList arrayList6 = arrayList;
        Layer layer = new Layer((List<ContentModel>)arrayList3, lottieComposition, string5, l3, layerType2, l4, string6, (List<Mask>)arrayList2, animatableTransform2, n8, n9, n10, f, f7, n4, n5, animatableTextFrame, animatableTextProperties, (List<Keyframe<Float>>)arrayList6, matteType2, animatableFloatValue, bl);
        return layer;
    }
}

