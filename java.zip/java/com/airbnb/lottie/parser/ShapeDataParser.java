/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  com.airbnb.lottie.model.CubicCurveData
 *  com.airbnb.lottie.model.content.ShapeData
 *  com.airbnb.lottie.parser.JsonUtils
 *  com.airbnb.lottie.parser.ValueParser
 *  com.airbnb.lottie.parser.moshi.JsonReader
 *  com.airbnb.lottie.parser.moshi.JsonReader$Options
 *  com.airbnb.lottie.parser.moshi.JsonReader$Token
 *  com.airbnb.lottie.utils.MiscUtils
 *  java.io.IOException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 */
package com.airbnb.lottie.parser;

import android.graphics.PointF;
import com.airbnb.lottie.model.CubicCurveData;
import com.airbnb.lottie.model.content.ShapeData;
import com.airbnb.lottie.parser.JsonUtils;
import com.airbnb.lottie.parser.ValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.utils.MiscUtils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ShapeDataParser
implements ValueParser<ShapeData> {
    public static final ShapeDataParser INSTANCE = new ShapeDataParser();
    private static final JsonReader.Options NAMES = JsonReader.Options.of((String[])new String[]{"c", "v", "i", "o"});

    private ShapeDataParser() {
    }

    public ShapeData parse(JsonReader jsonReader, float f2) throws IOException {
        IllegalArgumentException illegalArgumentException;
        if (jsonReader.peek() == JsonReader.Token.BEGIN_ARRAY) {
            jsonReader.beginArray();
        }
        jsonReader.beginObject();
        List list = null;
        List list2 = null;
        List list3 = null;
        boolean bl = false;
        while (jsonReader.hasNext()) {
            int n2 = jsonReader.selectName(NAMES);
            if (n2 != 0) {
                if (n2 != 1) {
                    if (n2 != 2) {
                        if (n2 != 3) {
                            jsonReader.skipName();
                            jsonReader.skipValue();
                            continue;
                        }
                        list3 = JsonUtils.jsonToPoints((JsonReader)jsonReader, (float)f2);
                        continue;
                    }
                    list2 = JsonUtils.jsonToPoints((JsonReader)jsonReader, (float)f2);
                    continue;
                }
                list = JsonUtils.jsonToPoints((JsonReader)jsonReader, (float)f2);
                continue;
            }
            bl = jsonReader.nextBoolean();
        }
        jsonReader.endObject();
        if (jsonReader.peek() == JsonReader.Token.END_ARRAY) {
            jsonReader.endArray();
        }
        if (list != null && list2 != null && list3 != null) {
            if (list.isEmpty()) {
                return new ShapeData(new PointF(), false, Collections.emptyList());
            }
            int n3 = list.size();
            PointF pointF = (PointF)list.get(0);
            ArrayList arrayList = new ArrayList(n3);
            for (int i2 = 1; i2 < n3; ++i2) {
                PointF pointF2 = (PointF)list.get(i2);
                int n4 = i2 - 1;
                PointF pointF3 = (PointF)list.get(n4);
                PointF pointF4 = (PointF)list3.get(n4);
                PointF pointF5 = (PointF)list2.get(i2);
                arrayList.add((Object)new CubicCurveData(MiscUtils.addPoints((PointF)pointF3, (PointF)pointF4), MiscUtils.addPoints((PointF)pointF2, (PointF)pointF5), pointF2));
            }
            if (bl) {
                PointF pointF6 = (PointF)list.get(0);
                int n5 = n3 - 1;
                PointF pointF7 = (PointF)list.get(n5);
                PointF pointF8 = (PointF)list3.get(n5);
                PointF pointF9 = (PointF)list2.get(0);
                arrayList.add((Object)new CubicCurveData(MiscUtils.addPoints((PointF)pointF7, (PointF)pointF8), MiscUtils.addPoints((PointF)pointF6, (PointF)pointF9), pointF6));
            }
            return new ShapeData(pointF, bl, (List)arrayList);
        }
        illegalArgumentException = new IllegalArgumentException("Shape data was missing information.");
        throw illegalArgumentException;
    }
}

