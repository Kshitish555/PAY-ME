/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.parser.JsonUtils
 *  com.airbnb.lottie.parser.ValueParser
 *  com.airbnb.lottie.parser.moshi.JsonReader
 *  java.io.IOException
 *  java.lang.Float
 *  java.lang.Object
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.parser.JsonUtils;
import com.airbnb.lottie.parser.ValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import java.io.IOException;

public class FloatParser
implements ValueParser<Float> {
    public static final FloatParser INSTANCE = new FloatParser();

    private FloatParser() {
    }

    public Float parse(JsonReader jsonReader, float f2) throws IOException {
        return Float.valueOf((float)(f2 * JsonUtils.valueFromObject((JsonReader)jsonReader)));
    }
}

