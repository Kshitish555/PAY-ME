/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.model.content.ContentModel;
import com.airbnb.lottie.parser.AnimatableTransformParser;
import com.airbnb.lottie.parser.CircleShapeParser;
import com.airbnb.lottie.parser.GradientFillParser;
import com.airbnb.lottie.parser.GradientStrokeParser;
import com.airbnb.lottie.parser.MergePathsParser;
import com.airbnb.lottie.parser.PolystarShapeParser;
import com.airbnb.lottie.parser.RectangleShapeParser;
import com.airbnb.lottie.parser.RepeaterParser;
import com.airbnb.lottie.parser.ShapeFillParser;
import com.airbnb.lottie.parser.ShapeGroupParser;
import com.airbnb.lottie.parser.ShapePathParser;
import com.airbnb.lottie.parser.ShapeStrokeParser;
import com.airbnb.lottie.parser.ShapeTrimPathParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.utils.Logger;
import java.io.IOException;

class ContentModelParser {
    private static JsonReader.Options NAMES = JsonReader.Options.of("ty", "d");

    private ContentModelParser() {
    }

    static ContentModel parse(JsonReader jsonReader, LottieComposition lottieComposition) throws IOException {
        int n;
        String string2;
        int n2;
        ContentModel contentModel;
        block36 : {
            block35 : {
                jsonReader.beginObject();
                n2 = 2;
                n = 2;
                while (jsonReader.hasNext()) {
                    int n3 = jsonReader.selectName(NAMES);
                    if (n3 != 0) {
                        if (n3 != 1) {
                            jsonReader.skipName();
                            jsonReader.skipValue();
                            continue;
                        }
                        n = jsonReader.nextInt();
                        continue;
                    }
                    string2 = jsonReader.nextString();
                    break block35;
                }
                string2 = null;
            }
            if (string2 == null) {
                return null;
            }
            switch (string2.hashCode()) {
                default: {
                    break;
                }
                case 3710: {
                    if (!string2.equals((Object)"tr")) break;
                    n2 = 5;
                    break block36;
                }
                case 3705: {
                    if (!string2.equals((Object)"tm")) break;
                    n2 = 9;
                    break block36;
                }
                case 3681: {
                    if (!string2.equals((Object)"st")) break;
                    n2 = 1;
                    break block36;
                }
                case 3679: {
                    if (!string2.equals((Object)"sr")) break;
                    n2 = 10;
                    break block36;
                }
                case 3669: {
                    if (!string2.equals((Object)"sh")) break;
                    n2 = 6;
                    break block36;
                }
                case 3646: {
                    if (!string2.equals((Object)"rp")) break;
                    n2 = 12;
                    break block36;
                }
                case 3633: {
                    if (!string2.equals((Object)"rc")) break;
                    n2 = 8;
                    break block36;
                }
                case 3488: {
                    if (!string2.equals((Object)"mm")) break;
                    n2 = 11;
                    break block36;
                }
                case 3308: {
                    if (!string2.equals((Object)"gs")) break;
                    break block36;
                }
                case 3307: {
                    if (!string2.equals((Object)"gr")) break;
                    n2 = 0;
                    break block36;
                }
                case 3295: {
                    if (!string2.equals((Object)"gf")) break;
                    n2 = 4;
                    break block36;
                }
                case 3270: {
                    if (!string2.equals((Object)"fl")) break;
                    n2 = 3;
                    break block36;
                }
                case 3239: {
                    if (!string2.equals((Object)"el")) break;
                    n2 = 7;
                    break block36;
                }
            }
            n2 = -1;
        }
        switch (n2) {
            default: {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unknown shape type ");
                stringBuilder.append(string2);
                Logger.warning(stringBuilder.toString());
                contentModel = null;
                break;
            }
            case 12: {
                contentModel = RepeaterParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 11: {
                contentModel = MergePathsParser.parse(jsonReader);
                lottieComposition.addWarning("Animation contains merge paths. Merge paths are only supported on KitKat+ and must be manually enabled by calling enableMergePathsForKitKatAndAbove().");
                break;
            }
            case 10: {
                contentModel = PolystarShapeParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 9: {
                contentModel = ShapeTrimPathParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 8: {
                contentModel = RectangleShapeParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 7: {
                contentModel = CircleShapeParser.parse(jsonReader, lottieComposition, n);
                break;
            }
            case 6: {
                contentModel = ShapePathParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 5: {
                contentModel = AnimatableTransformParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 4: {
                contentModel = GradientFillParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 3: {
                contentModel = ShapeFillParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 2: {
                contentModel = GradientStrokeParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 1: {
                contentModel = ShapeStrokeParser.parse(jsonReader, lottieComposition);
                break;
            }
            case 0: {
                contentModel = ShapeGroupParser.parse(jsonReader, lottieComposition);
            }
        }
        while (jsonReader.hasNext()) {
            jsonReader.skipValue();
        }
        jsonReader.endObject();
        return contentModel;
    }
}

