/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  com.airbnb.lottie.model.content.GradientColor
 *  com.airbnb.lottie.parser.ValueParser
 *  com.airbnb.lottie.parser.moshi.JsonReader
 *  com.airbnb.lottie.parser.moshi.JsonReader$Token
 *  com.airbnb.lottie.utils.MiscUtils
 *  java.io.IOException
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.List
 */
package com.airbnb.lottie.parser;

import android.graphics.Color;
import com.airbnb.lottie.model.content.GradientColor;
import com.airbnb.lottie.parser.ValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.utils.MiscUtils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GradientColorParser
implements ValueParser<GradientColor> {
    private int colorPoints;

    public GradientColorParser(int n2) {
        this.colorPoints = n2;
    }

    private void addOpacityStopsToGradientIfNeeded(GradientColor gradientColor, List<Float> list) {
        int n2 = 4 * this.colorPoints;
        if (list.size() <= n2) {
            return;
        }
        int n3 = (list.size() - n2) / 2;
        double[] arrd = new double[n3];
        double[] arrd2 = new double[n3];
        int n4 = 0;
        do {
            int n5 = list.size();
            if (n2 >= n5) break;
            if (n2 % 2 == 0) {
                arrd[n4] = ((Float)list.get(n2)).floatValue();
            } else {
                arrd2[n4] = ((Float)list.get(n2)).floatValue();
                ++n4;
            }
            ++n2;
        } while (true);
        for (int i2 = 0; i2 < gradientColor.getSize(); ++i2) {
            int n6;
            int n7 = gradientColor.getColors()[i2];
            gradientColor.getColors()[i2] = n6 = Color.argb((int)this.getOpacityAtPosition(gradientColor.getPositions()[i2], arrd, arrd2), (int)Color.red((int)n7), (int)Color.green((int)n7), (int)Color.blue((int)n7));
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int getOpacityAtPosition(double d2, double[] arrd, double[] arrd2) {
        double d3;
        for (int i2 = 1; i2 < arrd.length; ++i2) {
            int n2 = i2 - 1;
            double d4 = arrd[n2];
            double d5 = arrd[i2];
            if (!(arrd[i2] >= d2)) continue;
            double d6 = (d2 - d4) / (d5 - d4);
            d3 = MiscUtils.lerp((double)arrd2[n2], (double)arrd2[i2], (double)d6);
            do {
                return (int)(d3 * 255.0);
                break;
            } while (true);
        }
        d3 = arrd2[arrd2.length - 1];
        return (int)(d3 * 255.0);
    }

    public GradientColor parse(JsonReader jsonReader, float f2) throws IOException {
        ArrayList arrayList = new ArrayList();
        JsonReader.Token token = jsonReader.peek();
        JsonReader.Token token2 = JsonReader.Token.BEGIN_ARRAY;
        int n2 = 0;
        boolean bl = token == token2;
        if (bl) {
            jsonReader.beginArray();
        }
        while (jsonReader.hasNext()) {
            arrayList.add((Object)Float.valueOf((float)((float)jsonReader.nextDouble())));
        }
        if (bl) {
            jsonReader.endArray();
        }
        if (this.colorPoints == -1) {
            this.colorPoints = arrayList.size() / 4;
        }
        int n3 = this.colorPoints;
        float[] arrf = new float[n3];
        int[] arrn = new int[n3];
        int n4 = 0;
        int n5 = 0;
        while (n2 < 4 * this.colorPoints) {
            int n6 = n2 / 4;
            double d2 = ((Float)arrayList.get(n2)).floatValue();
            int n7 = n2 % 4;
            if (n7 != 0) {
                if (n7 != 1) {
                    if (n7 != 2) {
                        if (n7 == 3) {
                            Double.isNaN((double)d2);
                            arrn[n6] = Color.argb((int)255, (int)n4, (int)n5, (int)((int)(d2 * 255.0)));
                        }
                    } else {
                        Double.isNaN((double)d2);
                        n5 = (int)(d2 * 255.0);
                    }
                } else {
                    Double.isNaN((double)d2);
                    n4 = (int)(d2 * 255.0);
                }
            } else {
                arrf[n6] = (float)d2;
            }
            ++n2;
        }
        GradientColor gradientColor = new GradientColor(arrf, arrn);
        this.addOpacityStopsToGradientIfNeeded(gradientColor, (List<Float>)arrayList);
        return gradientColor;
    }
}

