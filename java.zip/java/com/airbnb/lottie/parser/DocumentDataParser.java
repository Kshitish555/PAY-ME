/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.model.DocumentData
 *  com.airbnb.lottie.model.DocumentData$Justification
 *  com.airbnb.lottie.parser.JsonUtils
 *  com.airbnb.lottie.parser.ValueParser
 *  com.airbnb.lottie.parser.moshi.JsonReader
 *  com.airbnb.lottie.parser.moshi.JsonReader$Options
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.model.DocumentData;
import com.airbnb.lottie.parser.JsonUtils;
import com.airbnb.lottie.parser.ValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import java.io.IOException;

public class DocumentDataParser
implements ValueParser<DocumentData> {
    public static final DocumentDataParser INSTANCE = new DocumentDataParser();
    private static final JsonReader.Options NAMES = JsonReader.Options.of((String[])new String[]{"t", "f", "s", "j", "tr", "lh", "ls", "fc", "sc", "sw", "of"});

    private DocumentDataParser() {
    }

    public DocumentData parse(JsonReader jsonReader, float f2) throws IOException {
        double d2;
        double d3;
        double d4;
        DocumentData.Justification justification = DocumentData.Justification.CENTER;
        jsonReader.beginObject();
        DocumentData.Justification justification2 = justification;
        String string2 = null;
        String string3 = null;
        double d5 = d3 = (d2 = (d4 = 0.0));
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        boolean bl = true;
        block13 : while (jsonReader.hasNext()) {
            switch (jsonReader.selectName(NAMES)) {
                default: {
                    jsonReader.skipName();
                    jsonReader.skipValue();
                    continue block13;
                }
                case 10: {
                    bl = jsonReader.nextBoolean();
                    continue block13;
                }
                case 9: {
                    d5 = jsonReader.nextDouble();
                    continue block13;
                }
                case 8: {
                    n4 = JsonUtils.jsonToColor((JsonReader)jsonReader);
                    continue block13;
                }
                case 7: {
                    n3 = JsonUtils.jsonToColor((JsonReader)jsonReader);
                    continue block13;
                }
                case 6: {
                    d3 = jsonReader.nextDouble();
                    continue block13;
                }
                case 5: {
                    d2 = jsonReader.nextDouble();
                    continue block13;
                }
                case 4: {
                    n2 = jsonReader.nextInt();
                    continue block13;
                }
                case 3: {
                    int n5 = jsonReader.nextInt();
                    if (n5 <= DocumentData.Justification.CENTER.ordinal() && n5 >= 0) {
                        justification2 = DocumentData.Justification.values()[n5];
                        continue block13;
                    }
                    justification2 = DocumentData.Justification.CENTER;
                    continue block13;
                }
                case 2: {
                    d4 = jsonReader.nextDouble();
                    continue block13;
                }
                case 1: {
                    string3 = jsonReader.nextString();
                    continue block13;
                }
                case 0: 
            }
            string2 = jsonReader.nextString();
        }
        jsonReader.endObject();
        DocumentData documentData = new DocumentData(string2, string3, d4, justification2, n2, d2, d3, n3, n4, d5, bl);
        return documentData;
    }
}

