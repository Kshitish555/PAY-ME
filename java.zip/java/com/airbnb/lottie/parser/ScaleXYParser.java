/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.parser.ValueParser
 *  com.airbnb.lottie.parser.moshi.JsonReader
 *  com.airbnb.lottie.parser.moshi.JsonReader$Token
 *  com.airbnb.lottie.value.ScaleXY
 *  java.io.IOException
 *  java.lang.Object
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.parser.ValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.value.ScaleXY;
import java.io.IOException;

public class ScaleXYParser
implements ValueParser<ScaleXY> {
    public static final ScaleXYParser INSTANCE = new ScaleXYParser();

    private ScaleXYParser() {
    }

    public ScaleXY parse(JsonReader jsonReader, float f2) throws IOException {
        boolean bl = jsonReader.peek() == JsonReader.Token.BEGIN_ARRAY;
        if (bl) {
            jsonReader.beginArray();
        }
        float f3 = (float)jsonReader.nextDouble();
        float f4 = (float)jsonReader.nextDouble();
        while (jsonReader.hasNext()) {
            jsonReader.skipValue();
        }
        if (bl) {
            jsonReader.endArray();
        }
        return new ScaleXY(f2 * (f3 / 100.0f), f2 * (f4 / 100.0f));
    }
}

