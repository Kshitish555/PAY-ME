/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Path
 *  android.graphics.RectF
 *  com.airbnb.lottie.LottieDrawable
 *  com.airbnb.lottie.animation.content.Content
 *  com.airbnb.lottie.animation.content.GreedyContent
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation$AnimationListener
 *  com.airbnb.lottie.animation.keyframe.TransformKeyframeAnimation
 *  com.airbnb.lottie.model.KeyPath
 *  com.airbnb.lottie.model.KeyPathElement
 *  com.airbnb.lottie.model.content.ContentModel
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  java.util.ListIterator
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.DrawingContent;
import com.airbnb.lottie.animation.content.GreedyContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.TransformKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.KeyPathElement;
import com.airbnb.lottie.model.animatable.AnimatableTransform;
import com.airbnb.lottie.model.content.ContentModel;
import com.airbnb.lottie.model.content.ShapeGroup;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.ListIterator;

public class ContentGroup
implements DrawingContent,
PathContent,
BaseKeyframeAnimation.AnimationListener,
KeyPathElement {
    private final List<Content> contents;
    private final boolean hidden;
    private final LottieDrawable lottieDrawable;
    private final Matrix matrix = new Matrix();
    private final String name;
    private final Path path = new Path();
    private List<PathContent> pathContents;
    private final RectF rect = new RectF();
    private TransformKeyframeAnimation transformAnimation;

    public ContentGroup(LottieDrawable lottieDrawable, BaseLayer baseLayer, ShapeGroup shapeGroup) {
        this(lottieDrawable, baseLayer, shapeGroup.getName(), shapeGroup.isHidden(), ContentGroup.contentsFromModels(lottieDrawable, baseLayer, shapeGroup.getItems()), ContentGroup.findTransform(shapeGroup.getItems()));
    }

    ContentGroup(LottieDrawable lottieDrawable, BaseLayer baseLayer, String string2, boolean bl, List<Content> list, AnimatableTransform animatableTransform) {
        this.name = string2;
        this.lottieDrawable = lottieDrawable;
        this.hidden = bl;
        this.contents = list;
        if (animatableTransform != null) {
            this.transformAnimation = animatableTransform.createAnimation();
            this.transformAnimation.addAnimationsToLayer(baseLayer);
            this.transformAnimation.addListener((BaseKeyframeAnimation.AnimationListener)this);
        }
        ArrayList arrayList = new ArrayList();
        for (int i2 = -1 + list.size(); i2 >= 0; --i2) {
            Content content = (Content)list.get(i2);
            if (!(content instanceof GreedyContent)) continue;
            arrayList.add((Object)((GreedyContent)content));
        }
        for (int i3 = -1 + arrayList.size(); i3 >= 0; --i3) {
            ((GreedyContent)arrayList.get(i3)).absorbContent(list.listIterator(list.size()));
        }
    }

    private static List<Content> contentsFromModels(LottieDrawable lottieDrawable, BaseLayer baseLayer, List<ContentModel> list) {
        ArrayList arrayList = new ArrayList(list.size());
        for (int i2 = 0; i2 < list.size(); ++i2) {
            Content content = ((ContentModel)list.get(i2)).toContent(lottieDrawable, baseLayer);
            if (content == null) continue;
            arrayList.add((Object)content);
        }
        return arrayList;
    }

    static AnimatableTransform findTransform(List<ContentModel> list) {
        for (int i2 = 0; i2 < list.size(); ++i2) {
            ContentModel contentModel = (ContentModel)list.get(i2);
            if (!(contentModel instanceof AnimatableTransform)) continue;
            return (AnimatableTransform)contentModel;
        }
        return null;
    }

    public <T> void addValueCallback(T t2, LottieValueCallback<T> lottieValueCallback) {
        TransformKeyframeAnimation transformKeyframeAnimation = this.transformAnimation;
        if (transformKeyframeAnimation != null) {
            transformKeyframeAnimation.applyValueCallback(t2, lottieValueCallback);
        }
    }

    @Override
    public void draw(Canvas canvas, Matrix matrix, int n2) {
        if (this.hidden) {
            return;
        }
        this.matrix.set(matrix);
        TransformKeyframeAnimation transformKeyframeAnimation = this.transformAnimation;
        if (transformKeyframeAnimation != null) {
            this.matrix.preConcat(transformKeyframeAnimation.getMatrix());
            int n3 = this.transformAnimation.getOpacity() == null ? 100 : (Integer)this.transformAnimation.getOpacity().getValue();
            n2 = (int)(255.0f * ((float)n3 / 100.0f * (float)n2 / 255.0f));
        }
        for (int i2 = -1 + this.contents.size(); i2 >= 0; --i2) {
            Object object = this.contents.get(i2);
            if (!(object instanceof DrawingContent)) continue;
            ((DrawingContent)object).draw(canvas, this.matrix, n2);
        }
    }

    @Override
    public void getBounds(RectF rectF, Matrix matrix, boolean bl) {
        this.matrix.set(matrix);
        TransformKeyframeAnimation transformKeyframeAnimation = this.transformAnimation;
        if (transformKeyframeAnimation != null) {
            this.matrix.preConcat(transformKeyframeAnimation.getMatrix());
        }
        this.rect.set(0.0f, 0.0f, 0.0f, 0.0f);
        for (int i2 = -1 + this.contents.size(); i2 >= 0; --i2) {
            Content content = (Content)this.contents.get(i2);
            if (!(content instanceof DrawingContent)) continue;
            ((DrawingContent)content).getBounds(this.rect, this.matrix, bl);
            rectF.union(this.rect);
        }
    }

    public String getName() {
        return this.name;
    }

    @Override
    public Path getPath() {
        this.matrix.reset();
        TransformKeyframeAnimation transformKeyframeAnimation = this.transformAnimation;
        if (transformKeyframeAnimation != null) {
            this.matrix.set(transformKeyframeAnimation.getMatrix());
        }
        this.path.reset();
        if (this.hidden) {
            return this.path;
        }
        for (int i2 = -1 + this.contents.size(); i2 >= 0; --i2) {
            Content content = (Content)this.contents.get(i2);
            if (!(content instanceof PathContent)) continue;
            this.path.addPath(((PathContent)content).getPath(), this.matrix);
        }
        return this.path;
    }

    List<PathContent> getPathList() {
        if (this.pathContents == null) {
            this.pathContents = new ArrayList();
            for (int i2 = 0; i2 < this.contents.size(); ++i2) {
                Content content = (Content)this.contents.get(i2);
                if (!(content instanceof PathContent)) continue;
                this.pathContents.add((Object)((PathContent)content));
            }
        }
        return this.pathContents;
    }

    Matrix getTransformationMatrix() {
        TransformKeyframeAnimation transformKeyframeAnimation = this.transformAnimation;
        if (transformKeyframeAnimation != null) {
            return transformKeyframeAnimation.getMatrix();
        }
        this.matrix.reset();
        return this.matrix;
    }

    public void onValueChanged() {
        this.lottieDrawable.invalidateSelf();
    }

    public void resolveKeyPath(KeyPath keyPath, int n2, List<KeyPath> list, KeyPath keyPath2) {
        if (!keyPath.matches(this.getName(), n2)) {
            return;
        }
        if (!"__container".equals((Object)this.getName())) {
            keyPath2 = keyPath2.addKey(this.getName());
            if (keyPath.fullyResolvesTo(this.getName(), n2)) {
                list.add((Object)keyPath2.resolve((KeyPathElement)this));
            }
        }
        if (keyPath.propagateToChildren(this.getName(), n2)) {
            int n3 = n2 + keyPath.incrementDepthBy(this.getName(), n2);
            for (int i2 = 0; i2 < this.contents.size(); ++i2) {
                Content content = (Content)this.contents.get(i2);
                if (!(content instanceof KeyPathElement)) continue;
                ((KeyPathElement)content).resolveKeyPath(keyPath, n3, list, keyPath2);
            }
        }
    }

    public void setContents(List<Content> list, List<Content> list2) {
        ArrayList arrayList = new ArrayList(list.size() + this.contents.size());
        arrayList.addAll(list);
        for (int i2 = -1 + this.contents.size(); i2 >= 0; --i2) {
            Content content = (Content)this.contents.get(i2);
            content.setContents((List)arrayList, this.contents.subList(0, i2));
            arrayList.add((Object)content);
        }
    }
}

