/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$FillType
 *  android.graphics.RectF
 *  com.airbnb.lottie.L
 *  com.airbnb.lottie.LottieDrawable
 *  com.airbnb.lottie.LottieProperty
 *  com.airbnb.lottie.animation.LPaint
 *  com.airbnb.lottie.animation.content.Content
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation$AnimationListener
 *  com.airbnb.lottie.model.KeyPath
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import com.airbnb.lottie.L;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.LPaint;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.DrawingContent;
import com.airbnb.lottie.animation.content.KeyPathElementContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.ColorKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.ValueCallbackKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.animatable.AnimatableColorValue;
import com.airbnb.lottie.model.animatable.AnimatableIntegerValue;
import com.airbnb.lottie.model.content.ShapeFill;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.List;

public class FillContent
implements DrawingContent,
BaseKeyframeAnimation.AnimationListener,
KeyPathElementContent {
    private final BaseKeyframeAnimation<Integer, Integer> colorAnimation;
    private BaseKeyframeAnimation<ColorFilter, ColorFilter> colorFilterAnimation;
    private final boolean hidden;
    private final BaseLayer layer;
    private final LottieDrawable lottieDrawable;
    private final String name;
    private final BaseKeyframeAnimation<Integer, Integer> opacityAnimation;
    private final Paint paint = new LPaint(1);
    private final Path path = new Path();
    private final List<PathContent> paths = new ArrayList();

    public FillContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, ShapeFill shapeFill) {
        this.layer = baseLayer;
        this.name = shapeFill.getName();
        this.hidden = shapeFill.isHidden();
        this.lottieDrawable = lottieDrawable;
        if (shapeFill.getColor() != null && shapeFill.getOpacity() != null) {
            this.path.setFillType(shapeFill.getFillType());
            this.colorAnimation = shapeFill.getColor().createAnimation();
            this.colorAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            baseLayer.addAnimation(this.colorAnimation);
            this.opacityAnimation = shapeFill.getOpacity().createAnimation();
            this.opacityAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            baseLayer.addAnimation(this.opacityAnimation);
            return;
        }
        this.colorAnimation = null;
        this.opacityAnimation = null;
    }

    public <T> void addValueCallback(T t2, LottieValueCallback<T> lottieValueCallback) {
        if (t2 == LottieProperty.COLOR) {
            this.colorAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.OPACITY) {
            this.opacityAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.COLOR_FILTER) {
            if (lottieValueCallback == null) {
                this.colorFilterAnimation = null;
                return;
            }
            this.colorFilterAnimation = new ValueCallbackKeyframeAnimation<ColorFilter, T>(lottieValueCallback);
            this.colorFilterAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            this.layer.addAnimation(this.colorFilterAnimation);
        }
    }

    @Override
    public void draw(Canvas canvas, Matrix matrix, int n2) {
        if (this.hidden) {
            return;
        }
        L.beginSection((String)"FillContent#draw");
        this.paint.setColor(((ColorKeyframeAnimation)this.colorAnimation).getIntValue());
        int n3 = (int)(255.0f * ((float)n2 / 255.0f * (float)((Integer)this.opacityAnimation.getValue()).intValue() / 100.0f));
        Paint paint = this.paint;
        int n4 = 0;
        paint.setAlpha(MiscUtils.clamp((int)n3, (int)0, (int)255));
        BaseKeyframeAnimation<ColorFilter, ColorFilter> baseKeyframeAnimation = this.colorFilterAnimation;
        if (baseKeyframeAnimation != null) {
            this.paint.setColorFilter((ColorFilter)baseKeyframeAnimation.getValue());
        }
        this.path.reset();
        while (n4 < this.paths.size()) {
            this.path.addPath(((PathContent)this.paths.get(n4)).getPath(), matrix);
            ++n4;
        }
        canvas.drawPath(this.path, this.paint);
        L.endSection((String)"FillContent#draw");
    }

    @Override
    public void getBounds(RectF rectF, Matrix matrix, boolean bl) {
        this.path.reset();
        for (int i2 = 0; i2 < this.paths.size(); ++i2) {
            this.path.addPath(((PathContent)this.paths.get(i2)).getPath(), matrix);
        }
        this.path.computeBounds(rectF, false);
        rectF.set(rectF.left - 1.0f, rectF.top - 1.0f, 1.0f + rectF.right, 1.0f + rectF.bottom);
    }

    public String getName() {
        return this.name;
    }

    public void onValueChanged() {
        this.lottieDrawable.invalidateSelf();
    }

    public void resolveKeyPath(KeyPath keyPath, int n2, List<KeyPath> list, KeyPath keyPath2) {
        MiscUtils.resolveKeyPath((KeyPath)keyPath, (int)n2, list, (KeyPath)keyPath2, (KeyPathElementContent)this);
    }

    public void setContents(List<Content> list, List<Content> list2) {
        for (int i2 = 0; i2 < list2.size(); ++i2) {
            Content content = (Content)list2.get(i2);
            if (!(content instanceof PathContent)) continue;
            this.paths.add((Object)((PathContent)content));
        }
    }
}

