/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.DashPathEffect
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Cap
 *  android.graphics.Paint$Join
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.PathEffect
 *  android.graphics.PathMeasure
 *  android.graphics.RectF
 *  com.airbnb.lottie.L
 *  com.airbnb.lottie.LottieDrawable
 *  com.airbnb.lottie.LottieProperty
 *  com.airbnb.lottie.animation.LPaint
 *  com.airbnb.lottie.animation.content.BaseStrokeContent$1
 *  com.airbnb.lottie.animation.content.BaseStrokeContent$PathGroup
 *  com.airbnb.lottie.animation.content.Content
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation$AnimationListener
 *  com.airbnb.lottie.model.KeyPath
 *  com.airbnb.lottie.model.content.ShapeTrimPath$Type
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.utils.Utils
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import com.airbnb.lottie.L;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.LPaint;
import com.airbnb.lottie.animation.content.BaseStrokeContent;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.DrawingContent;
import com.airbnb.lottie.animation.content.KeyPathElementContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.animation.content.TrimPathContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.FloatKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.IntegerKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.ValueCallbackKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableIntegerValue;
import com.airbnb.lottie.model.content.ShapeTrimPath;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.utils.Utils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 * Exception performing whole class analysis ignored.
 */
public abstract class BaseStrokeContent
implements BaseKeyframeAnimation.AnimationListener,
KeyPathElementContent,
DrawingContent {
    private BaseKeyframeAnimation<ColorFilter, ColorFilter> colorFilterAnimation;
    private final List<BaseKeyframeAnimation<?, Float>> dashPatternAnimations;
    private final BaseKeyframeAnimation<?, Float> dashPatternOffsetAnimation;
    private final float[] dashPatternValues;
    protected final BaseLayer layer;
    private final LottieDrawable lottieDrawable;
    private final BaseKeyframeAnimation<?, Integer> opacityAnimation;
    final Paint paint;
    private final Path path;
    private final List<PathGroup> pathGroups;
    private final PathMeasure pm;
    private final RectF rect;
    private final Path trimPathPath;
    private final BaseKeyframeAnimation<?, Float> widthAnimation;

    BaseStrokeContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, Paint.Cap cap, Paint.Join join, float f2, AnimatableIntegerValue animatableIntegerValue, AnimatableFloatValue animatableFloatValue, List<AnimatableFloatValue> list, AnimatableFloatValue animatableFloatValue2) {
        this.pm = new PathMeasure();
        this.path = new Path();
        this.trimPathPath = new Path();
        this.rect = new RectF();
        this.pathGroups = new ArrayList();
        this.paint = new LPaint(1);
        this.lottieDrawable = lottieDrawable;
        this.layer = baseLayer;
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeCap(cap);
        this.paint.setStrokeJoin(join);
        this.paint.setStrokeMiter(f2);
        this.opacityAnimation = animatableIntegerValue.createAnimation();
        this.widthAnimation = animatableFloatValue.createAnimation();
        this.dashPatternOffsetAnimation = animatableFloatValue2 == null ? null : animatableFloatValue2.createAnimation();
        this.dashPatternAnimations = new ArrayList(list.size());
        this.dashPatternValues = new float[list.size()];
        int n2 = 0;
        for (int i2 = 0; i2 < list.size(); ++i2) {
            this.dashPatternAnimations.add(((AnimatableFloatValue)list.get(i2)).createAnimation());
        }
        baseLayer.addAnimation(this.opacityAnimation);
        baseLayer.addAnimation(this.widthAnimation);
        for (int i3 = 0; i3 < this.dashPatternAnimations.size(); ++i3) {
            baseLayer.addAnimation((BaseKeyframeAnimation)this.dashPatternAnimations.get(i3));
        }
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation = this.dashPatternOffsetAnimation;
        if (baseKeyframeAnimation != null) {
            baseLayer.addAnimation(baseKeyframeAnimation);
        }
        this.opacityAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        this.widthAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        while (n2 < list.size()) {
            ((BaseKeyframeAnimation)this.dashPatternAnimations.get(n2)).addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            ++n2;
        }
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation2 = this.dashPatternOffsetAnimation;
        if (baseKeyframeAnimation2 != null) {
            baseKeyframeAnimation2.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        }
    }

    private void applyDashPatternIfNeeded(Matrix matrix) {
        L.beginSection((String)"StrokeContent#applyDashPattern");
        if (this.dashPatternAnimations.isEmpty()) {
            L.endSection((String)"StrokeContent#applyDashPattern");
            return;
        }
        float f2 = Utils.getScale((Matrix)matrix);
        for (int i2 = 0; i2 < this.dashPatternAnimations.size(); ++i2) {
            this.dashPatternValues[i2] = ((Float)((BaseKeyframeAnimation)this.dashPatternAnimations.get(i2)).getValue()).floatValue();
            if (i2 % 2 == 0) {
                float[] arrf = this.dashPatternValues;
                if (arrf[i2] < 1.0f) {
                    arrf[i2] = 1.0f;
                }
            } else {
                float[] arrf = this.dashPatternValues;
                if (arrf[i2] < 0.1f) {
                    arrf[i2] = 0.1f;
                }
            }
            float[] arrf = this.dashPatternValues;
            arrf[i2] = f2 * arrf[i2];
        }
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation = this.dashPatternOffsetAnimation;
        float f3 = baseKeyframeAnimation == null ? 0.0f : ((Float)baseKeyframeAnimation.getValue()).floatValue();
        this.paint.setPathEffect((PathEffect)new DashPathEffect(this.dashPatternValues, f3));
        L.endSection((String)"StrokeContent#applyDashPattern");
    }

    private void applyTrimPath(Canvas canvas, PathGroup pathGroup, Matrix matrix) {
        L.beginSection((String)"StrokeContent#applyTrimPath");
        if (PathGroup.access$200(pathGroup) == null) {
            L.endSection((String)"StrokeContent#applyTrimPath");
            return;
        }
        this.path.reset();
        for (int i2 = -1 + PathGroup.access$100(pathGroup).size(); i2 >= 0; --i2) {
            this.path.addPath(((PathContent)PathGroup.access$100(pathGroup).get(i2)).getPath(), matrix);
        }
        this.pm.setPath(this.path, false);
        float f2 = this.pm.getLength();
        while (this.pm.nextContour()) {
            f2 += this.pm.getLength();
        }
        float f3 = f2 * ((Float)PathGroup.access$200(pathGroup).getOffset().getValue()).floatValue() / 360.0f;
        float f4 = f3 + f2 * ((Float)PathGroup.access$200(pathGroup).getStart().getValue()).floatValue() / 100.0f;
        float f5 = f3 + f2 * ((Float)PathGroup.access$200(pathGroup).getEnd().getValue()).floatValue() / 100.0f;
        float f6 = 0.0f;
        for (int i3 = -1 + PathGroup.access$100(pathGroup).size(); i3 >= 0; --i3) {
            float f7;
            this.trimPathPath.set(((PathContent)PathGroup.access$100(pathGroup).get(i3)).getPath());
            this.trimPathPath.transform(matrix);
            this.pm.setPath(this.trimPathPath, false);
            float f8 = this.pm.getLength();
            float f9 = 1.0f;
            if (f5 > f2 && (f7 = f5 - f2) < f6 + f8 && f6 < f7) {
                float f10 = f4 > f2 ? (f4 - f2) / f8 : 0.0f;
                float f11 = Math.min((float)(f7 / f8), (float)f9);
                Utils.applyTrimPathIfNeeded((Path)this.trimPathPath, (float)f10, (float)f11, (float)0.0f);
                canvas.drawPath(this.trimPathPath, this.paint);
            } else {
                float f12 = f6 + f8;
                if (!(f12 < f4) && !(f6 > f5)) {
                    if (f12 <= f5 && f4 < f6) {
                        canvas.drawPath(this.trimPathPath, this.paint);
                    } else {
                        float f13 = f4 < f6 ? 0.0f : (f4 - f6) / f8;
                        if (!(f5 > f12)) {
                            f9 = (f5 - f6) / f8;
                        }
                        Utils.applyTrimPathIfNeeded((Path)this.trimPathPath, (float)f13, (float)f9, (float)0.0f);
                        canvas.drawPath(this.trimPathPath, this.paint);
                    }
                }
            }
            f6 += f8;
        }
        L.endSection((String)"StrokeContent#applyTrimPath");
    }

    public <T> void addValueCallback(T t2, LottieValueCallback<T> lottieValueCallback) {
        if (t2 == LottieProperty.OPACITY) {
            this.opacityAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.STROKE_WIDTH) {
            this.widthAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.COLOR_FILTER) {
            if (lottieValueCallback == null) {
                this.colorFilterAnimation = null;
                return;
            }
            this.colorFilterAnimation = new ValueCallbackKeyframeAnimation<ColorFilter, T>(lottieValueCallback);
            this.colorFilterAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            this.layer.addAnimation(this.colorFilterAnimation);
        }
    }

    @Override
    public void draw(Canvas canvas, Matrix matrix, int n2) {
        L.beginSection((String)"StrokeContent#draw");
        if (Utils.hasZeroScaleAxis((Matrix)matrix)) {
            L.endSection((String)"StrokeContent#draw");
            return;
        }
        int n3 = (int)(255.0f * ((float)n2 / 255.0f * (float)((IntegerKeyframeAnimation)this.opacityAnimation).getIntValue() / 100.0f));
        this.paint.setAlpha(MiscUtils.clamp((int)n3, (int)0, (int)255));
        this.paint.setStrokeWidth(((FloatKeyframeAnimation)this.widthAnimation).getFloatValue() * Utils.getScale((Matrix)matrix));
        if (this.paint.getStrokeWidth() <= 0.0f) {
            L.endSection((String)"StrokeContent#draw");
            return;
        }
        this.applyDashPatternIfNeeded(matrix);
        BaseKeyframeAnimation<ColorFilter, ColorFilter> baseKeyframeAnimation = this.colorFilterAnimation;
        int n4 = 0;
        if (baseKeyframeAnimation != null) {
            this.paint.setColorFilter((ColorFilter)baseKeyframeAnimation.getValue());
        }
        while (n4 < this.pathGroups.size()) {
            PathGroup pathGroup = this.pathGroups.get(n4);
            if (PathGroup.access$200(pathGroup) != null) {
                this.applyTrimPath(canvas, pathGroup, matrix);
            } else {
                L.beginSection((String)"StrokeContent#buildPath");
                this.path.reset();
                for (int i2 = -1 + PathGroup.access$100(pathGroup).size(); i2 >= 0; --i2) {
                    this.path.addPath(((PathContent)PathGroup.access$100(pathGroup).get(i2)).getPath(), matrix);
                }
                L.endSection((String)"StrokeContent#buildPath");
                L.beginSection((String)"StrokeContent#drawPath");
                canvas.drawPath(this.path, this.paint);
                L.endSection((String)"StrokeContent#drawPath");
            }
            ++n4;
        }
        L.endSection((String)"StrokeContent#draw");
    }

    @Override
    public void getBounds(RectF rectF, Matrix matrix, boolean bl) {
        L.beginSection((String)"StrokeContent#getBounds");
        this.path.reset();
        for (int i2 = 0; i2 < this.pathGroups.size(); ++i2) {
            PathGroup pathGroup = this.pathGroups.get(i2);
            for (int i3 = 0; i3 < PathGroup.access$100(pathGroup).size(); ++i3) {
                this.path.addPath(((PathContent)PathGroup.access$100(pathGroup).get(i3)).getPath(), matrix);
            }
        }
        this.path.computeBounds(this.rect, false);
        float f2 = ((FloatKeyframeAnimation)this.widthAnimation).getFloatValue();
        RectF rectF2 = this.rect;
        float f3 = rectF2.left;
        float f4 = f2 / 2.0f;
        rectF2.set(f3 - f4, this.rect.top - f4, f4 + this.rect.right, f4 + this.rect.bottom);
        rectF.set(this.rect);
        rectF.set(rectF.left - 1.0f, rectF.top - 1.0f, 1.0f + rectF.right, 1.0f + rectF.bottom);
        L.endSection((String)"StrokeContent#getBounds");
    }

    public void onValueChanged() {
        this.lottieDrawable.invalidateSelf();
    }

    public void resolveKeyPath(KeyPath keyPath, int n2, List<KeyPath> list, KeyPath keyPath2) {
        MiscUtils.resolveKeyPath((KeyPath)keyPath, (int)n2, list, (KeyPath)keyPath2, (KeyPathElementContent)this);
    }

    public void setContents(List<Content> list, List<Content> list2) {
        TrimPathContent trimPathContent = null;
        for (int i2 = -1 + list.size(); i2 >= 0; --i2) {
            TrimPathContent trimPathContent2;
            Content content = (Content)list.get(i2);
            if (!(content instanceof TrimPathContent) || (trimPathContent2 = (TrimPathContent)content).getType() != ShapeTrimPath.Type.INDIVIDUALLY) continue;
            trimPathContent = trimPathContent2;
        }
        if (trimPathContent != null) {
            trimPathContent.addListener(this);
        }
        PathGroup pathGroup = null;
        for (int i3 = -1 + list2.size(); i3 >= 0; --i3) {
            TrimPathContent trimPathContent3;
            Content content = (Content)list2.get(i3);
            if (content instanceof TrimPathContent && (trimPathContent3 = (TrimPathContent)content).getType() == ShapeTrimPath.Type.INDIVIDUALLY) {
                if (pathGroup != null) {
                    this.pathGroups.add((Object)pathGroup);
                }
                pathGroup = new /* Unavailable Anonymous Inner Class!! */;
                trimPathContent3.addListener(this);
                continue;
            }
            if (!(content instanceof PathContent)) continue;
            if (pathGroup == null) {
                pathGroup = new /* Unavailable Anonymous Inner Class!! */;
            }
            PathGroup.access$100(pathGroup).add((Object)((PathContent)content));
        }
        if (pathGroup != null) {
            this.pathGroups.add(pathGroup);
        }
    }
}

