/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.LinearGradient
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$FillType
 *  android.graphics.PointF
 *  android.graphics.RadialGradient
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  androidx.collection.LongSparseArray
 *  com.airbnb.lottie.L
 *  com.airbnb.lottie.LottieComposition
 *  com.airbnb.lottie.LottieDrawable
 *  com.airbnb.lottie.LottieProperty
 *  com.airbnb.lottie.animation.LPaint
 *  com.airbnb.lottie.animation.content.Content
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation$AnimationListener
 *  com.airbnb.lottie.model.KeyPath
 *  com.airbnb.lottie.model.content.GradientColor
 *  com.airbnb.lottie.model.content.GradientType
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import androidx.collection.LongSparseArray;
import com.airbnb.lottie.L;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.LPaint;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.DrawingContent;
import com.airbnb.lottie.animation.content.KeyPathElementContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.ValueCallbackKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.animatable.AnimatableGradientColorValue;
import com.airbnb.lottie.model.animatable.AnimatableIntegerValue;
import com.airbnb.lottie.model.animatable.AnimatablePointValue;
import com.airbnb.lottie.model.content.GradientColor;
import com.airbnb.lottie.model.content.GradientFill;
import com.airbnb.lottie.model.content.GradientType;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.List;

public class GradientFillContent
implements DrawingContent,
BaseKeyframeAnimation.AnimationListener,
KeyPathElementContent {
    private static final int CACHE_STEPS_MS = 32;
    private final RectF boundsRect = new RectF();
    private final int cacheSteps;
    private final BaseKeyframeAnimation<GradientColor, GradientColor> colorAnimation;
    private ValueCallbackKeyframeAnimation colorCallbackAnimation;
    private BaseKeyframeAnimation<ColorFilter, ColorFilter> colorFilterAnimation;
    private final BaseKeyframeAnimation<PointF, PointF> endPointAnimation;
    private final boolean hidden;
    private final BaseLayer layer;
    private final LongSparseArray<LinearGradient> linearGradientCache = new LongSparseArray();
    private final LottieDrawable lottieDrawable;
    private final String name;
    private final BaseKeyframeAnimation<Integer, Integer> opacityAnimation;
    private final Paint paint = new LPaint(1);
    private final Path path = new Path();
    private final List<PathContent> paths = new ArrayList();
    private final LongSparseArray<RadialGradient> radialGradientCache = new LongSparseArray();
    private final Matrix shaderMatrix = new Matrix();
    private final BaseKeyframeAnimation<PointF, PointF> startPointAnimation;
    private final GradientType type;

    public GradientFillContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, GradientFill gradientFill) {
        this.layer = baseLayer;
        this.name = gradientFill.getName();
        this.hidden = gradientFill.isHidden();
        this.lottieDrawable = lottieDrawable;
        this.type = gradientFill.getGradientType();
        this.path.setFillType(gradientFill.getFillType());
        this.cacheSteps = (int)(lottieDrawable.getComposition().getDuration() / 32.0f);
        this.colorAnimation = gradientFill.getGradientColor().createAnimation();
        this.colorAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        baseLayer.addAnimation(this.colorAnimation);
        this.opacityAnimation = gradientFill.getOpacity().createAnimation();
        this.opacityAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        baseLayer.addAnimation(this.opacityAnimation);
        this.startPointAnimation = gradientFill.getStartPoint().createAnimation();
        this.startPointAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        baseLayer.addAnimation(this.startPointAnimation);
        this.endPointAnimation = gradientFill.getEndPoint().createAnimation();
        this.endPointAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        baseLayer.addAnimation(this.endPointAnimation);
    }

    private int[] applyDynamicColorsIfNeeded(int[] arrn) {
        block4 : {
            int n2;
            ValueCallbackKeyframeAnimation valueCallbackKeyframeAnimation = this.colorCallbackAnimation;
            if (valueCallbackKeyframeAnimation == null) break block4;
            Integer[] arrinteger = (Integer[])valueCallbackKeyframeAnimation.getValue();
            int n3 = arrn.length;
            int n4 = arrinteger.length;
            if (n3 == n4) {
                for (n2 = 0; n2 < arrn.length; ++n2) {
                    arrn[n2] = arrinteger[n2];
                }
            } else {
                arrn = new int[arrinteger.length];
                while (n2 < arrinteger.length) {
                    arrn[n2] = arrinteger[n2];
                    ++n2;
                }
            }
        }
        return arrn;
    }

    private int getGradientHash() {
        int n2 = Math.round((float)(this.startPointAnimation.getProgress() * (float)this.cacheSteps));
        int n3 = Math.round((float)(this.endPointAnimation.getProgress() * (float)this.cacheSteps));
        int n4 = Math.round((float)(this.colorAnimation.getProgress() * (float)this.cacheSteps));
        int n5 = n2 != 0 ? 527 * n2 : 17;
        if (n3 != 0) {
            n5 = n3 * (n5 * 31);
        }
        if (n4 != 0) {
            n5 = n4 * (n5 * 31);
        }
        return n5;
    }

    private LinearGradient getLinearGradient() {
        LongSparseArray<LinearGradient> longSparseArray = this.linearGradientCache;
        int n2 = this.getGradientHash();
        long l2 = n2;
        LinearGradient linearGradient = (LinearGradient)longSparseArray.get(l2);
        if (linearGradient != null) {
            return linearGradient;
        }
        PointF pointF = (PointF)this.startPointAnimation.getValue();
        PointF pointF2 = (PointF)this.endPointAnimation.getValue();
        GradientColor gradientColor = (GradientColor)this.colorAnimation.getValue();
        int[] arrn = this.applyDynamicColorsIfNeeded(gradientColor.getColors());
        float[] arrf = gradientColor.getPositions();
        LinearGradient linearGradient2 = new LinearGradient(pointF.x, pointF.y, pointF2.x, pointF2.y, arrn, arrf, Shader.TileMode.CLAMP);
        this.linearGradientCache.put(l2, (Object)linearGradient2);
        return linearGradient2;
    }

    private RadialGradient getRadialGradient() {
        LongSparseArray<RadialGradient> longSparseArray = this.radialGradientCache;
        int n2 = this.getGradientHash();
        long l2 = n2;
        RadialGradient radialGradient = (RadialGradient)longSparseArray.get(l2);
        if (radialGradient != null) {
            return radialGradient;
        }
        PointF pointF = (PointF)this.startPointAnimation.getValue();
        PointF pointF2 = (PointF)this.endPointAnimation.getValue();
        GradientColor gradientColor = (GradientColor)this.colorAnimation.getValue();
        int[] arrn = this.applyDynamicColorsIfNeeded(gradientColor.getColors());
        float[] arrf = gradientColor.getPositions();
        float f2 = pointF2.x;
        float f3 = pointF.x;
        float f4 = pointF2.y;
        float f5 = pointF.y;
        float f6 = (float)Math.hypot((double)(f2 - f3), (double)(f4 - f5));
        float f7 = f6 <= 0.0f ? 0.001f : f6;
        RadialGradient radialGradient2 = new RadialGradient(f3, f5, f7, arrn, arrf, Shader.TileMode.CLAMP);
        this.radialGradientCache.put(l2, (Object)radialGradient2);
        return radialGradient2;
    }

    public <T> void addValueCallback(T t2, LottieValueCallback<T> lottieValueCallback) {
        if (t2 == LottieProperty.OPACITY) {
            this.opacityAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.COLOR_FILTER) {
            if (lottieValueCallback == null) {
                this.colorFilterAnimation = null;
                return;
            }
            this.colorFilterAnimation = new ValueCallbackKeyframeAnimation<ColorFilter, T>(lottieValueCallback);
            this.colorFilterAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            this.layer.addAnimation(this.colorFilterAnimation);
            return;
        }
        if (t2 == LottieProperty.GRADIENT_COLOR) {
            if (lottieValueCallback == null) {
                ValueCallbackKeyframeAnimation valueCallbackKeyframeAnimation = this.colorCallbackAnimation;
                if (valueCallbackKeyframeAnimation != null) {
                    this.layer.removeAnimation(valueCallbackKeyframeAnimation);
                }
                this.colorCallbackAnimation = null;
                return;
            }
            this.colorCallbackAnimation = new ValueCallbackKeyframeAnimation(lottieValueCallback);
            this.colorCallbackAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            this.layer.addAnimation(this.colorCallbackAnimation);
        }
    }

    @Override
    public void draw(Canvas canvas, Matrix matrix, int n2) {
        if (this.hidden) {
            return;
        }
        L.beginSection((String)"GradientFillContent#draw");
        this.path.reset();
        for (int i2 = 0; i2 < this.paths.size(); ++i2) {
            this.path.addPath(((PathContent)this.paths.get(i2)).getPath(), matrix);
        }
        this.path.computeBounds(this.boundsRect, false);
        Object object = this.type == GradientType.LINEAR ? this.getLinearGradient() : this.getRadialGradient();
        this.shaderMatrix.set(matrix);
        object.setLocalMatrix(this.shaderMatrix);
        this.paint.setShader((Shader)object);
        BaseKeyframeAnimation<ColorFilter, ColorFilter> baseKeyframeAnimation = this.colorFilterAnimation;
        if (baseKeyframeAnimation != null) {
            this.paint.setColorFilter((ColorFilter)baseKeyframeAnimation.getValue());
        }
        int n3 = (int)(255.0f * ((float)n2 / 255.0f * (float)((Integer)this.opacityAnimation.getValue()).intValue() / 100.0f));
        this.paint.setAlpha(MiscUtils.clamp((int)n3, (int)0, (int)255));
        canvas.drawPath(this.path, this.paint);
        L.endSection((String)"GradientFillContent#draw");
    }

    @Override
    public void getBounds(RectF rectF, Matrix matrix, boolean bl) {
        this.path.reset();
        for (int i2 = 0; i2 < this.paths.size(); ++i2) {
            this.path.addPath(((PathContent)this.paths.get(i2)).getPath(), matrix);
        }
        this.path.computeBounds(rectF, false);
        rectF.set(rectF.left - 1.0f, rectF.top - 1.0f, 1.0f + rectF.right, 1.0f + rectF.bottom);
    }

    public String getName() {
        return this.name;
    }

    public void onValueChanged() {
        this.lottieDrawable.invalidateSelf();
    }

    public void resolveKeyPath(KeyPath keyPath, int n2, List<KeyPath> list, KeyPath keyPath2) {
        MiscUtils.resolveKeyPath((KeyPath)keyPath, (int)n2, list, (KeyPath)keyPath2, (KeyPathElementContent)this);
    }

    public void setContents(List<Content> list, List<Content> list2) {
        for (int i2 = 0; i2 < list2.size(); ++i2) {
            Content content = (Content)list2.get(i2);
            if (!(content instanceof PathContent)) continue;
            this.paths.add((Object)((PathContent)content));
        }
    }
}

