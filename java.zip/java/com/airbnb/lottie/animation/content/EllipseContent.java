/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 *  android.graphics.PointF
 *  com.airbnb.lottie.LottieDrawable
 *  com.airbnb.lottie.LottieProperty
 *  com.airbnb.lottie.animation.content.CompoundTrimPathContent
 *  com.airbnb.lottie.animation.content.Content
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation$AnimationListener
 *  com.airbnb.lottie.model.KeyPath
 *  com.airbnb.lottie.model.animatable.AnimatableValue
 *  com.airbnb.lottie.model.content.ShapeTrimPath$Type
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Path;
import android.graphics.PointF;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.content.CompoundTrimPathContent;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.KeyPathElementContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.animation.content.TrimPathContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.animatable.AnimatablePointValue;
import com.airbnb.lottie.model.animatable.AnimatableValue;
import com.airbnb.lottie.model.content.CircleShape;
import com.airbnb.lottie.model.content.ShapeTrimPath;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class EllipseContent
implements PathContent,
BaseKeyframeAnimation.AnimationListener,
KeyPathElementContent {
    private static final float ELLIPSE_CONTROL_POINT_PERCENTAGE = 0.55228f;
    private final CircleShape circleShape;
    private boolean isPathValid;
    private final LottieDrawable lottieDrawable;
    private final String name;
    private final Path path = new Path();
    private final BaseKeyframeAnimation<?, PointF> positionAnimation;
    private final BaseKeyframeAnimation<?, PointF> sizeAnimation;
    private CompoundTrimPathContent trimPaths = new CompoundTrimPathContent();

    public EllipseContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, CircleShape circleShape) {
        this.name = circleShape.getName();
        this.lottieDrawable = lottieDrawable;
        this.sizeAnimation = circleShape.getSize().createAnimation();
        this.positionAnimation = circleShape.getPosition().createAnimation();
        this.circleShape = circleShape;
        baseLayer.addAnimation(this.sizeAnimation);
        baseLayer.addAnimation(this.positionAnimation);
        this.sizeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        this.positionAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
    }

    private void invalidate() {
        this.isPathValid = false;
        this.lottieDrawable.invalidateSelf();
    }

    public <T> void addValueCallback(T t2, LottieValueCallback<T> lottieValueCallback) {
        if (t2 == LottieProperty.ELLIPSE_SIZE) {
            this.sizeAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.POSITION) {
            this.positionAnimation.setValueCallback(lottieValueCallback);
        }
    }

    public String getName() {
        return this.name;
    }

    @Override
    public Path getPath() {
        if (this.isPathValid) {
            return this.path;
        }
        this.path.reset();
        if (this.circleShape.isHidden()) {
            this.isPathValid = true;
            return this.path;
        }
        PointF pointF = (PointF)this.sizeAnimation.getValue();
        float f2 = pointF.x / 2.0f;
        float f3 = pointF.y / 2.0f;
        float f4 = f2 * 0.55228f;
        float f5 = 0.55228f * f3;
        this.path.reset();
        if (this.circleShape.isReversed()) {
            Path path = this.path;
            float f6 = -f3;
            path.moveTo(0.0f, f6);
            Path path2 = this.path;
            float f7 = 0.0f - f4;
            float f8 = -f2;
            float f9 = 0.0f - f5;
            path2.cubicTo(f7, f6, f8, f9, f8, 0.0f);
            Path path3 = this.path;
            float f10 = f5 + 0.0f;
            path3.cubicTo(f8, f10, f7, f3, 0.0f, f3);
            Path path4 = this.path;
            float f11 = f4 + 0.0f;
            path4.cubicTo(f11, f3, f2, f10, f2, 0.0f);
            this.path.cubicTo(f2, f9, f11, f6, 0.0f, f6);
        } else {
            Path path = this.path;
            float f12 = -f3;
            path.moveTo(0.0f, f12);
            Path path5 = this.path;
            float f13 = f4 + 0.0f;
            float f14 = 0.0f - f5;
            path5.cubicTo(f13, f12, f2, f14, f2, 0.0f);
            Path path6 = this.path;
            float f15 = f5 + 0.0f;
            path6.cubicTo(f2, f15, f13, f3, 0.0f, f3);
            Path path7 = this.path;
            float f16 = 0.0f - f4;
            float f17 = -f2;
            path7.cubicTo(f16, f3, f17, f15, f17, 0.0f);
            this.path.cubicTo(f17, f14, f16, f12, 0.0f, f12);
        }
        PointF pointF2 = (PointF)this.positionAnimation.getValue();
        this.path.offset(pointF2.x, pointF2.y);
        this.path.close();
        this.trimPaths.apply(this.path);
        this.isPathValid = true;
        return this.path;
    }

    public void onValueChanged() {
        this.invalidate();
    }

    public void resolveKeyPath(KeyPath keyPath, int n2, List<KeyPath> list, KeyPath keyPath2) {
        MiscUtils.resolveKeyPath((KeyPath)keyPath, (int)n2, list, (KeyPath)keyPath2, (KeyPathElementContent)this);
    }

    public void setContents(List<Content> list, List<Content> list2) {
        for (int i2 = 0; i2 < list.size(); ++i2) {
            TrimPathContent trimPathContent;
            Content content = (Content)list.get(i2);
            if (!(content instanceof TrimPathContent) || (trimPathContent = (TrimPathContent)content).getType() != ShapeTrimPath.Type.SIMULTANEOUSLY) continue;
            this.trimPaths.addTrimPath(trimPathContent);
            trimPathContent.addListener(this);
        }
    }
}

