/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 *  android.graphics.PointF
 *  com.airbnb.lottie.LottieDrawable
 *  com.airbnb.lottie.LottieProperty
 *  com.airbnb.lottie.animation.content.CompoundTrimPathContent
 *  com.airbnb.lottie.animation.content.Content
 *  com.airbnb.lottie.animation.content.PolystarContent$1
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation$AnimationListener
 *  com.airbnb.lottie.model.KeyPath
 *  com.airbnb.lottie.model.animatable.AnimatableValue
 *  com.airbnb.lottie.model.content.PolystarShape$Type
 *  com.airbnb.lottie.model.content.ShapeTrimPath$Type
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Path;
import android.graphics.PointF;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.content.CompoundTrimPathContent;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.KeyPathElementContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.animation.content.PolystarContent;
import com.airbnb.lottie.animation.content.TrimPathContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableValue;
import com.airbnb.lottie.model.content.PolystarShape;
import com.airbnb.lottie.model.content.ShapeTrimPath;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class PolystarContent
implements PathContent,
BaseKeyframeAnimation.AnimationListener,
KeyPathElementContent {
    private static final float POLYGON_MAGIC_NUMBER = 0.25f;
    private static final float POLYSTAR_MAGIC_NUMBER = 0.47829f;
    private final boolean hidden;
    private final BaseKeyframeAnimation<?, Float> innerRadiusAnimation;
    private final BaseKeyframeAnimation<?, Float> innerRoundednessAnimation;
    private boolean isPathValid;
    private final LottieDrawable lottieDrawable;
    private final String name;
    private final BaseKeyframeAnimation<?, Float> outerRadiusAnimation;
    private final BaseKeyframeAnimation<?, Float> outerRoundednessAnimation;
    private final Path path = new Path();
    private final BaseKeyframeAnimation<?, Float> pointsAnimation;
    private final BaseKeyframeAnimation<?, PointF> positionAnimation;
    private final BaseKeyframeAnimation<?, Float> rotationAnimation;
    private CompoundTrimPathContent trimPaths = new CompoundTrimPathContent();
    private final PolystarShape.Type type;

    public PolystarContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, PolystarShape polystarShape) {
        this.lottieDrawable = lottieDrawable;
        this.name = polystarShape.getName();
        this.type = polystarShape.getType();
        this.hidden = polystarShape.isHidden();
        this.pointsAnimation = polystarShape.getPoints().createAnimation();
        this.positionAnimation = polystarShape.getPosition().createAnimation();
        this.rotationAnimation = polystarShape.getRotation().createAnimation();
        this.outerRadiusAnimation = polystarShape.getOuterRadius().createAnimation();
        this.outerRoundednessAnimation = polystarShape.getOuterRoundedness().createAnimation();
        if (this.type == PolystarShape.Type.STAR) {
            this.innerRadiusAnimation = polystarShape.getInnerRadius().createAnimation();
            this.innerRoundednessAnimation = polystarShape.getInnerRoundedness().createAnimation();
        } else {
            this.innerRadiusAnimation = null;
            this.innerRoundednessAnimation = null;
        }
        baseLayer.addAnimation(this.pointsAnimation);
        baseLayer.addAnimation(this.positionAnimation);
        baseLayer.addAnimation(this.rotationAnimation);
        baseLayer.addAnimation(this.outerRadiusAnimation);
        baseLayer.addAnimation(this.outerRoundednessAnimation);
        if (this.type == PolystarShape.Type.STAR) {
            baseLayer.addAnimation(this.innerRadiusAnimation);
            baseLayer.addAnimation(this.innerRoundednessAnimation);
        }
        this.pointsAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        this.positionAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        this.rotationAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        this.outerRadiusAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        this.outerRoundednessAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        if (this.type == PolystarShape.Type.STAR) {
            this.innerRadiusAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
            this.innerRoundednessAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        }
    }

    private void createPolygonPath() {
        int n2 = (int)Math.floor((double)((Float)this.pointsAnimation.getValue()).floatValue());
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation = this.rotationAnimation;
        double d2 = baseKeyframeAnimation == null ? 0.0 : (double)((Float)baseKeyframeAnimation.getValue()).floatValue();
        double d3 = Math.toRadians((double)(d2 - 90.0));
        double d4 = n2;
        Double.isNaN((double)d4);
        float f2 = (float)(6.283185307179586 / d4);
        float f3 = ((Float)this.outerRoundednessAnimation.getValue()).floatValue() / 100.0f;
        float f4 = ((Float)this.outerRadiusAnimation.getValue()).floatValue();
        double d5 = f4;
        double d6 = Math.cos((double)d3);
        Double.isNaN((double)d5);
        float f5 = (float)(d6 * d5);
        double d7 = Math.sin((double)d3);
        Double.isNaN((double)d5);
        float f6 = (float)(d7 * d5);
        this.path.moveTo(f5, f6);
        double d8 = f2;
        Double.isNaN((double)d8);
        double d9 = d3 + d8;
        double d10 = Math.ceil((double)d4);
        int n3 = 0;
        while ((double)n3 < d10) {
            double d11;
            double d12;
            int n4;
            double d13;
            double d14 = Math.cos((double)d9);
            Double.isNaN((double)d5);
            float f7 = (float)(d14 * d5);
            double d15 = Math.sin((double)d9);
            Double.isNaN((double)d5);
            double d16 = d10;
            float f8 = (float)(d5 * d15);
            if (f3 != 0.0f) {
                d12 = d5;
                double d17 = f6;
                n4 = n3;
                d13 = d9;
                double d18 = (float)(Math.atan2((double)d17, (double)f5) - 1.5707963267948966);
                float f9 = (float)Math.cos((double)d18);
                float f10 = (float)Math.sin((double)d18);
                double d19 = f8;
                d11 = d8;
                double d20 = (float)(Math.atan2((double)d19, (double)f7) - 1.5707963267948966);
                float f11 = (float)Math.cos((double)d20);
                float f12 = (float)Math.sin((double)d20);
                float f13 = 0.25f * (f4 * f3);
                float f14 = f9 * f13;
                float f15 = f10 * f13;
                float f16 = f11 * f13;
                float f17 = f13 * f12;
                this.path.cubicTo(f5 - f14, f6 - f15, f7 + f16, f8 + f17, f7, f8);
            } else {
                d13 = d9;
                d12 = d5;
                d11 = d8;
                n4 = n3;
                this.path.lineTo(f7, f8);
            }
            Double.isNaN((double)d11);
            d9 = d13 + d11;
            n3 = n4 + 1;
            f6 = f8;
            f5 = f7;
            d10 = d16;
            d5 = d12;
            d8 = d11;
        }
        PointF pointF = (PointF)this.positionAnimation.getValue();
        this.path.offset(pointF.x, pointF.y);
        this.path.close();
    }

    private void createStarPath() {
        double d2;
        float f2;
        float f3;
        double d3;
        float f4;
        double d4;
        float f5;
        float f6;
        float f7 = ((Float)this.pointsAnimation.getValue()).floatValue();
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation = this.rotationAnimation;
        double d5 = baseKeyframeAnimation == null ? 0.0 : (double)((Float)baseKeyframeAnimation.getValue()).floatValue();
        double d6 = Math.toRadians((double)(d5 - 90.0));
        double d7 = f7;
        Double.isNaN((double)d7);
        float f8 = (float)(6.283185307179586 / d7);
        float f9 = f8 / 2.0f;
        float f10 = f7 - (float)((int)f7);
        if (f10 != 0.0f) {
            double d8 = f9 * (1.0f - f10);
            Double.isNaN((double)d8);
            d6 += d8;
        }
        float f11 = ((Float)this.outerRadiusAnimation.getValue()).floatValue();
        float f12 = ((Float)this.innerRadiusAnimation.getValue()).floatValue();
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation2 = this.innerRoundednessAnimation;
        float f13 = baseKeyframeAnimation2 != null ? ((Float)baseKeyframeAnimation2.getValue()).floatValue() / 100.0f : 0.0f;
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation3 = this.outerRoundednessAnimation;
        float f14 = baseKeyframeAnimation3 != null ? ((Float)baseKeyframeAnimation3.getValue()).floatValue() / 100.0f : 0.0f;
        if (f10 != 0.0f) {
            float f15 = f12 + f10 * (f11 - f12);
            double d9 = f15;
            double d10 = Math.cos((double)d6);
            Double.isNaN((double)d9);
            d2 = d7;
            float f16 = (float)(d9 * d10);
            double d11 = Math.sin((double)d6);
            Double.isNaN((double)d9);
            float f17 = (float)(d9 * d11);
            this.path.moveTo(f16, f17);
            double d12 = f8 * f10 / 2.0f;
            Double.isNaN((double)d12);
            d3 = d6 + d12;
            f5 = f16;
            f2 = f15;
            f6 = f11;
            f3 = f17;
            f4 = f9;
        } else {
            d2 = d7;
            f6 = f11;
            double d13 = f6;
            double d14 = Math.cos((double)d6);
            Double.isNaN((double)d13);
            f4 = f9;
            f5 = (float)(d13 * d14);
            double d15 = Math.sin((double)d6);
            Double.isNaN((double)d13);
            f3 = (float)(d13 * d15);
            this.path.moveTo(f5, f3);
            double d16 = f4;
            Double.isNaN((double)d16);
            d3 = d6 + d16;
            f2 = 0.0f;
        }
        double d17 = 2.0 * Math.ceil((double)d2);
        int n2 = 0;
        double d18 = d3;
        boolean bl = false;
        while ((d4 = (double)n2) < d17) {
            float f18;
            float f19;
            float f20;
            float f21;
            float f22;
            float f23;
            float f24;
            float f25;
            float f26;
            float f27;
            float f28;
            float f29 = bl ? f6 : f12;
            if (f2 != 0.0f && d4 == d17 - 2.0) {
                float f30 = f8 * f10 / 2.0f;
                f18 = f29;
                f21 = f30;
            } else {
                f18 = f29;
                f21 = f4;
            }
            if (f2 != 0.0f && d4 == d17 - 1.0) {
                f27 = f8;
                f19 = f6;
                f23 = f2;
            } else {
                f27 = f8;
                f23 = f18;
                f19 = f6;
            }
            double d19 = f23;
            double d20 = Math.cos((double)d18);
            Double.isNaN((double)d19);
            float f31 = (float)(d19 * d20);
            double d21 = Math.sin((double)d18);
            Double.isNaN((double)d19);
            float f32 = (float)(d19 * d21);
            if (f13 == 0.0f && f14 == 0.0f) {
                this.path.lineTo(f31, f32);
                f22 = f32;
                f25 = f4;
                f26 = f12;
                f24 = f13;
                f28 = f14;
                f20 = f21;
            } else {
                f25 = f4;
                double d22 = f3;
                f26 = f12;
                f24 = f13;
                double d23 = (float)(Math.atan2((double)d22, (double)f5) - 1.5707963267948966);
                float f33 = (float)Math.cos((double)d23);
                float f34 = (float)Math.sin((double)d23);
                f28 = f14;
                double d24 = f32;
                float f35 = f21;
                f22 = f32;
                double d25 = (float)(Math.atan2((double)d24, (double)f31) - 1.5707963267948966);
                float f36 = (float)Math.cos((double)d25);
                float f37 = (float)Math.sin((double)d25);
                float f38 = bl ? f24 : f28;
                float f39 = bl ? f28 : f24;
                float f40 = bl ? f26 : f19;
                float f41 = bl ? f19 : f26;
                float f42 = 0.47829f * (f40 * f38);
                float f43 = f33 * f42;
                float f44 = f42 * f34;
                float f45 = 0.47829f * (f41 * f39);
                float f46 = f36 * f45;
                float f47 = f45 * f37;
                if (f10 != 0.0f) {
                    if (n2 == 0) {
                        f43 *= f10;
                        f44 *= f10;
                    } else if (d4 == d17 - 1.0) {
                        f46 *= f10;
                        f47 *= f10;
                    }
                }
                this.path.cubicTo(f5 - f43, f3 - f44, f31 + f46, f22 + f47, f31, f22);
                f20 = f35;
            }
            double d26 = f20;
            Double.isNaN((double)d26);
            d18 += d26;
            bl ^= true;
            ++n2;
            f14 = f28;
            f5 = f31;
            f4 = f25;
            f6 = f19;
            f8 = f27;
            f12 = f26;
            f13 = f24;
            f3 = f22;
        }
        PointF pointF = (PointF)this.positionAnimation.getValue();
        this.path.offset(pointF.x, pointF.y);
        this.path.close();
    }

    private void invalidate() {
        this.isPathValid = false;
        this.lottieDrawable.invalidateSelf();
    }

    public <T> void addValueCallback(T t2, LottieValueCallback<T> lottieValueCallback) {
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation;
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation2;
        if (t2 == LottieProperty.POLYSTAR_POINTS) {
            this.pointsAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.POLYSTAR_ROTATION) {
            this.rotationAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.POSITION) {
            this.positionAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.POLYSTAR_INNER_RADIUS && (baseKeyframeAnimation = this.innerRadiusAnimation) != null) {
            baseKeyframeAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.POLYSTAR_OUTER_RADIUS) {
            this.outerRadiusAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.POLYSTAR_INNER_ROUNDEDNESS && (baseKeyframeAnimation2 = this.innerRoundednessAnimation) != null) {
            baseKeyframeAnimation2.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.POLYSTAR_OUTER_ROUNDEDNESS) {
            this.outerRoundednessAnimation.setValueCallback(lottieValueCallback);
        }
    }

    public String getName() {
        return this.name;
    }

    @Override
    public Path getPath() {
        if (this.isPathValid) {
            return this.path;
        }
        this.path.reset();
        if (this.hidden) {
            this.isPathValid = true;
            return this.path;
        }
        int n2 = 1.$SwitchMap$com$airbnb$lottie$model$content$PolystarShape$Type[this.type.ordinal()];
        if (n2 != 1) {
            if (n2 == 2) {
                this.createPolygonPath();
            }
        } else {
            this.createStarPath();
        }
        this.path.close();
        this.trimPaths.apply(this.path);
        this.isPathValid = true;
        return this.path;
    }

    public void onValueChanged() {
        this.invalidate();
    }

    public void resolveKeyPath(KeyPath keyPath, int n2, List<KeyPath> list, KeyPath keyPath2) {
        MiscUtils.resolveKeyPath((KeyPath)keyPath, (int)n2, list, (KeyPath)keyPath2, (KeyPathElementContent)this);
    }

    public void setContents(List<Content> list, List<Content> list2) {
        for (int i2 = 0; i2 < list.size(); ++i2) {
            TrimPathContent trimPathContent;
            Content content = (Content)list.get(i2);
            if (!(content instanceof TrimPathContent) || (trimPathContent = (TrimPathContent)content).getType() != ShapeTrimPath.Type.SIMULTANEOUSLY) continue;
            this.trimPaths.addTrimPath(trimPathContent);
            trimPathContent.addListener(this);
        }
    }
}

