/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.Path
 *  android.graphics.Path$Op
 *  android.os.Build
 *  android.os.Build$VERSION
 *  com.airbnb.lottie.animation.content.Content
 *  com.airbnb.lottie.animation.content.GreedyContent
 *  com.airbnb.lottie.animation.content.MergePathsContent$1
 *  com.airbnb.lottie.model.content.MergePaths$MergePathsMode
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.ListIterator
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Matrix;
import android.graphics.Path;
import android.os.Build;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.ContentGroup;
import com.airbnb.lottie.animation.content.GreedyContent;
import com.airbnb.lottie.animation.content.MergePathsContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.model.content.MergePaths;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class MergePathsContent
implements PathContent,
GreedyContent {
    private final Path firstPath = new Path();
    private final MergePaths mergePaths;
    private final String name;
    private final Path path = new Path();
    private final List<PathContent> pathContents = new ArrayList();
    private final Path remainderPath = new Path();

    public MergePathsContent(MergePaths mergePaths) {
        if (Build.VERSION.SDK_INT >= 19) {
            this.name = mergePaths.getName();
            this.mergePaths = mergePaths;
            return;
        }
        throw new IllegalStateException("Merge paths are not supported pre-KitKat.");
    }

    private void addPaths() {
        for (int i2 = 0; i2 < this.pathContents.size(); ++i2) {
            this.path.addPath(((PathContent)this.pathContents.get(i2)).getPath());
        }
    }

    private void opFirstPathWithRest(Path.Op op) {
        this.remainderPath.reset();
        this.firstPath.reset();
        for (int i2 = this.pathContents.size() - 1; i2 >= 1; --i2) {
            PathContent pathContent = (PathContent)this.pathContents.get(i2);
            if (pathContent instanceof ContentGroup) {
                ContentGroup contentGroup = (ContentGroup)pathContent;
                List<PathContent> list = contentGroup.getPathList();
                for (int i3 = list.size() - 1; i3 >= 0; --i3) {
                    Path path = ((PathContent)list.get(i3)).getPath();
                    path.transform(contentGroup.getTransformationMatrix());
                    this.remainderPath.addPath(path);
                }
                continue;
            }
            this.remainderPath.addPath(pathContent.getPath());
        }
        List<PathContent> list = this.pathContents;
        PathContent pathContent = (PathContent)list.get(0);
        if (pathContent instanceof ContentGroup) {
            ContentGroup contentGroup = (ContentGroup)pathContent;
            List<PathContent> list2 = contentGroup.getPathList();
            for (int i4 = 0; i4 < list2.size(); ++i4) {
                Path path = ((PathContent)list2.get(i4)).getPath();
                path.transform(contentGroup.getTransformationMatrix());
                this.firstPath.addPath(path);
            }
        } else {
            this.firstPath.set(pathContent.getPath());
        }
        this.path.op(this.firstPath, this.remainderPath, op);
    }

    public void absorbContent(ListIterator<Content> listIterator) {
        while (listIterator.hasPrevious() && listIterator.previous() != this) {
        }
        while (listIterator.hasPrevious()) {
            Content content = (Content)listIterator.previous();
            if (!(content instanceof PathContent)) continue;
            this.pathContents.add((Object)((PathContent)content));
            listIterator.remove();
        }
    }

    public String getName() {
        return this.name;
    }

    @Override
    public Path getPath() {
        this.path.reset();
        if (this.mergePaths.isHidden()) {
            return this.path;
        }
        int n2 = 1.$SwitchMap$com$airbnb$lottie$model$content$MergePaths$MergePathsMode[this.mergePaths.getMode().ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    if (n2 != 4) {
                        if (n2 == 5) {
                            this.opFirstPathWithRest(Path.Op.XOR);
                        }
                    } else {
                        this.opFirstPathWithRest(Path.Op.INTERSECT);
                    }
                } else {
                    this.opFirstPathWithRest(Path.Op.REVERSE_DIFFERENCE);
                }
            } else {
                this.opFirstPathWithRest(Path.Op.UNION);
            }
        } else {
            this.addPaths();
        }
        return this.path;
    }

    public void setContents(List<Content> list, List<Content> list2) {
        for (int i2 = 0; i2 < this.pathContents.size(); ++i2) {
            ((PathContent)this.pathContents.get(i2)).setContents(list, list2);
        }
    }
}

