/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.LinearGradient
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Cap
 *  android.graphics.Paint$Join
 *  android.graphics.PointF
 *  android.graphics.RadialGradient
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  androidx.collection.LongSparseArray
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import androidx.collection.LongSparseArray;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.content.BaseStrokeContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.ValueCallbackKeyframeAnimation;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableGradientColorValue;
import com.airbnb.lottie.model.animatable.AnimatableIntegerValue;
import com.airbnb.lottie.model.animatable.AnimatablePointValue;
import com.airbnb.lottie.model.content.GradientColor;
import com.airbnb.lottie.model.content.GradientStroke;
import com.airbnb.lottie.model.content.GradientType;
import com.airbnb.lottie.model.content.ShapeStroke;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class GradientStrokeContent
extends BaseStrokeContent {
    private static final int CACHE_STEPS_MS = 32;
    private final RectF boundsRect = new RectF();
    private final int cacheSteps;
    private final BaseKeyframeAnimation<GradientColor, GradientColor> colorAnimation;
    private ValueCallbackKeyframeAnimation colorCallbackAnimation;
    private final BaseKeyframeAnimation<PointF, PointF> endPointAnimation;
    private final boolean hidden;
    private final LongSparseArray<LinearGradient> linearGradientCache = new LongSparseArray();
    private final String name;
    private final LongSparseArray<RadialGradient> radialGradientCache = new LongSparseArray();
    private final BaseKeyframeAnimation<PointF, PointF> startPointAnimation;
    private final GradientType type;

    public GradientStrokeContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, GradientStroke gradientStroke) {
        super(lottieDrawable, baseLayer, gradientStroke.getCapType().toPaintCap(), gradientStroke.getJoinType().toPaintJoin(), gradientStroke.getMiterLimit(), gradientStroke.getOpacity(), gradientStroke.getWidth(), gradientStroke.getLineDashPattern(), gradientStroke.getDashOffset());
        this.name = gradientStroke.getName();
        this.type = gradientStroke.getGradientType();
        this.hidden = gradientStroke.isHidden();
        this.cacheSteps = (int)(lottieDrawable.getComposition().getDuration() / 32.0f);
        this.colorAnimation = gradientStroke.getGradientColor().createAnimation();
        this.colorAnimation.addUpdateListener(this);
        baseLayer.addAnimation(this.colorAnimation);
        this.startPointAnimation = gradientStroke.getStartPoint().createAnimation();
        this.startPointAnimation.addUpdateListener(this);
        baseLayer.addAnimation(this.startPointAnimation);
        this.endPointAnimation = gradientStroke.getEndPoint().createAnimation();
        this.endPointAnimation.addUpdateListener(this);
        baseLayer.addAnimation(this.endPointAnimation);
    }

    private int[] applyDynamicColorsIfNeeded(int[] arrn) {
        block4 : {
            int n;
            ValueCallbackKeyframeAnimation valueCallbackKeyframeAnimation = this.colorCallbackAnimation;
            if (valueCallbackKeyframeAnimation == null) break block4;
            Integer[] arrinteger = (Integer[])valueCallbackKeyframeAnimation.getValue();
            int n2 = arrn.length;
            int n3 = arrinteger.length;
            if (n2 == n3) {
                for (n = 0; n < arrn.length; ++n) {
                    arrn[n] = arrinteger[n];
                }
            } else {
                arrn = new int[arrinteger.length];
                while (n < arrinteger.length) {
                    arrn[n] = arrinteger[n];
                    ++n;
                }
            }
        }
        return arrn;
    }

    private int getGradientHash() {
        int n = Math.round((float)(this.startPointAnimation.getProgress() * (float)this.cacheSteps));
        int n2 = Math.round((float)(this.endPointAnimation.getProgress() * (float)this.cacheSteps));
        int n3 = Math.round((float)(this.colorAnimation.getProgress() * (float)this.cacheSteps));
        int n4 = n != 0 ? 527 * n : 17;
        if (n2 != 0) {
            n4 = n2 * (n4 * 31);
        }
        if (n3 != 0) {
            n4 = n3 * (n4 * 31);
        }
        return n4;
    }

    private LinearGradient getLinearGradient() {
        LongSparseArray<LinearGradient> longSparseArray = this.linearGradientCache;
        int n = this.getGradientHash();
        long l = n;
        LinearGradient linearGradient = (LinearGradient)longSparseArray.get(l);
        if (linearGradient != null) {
            return linearGradient;
        }
        PointF pointF = this.startPointAnimation.getValue();
        PointF pointF2 = this.endPointAnimation.getValue();
        GradientColor gradientColor = this.colorAnimation.getValue();
        int[] arrn = this.applyDynamicColorsIfNeeded(gradientColor.getColors());
        float[] arrf = gradientColor.getPositions();
        int n2 = (int)(this.boundsRect.left + this.boundsRect.width() / 2.0f + pointF.x);
        int n3 = (int)(this.boundsRect.top + this.boundsRect.height() / 2.0f + pointF.y);
        int n4 = (int)(this.boundsRect.left + this.boundsRect.width() / 2.0f + pointF2.x);
        int n5 = (int)(this.boundsRect.top + this.boundsRect.height() / 2.0f + pointF2.y);
        LinearGradient linearGradient2 = new LinearGradient((float)n2, (float)n3, (float)n4, (float)n5, arrn, arrf, Shader.TileMode.CLAMP);
        this.linearGradientCache.put(l, (Object)linearGradient2);
        return linearGradient2;
    }

    private RadialGradient getRadialGradient() {
        LongSparseArray<RadialGradient> longSparseArray = this.radialGradientCache;
        int n = this.getGradientHash();
        long l = n;
        RadialGradient radialGradient = (RadialGradient)longSparseArray.get(l);
        if (radialGradient != null) {
            return radialGradient;
        }
        PointF pointF = this.startPointAnimation.getValue();
        PointF pointF2 = this.endPointAnimation.getValue();
        GradientColor gradientColor = this.colorAnimation.getValue();
        int[] arrn = this.applyDynamicColorsIfNeeded(gradientColor.getColors());
        float[] arrf = gradientColor.getPositions();
        int n2 = (int)(this.boundsRect.left + this.boundsRect.width() / 2.0f + pointF.x);
        int n3 = (int)(this.boundsRect.top + this.boundsRect.height() / 2.0f + pointF.y);
        int n4 = (int)(this.boundsRect.left + this.boundsRect.width() / 2.0f + pointF2.x);
        int n5 = (int)(this.boundsRect.top + this.boundsRect.height() / 2.0f + pointF2.y);
        float f = (float)Math.hypot((double)(n4 - n2), (double)(n5 - n3));
        RadialGradient radialGradient2 = new RadialGradient((float)n2, (float)n3, f, arrn, arrf, Shader.TileMode.CLAMP);
        this.radialGradientCache.put(l, (Object)radialGradient2);
        return radialGradient2;
    }

    @Override
    public <T> void addValueCallback(T t, LottieValueCallback<T> lottieValueCallback) {
        super.addValueCallback(t, lottieValueCallback);
        if (t == LottieProperty.GRADIENT_COLOR) {
            if (lottieValueCallback == null) {
                if (this.colorCallbackAnimation != null) {
                    this.layer.removeAnimation(this.colorCallbackAnimation);
                }
                this.colorCallbackAnimation = null;
                return;
            }
            this.colorCallbackAnimation = new ValueCallbackKeyframeAnimation(lottieValueCallback);
            this.colorCallbackAnimation.addUpdateListener(this);
            this.layer.addAnimation(this.colorCallbackAnimation);
        }
    }

    @Override
    public void draw(Canvas canvas, Matrix matrix, int n) {
        if (this.hidden) {
            return;
        }
        this.getBounds(this.boundsRect, matrix, false);
        Object object = this.type == GradientType.LINEAR ? this.getLinearGradient() : this.getRadialGradient();
        this.paint.setShader((Shader)object);
        super.draw(canvas, matrix, n);
    }

    @Override
    public String getName() {
        return this.name;
    }
}

