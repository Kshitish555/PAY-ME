/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Path
 *  android.graphics.RectF
 *  com.airbnb.lottie.LottieDrawable
 *  com.airbnb.lottie.LottieProperty
 *  com.airbnb.lottie.animation.content.Content
 *  com.airbnb.lottie.animation.content.GreedyContent
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation$AnimationListener
 *  com.airbnb.lottie.animation.keyframe.TransformKeyframeAnimation
 *  com.airbnb.lottie.model.KeyPath
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 *  java.util.ListIterator
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.ContentGroup;
import com.airbnb.lottie.animation.content.DrawingContent;
import com.airbnb.lottie.animation.content.GreedyContent;
import com.airbnb.lottie.animation.content.KeyPathElementContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.TransformKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableTransform;
import com.airbnb.lottie.model.content.Repeater;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

public class RepeaterContent
implements DrawingContent,
PathContent,
GreedyContent,
BaseKeyframeAnimation.AnimationListener,
KeyPathElementContent {
    private ContentGroup contentGroup;
    private final BaseKeyframeAnimation<Float, Float> copies;
    private final boolean hidden;
    private final BaseLayer layer;
    private final LottieDrawable lottieDrawable;
    private final Matrix matrix = new Matrix();
    private final String name;
    private final BaseKeyframeAnimation<Float, Float> offset;
    private final Path path = new Path();
    private final TransformKeyframeAnimation transform;

    public RepeaterContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, Repeater repeater) {
        this.lottieDrawable = lottieDrawable;
        this.layer = baseLayer;
        this.name = repeater.getName();
        this.hidden = repeater.isHidden();
        this.copies = repeater.getCopies().createAnimation();
        baseLayer.addAnimation(this.copies);
        this.copies.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        this.offset = repeater.getOffset().createAnimation();
        baseLayer.addAnimation(this.offset);
        this.offset.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        this.transform = repeater.getTransform().createAnimation();
        this.transform.addAnimationsToLayer(baseLayer);
        this.transform.addListener((BaseKeyframeAnimation.AnimationListener)this);
    }

    public void absorbContent(ListIterator<Content> listIterator) {
        ContentGroup contentGroup;
        if (this.contentGroup != null) {
            return;
        }
        while (listIterator.hasPrevious() && listIterator.previous() != this) {
        }
        ArrayList arrayList = new ArrayList();
        while (listIterator.hasPrevious()) {
            arrayList.add(listIterator.previous());
            listIterator.remove();
        }
        Collections.reverse((List)arrayList);
        this.contentGroup = contentGroup = new ContentGroup(this.lottieDrawable, this.layer, "Repeater", this.hidden, (List<Content>)arrayList, null);
    }

    public <T> void addValueCallback(T t2, LottieValueCallback<T> lottieValueCallback) {
        if (this.transform.applyValueCallback(t2, lottieValueCallback)) {
            return;
        }
        if (t2 == LottieProperty.REPEATER_COPIES) {
            this.copies.setValueCallback(lottieValueCallback);
            return;
        }
        if (t2 == LottieProperty.REPEATER_OFFSET) {
            this.offset.setValueCallback(lottieValueCallback);
        }
    }

    @Override
    public void draw(Canvas canvas, Matrix matrix, int n2) {
        float f2 = ((Float)this.copies.getValue()).floatValue();
        float f3 = ((Float)this.offset.getValue()).floatValue();
        float f4 = ((Float)this.transform.getStartOpacity().getValue()).floatValue() / 100.0f;
        float f5 = ((Float)this.transform.getEndOpacity().getValue()).floatValue() / 100.0f;
        for (int i2 = -1 + (int)f2; i2 >= 0; --i2) {
            this.matrix.set(matrix);
            Matrix matrix2 = this.matrix;
            TransformKeyframeAnimation transformKeyframeAnimation = this.transform;
            float f6 = i2;
            matrix2.preConcat(transformKeyframeAnimation.getMatrixForRepeater(f6 + f3));
            float f7 = (float)n2 * MiscUtils.lerp((float)f4, (float)f5, (float)(f6 / f2));
            this.contentGroup.draw(canvas, this.matrix, (int)f7);
        }
    }

    @Override
    public void getBounds(RectF rectF, Matrix matrix, boolean bl) {
        this.contentGroup.getBounds(rectF, matrix, bl);
    }

    public String getName() {
        return this.name;
    }

    @Override
    public Path getPath() {
        Path path = this.contentGroup.getPath();
        this.path.reset();
        float f2 = ((Float)this.copies.getValue()).floatValue();
        float f3 = ((Float)this.offset.getValue()).floatValue();
        for (int i2 = -1 + (int)f2; i2 >= 0; --i2) {
            this.matrix.set(this.transform.getMatrixForRepeater(f3 + (float)i2));
            this.path.addPath(path, this.matrix);
        }
        return this.path;
    }

    public void onValueChanged() {
        this.lottieDrawable.invalidateSelf();
    }

    public void resolveKeyPath(KeyPath keyPath, int n2, List<KeyPath> list, KeyPath keyPath2) {
        MiscUtils.resolveKeyPath((KeyPath)keyPath, (int)n2, list, (KeyPath)keyPath2, (KeyPathElementContent)this);
    }

    public void setContents(List<Content> list, List<Content> list2) {
        this.contentGroup.setContents(list, list2);
    }
}

