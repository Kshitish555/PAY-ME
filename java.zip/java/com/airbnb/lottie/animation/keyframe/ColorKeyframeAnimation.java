/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.utils.GammaEvaluator
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.Keyframe
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import com.airbnb.lottie.animation.keyframe.KeyframeAnimation;
import com.airbnb.lottie.utils.GammaEvaluator;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class ColorKeyframeAnimation
extends KeyframeAnimation<Integer> {
    public ColorKeyframeAnimation(List<Keyframe<Integer>> list) {
        super(list);
    }

    public int getIntValue() {
        return this.getIntValue((Keyframe<Integer>)this.getCurrentKeyframe(), this.getInterpolatedCurrentKeyframeProgress());
    }

    public int getIntValue(Keyframe<Integer> keyframe, float f2) {
        if (keyframe.startValue != null && keyframe.endValue != null) {
            Integer n2;
            int n3 = (Integer)keyframe.startValue;
            int n4 = (Integer)keyframe.endValue;
            if (this.valueCallback != null && (n2 = (Integer)this.valueCallback.getValueInternal(keyframe.startFrame, keyframe.endFrame.floatValue(), (Object)n3, (Object)n4, f2, this.getLinearCurrentKeyframeProgress(), this.getProgress())) != null) {
                return n2;
            }
            return GammaEvaluator.evaluate((float)MiscUtils.clamp((float)f2, (float)0.0f, (float)1.0f), (int)n3, (int)n4);
        }
        throw new IllegalStateException("Missing values for keyframe.");
    }

    Integer getValue(Keyframe<Integer> keyframe, float f2) {
        return this.getIntValue(keyframe, f2);
    }
}

