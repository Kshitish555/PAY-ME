/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation$AnimationListener
 *  com.airbnb.lottie.value.Keyframe
 *  java.lang.Float
 *  java.lang.Object
 *  java.util.Collections
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import android.graphics.PointF;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.value.Keyframe;
import java.util.Collections;
import java.util.List;

public class SplitDimensionPathKeyframeAnimation
extends BaseKeyframeAnimation<PointF, PointF> {
    private final PointF point = new PointF();
    private final BaseKeyframeAnimation<Float, Float> xAnimation;
    private final BaseKeyframeAnimation<Float, Float> yAnimation;

    public SplitDimensionPathKeyframeAnimation(BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation, BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation2) {
        super(Collections.emptyList());
        this.xAnimation = baseKeyframeAnimation;
        this.yAnimation = baseKeyframeAnimation2;
        this.setProgress(this.getProgress());
    }

    public PointF getValue() {
        return this.getValue((Keyframe<PointF>)null, 0.0f);
    }

    PointF getValue(Keyframe<PointF> keyframe, float f2) {
        return this.point;
    }

    public void setProgress(float f2) {
        this.xAnimation.setProgress(f2);
        this.yAnimation.setProgress(f2);
        this.point.set(((Float)this.xAnimation.getValue()).floatValue(), ((Float)this.yAnimation.getValue()).floatValue());
        for (int i2 = 0; i2 < this.listeners.size(); ++i2) {
            ((BaseKeyframeAnimation.AnimationListener)this.listeners.get(i2)).onValueChanged();
        }
    }
}

