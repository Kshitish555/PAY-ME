/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 *  com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation
 *  com.airbnb.lottie.model.content.ShapeData
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.Keyframe
 *  java.lang.Object
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import android.graphics.Path;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.model.content.ShapeData;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.Keyframe;
import java.util.List;

public class ShapeKeyframeAnimation
extends BaseKeyframeAnimation<ShapeData, Path> {
    private final Path tempPath = new Path();
    private final ShapeData tempShapeData = new ShapeData();

    public ShapeKeyframeAnimation(List<Keyframe<ShapeData>> list) {
        super(list);
    }

    public Path getValue(Keyframe<ShapeData> keyframe, float f2) {
        ShapeData shapeData = (ShapeData)keyframe.startValue;
        ShapeData shapeData2 = (ShapeData)keyframe.endValue;
        this.tempShapeData.interpolateBetween(shapeData, shapeData2, f2);
        MiscUtils.getPathFromData((ShapeData)this.tempShapeData, (Path)this.tempPath);
        return this.tempPath;
    }
}

