/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.model.DocumentData
 *  com.airbnb.lottie.value.Keyframe
 *  java.lang.Object
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import com.airbnb.lottie.animation.keyframe.KeyframeAnimation;
import com.airbnb.lottie.model.DocumentData;
import com.airbnb.lottie.value.Keyframe;
import java.util.List;

public class TextKeyframeAnimation
extends KeyframeAnimation<DocumentData> {
    public TextKeyframeAnimation(List<Keyframe<DocumentData>> list) {
        super(list);
    }

    DocumentData getValue(Keyframe<DocumentData> keyframe, float f2) {
        return (DocumentData)keyframe.startValue;
    }
}

