/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.Keyframe
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import com.airbnb.lottie.animation.keyframe.KeyframeAnimation;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class IntegerKeyframeAnimation
extends KeyframeAnimation<Integer> {
    public IntegerKeyframeAnimation(List<Keyframe<Integer>> list) {
        super(list);
    }

    public int getIntValue() {
        return this.getIntValue((Keyframe<Integer>)this.getCurrentKeyframe(), this.getInterpolatedCurrentKeyframeProgress());
    }

    int getIntValue(Keyframe<Integer> keyframe, float f2) {
        if (keyframe.startValue != null && keyframe.endValue != null) {
            Integer n2;
            if (this.valueCallback != null && (n2 = (Integer)this.valueCallback.getValueInternal(keyframe.startFrame, keyframe.endFrame.floatValue(), keyframe.startValue, keyframe.endValue, f2, this.getLinearCurrentKeyframeProgress(), this.getProgress())) != null) {
                return n2;
            }
            return MiscUtils.lerp((int)keyframe.getStartValueInt(), (int)keyframe.getEndValueInt(), (float)f2);
        }
        throw new IllegalStateException("Missing values for keyframe.");
    }

    Integer getValue(Keyframe<Integer> keyframe, float f2) {
        return this.getIntValue(keyframe, f2);
    }
}

