/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.Keyframe
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import com.airbnb.lottie.animation.keyframe.KeyframeAnimation;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class FloatKeyframeAnimation
extends KeyframeAnimation<Float> {
    public FloatKeyframeAnimation(List<Keyframe<Float>> list) {
        super(list);
    }

    public float getFloatValue() {
        return this.getFloatValue((Keyframe<Float>)this.getCurrentKeyframe(), this.getInterpolatedCurrentKeyframeProgress());
    }

    float getFloatValue(Keyframe<Float> keyframe, float f2) {
        if (keyframe.startValue != null && keyframe.endValue != null) {
            Float f3;
            if (this.valueCallback != null && (f3 = (Float)this.valueCallback.getValueInternal(keyframe.startFrame, keyframe.endFrame.floatValue(), keyframe.startValue, keyframe.endValue, f2, this.getLinearCurrentKeyframeProgress(), this.getProgress())) != null) {
                return f3.floatValue();
            }
            return MiscUtils.lerp((float)keyframe.getStartValueFloat(), (float)keyframe.getEndValueFloat(), (float)f2);
        }
        throw new IllegalStateException("Missing values for keyframe.");
    }

    Float getValue(Keyframe<Float> keyframe, float f2) {
        return Float.valueOf((float)this.getFloatValue(keyframe, f2));
    }
}

