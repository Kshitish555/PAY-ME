/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import android.view.animation.Interpolator;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseKeyframeAnimation<K, A> {
    private float cachedEndProgress = -1.0f;
    private A cachedGetValue = null;
    private Keyframe<K> cachedGetValueKeyframe;
    private float cachedGetValueProgress = -1.0f;
    private Keyframe<K> cachedKeyframe;
    private float cachedStartDelayProgress = -1.0f;
    private boolean isDiscrete = false;
    private final List<? extends Keyframe<K>> keyframes;
    final List<AnimationListener> listeners = new ArrayList(1);
    private float progress = 0.0f;
    protected LottieValueCallback<A> valueCallback;

    BaseKeyframeAnimation(List<? extends Keyframe<K>> list) {
        this.keyframes = list;
    }

    private float getStartDelayProgress() {
        if (this.cachedStartDelayProgress == -1.0f) {
            float f = this.keyframes.isEmpty() ? 0.0f : ((Keyframe)this.keyframes.get(0)).getStartProgress();
            this.cachedStartDelayProgress = f;
        }
        return this.cachedStartDelayProgress;
    }

    public void addUpdateListener(AnimationListener animationListener) {
        this.listeners.add((Object)animationListener);
    }

    protected Keyframe<K> getCurrentKeyframe() {
        Keyframe<K> keyframe = this.cachedKeyframe;
        if (keyframe != null && keyframe.containsProgress(this.progress)) {
            return this.cachedKeyframe;
        }
        List<? extends Keyframe<K>> list = this.keyframes;
        Keyframe keyframe2 = (Keyframe)list.get(-1 + list.size());
        if (this.progress < keyframe2.getStartProgress()) {
            for (int i = -1 + this.keyframes.size(); i >= 0 && !(keyframe2 = (Keyframe)this.keyframes.get(i)).containsProgress(this.progress); --i) {
            }
        }
        this.cachedKeyframe = keyframe2;
        return keyframe2;
    }

    float getEndProgress() {
        if (this.cachedEndProgress == -1.0f) {
            float f;
            if (this.keyframes.isEmpty()) {
                f = 1.0f;
            } else {
                List<? extends Keyframe<K>> list = this.keyframes;
                f = ((Keyframe)list.get(-1 + list.size())).getEndProgress();
            }
            this.cachedEndProgress = f;
        }
        return this.cachedEndProgress;
    }

    protected float getInterpolatedCurrentKeyframeProgress() {
        Keyframe<K> keyframe = this.getCurrentKeyframe();
        if (keyframe.isStatic()) {
            return 0.0f;
        }
        return keyframe.interpolator.getInterpolation(this.getLinearCurrentKeyframeProgress());
    }

    float getLinearCurrentKeyframeProgress() {
        if (this.isDiscrete) {
            return 0.0f;
        }
        Keyframe<K> keyframe = this.getCurrentKeyframe();
        if (keyframe.isStatic()) {
            return 0.0f;
        }
        return (this.progress - keyframe.getStartProgress()) / (keyframe.getEndProgress() - keyframe.getStartProgress());
    }

    public float getProgress() {
        return this.progress;
    }

    public A getValue() {
        Keyframe<K> keyframe = this.getCurrentKeyframe();
        float f = this.getInterpolatedCurrentKeyframeProgress();
        if (this.valueCallback == null && keyframe == this.cachedGetValueKeyframe && this.cachedGetValueProgress == f) {
            return this.cachedGetValue;
        }
        this.cachedGetValueKeyframe = keyframe;
        this.cachedGetValueProgress = f;
        A a = this.getValue(keyframe, f);
        this.cachedGetValue = a;
        return a;
    }

    abstract A getValue(Keyframe<K> var1, float var2);

    public void notifyListeners() {
        for (int i = 0; i < this.listeners.size(); ++i) {
            ((AnimationListener)this.listeners.get(i)).onValueChanged();
        }
    }

    public void setIsDiscrete() {
        this.isDiscrete = true;
    }

    public void setProgress(float f) {
        if (this.keyframes.isEmpty()) {
            return;
        }
        Keyframe<K> keyframe = this.getCurrentKeyframe();
        if (f < this.getStartDelayProgress()) {
            f = this.getStartDelayProgress();
        } else if (f > this.getEndProgress()) {
            f = this.getEndProgress();
        }
        if (f == this.progress) {
            return;
        }
        this.progress = f;
        Keyframe<K> keyframe2 = this.getCurrentKeyframe();
        if (keyframe != keyframe2 || !keyframe2.isStatic()) {
            this.notifyListeners();
        }
    }

    public void setValueCallback(LottieValueCallback<A> lottieValueCallback) {
        LottieValueCallback<A> lottieValueCallback2 = this.valueCallback;
        if (lottieValueCallback2 != null) {
            lottieValueCallback2.setAnimation(null);
        }
        this.valueCallback = lottieValueCallback;
        if (lottieValueCallback != null) {
            lottieValueCallback.setAnimation(this);
        }
    }

    public static interface AnimationListener {
        public void onValueChanged();
    }

}

