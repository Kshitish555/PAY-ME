/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.ColorFilter
 *  android.graphics.Paint
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$Callback
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.View
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.lottie.FontAssetDelegate
 *  com.airbnb.lottie.ImageAssetDelegate
 *  com.airbnb.lottie.L
 *  com.airbnb.lottie.LottieAnimationView$4
 *  com.airbnb.lottie.LottieAnimationView$SavedState
 *  com.airbnb.lottie.LottieComposition
 *  com.airbnb.lottie.LottieCompositionFactory
 *  com.airbnb.lottie.LottieDrawable
 *  com.airbnb.lottie.LottieListener
 *  com.airbnb.lottie.LottieOnCompositionLoadedListener
 *  com.airbnb.lottie.LottieProperty
 *  com.airbnb.lottie.LottieTask
 *  com.airbnb.lottie.PerformanceTracker
 *  com.airbnb.lottie.R
 *  com.airbnb.lottie.R$styleable
 *  com.airbnb.lottie.RenderMode
 *  com.airbnb.lottie.SimpleColorFilter
 *  com.airbnb.lottie.TextDelegate
 *  com.airbnb.lottie.model.KeyPath
 *  com.airbnb.lottie.parser.moshi.JsonReader
 *  com.airbnb.lottie.utils.Utils
 *  com.airbnb.lottie.value.LottieFrameInfo
 *  com.airbnb.lottie.value.LottieValueCallback
 *  com.airbnb.lottie.value.SimpleLottieValueCallback
 *  java.io.ByteArrayInputStream
 *  java.io.InputStream
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  okio.BufferedSource
 *  okio.Okio
 *  okio.Source
 */
package com.airbnb.lottie;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.lottie.FontAssetDelegate;
import com.airbnb.lottie.ImageAssetDelegate;
import com.airbnb.lottie.L;
import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieCompositionFactory;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieListener;
import com.airbnb.lottie.LottieOnCompositionLoadedListener;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.LottieTask;
import com.airbnb.lottie.PerformanceTracker;
import com.airbnb.lottie.R;
import com.airbnb.lottie.RenderMode;
import com.airbnb.lottie.SimpleColorFilter;
import com.airbnb.lottie.TextDelegate;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.utils.Utils;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.LottieValueCallback;
import com.airbnb.lottie.value.SimpleLottieValueCallback;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import okio.BufferedSource;
import okio.Okio;
import okio.Source;

/*
 * Exception performing whole class analysis.
 */
public class LottieAnimationView
extends AppCompatImageView {
    private static final String TAG;
    private String animationName;
    private int animationResId;
    private boolean autoPlay;
    private LottieComposition composition;
    private LottieTask<LottieComposition> compositionTask;
    private final LottieListener<Throwable> failureListener;
    private boolean isInitialized;
    private final LottieListener<LottieComposition> loadedListener;
    private final LottieDrawable lottieDrawable;
    private Set<LottieOnCompositionLoadedListener> lottieOnCompositionLoadedListeners;
    private RenderMode renderMode;
    private boolean wasAnimatingWhenDetached;
    private boolean wasAnimatingWhenNotShown;

    static {
        TAG = LottieAnimationView.class.getSimpleName();
    }

    public LottieAnimationView(Context context) {
        super(context);
        this.loadedListener = new LottieListener<LottieComposition>(){

            public void onResult(LottieComposition lottieComposition) {
                LottieAnimationView.this.setComposition(lottieComposition);
            }
        };
        this.failureListener = new LottieListener<Throwable>(){

            public void onResult(Throwable throwable) {
                throw new IllegalStateException("Unable to parse composition", throwable);
            }
        };
        this.lottieDrawable = new LottieDrawable();
        this.wasAnimatingWhenNotShown = false;
        this.wasAnimatingWhenDetached = false;
        this.autoPlay = false;
        this.renderMode = RenderMode.AUTOMATIC;
        this.lottieOnCompositionLoadedListeners = new HashSet();
        this.init(null);
    }

    public LottieAnimationView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.loadedListener = new /* invalid duplicate definition of identical inner class */;
        this.failureListener = new /* invalid duplicate definition of identical inner class */;
        this.lottieDrawable = new LottieDrawable();
        this.wasAnimatingWhenNotShown = false;
        this.wasAnimatingWhenDetached = false;
        this.autoPlay = false;
        this.renderMode = RenderMode.AUTOMATIC;
        this.lottieOnCompositionLoadedListeners = new HashSet();
        this.init(attributeSet);
    }

    public LottieAnimationView(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.loadedListener = new /* invalid duplicate definition of identical inner class */;
        this.failureListener = new /* invalid duplicate definition of identical inner class */;
        this.lottieDrawable = new LottieDrawable();
        this.wasAnimatingWhenNotShown = false;
        this.wasAnimatingWhenDetached = false;
        this.autoPlay = false;
        this.renderMode = RenderMode.AUTOMATIC;
        this.lottieOnCompositionLoadedListeners = new HashSet();
        this.init(attributeSet);
    }

    private void cancelLoaderTask() {
        LottieTask<LottieComposition> lottieTask = this.compositionTask;
        if (lottieTask != null) {
            lottieTask.removeListener(this.loadedListener);
            this.compositionTask.removeFailureListener(this.failureListener);
        }
    }

    private void clearComposition() {
        this.composition = null;
        this.lottieDrawable.clearComposition();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void enableOrDisableHardwareLayer() {
        LottieComposition lottieComposition;
        LottieComposition lottieComposition2;
        boolean bl;
        int n2 = 4.$SwitchMap$com$airbnb$lottie$RenderMode[this.renderMode.ordinal()];
        int n3 = 2;
        if (!(n2 == 1 || n2 != n3 && n2 == 3 && (bl = (lottieComposition2 = this.composition) != null && lottieComposition2.hasDashPattern() && Build.VERSION.SDK_INT < 28 ? false : ((lottieComposition = this.composition) != null && lottieComposition.getMaskAndMatteCount() > 4 ? false : Build.VERSION.SDK_INT >= 21)))) {
            n3 = 1;
        }
        if (n3 != this.getLayerType()) {
            this.setLayerType(n3, null);
        }
    }

    private void init(AttributeSet attributeSet) {
        TypedArray typedArray = this.getContext().obtainStyledAttributes(attributeSet, R.styleable.LottieAnimationView);
        if (!this.isInEditMode()) {
            String string2;
            boolean bl = typedArray.hasValue(R.styleable.LottieAnimationView_lottie_rawRes);
            boolean bl2 = typedArray.hasValue(R.styleable.LottieAnimationView_lottie_fileName);
            boolean bl3 = typedArray.hasValue(R.styleable.LottieAnimationView_lottie_url);
            if (bl && bl2) {
                throw new IllegalArgumentException("lottie_rawRes and lottie_fileName cannot be used at the same time. Please use only one at once.");
            }
            if (bl) {
                int n2 = typedArray.getResourceId(R.styleable.LottieAnimationView_lottie_rawRes, 0);
                if (n2 != 0) {
                    this.setAnimation(n2);
                }
            } else if (bl2) {
                String string3 = typedArray.getString(R.styleable.LottieAnimationView_lottie_fileName);
                if (string3 != null) {
                    this.setAnimation(string3);
                }
            } else if (bl3 && (string2 = typedArray.getString(R.styleable.LottieAnimationView_lottie_url)) != null) {
                this.setAnimationFromUrl(string2);
            }
        }
        if (typedArray.getBoolean(R.styleable.LottieAnimationView_lottie_autoPlay, false)) {
            this.wasAnimatingWhenDetached = true;
            this.autoPlay = true;
        }
        if (typedArray.getBoolean(R.styleable.LottieAnimationView_lottie_loop, false)) {
            this.lottieDrawable.setRepeatCount(-1);
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_repeatMode)) {
            this.setRepeatMode(typedArray.getInt(R.styleable.LottieAnimationView_lottie_repeatMode, 1));
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_repeatCount)) {
            this.setRepeatCount(typedArray.getInt(R.styleable.LottieAnimationView_lottie_repeatCount, -1));
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_speed)) {
            this.setSpeed(typedArray.getFloat(R.styleable.LottieAnimationView_lottie_speed, 1.0f));
        }
        this.setImageAssetsFolder(typedArray.getString(R.styleable.LottieAnimationView_lottie_imageAssetsFolder));
        this.setProgress(typedArray.getFloat(R.styleable.LottieAnimationView_lottie_progress, 0.0f));
        this.enableMergePathsForKitKatAndAbove(typedArray.getBoolean(R.styleable.LottieAnimationView_lottie_enableMergePathsForKitKatAndAbove, false));
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_colorFilter)) {
            SimpleColorFilter simpleColorFilter = new SimpleColorFilter(typedArray.getColor(R.styleable.LottieAnimationView_lottie_colorFilter, 0));
            KeyPath keyPath = new KeyPath(new String[]{"**"});
            LottieValueCallback lottieValueCallback = new LottieValueCallback((Object)simpleColorFilter);
            this.addValueCallback(keyPath, (T)LottieProperty.COLOR_FILTER, (LottieValueCallback<T>)lottieValueCallback);
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_scale)) {
            this.lottieDrawable.setScale(typedArray.getFloat(R.styleable.LottieAnimationView_lottie_scale, 1.0f));
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_renderMode)) {
            int n3 = typedArray.getInt(R.styleable.LottieAnimationView_lottie_renderMode, RenderMode.AUTOMATIC.ordinal());
            if (n3 >= RenderMode.values().length) {
                n3 = RenderMode.AUTOMATIC.ordinal();
            }
            this.renderMode = RenderMode.values()[n3];
        }
        typedArray.recycle();
        LottieDrawable lottieDrawable = this.lottieDrawable;
        float f2 = Utils.getAnimationScale((Context)this.getContext()) FCMPL 0.0f;
        boolean bl = false;
        if (f2 != false) {
            bl = true;
        }
        lottieDrawable.setSystemAnimationsAreEnabled(Boolean.valueOf((boolean)bl));
        this.enableOrDisableHardwareLayer();
        this.isInitialized = true;
    }

    private void setCompositionTask(LottieTask<LottieComposition> lottieTask) {
        this.clearComposition();
        this.cancelLoaderTask();
        this.compositionTask = lottieTask.addListener(this.loadedListener).addFailureListener(this.failureListener);
    }

    public void addAnimatorListener(Animator.AnimatorListener animatorListener) {
        this.lottieDrawable.addAnimatorListener(animatorListener);
    }

    public void addAnimatorUpdateListener(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.lottieDrawable.addAnimatorUpdateListener(animatorUpdateListener);
    }

    public boolean addLottieOnCompositionLoadedListener(LottieOnCompositionLoadedListener lottieOnCompositionLoadedListener) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition != null) {
            lottieOnCompositionLoadedListener.onCompositionLoaded(lottieComposition);
        }
        return this.lottieOnCompositionLoadedListeners.add((Object)lottieOnCompositionLoadedListener);
    }

    public <T> void addValueCallback(KeyPath keyPath, T t2, LottieValueCallback<T> lottieValueCallback) {
        this.lottieDrawable.addValueCallback(keyPath, t2, lottieValueCallback);
    }

    public <T> void addValueCallback(KeyPath keyPath, T t2, final SimpleLottieValueCallback<T> simpleLottieValueCallback) {
        this.lottieDrawable.addValueCallback(keyPath, t2, new LottieValueCallback<T>(){

            public T getValue(LottieFrameInfo<T> lottieFrameInfo) {
                return (T)simpleLottieValueCallback.getValue(lottieFrameInfo);
            }
        });
    }

    public void buildDrawingCache(boolean bl) {
        super.buildDrawingCache(bl);
        if (this.getLayerType() == 1 && this.getDrawingCache(bl) == null) {
            this.setRenderMode(RenderMode.HARDWARE);
        }
    }

    public void cancelAnimation() {
        this.wasAnimatingWhenNotShown = false;
        this.lottieDrawable.cancelAnimation();
        this.enableOrDisableHardwareLayer();
    }

    public void enableMergePathsForKitKatAndAbove(boolean bl) {
        this.lottieDrawable.enableMergePathsForKitKatAndAbove(bl);
    }

    public LottieComposition getComposition() {
        return this.composition;
    }

    public long getDuration() {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition != null) {
            return (long)lottieComposition.getDuration();
        }
        return 0L;
    }

    public int getFrame() {
        return this.lottieDrawable.getFrame();
    }

    public String getImageAssetsFolder() {
        return this.lottieDrawable.getImageAssetsFolder();
    }

    public float getMaxFrame() {
        return this.lottieDrawable.getMaxFrame();
    }

    public float getMinFrame() {
        return this.lottieDrawable.getMinFrame();
    }

    public PerformanceTracker getPerformanceTracker() {
        return this.lottieDrawable.getPerformanceTracker();
    }

    public float getProgress() {
        return this.lottieDrawable.getProgress();
    }

    public int getRepeatCount() {
        return this.lottieDrawable.getRepeatCount();
    }

    public int getRepeatMode() {
        return this.lottieDrawable.getRepeatMode();
    }

    public float getScale() {
        return this.lottieDrawable.getScale();
    }

    public float getSpeed() {
        return this.lottieDrawable.getSpeed();
    }

    public boolean hasMasks() {
        return this.lottieDrawable.hasMasks();
    }

    public boolean hasMatte() {
        return this.lottieDrawable.hasMatte();
    }

    public void invalidateDrawable(Drawable drawable2) {
        LottieDrawable lottieDrawable;
        Drawable drawable3 = this.getDrawable();
        if (drawable3 == (lottieDrawable = this.lottieDrawable)) {
            super.invalidateDrawable((Drawable)lottieDrawable);
            return;
        }
        super.invalidateDrawable(drawable2);
    }

    public boolean isAnimating() {
        return this.lottieDrawable.isAnimating();
    }

    public boolean isMergePathsEnabledForKitKatAndAbove() {
        return this.lottieDrawable.isMergePathsEnabledForKitKatAndAbove();
    }

    @Deprecated
    public void loop(boolean bl) {
        LottieDrawable lottieDrawable = this.lottieDrawable;
        int n2 = bl ? -1 : 0;
        lottieDrawable.setRepeatCount(n2);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.autoPlay || this.wasAnimatingWhenDetached) {
            this.playAnimation();
            this.autoPlay = false;
        }
        if (Build.VERSION.SDK_INT < 23) {
            this.onVisibilityChanged((View)this, this.getVisibility());
        }
    }

    protected void onDetachedFromWindow() {
        if (this.isAnimating()) {
            this.cancelAnimation();
            this.wasAnimatingWhenDetached = true;
        }
        super.onDetachedFromWindow();
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        int n2;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.animationName = savedState.animationName;
        if (!TextUtils.isEmpty((CharSequence)this.animationName)) {
            this.setAnimation(this.animationName);
        }
        if ((n2 = (this.animationResId = savedState.animationResId)) != 0) {
            this.setAnimation(n2);
        }
        this.setProgress(savedState.progress);
        if (savedState.isAnimating) {
            this.playAnimation();
        }
        this.lottieDrawable.setImagesAssetsFolder(savedState.imageAssetsFolder);
        this.setRepeatMode(savedState.repeatMode);
        this.setRepeatCount(savedState.repeatCount);
    }

    protected Parcelable onSaveInstanceState() {
        SavedState savedState = new /* Unavailable Anonymous Inner Class!! */;
        savedState.animationName = this.animationName;
        savedState.animationResId = this.animationResId;
        savedState.progress = this.lottieDrawable.getProgress();
        savedState.isAnimating = this.lottieDrawable.isAnimating();
        savedState.imageAssetsFolder = this.lottieDrawable.getImageAssetsFolder();
        savedState.repeatMode = this.lottieDrawable.getRepeatMode();
        savedState.repeatCount = this.lottieDrawable.getRepeatCount();
        return savedState;
    }

    protected void onVisibilityChanged(View view, int n2) {
        if (!this.isInitialized) {
            return;
        }
        if (this.isShown()) {
            if (this.wasAnimatingWhenNotShown) {
                this.resumeAnimation();
                this.wasAnimatingWhenNotShown = false;
                return;
            }
        } else if (this.isAnimating()) {
            this.pauseAnimation();
            this.wasAnimatingWhenNotShown = true;
        }
    }

    public void pauseAnimation() {
        this.autoPlay = false;
        this.wasAnimatingWhenDetached = false;
        this.wasAnimatingWhenNotShown = false;
        this.lottieDrawable.pauseAnimation();
        this.enableOrDisableHardwareLayer();
    }

    public void playAnimation() {
        if (this.isShown()) {
            this.lottieDrawable.playAnimation();
            this.enableOrDisableHardwareLayer();
            return;
        }
        this.wasAnimatingWhenNotShown = true;
    }

    public void removeAllAnimatorListeners() {
        this.lottieDrawable.removeAllAnimatorListeners();
    }

    public void removeAllLottieOnCompositionLoadedListener() {
        this.lottieOnCompositionLoadedListeners.clear();
    }

    public void removeAllUpdateListeners() {
        this.lottieDrawable.removeAllUpdateListeners();
    }

    public void removeAnimatorListener(Animator.AnimatorListener animatorListener) {
        this.lottieDrawable.removeAnimatorListener(animatorListener);
    }

    public boolean removeLottieOnCompositionLoadedListener(LottieOnCompositionLoadedListener lottieOnCompositionLoadedListener) {
        return this.lottieOnCompositionLoadedListeners.remove((Object)lottieOnCompositionLoadedListener);
    }

    public void removeUpdateListener(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.lottieDrawable.removeAnimatorUpdateListener(animatorUpdateListener);
    }

    public List<KeyPath> resolveKeyPath(KeyPath keyPath) {
        return this.lottieDrawable.resolveKeyPath(keyPath);
    }

    public void resumeAnimation() {
        if (this.isShown()) {
            this.lottieDrawable.resumeAnimation();
            this.enableOrDisableHardwareLayer();
            return;
        }
        this.wasAnimatingWhenNotShown = true;
    }

    public void reverseAnimationSpeed() {
        this.lottieDrawable.reverseAnimationSpeed();
    }

    public void setAnimation(int n2) {
        this.animationResId = n2;
        this.animationName = null;
        this.setCompositionTask((LottieTask<LottieComposition>)LottieCompositionFactory.fromRawRes((Context)this.getContext(), (int)n2));
    }

    public void setAnimation(JsonReader jsonReader, String string2) {
        this.setCompositionTask((LottieTask<LottieComposition>)LottieCompositionFactory.fromJsonReader((JsonReader)jsonReader, (String)string2));
    }

    public void setAnimation(String string2) {
        this.animationName = string2;
        this.animationResId = 0;
        this.setCompositionTask((LottieTask<LottieComposition>)LottieCompositionFactory.fromAsset((Context)this.getContext(), (String)string2));
    }

    @Deprecated
    public void setAnimationFromJson(String string2) {
        this.setAnimationFromJson(string2, null);
    }

    public void setAnimationFromJson(String string2, String string3) {
        this.setAnimation(JsonReader.of((BufferedSource)Okio.buffer((Source)Okio.source((InputStream)new ByteArrayInputStream(string2.getBytes())))), string3);
    }

    public void setAnimationFromUrl(String string2) {
        this.setCompositionTask((LottieTask<LottieComposition>)LottieCompositionFactory.fromUrl((Context)this.getContext(), (String)string2));
    }

    public void setComposition(LottieComposition lottieComposition) {
        if (L.DBG) {
            String string2 = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Set Composition \n");
            stringBuilder.append((Object)lottieComposition);
            Log.v((String)string2, (String)stringBuilder.toString());
        }
        this.lottieDrawable.setCallback((Drawable.Callback)this);
        this.composition = lottieComposition;
        boolean bl = this.lottieDrawable.setComposition(lottieComposition);
        this.enableOrDisableHardwareLayer();
        if (this.getDrawable() == this.lottieDrawable && !bl) {
            return;
        }
        this.setImageDrawable(null);
        this.setImageDrawable((Drawable)this.lottieDrawable);
        this.onVisibilityChanged((View)this, this.getVisibility());
        this.requestLayout();
        Iterator iterator = this.lottieOnCompositionLoadedListeners.iterator();
        while (iterator.hasNext()) {
            ((LottieOnCompositionLoadedListener)iterator.next()).onCompositionLoaded(lottieComposition);
        }
    }

    public void setFontAssetDelegate(FontAssetDelegate fontAssetDelegate) {
        this.lottieDrawable.setFontAssetDelegate(fontAssetDelegate);
    }

    public void setFrame(int n2) {
        this.lottieDrawable.setFrame(n2);
    }

    public void setImageAssetDelegate(ImageAssetDelegate imageAssetDelegate) {
        this.lottieDrawable.setImageAssetDelegate(imageAssetDelegate);
    }

    public void setImageAssetsFolder(String string2) {
        this.lottieDrawable.setImagesAssetsFolder(string2);
    }

    public void setImageBitmap(Bitmap bitmap) {
        this.cancelLoaderTask();
        super.setImageBitmap(bitmap);
    }

    public void setImageDrawable(Drawable drawable2) {
        this.cancelLoaderTask();
        super.setImageDrawable(drawable2);
    }

    public void setImageResource(int n2) {
        this.cancelLoaderTask();
        super.setImageResource(n2);
    }

    public void setMaxFrame(int n2) {
        this.lottieDrawable.setMaxFrame(n2);
    }

    public void setMaxFrame(String string2) {
        this.lottieDrawable.setMaxFrame(string2);
    }

    public void setMaxProgress(float f2) {
        this.lottieDrawable.setMaxProgress(f2);
    }

    public void setMinAndMaxFrame(int n2, int n3) {
        this.lottieDrawable.setMinAndMaxFrame(n2, n3);
    }

    public void setMinAndMaxFrame(String string2) {
        this.lottieDrawable.setMinAndMaxFrame(string2);
    }

    public void setMinAndMaxProgress(float f2, float f3) {
        this.lottieDrawable.setMinAndMaxProgress(f2, f3);
    }

    public void setMinFrame(int n2) {
        this.lottieDrawable.setMinFrame(n2);
    }

    public void setMinFrame(String string2) {
        this.lottieDrawable.setMinFrame(string2);
    }

    public void setMinProgress(float f2) {
        this.lottieDrawable.setMinProgress(f2);
    }

    public void setPerformanceTrackingEnabled(boolean bl) {
        this.lottieDrawable.setPerformanceTrackingEnabled(bl);
    }

    public void setProgress(float f2) {
        this.lottieDrawable.setProgress(f2);
    }

    public void setRenderMode(RenderMode renderMode) {
        this.renderMode = renderMode;
        this.enableOrDisableHardwareLayer();
    }

    public void setRepeatCount(int n2) {
        this.lottieDrawable.setRepeatCount(n2);
    }

    public void setRepeatMode(int n2) {
        this.lottieDrawable.setRepeatMode(n2);
    }

    public void setScale(float f2) {
        this.lottieDrawable.setScale(f2);
        if (this.getDrawable() == this.lottieDrawable) {
            this.setImageDrawable(null);
            this.setImageDrawable((Drawable)this.lottieDrawable);
        }
    }

    public void setSpeed(float f2) {
        this.lottieDrawable.setSpeed(f2);
    }

    public void setTextDelegate(TextDelegate textDelegate) {
        this.lottieDrawable.setTextDelegate(textDelegate);
    }

    public Bitmap updateBitmap(String string2, Bitmap bitmap) {
        return this.lottieDrawable.updateBitmap(string2, bitmap);
    }

}

