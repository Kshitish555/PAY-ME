/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 *  com.airbnb.lottie.utils.MiscUtils
 *  java.lang.Integer
 *  java.lang.Object
 */
package com.airbnb.lottie.value;

import android.view.animation.Interpolator;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieInterpolatedValue;

public class LottieInterpolatedIntegerValue
extends LottieInterpolatedValue<Integer> {
    public LottieInterpolatedIntegerValue(Integer n2, Integer n3) {
        super(n2, n3);
    }

    public LottieInterpolatedIntegerValue(Integer n2, Integer n3, Interpolator interpolator) {
        super(n2, n3, interpolator);
    }

    @Override
    Integer interpolateValue(Integer n2, Integer n3, float f2) {
        return MiscUtils.lerp((int)n2, (int)n3, (float)f2);
    }
}

