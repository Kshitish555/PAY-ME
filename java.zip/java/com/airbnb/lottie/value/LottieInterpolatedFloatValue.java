/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 *  com.airbnb.lottie.utils.MiscUtils
 *  java.lang.Float
 *  java.lang.Object
 */
package com.airbnb.lottie.value;

import android.view.animation.Interpolator;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieInterpolatedValue;

public class LottieInterpolatedFloatValue
extends LottieInterpolatedValue<Float> {
    public LottieInterpolatedFloatValue(Float f2, Float f3) {
        super(f2, f3);
    }

    public LottieInterpolatedFloatValue(Float f2, Float f3, Interpolator interpolator) {
        super(f2, f3, interpolator);
    }

    @Override
    Float interpolateValue(Float f2, Float f3, float f4) {
        return Float.valueOf((float)MiscUtils.lerp((float)f2.floatValue(), (float)f3.floatValue(), (float)f4));
    }
}

