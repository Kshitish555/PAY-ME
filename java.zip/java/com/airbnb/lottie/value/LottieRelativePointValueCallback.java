/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.LottieFrameInfo
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.value;

import android.graphics.PointF;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.LottieValueCallback;

public class LottieRelativePointValueCallback
extends LottieValueCallback<PointF> {
    private final PointF point = new PointF();

    public LottieRelativePointValueCallback() {
    }

    public LottieRelativePointValueCallback(PointF pointF) {
        super((Object)pointF);
    }

    public PointF getOffset(LottieFrameInfo<PointF> lottieFrameInfo) {
        if (this.value != null) {
            return (PointF)this.value;
        }
        throw new IllegalArgumentException("You must provide a static value in the constructor , call setValue, or override getValue.");
    }

    public final PointF getValue(LottieFrameInfo<PointF> lottieFrameInfo) {
        this.point.set(MiscUtils.lerp((float)((PointF)lottieFrameInfo.getStartValue()).x, (float)((PointF)lottieFrameInfo.getEndValue()).x, (float)lottieFrameInfo.getInterpolatedKeyframeProgress()), MiscUtils.lerp((float)((PointF)lottieFrameInfo.getStartValue()).y, (float)((PointF)lottieFrameInfo.getEndValue()).y, (float)lottieFrameInfo.getInterpolatedKeyframeProgress()));
        PointF pointF = this.getOffset(lottieFrameInfo);
        this.point.offset(pointF.x, pointF.y);
        return this.point;
    }
}

