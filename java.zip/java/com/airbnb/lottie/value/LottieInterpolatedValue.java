/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 *  android.view.animation.LinearInterpolator
 *  com.airbnb.lottie.value.LottieFrameInfo
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Object
 */
package com.airbnb.lottie.value;

import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.LottieValueCallback;

abstract class LottieInterpolatedValue<T>
extends LottieValueCallback<T> {
    private final T endValue;
    private final Interpolator interpolator;
    private final T startValue;

    LottieInterpolatedValue(T t2, T t3) {
        this(t2, t3, (Interpolator)new LinearInterpolator());
    }

    LottieInterpolatedValue(T t2, T t3, Interpolator interpolator) {
        this.startValue = t2;
        this.endValue = t3;
        this.interpolator = interpolator;
    }

    public T getValue(LottieFrameInfo<T> lottieFrameInfo) {
        float f2 = this.interpolator.getInterpolation(lottieFrameInfo.getOverallProgress());
        return this.interpolateValue(this.startValue, this.endValue, f2);
    }

    abstract T interpolateValue(T var1, T var2, float var3);
}

