/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie.value;

import com.airbnb.lottie.value.LottieFrameInfo;

public interface SimpleLottieValueCallback<T> {
    public T getValue(LottieFrameInfo<T> var1);
}

