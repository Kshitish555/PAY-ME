/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  android.view.animation.Interpolator
 *  com.airbnb.lottie.utils.MiscUtils
 *  java.lang.Object
 */
package com.airbnb.lottie.value;

import android.graphics.PointF;
import android.view.animation.Interpolator;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieInterpolatedValue;

public class LottieInterpolatedPointValue
extends LottieInterpolatedValue<PointF> {
    private final PointF point = new PointF();

    public LottieInterpolatedPointValue(PointF pointF, PointF pointF2) {
        super(pointF, pointF2);
    }

    public LottieInterpolatedPointValue(PointF pointF, PointF pointF2, Interpolator interpolator) {
        super(pointF, pointF2, interpolator);
    }

    @Override
    PointF interpolateValue(PointF pointF, PointF pointF2, float f2) {
        this.point.set(MiscUtils.lerp((float)pointF.x, (float)pointF2.x, (float)f2), MiscUtils.lerp((float)pointF.y, (float)pointF2.y, (float)f2));
        return this.point;
    }
}

