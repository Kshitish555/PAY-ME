/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.utils.MiscUtils
 *  com.airbnb.lottie.value.LottieFrameInfo
 *  com.airbnb.lottie.value.LottieValueCallback
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.value;

import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.LottieValueCallback;

public class LottieRelativeFloatValueCallback
extends LottieValueCallback<Float> {
    public LottieRelativeFloatValueCallback() {
    }

    public LottieRelativeFloatValueCallback(Float f2) {
        super((Object)f2);
    }

    public Float getOffset(LottieFrameInfo<Float> lottieFrameInfo) {
        if (this.value != null) {
            return (Float)this.value;
        }
        throw new IllegalArgumentException("You must provide a static value in the constructor , call setValue, or override getValue.");
    }

    public Float getValue(LottieFrameInfo<Float> lottieFrameInfo) {
        return Float.valueOf((float)(MiscUtils.lerp((float)((Float)lottieFrameInfo.getStartValue()).floatValue(), (float)((Float)lottieFrameInfo.getEndValue()).floatValue(), (float)lottieFrameInfo.getInterpolatedKeyframeProgress()) + this.getOffset(lottieFrameInfo).floatValue()));
    }
}

