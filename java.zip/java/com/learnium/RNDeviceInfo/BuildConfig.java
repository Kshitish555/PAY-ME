/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package com.learnium.RNDeviceInfo;

public final class BuildConfig {
    @Deprecated
    public static final String APPLICATION_ID = "com.learnium.RNDeviceInfo";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final String LIBRARY_PACKAGE_NAME = "com.learnium.RNDeviceInfo";
    public static final int VERSION_CODE = 2;
    public static final String VERSION_NAME = "1.1";
}

