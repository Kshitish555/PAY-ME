/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.learnium.RNDeviceInfo;

public final class DeviceType
extends Enum<DeviceType> {
    private static final /* synthetic */ DeviceType[] $VALUES;
    public static final /* enum */ DeviceType HANDSET = new DeviceType("Handset");
    public static final /* enum */ DeviceType TABLET = new DeviceType("Tablet");
    public static final /* enum */ DeviceType TV = new DeviceType("Tv");
    public static final /* enum */ DeviceType UNKNOWN = new DeviceType("Unknown");
    private final String value;

    static {
        DeviceType[] arrdeviceType = new DeviceType[]{HANDSET, TABLET, TV, UNKNOWN};
        $VALUES = arrdeviceType;
    }

    private DeviceType(String string3) {
        this.value = string3;
    }

    public static DeviceType valueOf(String string2) {
        return (DeviceType)Enum.valueOf(DeviceType.class, (String)string2);
    }

    public static DeviceType[] values() {
        return (DeviceType[])$VALUES.clone();
    }

    public String getValue() {
        return this.value;
    }
}

