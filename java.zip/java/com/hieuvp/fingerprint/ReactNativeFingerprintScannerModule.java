/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  androidx.biometric.BiometricManager
 *  androidx.biometric.BiometricPrompt
 *  androidx.biometric.BiometricPrompt$AuthenticationCallback
 *  androidx.biometric.BiometricPrompt$AuthenticationResult
 *  androidx.fragment.app.FragmentActivity
 *  com.facebook.react.bridge.LifecycleEventListener
 *  com.facebook.react.bridge.Promise
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.UiThreadUtil
 *  com.facebook.react.module.annotations.ReactModule
 *  com.wei.android.lib.fingerprintidentify.FingerprintIdentify
 *  com.wei.android.lib.fingerprintidentify.base.BaseFingerprint
 *  com.wei.android.lib.fingerprintidentify.base.BaseFingerprint$ExceptionListener
 *  com.wei.android.lib.fingerprintidentify.base.BaseFingerprint$IdentifyListener
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.concurrent.Executor
 *  java.util.concurrent.Executors
 */
package com.hieuvp.fingerprint;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.fragment.app.FragmentActivity;
import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.UiThreadUtil;
import com.facebook.react.module.annotations.ReactModule;
import com.hieuvp.fingerprint.ReactNativeFingerprintScannerModule;
import com.wei.android.lib.fingerprintidentify.FingerprintIdentify;
import com.wei.android.lib.fingerprintidentify.base.BaseFingerprint;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@ReactModule(name="ReactNativeFingerprintScanner")
public class ReactNativeFingerprintScannerModule
extends ReactContextBaseJavaModule
implements LifecycleEventListener {
    public static final int MAX_AVAILABLE_TIMES = Integer.MAX_VALUE;
    public static final String TYPE_BIOMETRICS = "Biometrics";
    public static final String TYPE_FINGERPRINT_LEGACY = "Fingerprint";
    private BiometricPrompt biometricPrompt;
    private FingerprintIdentify mFingerprintIdentify;
    private final ReactApplicationContext mReactContext;

    public ReactNativeFingerprintScannerModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        this.mReactContext = reactApplicationContext;
    }

    static /* synthetic */ ReactApplicationContext access$100(ReactNativeFingerprintScannerModule reactNativeFingerprintScannerModule) {
        return reactNativeFingerprintScannerModule.mReactContext;
    }

    private void biometricAuthenticate(String string, Promise promise) {
        UiThreadUtil.runOnUiThread((Runnable)new Runnable(this, promise, string){
            final /* synthetic */ ReactNativeFingerprintScannerModule this$0;
            final /* synthetic */ String val$description;
            final /* synthetic */ Promise val$promise;
            {
                this.this$0 = reactNativeFingerprintScannerModule;
                this.val$promise = promise;
                this.val$description = string;
            }

            public void run() {
                this.this$0.getBiometricPrompt(this.val$promise).authenticate(new androidx.biometric.BiometricPrompt$PromptInfo$Builder().setDeviceCredentialAllowed(false).setConfirmationRequired(false).setNegativeButtonText((CharSequence)"Cancel").setTitle((CharSequence)this.val$description).build());
            }
        });
    }

    private String biometricPromptErrName(int n) {
        switch (n) {
            default: {
                return "FingerprintScannerUnknownError";
            }
            case 14: {
                return "PasscodeNotSet";
            }
            case 13: {
                return "UserCancel";
            }
            case 12: {
                return "FingerprintScannerNotSupported";
            }
            case 11: {
                return "FingerprintScannerNotEnrolled";
            }
            case 10: {
                return "UserFallback";
            }
            case 9: {
                return "DeviceLocked";
            }
            case 8: {
                return "HardwareError";
            }
            case 7: {
                return "DeviceLocked";
            }
            case 5: {
                return "SystemCancel";
            }
            case 4: {
                return "DeviceOutOfMemory";
            }
            case 3: {
                return "AuthenticationTimeout";
            }
            case 2: {
                return "AuthenticationProcessFailed";
            }
            case 1: 
        }
        return "FingerprintScannerNotAvailable";
    }

    private int currentAndroidVersion() {
        return Build.VERSION.SDK_INT;
    }

    private FingerprintIdentify getFingerprintIdentify() {
        FingerprintIdentify fingerprintIdentify = this.mFingerprintIdentify;
        if (fingerprintIdentify != null) {
            return fingerprintIdentify;
        }
        this.mReactContext.addLifecycleEventListener((LifecycleEventListener)this);
        this.mFingerprintIdentify = new FingerprintIdentify((Context)this.mReactContext);
        this.mFingerprintIdentify.setSupportAndroidL(true);
        this.mFingerprintIdentify.setExceptionListener(new BaseFingerprint.ExceptionListener(this){
            final /* synthetic */ ReactNativeFingerprintScannerModule this$0;
            {
                this.this$0 = reactNativeFingerprintScannerModule;
            }

            public void onCatchException(java.lang.Throwable throwable) {
                ReactNativeFingerprintScannerModule.access$100(this.this$0).removeLifecycleEventListener((LifecycleEventListener)this.this$0);
            }
        });
        this.mFingerprintIdentify.init();
        return this.mFingerprintIdentify;
    }

    private String getSensorError() {
        int n = BiometricManager.from((Context)this.mReactContext).canAuthenticate();
        if (n == 0) {
            return null;
        }
        if (n == 12) {
            return "FingerprintScannerNotSupported";
        }
        if (n == 11) {
            return "FingerprintScannerNotEnrolled";
        }
        if (n == 1) {
            return "FingerprintScannerNotAvailable";
        }
        return null;
    }

    private void legacyAuthenticate(Promise promise) {
        String string = this.legacyGetErrorMessage();
        if (string != null) {
            promise.reject(string, TYPE_FINGERPRINT_LEGACY);
            this.release();
            return;
        }
        this.getFingerprintIdentify().resumeIdentify();
        this.getFingerprintIdentify().startIdentify(Integer.MAX_VALUE, new BaseFingerprint.IdentifyListener(this, promise){
            final /* synthetic */ ReactNativeFingerprintScannerModule this$0;
            final /* synthetic */ Promise val$promise;
            {
                this.this$0 = reactNativeFingerprintScannerModule;
                this.val$promise = promise;
            }

            public void onFailed(boolean bl) {
                if (bl) {
                    this.val$promise.reject("AuthenticationFailed", "DeviceLocked");
                } else {
                    this.val$promise.reject("AuthenticationFailed", "Fingerprint");
                }
                this.this$0.release();
            }

            public void onNotMatch(int n) {
                ((com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter)ReactNativeFingerprintScannerModule.access$100(this.this$0).getJSModule(com.facebook.react.modules.core.DeviceEventManagerModule$RCTDeviceEventEmitter.class)).emit("FINGERPRINT_SCANNER_AUTHENTICATION", (Object)"AuthenticationNotMatch");
            }

            public void onStartFailedByDeviceLocked() {
                this.val$promise.reject("AuthenticationFailed", "DeviceLocked");
            }

            public void onSucceed() {
                this.val$promise.resolve((Object)true);
                this.this$0.release();
            }
        });
    }

    private String legacyGetErrorMessage() {
        if (!this.getFingerprintIdentify().isHardwareEnable()) {
            return "FingerprintScannerNotSupported";
        }
        if (!this.getFingerprintIdentify().isRegisteredFingerprint()) {
            return "FingerprintScannerNotEnrolled";
        }
        if (!this.getFingerprintIdentify().isFingerprintEnable()) {
            return "FingerprintScannerNotAvailable";
        }
        return null;
    }

    private boolean requiresLegacyAuthentication() {
        return this.currentAndroidVersion() < 23;
    }

    @ReactMethod
    public void authenticate(String string, Promise promise) {
        if (this.requiresLegacyAuthentication()) {
            this.legacyAuthenticate(promise);
            return;
        }
        String string2 = this.getSensorError();
        if (string2 != null) {
            promise.reject(string2, TYPE_BIOMETRICS);
            this.release();
            return;
        }
        this.biometricAuthenticate(string, promise);
    }

    public BiometricPrompt getBiometricPrompt(Promise promise) {
        BiometricPrompt biometricPrompt = this.biometricPrompt;
        if (biometricPrompt != null) {
            return biometricPrompt;
        }
        this.mReactContext.addLifecycleEventListener((LifecycleEventListener)this);
        BiometricPrompt.AuthenticationCallback authenticationCallback = new BiometricPrompt.AuthenticationCallback(promise){
            private Promise promise;
            {
                this.promise = promise;
            }

            public void onAuthenticationError(int n, CharSequence charSequence) {
                super.onAuthenticationError(n, charSequence);
                this.promise.reject(ReactNativeFingerprintScannerModule.this.biometricPromptErrName(n), ReactNativeFingerprintScannerModule.TYPE_BIOMETRICS);
            }

            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult authenticationResult) {
                super.onAuthenticationSucceeded(authenticationResult);
                this.promise.resolve((Object)true);
            }
        };
        this.biometricPrompt = new BiometricPrompt((FragmentActivity)this.getCurrentActivity(), (Executor)Executors.newSingleThreadExecutor(), authenticationCallback);
        return this.biometricPrompt;
    }

    public String getName() {
        return "ReactNativeFingerprintScanner";
    }

    @ReactMethod
    public void isSensorAvailable(Promise promise) {
        if (this.requiresLegacyAuthentication()) {
            String string = this.legacyGetErrorMessage();
            if (string != null) {
                promise.reject(string, TYPE_FINGERPRINT_LEGACY);
                return;
            }
            promise.resolve((Object)TYPE_FINGERPRINT_LEGACY);
            return;
        }
        String string = this.getSensorError();
        if (string != null) {
            promise.reject(string, TYPE_BIOMETRICS);
            return;
        }
        promise.resolve((Object)TYPE_BIOMETRICS);
    }

    public void onHostDestroy() {
        this.release();
    }

    public void onHostPause() {
    }

    public void onHostResume() {
    }

    @ReactMethod
    public void release() {
        BiometricPrompt biometricPrompt;
        if (this.requiresLegacyAuthentication()) {
            this.getFingerprintIdentify().cancelIdentify();
            this.mFingerprintIdentify = null;
        }
        if ((biometricPrompt = this.biometricPrompt) != null) {
            biometricPrompt.cancelAuthentication();
        }
        this.biometricPrompt = null;
        this.mReactContext.removeLifecycleEventListener((LifecycleEventListener)this);
    }

}

