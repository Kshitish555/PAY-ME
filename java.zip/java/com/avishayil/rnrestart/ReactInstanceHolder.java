/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.ReactInstanceManager
 *  java.lang.Object
 */
package com.avishayil.rnrestart;

import com.facebook.react.ReactInstanceManager;

public interface ReactInstanceHolder {
    public ReactInstanceManager getReactInstanceManager();
}

