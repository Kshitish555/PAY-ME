/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.os.Handler
 *  android.os.Looper
 *  com.facebook.react.ReactApplication
 *  com.facebook.react.ReactInstanceManager
 *  com.facebook.react.ReactNativeHost
 *  com.facebook.react.bridge.LifecycleEventListener
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.NoSuchFieldException
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.avishayil.rnrestart;

import android.app.Activity;
import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import com.avishayil.rnrestart.ReactInstanceHolder;
import com.avishayil.rnrestart.ReactNativeRestart;
import com.facebook.react.ReactApplication;
import com.facebook.react.ReactInstanceManager;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class ReactNativeRestart
extends ReactContextBaseJavaModule {
    private static final String REACT_APPLICATION_CLASS_NAME = "com.facebook.react.ReactApplication";
    private static final String REACT_NATIVE_HOST_CLASS_NAME = "com.facebook.react.ReactNativeHost";
    private static ReactInstanceHolder mReactInstanceHolder;
    private LifecycleEventListener mLifecycleEventListener = null;

    public ReactNativeRestart(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
    }

    static /* synthetic */ void access$000(ReactNativeRestart reactNativeRestart) {
        reactNativeRestart.loadBundleLegacy();
    }

    private void clearLifecycleEventListener() {
        if (this.mLifecycleEventListener != null) {
            this.getReactApplicationContext().removeLifecycleEventListener(this.mLifecycleEventListener);
            this.mLifecycleEventListener = null;
        }
    }

    static ReactInstanceManager getReactInstanceManager() {
        ReactInstanceHolder reactInstanceHolder = mReactInstanceHolder;
        if (reactInstanceHolder == null) {
            return null;
        }
        return reactInstanceHolder.getReactInstanceManager();
    }

    private void loadBundle() {
        ReactInstanceManager reactInstanceManager;
        block3 : {
            this.clearLifecycleEventListener();
            try {
                reactInstanceManager = this.resolveInstanceManager();
                if (reactInstanceManager != null) break block3;
                return;
            }
            catch (Exception exception) {
                this.loadBundleLegacy();
                return;
            }
        }
        new Handler(Looper.getMainLooper()).post(new Runnable(this, reactInstanceManager){
            final /* synthetic */ ReactNativeRestart this$0;
            final /* synthetic */ ReactInstanceManager val$instanceManager;
            {
                this.this$0 = reactNativeRestart;
                this.val$instanceManager = reactInstanceManager;
            }

            public void run() {
                try {
                    this.val$instanceManager.recreateReactContextInBackground();
                    return;
                }
                catch (Exception exception) {
                    ReactNativeRestart.access$000(this.this$0);
                    return;
                }
            }
        });
    }

    private void loadBundleLegacy() {
        Activity activity = this.getCurrentActivity();
        if (activity == null) {
            return;
        }
        activity.runOnUiThread(new Runnable(this, activity){
            final /* synthetic */ ReactNativeRestart this$0;
            final /* synthetic */ Activity val$currentActivity;
            {
                this.this$0 = reactNativeRestart;
                this.val$currentActivity = activity;
            }

            public void run() {
                this.val$currentActivity.recreate();
            }
        });
    }

    private ReactInstanceManager resolveInstanceManager() throws NoSuchFieldException, IllegalAccessException {
        ReactInstanceManager reactInstanceManager = ReactNativeRestart.getReactInstanceManager();
        if (reactInstanceManager != null) {
            return reactInstanceManager;
        }
        Activity activity = this.getCurrentActivity();
        if (activity == null) {
            return null;
        }
        return ((ReactApplication)activity.getApplication()).getReactNativeHost().getReactInstanceManager();
    }

    @ReactMethod
    public void Restart() {
        this.loadBundle();
    }

    public String getName() {
        return "RNRestart";
    }
}

