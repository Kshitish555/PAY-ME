/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.net.Uri
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  java.lang.Object
 *  java.lang.String
 */
package com.reactlibrary.androidsettings;

import android.content.Intent;
import android.net.Uri;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class RNANAndroidSettingsLibraryModule
extends ReactContextBaseJavaModule {
    private final ReactApplicationContext reactContext;

    public RNANAndroidSettingsLibraryModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        this.reactContext = reactApplicationContext;
    }

    public String getName() {
        return "RNANAndroidSettingsLibrary";
    }

    @ReactMethod
    public void main() {
        this.open("main");
    }

    @ReactMethod
    public void open(String string) {
        int n;
        Uri uri;
        Intent intent;
        block36 : {
            intent = new Intent();
            uri = Uri.fromParts((String)"package", (String)this.reactContext.getPackageName(), null);
            switch (string.hashCode()) {
                default: {
                    break;
                }
                case 2104878923: {
                    if (!string.equals((Object)"ACTION_DATE_SETTINGS")) break;
                    n = 6;
                    break block36;
                }
                case 1657633887: {
                    if (!string.equals((Object)"ACTION_LOCALE_SETTINGS")) break;
                    n = 7;
                    break block36;
                }
                case 1645097481: {
                    if (!string.equals((Object)"ACTION_DISPLAY_SETTINGS")) break;
                    n = 9;
                    break block36;
                }
                case 1399827939: {
                    if (!string.equals((Object)"ACTION_INPUT_METHOD_SETTINGS")) break;
                    n = 8;
                    break block36;
                }
                case 1290373132: {
                    if (!string.equals((Object)"ACTION_SETTINGS")) break;
                    n = 0;
                    break block36;
                }
                case 459312068: {
                    if (!string.equals((Object)"ACTION_WIFI_SETTINGS")) break;
                    n = 3;
                    break block36;
                }
                case 277263872: {
                    if (!string.equals((Object)"ACTION_INTERNAL_STORAGE_SETTINGS")) break;
                    n = 12;
                    break block36;
                }
                case -147853876: {
                    if (!string.equals((Object)"ACTION_APN_SETTINGS")) break;
                    n = 4;
                    break block36;
                }
                case -163167688: {
                    if (!string.equals((Object)"ACTION_APPLICATION_DETAILS_SETTINGS")) break;
                    n = 15;
                    break block36;
                }
                case -273295523: {
                    if (!string.equals((Object)"ACTION_BLUETOOTH_SETTINGS")) break;
                    n = 5;
                    break block36;
                }
                case -777499333: {
                    if (!string.equals((Object)"ACTION_AIRPLANE_MODE_SETTINGS")) break;
                    n = 2;
                    break block36;
                }
                case -1048752099: {
                    if (!string.equals((Object)"ACTION_MEMORY_CARD_SETTINGS")) break;
                    n = 14;
                    break block36;
                }
                case -1417391296: {
                    if (!string.equals((Object)"ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS")) break;
                    n = 13;
                    break block36;
                }
                case -1710024583: {
                    if (!string.equals((Object)"ACTION_SECURITY_SETTINGS")) break;
                    n = 10;
                    break block36;
                }
                case -1851149018: {
                    if (!string.equals((Object)"ACTION_LOCATION_SOURCE_SETTINGS")) break;
                    n = 11;
                    break block36;
                }
                case -2071293477: {
                    if (!string.equals((Object)"ACTION_WIRELESS_SETTINGS")) break;
                    n = 1;
                    break block36;
                }
            }
            n = -1;
        }
        switch (n) {
            default: {
                intent.setAction("android.settings.SETTINGS");
                break;
            }
            case 15: {
                intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                intent.setData(uri);
                break;
            }
            case 14: {
                intent.setAction("android.settings.MEMORY_CARD_SETTINGS");
                break;
            }
            case 13: {
                intent.setAction("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS");
                intent.setData(uri);
                break;
            }
            case 12: {
                intent.setAction("android.settings.INTERNAL_STORAGE_SETTINGS");
                break;
            }
            case 11: {
                intent.setAction("android.settings.LOCATION_SOURCE_SETTINGS");
                break;
            }
            case 10: {
                intent.setAction("android.settings.SECURITY_SETTINGS");
                break;
            }
            case 9: {
                intent.setAction("android.settings.DISPLAY_SETTINGS");
                break;
            }
            case 8: {
                intent.setAction("android.settings.INPUT_METHOD_SETTINGS");
                break;
            }
            case 7: {
                intent.setAction("android.settings.LOCALE_SETTINGS");
                break;
            }
            case 6: {
                intent.setAction("android.settings.DATE_SETTINGS");
                break;
            }
            case 5: {
                intent.setAction("android.settings.BLUETOOTH_SETTINGS");
                break;
            }
            case 4: {
                intent.setAction("android.settings.APN_SETTINGS");
                break;
            }
            case 3: {
                intent.setAction("android.settings.WIFI_SETTINGS");
                break;
            }
            case 2: {
                intent.setAction("android.settings.AIRPLANE_MODE_SETTINGS");
                break;
            }
            case 1: {
                intent.setAction("android.settings.WIRELESS_SETTINGS");
                break;
            }
            case 0: {
                intent.setAction("android.settings.SETTINGS");
            }
        }
        intent.addFlags(268435456);
        this.reactContext.startActivity(intent);
    }
}

