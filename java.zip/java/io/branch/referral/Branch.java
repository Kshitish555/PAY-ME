/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.text.TextUtils
 *  android.text.format.DateFormat
 *  io.branch.indexing.BranchUniversalObject
 *  io.branch.indexing.BranchUniversalObject$RegisterViewStatusListener
 *  io.branch.referral.Base64
 *  io.branch.referral.Branch$1
 *  io.branch.referral.Branch$2
 *  io.branch.referral.Branch$BranchActivityLifeCycleObserver
 *  io.branch.referral.Branch$BranchListResponseListener
 *  io.branch.referral.Branch$BranchPostTask
 *  io.branch.referral.Branch$BranchReferralInitListener
 *  io.branch.referral.Branch$BranchReferralStateChangedListener
 *  io.branch.referral.Branch$BranchUniversalReferralInitListener
 *  io.branch.referral.Branch$CUSTOM_REFERRABLE_SETTINGS
 *  io.branch.referral.Branch$CreditHistoryOrder
 *  io.branch.referral.Branch$INTENT_STATE
 *  io.branch.referral.Branch$LogoutStatusListener
 *  io.branch.referral.Branch$SESSION_STATE
 *  io.branch.referral.Branch$ShareLinkBuilder
 *  io.branch.referral.BranchError
 *  io.branch.referral.BranchLinkData
 *  io.branch.referral.BranchPreinstall
 *  io.branch.referral.BranchStrongMatchHelper
 *  io.branch.referral.BranchStrongMatchHelper$StrongMatchCheckEvents
 *  io.branch.referral.BranchUniversalReferralInitWrapper
 *  io.branch.referral.BranchViewHandler
 *  io.branch.referral.DeferredAppLinkDataHandler
 *  io.branch.referral.DeferredAppLinkDataHandler$AppLinkFetchEvents
 *  io.branch.referral.Defines
 *  io.branch.referral.Defines$Jsonkey
 *  io.branch.referral.Defines$PreinstallKey
 *  io.branch.referral.DeviceInfo
 *  io.branch.referral.InstallListener
 *  io.branch.referral.InstantAppUtil
 *  io.branch.referral.PrefHelper
 *  io.branch.referral.ServerRequest
 *  io.branch.referral.ServerRequest$PROCESS_WAIT_LOCK
 *  io.branch.referral.ServerRequestActionCompleted
 *  io.branch.referral.ServerRequestCreateUrl
 *  io.branch.referral.ServerRequestGetRewardHistory
 *  io.branch.referral.ServerRequestGetRewards
 *  io.branch.referral.ServerRequestIdentifyUserRequest
 *  io.branch.referral.ServerRequestInitSession
 *  io.branch.referral.ServerRequestLogout
 *  io.branch.referral.ServerRequestPing
 *  io.branch.referral.ServerRequestQueue
 *  io.branch.referral.ServerRequestRActionCompleted
 *  io.branch.referral.ServerRequestRedeemRewards
 *  io.branch.referral.ServerRequestRegisterClose
 *  io.branch.referral.ServerRequestRegisterInstall
 *  io.branch.referral.ServerRequestRegisterOpen
 *  io.branch.referral.ShareLinkManager
 *  io.branch.referral.SystemObserver
 *  io.branch.referral.TrackingController
 *  io.branch.referral.UniversalResourceAnalyser
 *  io.branch.referral.network.BranchRemoteInterface
 *  io.branch.referral.util.BRANCH_STANDARD_EVENT
 *  io.branch.referral.util.BranchCrossPlatformId
 *  io.branch.referral.util.BranchCrossPlatformId$BranchCrossPlatformIdListener
 *  io.branch.referral.util.BranchEvent
 *  io.branch.referral.util.BranchLastAttributedTouchData
 *  io.branch.referral.util.BranchLastAttributedTouchData$BranchLastAttributedTouchDataListener
 *  io.branch.referral.util.CommerceEvent
 *  io.branch.referral.util.LinkProperties
 *  java.io.UnsupportedEncodingException
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.NoClassDefFoundError
 *  java.lang.NoSuchMethodError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.lang.ref.WeakReference
 *  java.net.URLEncoder
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.Semaphore
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package io.branch.referral;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.format.DateFormat;
import io.branch.indexing.BranchUniversalObject;
import io.branch.referral.Base64;
import io.branch.referral.Branch;
import io.branch.referral.BranchError;
import io.branch.referral.BranchLinkData;
import io.branch.referral.BranchPreinstall;
import io.branch.referral.BranchStrongMatchHelper;
import io.branch.referral.BranchUniversalReferralInitWrapper;
import io.branch.referral.BranchUtil;
import io.branch.referral.BranchViewHandler;
import io.branch.referral.DeferredAppLinkDataHandler;
import io.branch.referral.Defines;
import io.branch.referral.DeviceInfo;
import io.branch.referral.InstallListener;
import io.branch.referral.InstantAppUtil;
import io.branch.referral.PrefHelper;
import io.branch.referral.ServerRequest;
import io.branch.referral.ServerRequestActionCompleted;
import io.branch.referral.ServerRequestCreateUrl;
import io.branch.referral.ServerRequestGetRewardHistory;
import io.branch.referral.ServerRequestGetRewards;
import io.branch.referral.ServerRequestIdentifyUserRequest;
import io.branch.referral.ServerRequestInitSession;
import io.branch.referral.ServerRequestLogout;
import io.branch.referral.ServerRequestPing;
import io.branch.referral.ServerRequestQueue;
import io.branch.referral.ServerRequestRActionCompleted;
import io.branch.referral.ServerRequestRedeemRewards;
import io.branch.referral.ServerRequestRegisterClose;
import io.branch.referral.ServerRequestRegisterInstall;
import io.branch.referral.ServerRequestRegisterOpen;
import io.branch.referral.ShareLinkManager;
import io.branch.referral.SystemObserver;
import io.branch.referral.TrackingController;
import io.branch.referral.UniversalResourceAnalyser;
import io.branch.referral.network.BranchRemoteInterface;
import io.branch.referral.util.BRANCH_STANDARD_EVENT;
import io.branch.referral.util.BranchCrossPlatformId;
import io.branch.referral.util.BranchEvent;
import io.branch.referral.util.BranchLastAttributedTouchData;
import io.branch.referral.util.CommerceEvent;
import io.branch.referral.util.LinkProperties;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import org.json.JSONException;
import org.json.JSONObject;

/*
 * Exception performing whole class analysis.
 */
public class Branch
implements BranchViewHandler.IBranchViewEvents,
SystemObserver.GAdsParamsFetchEvents,
InstallListener.IInstallReferrerEvents {
    public static final String ALWAYS_DEEPLINK = "$always_deeplink";
    private static final String AUTO_DEEP_LINKED = "io.branch.sdk.auto_linked";
    private static final String AUTO_DEEP_LINK_DISABLE = "io.branch.sdk.auto_link_disable";
    private static final String AUTO_DEEP_LINK_KEY = "io.branch.sdk.auto_link_keys";
    private static final String AUTO_DEEP_LINK_PATH = "io.branch.sdk.auto_link_path";
    private static final String AUTO_DEEP_LINK_REQ_CODE = "io.branch.sdk.auto_link_request_code";
    private static final String BRANCH_LIBRARY_VERSION = "io.branch.sdk.android:library:4.1.0";
    public static final String DEEPLINK_PATH = "$deeplink_path";
    private static final int DEF_AUTO_DEEP_LINK_REQ_CODE = 1501;
    private static final String[] EXTERNAL_INTENT_EXTRA_KEY_WHITE_LIST;
    private static final String FABRIC_BRANCH_API_KEY = "io.branch.apiKey";
    public static final String FEATURE_TAG_DEAL = "deal";
    public static final String FEATURE_TAG_GIFT = "gift";
    public static final String FEATURE_TAG_INVITE = "invite";
    public static final String FEATURE_TAG_REFERRAL = "referral";
    public static final String FEATURE_TAG_SHARE = "share";
    private static final String GOOGLE_VERSION_TAG = "!SDK-VERSION-STRING!:io.branch.sdk.android:library:4.1.0";
    private static int LATCH_WAIT_UNTIL = 0;
    public static final int LINK_TYPE_ONE_TIME_USE = 1;
    public static final int LINK_TYPE_UNLIMITED_USE = 0;
    public static final long NO_PLAY_STORE_REFERRER_WAIT = 0L;
    public static final String OG_APP_ID = "$og_app_id";
    public static final String OG_DESC = "$og_description";
    public static final String OG_IMAGE_URL = "$og_image_url";
    public static final String OG_TITLE = "$og_title";
    public static final String OG_URL = "$og_url";
    public static final String OG_VIDEO = "$og_video";
    private static final int PREVENT_CLOSE_TIMEOUT = 500;
    public static final String REDEEM_CODE = "$redeem_code";
    public static final String REDIRECT_ANDROID_URL = "$android_url";
    public static final String REDIRECT_BLACKBERRY_URL = "$blackberry_url";
    public static final String REDIRECT_DESKTOP_URL = "$desktop_url";
    public static final String REDIRECT_FIRE_URL = "$fire_url";
    public static final String REDIRECT_IOS_URL = "$ios_url";
    public static final String REDIRECT_IPAD_URL = "$ipad_url";
    public static final String REDIRECT_WINDOWS_PHONE_URL = "$windows_phone_url";
    public static final String REFERRAL_BUCKET_DEFAULT = "default";
    public static final String REFERRAL_CODE = "referral_code";
    public static final int REFERRAL_CODE_AWARD_UNIQUE = 0;
    public static final int REFERRAL_CODE_AWARD_UNLIMITED = 1;
    public static final int REFERRAL_CODE_LOCATION_BOTH = 3;
    public static final int REFERRAL_CODE_LOCATION_REFERREE = 0;
    public static final int REFERRAL_CODE_LOCATION_REFERRING_USER = 2;
    public static final String REFERRAL_CODE_TYPE = "credit";
    public static final int REFERRAL_CREATION_SOURCE_SDK = 2;
    private static final int SESSION_KEEPALIVE = 2000;
    private static Branch branchReferral_;
    private static boolean bypassCurrentActivityIntentState_ = false;
    static boolean checkInstallReferrer_ = true;
    private static String cookieBasedMatchDomain_;
    private static CUSTOM_REFERRABLE_SETTINGS customReferrableSettings_;
    private static boolean disableDeviceIDFetch_ = false;
    private static boolean disableInstantDeepLinking = false;
    private static boolean isActivityLifeCycleCallbackRegistered_ = false;
    private static boolean isAutoSessionMode_ = false;
    static boolean isForcedSession_ = false;
    private static boolean isSimulatingInstalls_ = false;
    private static long playStoreReferrerFetchTime = 1500L;
    private BranchRemoteInterface branchRemoteInterface_;
    private Context context_;
    WeakReference<Activity> currentActivityReference_;
    private JSONObject deeplinkDebugParams_;
    private WeakReference<BranchReferralInitListener> deferredInitListener_;
    private final DeviceInfo deviceInfo_;
    private boolean enableFacebookAppLinkCheck_;
    private CountDownLatch getFirstReferringParamsLatch;
    private CountDownLatch getLatestReferringParamsLatch;
    private boolean handleDelayedNewIntents_;
    private boolean hasNetwork_;
    private SESSION_STATE initState_;
    private final ConcurrentHashMap<String, String> instrumentationExtraData_;
    private INTENT_STATE intentState_;
    private boolean isActivityCreatedAndLaunched;
    private boolean isGAParamsFetchInProgress_;
    boolean isInitReportedThroughCallBack;
    boolean isInstantDeepLinkPossible;
    private Map<BranchLinkData, String> linkCache_;
    final Object lock;
    private int networkCount_;
    private boolean performCookieBasedStrongMatchingOnGAIDAvailable;
    private PrefHelper prefHelper_;
    private final ServerRequestQueue requestQueue_;
    private Semaphore serverSema_;
    private ShareLinkManager shareLinkManager_;
    private final TrackingController trackingController;

    static {
        customReferrableSettings_ = CUSTOM_REFERRABLE_SETTINGS.USE_DEFAULT;
        cookieBasedMatchDomain_ = "app.link";
        LATCH_WAIT_UNTIL = 2500;
        EXTERNAL_INTENT_EXTRA_KEY_WHITE_LIST = new String[]{"extra_launch_uri", "branch_intent"};
        disableInstantDeepLinking = true;
    }

    private Branch(Context context) {
        this.enableFacebookAppLinkCheck_ = false;
        this.intentState_ = INTENT_STATE.PENDING;
        this.handleDelayedNewIntents_ = false;
        this.initState_ = SESSION_STATE.UNINITIALISED;
        this.isInitReportedThroughCallBack = false;
        this.isGAParamsFetchInProgress_ = false;
        this.getFirstReferringParamsLatch = null;
        this.getLatestReferringParamsLatch = null;
        this.performCookieBasedStrongMatchingOnGAIDAvailable = false;
        this.isInstantDeepLinkPossible = false;
        this.isActivityCreatedAndLaunched = false;
        this.prefHelper_ = PrefHelper.getInstance((Context)context);
        this.trackingController = new TrackingController(context);
        this.branchRemoteInterface_ = BranchRemoteInterface.getDefaultBranchRemoteInterface((Context)context);
        this.deviceInfo_ = DeviceInfo.initialize((Context)context);
        this.requestQueue_ = ServerRequestQueue.getInstance((Context)context);
        this.serverSema_ = new Semaphore(1);
        this.lock = new Object();
        this.networkCount_ = 0;
        this.hasNetwork_ = true;
        this.linkCache_ = new HashMap();
        this.instrumentationExtraData_ = new ConcurrentHashMap();
        if (!this.trackingController.isTrackingDisabled()) {
            this.isGAParamsFetchInProgress_ = this.deviceInfo_.getSystemObserver().prefetchGAdsParams(context, (SystemObserver.GAdsParamsFetchEvents)this);
        }
        if (Build.VERSION.SDK_INT >= 15) {
            this.handleDelayedNewIntents_ = true;
            this.intentState_ = INTENT_STATE.PENDING;
            return;
        }
        this.handleDelayedNewIntents_ = false;
        this.intentState_ = INTENT_STATE.READY;
    }

    static /* synthetic */ PrefHelper access$100(Branch branch) {
        return branch.prefHelper_;
    }

    static /* synthetic */ boolean access$1000(Branch branch, Intent intent) {
        return branch.checkIntentForSessionRestart(intent);
    }

    static /* synthetic */ boolean access$1100() {
        return bypassCurrentActivityIntentState_;
    }

    static /* synthetic */ void access$1200(Branch branch, Activity activity, boolean bl) {
        branch.onIntentReady(activity, bl);
    }

    static /* synthetic */ ShareLinkManager access$1300(Branch branch) {
        return branch.shareLinkManager_;
    }

    static /* synthetic */ BranchRemoteInterface access$1400(Branch branch) {
        return branch.branchRemoteInterface_;
    }

    static /* synthetic */ ConcurrentHashMap access$1500(Branch branch) {
        return branch.instrumentationExtraData_;
    }

    static /* synthetic */ boolean access$1600(Branch branch) {
        return branch.hasNetwork_;
    }

    static /* synthetic */ boolean access$1602(Branch branch, boolean bl) {
        branch.hasNetwork_ = bl;
        return bl;
    }

    static /* synthetic */ void access$1700(Branch branch, int n2, int n3) {
        branch.handleFailure(n2, n3);
    }

    static /* synthetic */ int access$1802(Branch branch, int n2) {
        branch.networkCount_ = n2;
        return n2;
    }

    static /* synthetic */ Map access$1900(Branch branch) {
        return branch.linkCache_;
    }

    static /* synthetic */ ServerRequestQueue access$200(Branch branch) {
        return branch.requestQueue_;
    }

    static /* synthetic */ void access$2000(Branch branch) {
        branch.updateAllRequestsInQueue();
    }

    static /* synthetic */ Branch access$2100() {
        return branchReferral_;
    }

    static /* synthetic */ void access$2200(Branch branch) {
        branch.checkForAutoDeepLinkConfiguration();
    }

    static /* synthetic */ CountDownLatch access$2300(Branch branch) {
        return branch.getLatestReferringParamsLatch;
    }

    static /* synthetic */ CountDownLatch access$2400(Branch branch) {
        return branch.getFirstReferringParamsLatch;
    }

    static /* synthetic */ void access$2500(Branch branch, ShareLinkBuilder shareLinkBuilder) {
        branch.shareLink(shareLinkBuilder);
    }

    static /* synthetic */ void access$300(Branch branch) {
        branch.processNextQueueItem();
    }

    static /* synthetic */ INTENT_STATE access$502(Branch branch, INTENT_STATE iNTENT_STATE) {
        branch.intentState_ = iNTENT_STATE;
        return iNTENT_STATE;
    }

    static /* synthetic */ boolean access$600(Branch branch) {
        return branch.handleDelayedNewIntents_;
    }

    static /* synthetic */ boolean access$702(Branch branch, boolean bl) {
        branch.isActivityCreatedAndLaunched = bl;
        return bl;
    }

    static /* synthetic */ SESSION_STATE access$800(Branch branch) {
        return branch.initState_;
    }

    static /* synthetic */ SESSION_STATE access$802(Branch branch, SESSION_STATE sESSION_STATE) {
        branch.initState_ = sESSION_STATE;
        return sESSION_STATE;
    }

    static /* synthetic */ void access$900(Branch branch, Activity activity) {
        branch.startSession(activity);
    }

    /*
     * Exception decompiling
     */
    private JSONObject appendDebugParams(JSONObject var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl32.1 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private void checkForAutoDeepLinkConfiguration() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private boolean checkForAutoDeepLinkKeys(JSONObject jSONObject, ActivityInfo activityInfo) {
        if (activityInfo.metaData.getString(AUTO_DEEP_LINK_KEY) != null) {
            String[] arrstring = activityInfo.metaData.getString(AUTO_DEEP_LINK_KEY).split(",");
            int n2 = arrstring.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (!jSONObject.has(arrstring[i2])) continue;
                return true;
            }
        }
        return false;
    }

    /*
     * Exception decompiling
     */
    private boolean checkForAutoDeepLinkPath(JSONObject var1, ActivityInfo var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl29.1 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private boolean checkIntentForSessionRestart(Intent var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private String convertDate(Date date) {
        return DateFormat.format((CharSequence)"yyyy-MM-dd", (Date)date).toString();
    }

    private JSONObject convertParamsStringToDictionary(String string2) {
        if (string2.equals((Object)"bnc_no_value")) {
            return new JSONObject();
        }
        try {
            JSONObject jSONObject = new JSONObject(string2);
            return jSONObject;
        }
        catch (JSONException jSONException) {
            byte[] arrby = Base64.decode((byte[])string2.getBytes(), (int)2);
            try {
                JSONObject jSONObject = new JSONObject(new String(arrby));
                return jSONObject;
            }
            catch (JSONException jSONException2) {
                jSONException2.printStackTrace();
                return new JSONObject();
            }
        }
    }

    public static void disableDebugMode() {
        BranchUtil.setDebugMode(false);
    }

    public static void disableDeviceIDFetch(Boolean bl) {
        disableDeviceIDFetch_ = bl;
    }

    public static void disableForcedSession() {
        isForcedSession_ = false;
    }

    public static void disableInstantDeepLinking(boolean bl) {
        disableInstantDeepLinking = bl;
    }

    public static void disableLogging() {
        PrefHelper.enableLogging((boolean)false);
    }

    public static void disableSimulateInstalls() {
        isSimulatingInstalls_ = false;
    }

    public static void disableTestMode() {
        BranchUtil.setTestMode(false);
        Branch.disableDebugMode();
    }

    public static void enableBypassCurrentActivityIntentState() {
        bypassCurrentActivityIntentState_ = true;
    }

    public static void enableCookieBasedMatching(String string2) {
        cookieBasedMatchDomain_ = string2;
    }

    public static void enableCookieBasedMatching(String string2, int n2) {
        cookieBasedMatchDomain_ = string2;
        BranchStrongMatchHelper.getInstance().setStrongMatchUrlHitDelay(n2);
    }

    public static void enableDebugMode() {
        BranchUtil.setDebugMode(true);
        PrefHelper.LogAlways((String)GOOGLE_VERSION_TAG);
    }

    public static void enableForcedSession() {
        isForcedSession_ = true;
    }

    public static void enableLogging() {
        PrefHelper.enableLogging((boolean)true);
    }

    public static void enablePlayStoreReferrer(long l2) {
        Branch.setPlayStoreReferrerCheckTimeout(l2);
    }

    public static void enableSimulateInstalls() {
        isSimulatingInstalls_ = true;
    }

    public static void enableTestMode() {
        BranchUtil.setTestMode(true);
        Branch.enableDebugMode();
    }

    private void executeClose() {
        if (this.initState_ != SESSION_STATE.UNINITIALISED) {
            if (!this.hasNetwork_) {
                ServerRequest serverRequest = this.requestQueue_.peek();
                if (serverRequest != null && serverRequest instanceof ServerRequestRegisterInstall || serverRequest instanceof ServerRequestRegisterOpen) {
                    this.requestQueue_.dequeue();
                }
            } else if (!this.requestQueue_.containsClose()) {
                this.handleNewRequest((ServerRequest)new ServerRequestRegisterClose(this.context_));
            }
            this.initState_ = SESSION_STATE.UNINITIALISED;
        }
    }

    private void generateShortLinkAsync(ServerRequest serverRequest) {
        this.handleNewRequest(serverRequest);
    }

    /*
     * Exception decompiling
     */
    private String generateShortLinkSync(ServerRequestCreateUrl var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl39 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public static Branch getAutoInstance(Context context) {
        isAutoSessionMode_ = true;
        customReferrableSettings_ = CUSTOM_REFERRABLE_SETTINGS.USE_DEFAULT;
        Branch.getBranchInstance(context, true ^ BranchUtil.checkTestMode(context), null);
        BranchPreinstall.getPreinstallSystemData((Branch)branchReferral_, (Context)context);
        return branchReferral_;
    }

    public static Branch getAutoInstance(Context context, String string2) {
        isAutoSessionMode_ = true;
        customReferrableSettings_ = CUSTOM_REFERRABLE_SETTINGS.USE_DEFAULT;
        Branch.getBranchInstance(context, true ^ BranchUtil.checkTestMode(context), string2);
        if (string2.startsWith("key_")) {
            if (Branch.branchReferral_.prefHelper_.setBranchKey(string2)) {
                Branch.branchReferral_.linkCache_.clear();
                Branch.branchReferral_.requestQueue_.clear();
            }
        } else {
            PrefHelper.Debug((String)"Branch Key is invalid. Please check your BranchKey");
        }
        BranchPreinstall.getPreinstallSystemData((Branch)branchReferral_, (Context)context);
        return branchReferral_;
    }

    public static Branch getAutoInstance(Context context, boolean bl) {
        isAutoSessionMode_ = true;
        CUSTOM_REFERRABLE_SETTINGS cUSTOM_REFERRABLE_SETTINGS = bl ? CUSTOM_REFERRABLE_SETTINGS.REFERRABLE : CUSTOM_REFERRABLE_SETTINGS.NON_REFERRABLE;
        customReferrableSettings_ = cUSTOM_REFERRABLE_SETTINGS;
        Branch.getBranchInstance(context, true ^ BranchUtil.checkTestMode(context), null);
        BranchPreinstall.getPreinstallSystemData((Branch)branchReferral_, (Context)context);
        return branchReferral_;
    }

    public static Branch getAutoTestInstance(Context context) {
        isAutoSessionMode_ = true;
        customReferrableSettings_ = CUSTOM_REFERRABLE_SETTINGS.USE_DEFAULT;
        Branch.getBranchInstance(context, false, null);
        BranchPreinstall.getPreinstallSystemData((Branch)branchReferral_, (Context)context);
        return branchReferral_;
    }

    public static Branch getAutoTestInstance(Context context, boolean bl) {
        isAutoSessionMode_ = true;
        CUSTOM_REFERRABLE_SETTINGS cUSTOM_REFERRABLE_SETTINGS = bl ? CUSTOM_REFERRABLE_SETTINGS.REFERRABLE : CUSTOM_REFERRABLE_SETTINGS.NON_REFERRABLE;
        customReferrableSettings_ = cUSTOM_REFERRABLE_SETTINGS;
        Branch.getBranchInstance(context, false, null);
        BranchPreinstall.getPreinstallSystemData((Branch)branchReferral_, (Context)context);
        return branchReferral_;
    }

    /*
     * Exception decompiling
     */
    private static Branch getBranchInstance(Context var0, boolean var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl39.1 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private ServerRequest getInstallOrOpenRequest(BranchReferralInitListener branchReferralInitListener) {
        if (this.hasUser()) {
            return new ServerRequestRegisterOpen(this.context_, branchReferralInitListener);
        }
        return new ServerRequestRegisterInstall(this.context_, branchReferralInitListener, InstallListener.getInstallationID());
    }

    public static Branch getInstance() {
        if (branchReferral_ == null) {
            PrefHelper.Debug((String)"Branch instance is not created yet. Make sure you have initialised Branch. [Consider Calling getInstance(Context ctx) if you still have issue.]");
        } else if (isAutoSessionMode_ && !isActivityLifeCycleCallbackRegistered_) {
            PrefHelper.Debug((String)"Branch instance is not properly initialised. Make sure your Application class is extending BranchApp class. If you are not extending BranchApp class make sure you are initialising Branch in your Applications onCreate()");
        }
        return branchReferral_;
    }

    public static Branch getInstance(Context context) {
        return Branch.getBranchInstance(context, true, null);
    }

    public static Branch getInstance(Context context, String string2) {
        if (branchReferral_ == null) {
            branchReferral_ = Branch.initInstance(context);
        }
        Branch.branchReferral_.context_ = context.getApplicationContext();
        if (string2.startsWith("key_")) {
            if (Branch.branchReferral_.prefHelper_.setBranchKey(string2)) {
                Branch.branchReferral_.linkCache_.clear();
                Branch.branchReferral_.requestQueue_.clear();
            }
        } else {
            PrefHelper.Debug((String)"Branch Key is invalid. Please check your BranchKey");
        }
        return branchReferral_;
    }

    public static Branch getTestInstance(Context context) {
        return Branch.getBranchInstance(context, false, null);
    }

    private void handleFailure(int n2, int n3) {
        ServerRequest serverRequest;
        if (n2 >= this.requestQueue_.getSize()) {
            ServerRequestQueue serverRequestQueue = this.requestQueue_;
            serverRequest = serverRequestQueue.peekAt(-1 + serverRequestQueue.getSize());
        } else {
            serverRequest = this.requestQueue_.peekAt(n2);
        }
        this.handleFailure(serverRequest, n3);
    }

    private void handleFailure(ServerRequest serverRequest, int n2) {
        if (serverRequest == null) {
            return;
        }
        serverRequest.handleFailure(n2, "");
    }

    private boolean hasDeviceFingerPrint() {
        return true ^ this.prefHelper_.getDeviceFingerPrintID().equals((Object)"bnc_no_value");
    }

    private boolean hasSession() {
        return true ^ this.prefHelper_.getSessionID().equals((Object)"bnc_no_value");
    }

    private boolean hasUser() {
        return true ^ this.prefHelper_.getIdentityID().equals((Object)"bnc_no_value");
    }

    private static Branch initInstance(Context context) {
        return new Branch(context.getApplicationContext());
    }

    private void initUserSessionInternal(BranchReferralInitListener branchReferralInitListener, Activity activity, boolean bl) {
        if (activity != null) {
            this.currentActivityReference_ = new WeakReference((Object)activity);
        }
        if (branchReferralInitListener != null) {
            this.deferredInitListener_ = new WeakReference((Object)branchReferralInitListener);
        }
        if (this.hasUser() && this.hasSession() && this.initState_ == SESSION_STATE.INITIALISED) {
            this.reportInitSession(branchReferralInitListener);
            this.isInstantDeepLinkPossible = false;
            return;
        }
        if (this.isInstantDeepLinkPossible && this.reportInitSession(branchReferralInitListener)) {
            this.addExtraInstrumentationData(Defines.Jsonkey.InstantDeepLinkSession.getKey(), "true");
            this.isInstantDeepLinkPossible = false;
            this.checkForAutoDeepLinkConfiguration();
        }
        if (bl) {
            this.prefHelper_.setIsReferrable();
        } else {
            this.prefHelper_.clearIsReferrable();
        }
        if (this.initState_ == SESSION_STATE.INITIALISING) {
            if (branchReferralInitListener != null) {
                this.requestQueue_.setInstallOrOpenCallback(branchReferralInitListener);
                return;
            }
        } else {
            this.initState_ = SESSION_STATE.INITIALISING;
            this.initializeSession(branchReferralInitListener);
        }
    }

    private void initUserSessionInternal(BranchUniversalReferralInitListener branchUniversalReferralInitListener, Activity activity, boolean bl) {
        this.initUserSessionInternal(new BranchUniversalReferralInitWrapper(branchUniversalReferralInitListener), activity, bl);
    }

    private void initializeSession(BranchReferralInitListener branchReferralInitListener) {
        if (this.prefHelper_.getBranchKey() != null && !this.prefHelper_.getBranchKey().equalsIgnoreCase("bnc_no_value")) {
            if (this.prefHelper_.getBranchKey() != null && this.prefHelper_.getBranchKey().startsWith("key_test_")) {
                PrefHelper.Debug((String)"Warning: You are using your test app's Branch Key. Remember to change it to live Branch Key during deployment.");
            }
            if (this.getSessionReferredLink() == null && this.enableFacebookAppLinkCheck_) {
                if (DeferredAppLinkDataHandler.fetchDeferredAppLinkData((Context)this.context_, (DeferredAppLinkDataHandler.AppLinkFetchEvents)new 1(this)).booleanValue()) {
                    this.registerAppInit(branchReferralInitListener, ServerRequest.PROCESS_WAIT_LOCK.FB_APP_LINK_WAIT_LOCK);
                    return;
                }
                this.registerAppInit(branchReferralInitListener, null);
                return;
            }
            this.registerAppInit(branchReferralInitListener, null);
            return;
        }
        this.initState_ = SESSION_STATE.UNINITIALISED;
        if (branchReferralInitListener != null) {
            branchReferralInitListener.onInitFinished(null, new BranchError("Trouble initializing Branch.", -114));
        }
        PrefHelper.Debug((String)"Warning: Please enter your branch_key in your project's res/values/strings.xml!");
    }

    private void insertRequestAtFront(ServerRequest serverRequest) {
        if (this.networkCount_ == 0) {
            this.requestQueue_.insert(serverRequest, 0);
            return;
        }
        this.requestQueue_.insert(serverRequest, 1);
    }

    private boolean isActivityLaunchedFromHistory(Activity activity) {
        return activity != null && activity.getIntent() != null && (1048576 & activity.getIntent().getFlags()) != 0;
    }

    public static boolean isAutoDeepLinkLaunch(Activity activity) {
        return activity.getIntent().getStringExtra(AUTO_DEEP_LINKED) != null;
    }

    public static boolean isDeviceIDFetchDisabled() {
        return disableDeviceIDFetch_;
    }

    public static boolean isForceSessionEnabled() {
        return isForcedSession_;
    }

    public static boolean isInstantApp(Context context) {
        return InstantAppUtil.isInstantApp((Context)context);
    }

    private boolean isIntentParamsAlreadyConsumed(Activity activity) {
        boolean bl = false;
        if (activity != null) {
            Intent intent = activity.getIntent();
            bl = false;
            if (intent != null) {
                boolean bl2 = activity.getIntent().getBooleanExtra(Defines.Jsonkey.BranchLinkUsed.getKey(), false);
                bl = false;
                if (bl2) {
                    bl = true;
                }
            }
        }
        return bl;
    }

    private boolean isSessionAvailableForRequest() {
        return this.hasSession() && this.hasDeviceFingerPrint();
    }

    static boolean isSimulatingInstalls() {
        return isSimulatingInstalls_;
    }

    private void onIntentReady(Activity activity, boolean bl) {
        this.requestQueue_.unlockProcessWait(ServerRequest.PROCESS_WAIT_LOCK.INTENT_PENDING_WAIT_LOCK);
        if (bl) {
            this.readAndStripParam(activity.getIntent().getData(), activity);
            if (!this.isTrackingDisabled() && cookieBasedMatchDomain_ != null && this.prefHelper_.getBranchKey() != null && !this.prefHelper_.getBranchKey().equalsIgnoreCase("bnc_no_value")) {
                if (this.isGAParamsFetchInProgress_) {
                    this.performCookieBasedStrongMatchingOnGAIDAvailable = true;
                    return;
                }
                this.performCookieBasedStrongMatch();
                return;
            }
            this.processNextQueueItem();
            return;
        }
        this.processNextQueueItem();
    }

    private boolean pathMatch(String string2, String string3) {
        String[] arrstring;
        String[] arrstring2 = string2.split("\\?")[0].split("/");
        if (arrstring2.length != (arrstring = string3.split("\\?")[0].split("/")).length) {
            return false;
        }
        for (int i2 = 0; i2 < arrstring2.length && i2 < arrstring.length; ++i2) {
            String string4 = arrstring2[i2];
            if (string4.equals((Object)arrstring[i2]) || string4.contains((CharSequence)"*")) continue;
            return false;
        }
        return true;
    }

    private void performCookieBasedStrongMatch() {
        if (!this.trackingController.isTrackingDisabled()) {
            Context context;
            WeakReference<Activity> weakReference = this.currentActivityReference_;
            Activity activity = weakReference != null ? (Activity)weakReference.get() : null;
            Context context2 = null;
            if (activity != null) {
                context2 = activity.getApplicationContext();
            }
            if ((context = context2) != null) {
                this.requestQueue_.setStrongMatchWaitLock();
                BranchStrongMatchHelper.getInstance().checkForStrongMatch(context, cookieBasedMatchDomain_, this.deviceInfo_, this.prefHelper_, (BranchStrongMatchHelper.StrongMatchCheckEvents)new 2(this));
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void processNextQueueItem() {
        try {
            this.serverSema_.acquire();
            if (this.networkCount_ == 0 && this.requestQueue_.getSize() > 0) {
                this.networkCount_ = 1;
                ServerRequest serverRequest = this.requestQueue_.peek();
                this.serverSema_.release();
                if (serverRequest == null) {
                    this.requestQueue_.remove(null);
                    return;
                }
                if (serverRequest.isWaitingOnProcessToFinish()) {
                    this.networkCount_ = 0;
                    return;
                }
                if (!(serverRequest instanceof ServerRequestRegisterInstall) && !this.hasUser()) {
                    PrefHelper.Debug((String)"Branch Error: User session has not been initialized!");
                    this.networkCount_ = 0;
                    this.handleFailure(this.requestQueue_.getSize() - 1, -101);
                    return;
                }
                if (this.requestNeedsSession(serverRequest) && !this.isSessionAvailableForRequest()) {
                    this.networkCount_ = 0;
                    this.handleFailure(this.requestQueue_.getSize() - 1, -101);
                    return;
                }
                new /* Unavailable Anonymous Inner Class!! */.executeTask((Object[])new Void[0]);
                return;
            }
            this.serverSema_.release();
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Exception decompiling
     */
    private boolean readAndStripParam(Uri var1, Activity var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private void registerAppInit(BranchReferralInitListener branchReferralInitListener, ServerRequest.PROCESS_WAIT_LOCK pROCESS_WAIT_LOCK) {
        ServerRequest serverRequest = this.getInstallOrOpenRequest(branchReferralInitListener);
        serverRequest.addProcessWaitLock(pROCESS_WAIT_LOCK);
        if (this.isGAParamsFetchInProgress_) {
            serverRequest.addProcessWaitLock(ServerRequest.PROCESS_WAIT_LOCK.GAID_FETCH_WAIT_LOCK);
        }
        if (this.intentState_ != INTENT_STATE.READY && !Branch.isForceSessionEnabled()) {
            serverRequest.addProcessWaitLock(ServerRequest.PROCESS_WAIT_LOCK.INTENT_PENDING_WAIT_LOCK);
        }
        if (checkInstallReferrer_ && serverRequest instanceof ServerRequestRegisterInstall && !InstallListener.unReportedReferrerAvailable) {
            serverRequest.addProcessWaitLock(ServerRequest.PROCESS_WAIT_LOCK.INSTALL_REFERRER_FETCH_WAIT_LOCK);
            new InstallListener().captureInstallReferrer(this.context_, playStoreReferrerFetchTime, (InstallListener.IInstallReferrerEvents)this);
        }
        this.registerInstallOrOpen(serverRequest, branchReferralInitListener);
    }

    private void registerInstallOrOpen(ServerRequest serverRequest, BranchReferralInitListener branchReferralInitListener) {
        if (!this.requestQueue_.containsInstallOrOpen()) {
            this.insertRequestAtFront(serverRequest);
        } else {
            if (branchReferralInitListener != null) {
                this.requestQueue_.setInstallOrOpenCallback(branchReferralInitListener);
            }
            this.requestQueue_.moveInstallOrOpenToFront(serverRequest, this.networkCount_, branchReferralInitListener);
        }
        this.processNextQueueItem();
    }

    private boolean reportInitSession(BranchReferralInitListener branchReferralInitListener) {
        if (branchReferralInitListener != null) {
            if (isAutoSessionMode_) {
                if (!this.isInitReportedThroughCallBack) {
                    branchReferralInitListener.onInitFinished(this.getLatestReferringParams(), null);
                    this.isInitReportedThroughCallBack = true;
                } else {
                    branchReferralInitListener.onInitFinished(new JSONObject(), null);
                }
            } else {
                branchReferralInitListener.onInitFinished(new JSONObject(), null);
            }
        }
        return this.isInitReportedThroughCallBack;
    }

    private boolean requestNeedsSession(ServerRequest serverRequest) {
        if (serverRequest instanceof ServerRequestInitSession) {
            return false;
        }
        return !(serverRequest instanceof ServerRequestCreateUrl);
    }

    private void resetSessionReferredLink() {
        this.setSessionReferredLink(null);
    }

    public static void setAPIUrl(String string2) {
        PrefHelper.setAPIUrl((String)string2);
    }

    private void setActivityLifeCycleObserver(Application application) {
        try {
            BranchActivityLifeCycleObserver branchActivityLifeCycleObserver = new /* Unavailable Anonymous Inner Class!! */;
            application.unregisterActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)branchActivityLifeCycleObserver);
            application.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)branchActivityLifeCycleObserver);
            isActivityLifeCycleCallbackRegistered_ = true;
            return;
        }
        catch (NoClassDefFoundError | NoSuchMethodError throwable) {
            isActivityLifeCycleCallbackRegistered_ = false;
            isAutoSessionMode_ = false;
            PrefHelper.Debug((String)new BranchError("", -108).getMessage());
            return;
        }
    }

    public static void setPlayStoreReferrerCheckTimeout(long l2) {
        boolean bl = l2 > 0L;
        checkInstallReferrer_ = bl;
        playStoreReferrerFetchTime = l2;
    }

    private void setSessionReferredLink(String string2) {
        this.prefHelper_.setExternalIntentUri(string2);
    }

    private void shareLink(ShareLinkBuilder shareLinkBuilder) {
        ShareLinkManager shareLinkManager = this.shareLinkManager_;
        if (shareLinkManager != null) {
            shareLinkManager.cancelShareLinkDialog(true);
        }
        this.shareLinkManager_ = new ShareLinkManager();
        this.shareLinkManager_.shareLink(shareLinkBuilder);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean showInstallPrompt(Activity activity, int n2) {
        String string2;
        String string4;
        block6 : {
            void var9_12;
            block7 : {
                Branch branch = Branch.getInstance();
                string2 = "";
                if (branch == null) return InstantAppUtil.doShowInstallPrompt((Activity)activity, (int)n2, (String)string2);
                JSONObject jSONObject = Branch.getInstance().getLatestReferringParams();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("~");
                stringBuilder.append(Defines.Jsonkey.ReferringLink.getKey());
                String string3 = stringBuilder.toString();
                if (jSONObject == null) return InstantAppUtil.doShowInstallPrompt((Activity)activity, (int)n2, (String)string2);
                if (!jSONObject.has(string3)) return InstantAppUtil.doShowInstallPrompt((Activity)activity, (int)n2, (String)string2);
                string4 = jSONObject.getString(string3);
                try {
                    string4 = URLEncoder.encode((String)string4, (String)"UTF-8");
                    break block6;
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    break block7;
                }
                catch (JSONException jSONException) {
                    break block7;
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                }
                catch (JSONException jSONException) {
                    // empty catch block
                }
                string4 = string2;
            }
            var9_12.printStackTrace();
        }
        if (TextUtils.isEmpty((CharSequence)string4)) return InstantAppUtil.doShowInstallPrompt((Activity)activity, (int)n2, (String)string2);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(Defines.Jsonkey.IsFullAppConv.getKey());
        stringBuilder2.append("=true&");
        stringBuilder2.append(Defines.Jsonkey.ReferringLink.getKey());
        stringBuilder2.append("=");
        stringBuilder2.append(string4);
        string2 = stringBuilder2.toString();
        return InstantAppUtil.doShowInstallPrompt((Activity)activity, (int)n2, (String)string2);
    }

    public static boolean showInstallPrompt(Activity activity, int n2, BranchUniversalObject branchUniversalObject) {
        if (branchUniversalObject != null) {
            String string2 = branchUniversalObject.getShortUrl((Context)activity, new LinkProperties());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Defines.Jsonkey.ReferringLink.getKey());
            stringBuilder.append("=");
            stringBuilder.append(string2);
            String string3 = stringBuilder.toString();
            if (!TextUtils.isEmpty((CharSequence)string3)) {
                return Branch.showInstallPrompt(activity, n2, string3);
            }
            return Branch.showInstallPrompt(activity, n2, "");
        }
        return false;
    }

    public static boolean showInstallPrompt(Activity activity, int n2, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Defines.Jsonkey.IsFullAppConv.getKey());
        stringBuilder.append("=true&");
        stringBuilder.append(string2);
        return InstantAppUtil.doShowInstallPrompt((Activity)activity, (int)n2, (String)stringBuilder.toString());
    }

    static void shutDown() {
        ServerRequestQueue.shutDown();
        PrefHelper.shutDown();
        BranchUtil.shutDown();
        DeviceInfo.shutDown();
        Branch branch = branchReferral_;
        if (branch != null) {
            branch.context_ = null;
            branch.currentActivityReference_ = null;
        }
        branchReferral_ = null;
        customReferrableSettings_ = CUSTOM_REFERRABLE_SETTINGS.USE_DEFAULT;
        bypassCurrentActivityIntentState_ = false;
        disableInstantDeepLinking = false;
        isActivityLifeCycleCallbackRegistered_ = false;
        isAutoSessionMode_ = false;
        isForcedSession_ = false;
        isSimulatingInstalls_ = false;
        checkInstallReferrer_ = true;
    }

    private void startSession(Activity activity) {
        Uri uri = activity.getIntent() != null ? activity.getIntent().getData() : null;
        WeakReference<BranchReferralInitListener> weakReference = this.deferredInitListener_;
        BranchReferralInitListener branchReferralInitListener = null;
        if (weakReference != null) {
            branchReferralInitListener = weakReference.get();
        }
        this.isInitReportedThroughCallBack = false;
        this.initSession(branchReferralInitListener, uri, activity);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void updateAllRequestsInQueue() {
        try {
            for (int n2 = 0; n2 < this.requestQueue_.getSize(); ++n2) {
                JSONObject jSONObject;
                ServerRequest serverRequest = this.requestQueue_.peekAt(n2);
                if (serverRequest == null || (jSONObject = serverRequest.getPost()) == null) continue;
                if (jSONObject.has(Defines.Jsonkey.SessionID.getKey())) {
                    serverRequest.getPost().put(Defines.Jsonkey.SessionID.getKey(), (Object)this.prefHelper_.getSessionID());
                }
                if (jSONObject.has(Defines.Jsonkey.IdentityID.getKey())) {
                    serverRequest.getPost().put(Defines.Jsonkey.IdentityID.getKey(), (Object)this.prefHelper_.getIdentityID());
                }
                if (!jSONObject.has(Defines.Jsonkey.DeviceFingerprintID.getKey())) continue;
                serverRequest.getPost().put(Defines.Jsonkey.DeviceFingerprintID.getKey(), (Object)this.prefHelper_.getDeviceFingerPrintID());
            }
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
        }
    }

    public void addExtraInstrumentationData(String string2, String string3) {
        this.instrumentationExtraData_.put((Object)string2, (Object)string3);
    }

    public void addExtraInstrumentationData(HashMap<String, String> hashMap) {
        this.instrumentationExtraData_.putAll(hashMap);
    }

    public Branch addInstallMetadata(String string2, String string3) {
        this.prefHelper_.addInstallMetadata(string2, string3);
        return this;
    }

    /*
     * Exception decompiling
     */
    public void addModule(JSONObject var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl6 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public Branch addUriHostsToSkip(String string2) {
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            UniversalResourceAnalyser.getInstance((Context)this.context_).addToSkipURLFormats(string2);
        }
        return this;
    }

    public Branch addWhiteListedScheme(String string2) {
        if (string2 != null) {
            UniversalResourceAnalyser.getInstance((Context)this.context_).addToAcceptURLFormats(string2);
        }
        return this;
    }

    public void cancelShareLinkDialog(boolean bl) {
        ShareLinkManager shareLinkManager = this.shareLinkManager_;
        if (shareLinkManager != null) {
            shareLinkManager.cancelShareLinkDialog(bl);
        }
    }

    void clearPendingRequests() {
        this.requestQueue_.clear();
    }

    public void closeSession() {
        PrefHelper.Debug((String)"closeSession() method is deprecated from SDK v1.14.6.Session is  automatically handled by Branch.In case you need to handle sessions manually inorder to support minimum sdk version less than 14 please consider using  SDK version 1.14.5");
    }

    void closeSessionInternal() {
        this.executeClose();
        this.resetSessionReferredLink();
        this.trackingController.updateTrackingState(this.context_);
    }

    public void disableAppList() {
    }

    public void disableTracking(boolean bl) {
        this.trackingController.disableTracking(this.context_, bl);
    }

    public void enableFacebookAppLinkCheck() {
        this.enableFacebookAppLinkCheck_ = true;
    }

    String generateShortLinkInternal(ServerRequestCreateUrl serverRequestCreateUrl) {
        if (!serverRequestCreateUrl.constructError_ && !serverRequestCreateUrl.handleErrors(this.context_)) {
            if (this.linkCache_.containsKey((Object)serverRequestCreateUrl.getLinkPost())) {
                String string2 = (String)this.linkCache_.get((Object)serverRequestCreateUrl.getLinkPost());
                serverRequestCreateUrl.onUrlAvailable(string2);
                return string2;
            }
            if (serverRequestCreateUrl.isAsync()) {
                this.generateShortLinkAsync((ServerRequest)serverRequestCreateUrl);
            } else {
                return this.generateShortLinkSync(serverRequestCreateUrl);
            }
        }
        return null;
    }

    public Context getApplicationContext() {
        return this.context_;
    }

    public void getCreditHistory(BranchListResponseListener branchListResponseListener) {
        this.getCreditHistory(null, null, 100, CreditHistoryOrder.kMostRecentFirst, branchListResponseListener);
    }

    public void getCreditHistory(String string2, int n2, CreditHistoryOrder creditHistoryOrder, BranchListResponseListener branchListResponseListener) {
        this.getCreditHistory(null, string2, n2, creditHistoryOrder, branchListResponseListener);
    }

    public void getCreditHistory(String string2, BranchListResponseListener branchListResponseListener) {
        this.getCreditHistory(string2, null, 100, CreditHistoryOrder.kMostRecentFirst, branchListResponseListener);
    }

    public void getCreditHistory(String string2, String string3, int n2, CreditHistoryOrder creditHistoryOrder, BranchListResponseListener branchListResponseListener) {
        ServerRequestGetRewardHistory serverRequestGetRewardHistory = new ServerRequestGetRewardHistory(this.context_, string2, string3, n2, creditHistoryOrder, branchListResponseListener);
        if (!serverRequestGetRewardHistory.constructError_ && !serverRequestGetRewardHistory.handleErrors(this.context_)) {
            this.handleNewRequest((ServerRequest)serverRequestGetRewardHistory);
        }
    }

    public int getCredits() {
        return this.prefHelper_.getCreditCount();
    }

    public int getCreditsForBucket(String string2) {
        return this.prefHelper_.getCreditCount(string2);
    }

    public void getCrossPlatformIds(BranchCrossPlatformId.BranchCrossPlatformIdListener branchCrossPlatformIdListener) {
        new BranchCrossPlatformId(branchCrossPlatformIdListener, this.context_);
    }

    public JSONObject getDeeplinkDebugParams() {
        JSONObject jSONObject = this.deeplinkDebugParams_;
        if (jSONObject != null && jSONObject.length() > 0) {
            PrefHelper.Debug((String)"You're currently in deep link debug mode. Please comment out 'setDeepLinkDebugMode' to receive the deep link parameters from a real Branch link");
        }
        return this.deeplinkDebugParams_;
    }

    public JSONObject getFirstReferringParams() {
        return this.appendDebugParams(this.convertParamsStringToDictionary(this.prefHelper_.getInstallParams()));
    }

    /*
     * Exception decompiling
     */
    public JSONObject getFirstReferringParamsSync() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public void getLastAttributedTouchData(BranchLastAttributedTouchData.BranchLastAttributedTouchDataListener branchLastAttributedTouchDataListener, int n2) {
        this.prefHelper_.setLATDAttributonWindow(n2);
        new BranchLastAttributedTouchData(branchLastAttributedTouchDataListener, this.context_);
    }

    public JSONObject getLatestReferringParams() {
        return this.appendDebugParams(this.convertParamsStringToDictionary(this.prefHelper_.getSessionParams()));
    }

    /*
     * Exception decompiling
     */
    public JSONObject getLatestReferringParamsSync() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    String getSessionReferredLink() {
        String string2 = this.prefHelper_.getExternalIntentUri();
        if (string2.equals((Object)"bnc_no_value")) {
            string2 = null;
        }
        return string2;
    }

    public void handleNewRequest(ServerRequest serverRequest) {
        if (this.trackingController.isTrackingDisabled() && !serverRequest.prepareExecuteWithoutTracking()) {
            serverRequest.reportTrackingDisabledError();
            return;
        }
        if (this.initState_ != SESSION_STATE.INITIALISED && !(serverRequest instanceof ServerRequestInitSession)) {
            if (serverRequest instanceof ServerRequestLogout) {
                serverRequest.handleFailure(-101, "");
                PrefHelper.Debug((String)"Branch is not initialized, cannot logout");
                return;
            }
            if (serverRequest instanceof ServerRequestRegisterClose) {
                PrefHelper.Debug((String)"Branch is not initialized, cannot close session");
                return;
            }
            WeakReference<Activity> weakReference = this.currentActivityReference_;
            Activity activity = weakReference != null ? (Activity)weakReference.get() : null;
            CUSTOM_REFERRABLE_SETTINGS cUSTOM_REFERRABLE_SETTINGS = customReferrableSettings_;
            CUSTOM_REFERRABLE_SETTINGS cUSTOM_REFERRABLE_SETTINGS2 = CUSTOM_REFERRABLE_SETTINGS.USE_DEFAULT;
            boolean bl = true;
            if (cUSTOM_REFERRABLE_SETTINGS == cUSTOM_REFERRABLE_SETTINGS2) {
                this.initUserSessionInternal(null, activity, bl);
            } else {
                if (customReferrableSettings_ != CUSTOM_REFERRABLE_SETTINGS.REFERRABLE) {
                    bl = false;
                }
                this.initUserSessionInternal(null, activity, bl);
            }
        }
        if (!(serverRequest instanceof ServerRequestPing)) {
            this.requestQueue_.enqueue(serverRequest);
            serverRequest.onRequestQueued();
        }
        this.processNextQueueItem();
    }

    public boolean initSession() {
        return this.initSession((Activity)null);
    }

    public boolean initSession(Activity activity) {
        return this.initSession(null, activity);
    }

    public boolean initSession(BranchReferralInitListener branchReferralInitListener) {
        return this.initSession(branchReferralInitListener, (Activity)null);
    }

    public boolean initSession(BranchReferralInitListener branchReferralInitListener, Activity activity) {
        if (customReferrableSettings_ == CUSTOM_REFERRABLE_SETTINGS.USE_DEFAULT) {
            this.initUserSessionInternal(branchReferralInitListener, activity, true);
            return true;
        }
        boolean bl = customReferrableSettings_ == CUSTOM_REFERRABLE_SETTINGS.REFERRABLE;
        this.initUserSessionInternal(branchReferralInitListener, activity, bl);
        return true;
    }

    public boolean initSession(BranchReferralInitListener branchReferralInitListener, Uri uri) {
        return this.initSession(branchReferralInitListener, uri, null);
    }

    public boolean initSession(BranchReferralInitListener branchReferralInitListener, Uri uri, Activity activity) {
        this.readAndStripParam(uri, activity);
        return this.initSession(branchReferralInitListener, activity);
    }

    public boolean initSession(BranchReferralInitListener branchReferralInitListener, boolean bl) {
        return this.initSession(branchReferralInitListener, bl, (Activity)null);
    }

    public boolean initSession(BranchReferralInitListener branchReferralInitListener, boolean bl, Activity activity) {
        this.initUserSessionInternal(branchReferralInitListener, activity, bl);
        return true;
    }

    public boolean initSession(BranchReferralInitListener branchReferralInitListener, boolean bl, Uri uri) {
        return this.initSession(branchReferralInitListener, bl, uri, null);
    }

    public boolean initSession(BranchReferralInitListener branchReferralInitListener, boolean bl, Uri uri, Activity activity) {
        this.readAndStripParam(uri, activity);
        return this.initSession(branchReferralInitListener, bl, activity);
    }

    public boolean initSession(BranchUniversalReferralInitListener branchUniversalReferralInitListener) {
        return this.initSession(branchUniversalReferralInitListener, (Activity)null);
    }

    public boolean initSession(BranchUniversalReferralInitListener branchUniversalReferralInitListener, Activity activity) {
        if (customReferrableSettings_ == CUSTOM_REFERRABLE_SETTINGS.USE_DEFAULT) {
            this.initUserSessionInternal(branchUniversalReferralInitListener, activity, true);
            return true;
        }
        boolean bl = customReferrableSettings_ == CUSTOM_REFERRABLE_SETTINGS.REFERRABLE;
        this.initUserSessionInternal(branchUniversalReferralInitListener, activity, bl);
        return true;
    }

    public boolean initSession(BranchUniversalReferralInitListener branchUniversalReferralInitListener, Uri uri) {
        return this.initSession(branchUniversalReferralInitListener, uri, null);
    }

    public boolean initSession(BranchUniversalReferralInitListener branchUniversalReferralInitListener, Uri uri, Activity activity) {
        this.readAndStripParam(uri, activity);
        this.initSession(branchUniversalReferralInitListener, activity);
        return true;
    }

    public boolean initSession(BranchUniversalReferralInitListener branchUniversalReferralInitListener, boolean bl) {
        return this.initSession(branchUniversalReferralInitListener, bl, (Activity)null);
    }

    public boolean initSession(BranchUniversalReferralInitListener branchUniversalReferralInitListener, boolean bl, Activity activity) {
        this.initUserSessionInternal(branchUniversalReferralInitListener, activity, bl);
        return true;
    }

    public boolean initSession(BranchUniversalReferralInitListener branchUniversalReferralInitListener, boolean bl, Uri uri) {
        return this.initSession(branchUniversalReferralInitListener, bl, uri, null);
    }

    public boolean initSession(BranchUniversalReferralInitListener branchUniversalReferralInitListener, boolean bl, Uri uri, Activity activity) {
        this.readAndStripParam(uri, activity);
        return this.initSession(branchUniversalReferralInitListener, bl, activity);
    }

    public boolean initSession(boolean bl) {
        return this.initSession(null, bl, (Activity)null);
    }

    public boolean initSession(boolean bl, Activity activity) {
        return this.initSession(null, bl, activity);
    }

    public boolean initSessionForced(BranchReferralInitListener branchReferralInitListener) {
        Branch.enableForcedSession();
        if (this.initSession(branchReferralInitListener, (Activity)null)) {
            this.processNextQueueItem();
            return true;
        }
        return false;
    }

    public boolean initSessionWithData(Uri uri) {
        return this.initSessionWithData(uri, null);
    }

    public boolean initSessionWithData(Uri uri, Activity activity) {
        this.readAndStripParam(uri, activity);
        return this.initSession(null, activity);
    }

    public boolean isTrackingDisabled() {
        return this.trackingController.isTrackingDisabled();
    }

    public boolean isUserIdentified() {
        return true ^ this.prefHelper_.getIdentity().equals((Object)"bnc_no_value");
    }

    public void loadRewards() {
        this.loadRewards(null);
    }

    public void loadRewards(BranchReferralStateChangedListener branchReferralStateChangedListener) {
        ServerRequestGetRewards serverRequestGetRewards = new ServerRequestGetRewards(this.context_, branchReferralStateChangedListener);
        if (!serverRequestGetRewards.constructError_ && !serverRequestGetRewards.handleErrors(this.context_)) {
            this.handleNewRequest((ServerRequest)serverRequestGetRewards);
        }
    }

    public void logout() {
        this.logout(null);
    }

    public void logout(LogoutStatusListener logoutStatusListener) {
        ServerRequestLogout serverRequestLogout = new ServerRequestLogout(this.context_, logoutStatusListener);
        if (!serverRequestLogout.constructError_ && !serverRequestLogout.handleErrors(this.context_)) {
            this.handleNewRequest((ServerRequest)serverRequestLogout);
        }
    }

    public void notifyNetworkAvailable() {
        this.handleNewRequest((ServerRequest)new ServerRequestPing(this.context_));
    }

    @Override
    public void onBranchViewAccepted(String string2, String string3) {
        if (ServerRequestInitSession.isInitSessionAction((String)string2)) {
            this.checkForAutoDeepLinkConfiguration();
        }
    }

    @Override
    public void onBranchViewCancelled(String string2, String string3) {
        if (ServerRequestInitSession.isInitSessionAction((String)string2)) {
            this.checkForAutoDeepLinkConfiguration();
        }
    }

    @Override
    public void onBranchViewError(int n2, String string2, String string3) {
        if (ServerRequestInitSession.isInitSessionAction((String)string3)) {
            this.checkForAutoDeepLinkConfiguration();
        }
    }

    @Override
    public void onBranchViewVisible(String string2, String string3) {
    }

    @Override
    public void onGAdsFetchFinished() {
        this.isGAParamsFetchInProgress_ = false;
        this.requestQueue_.unlockProcessWait(ServerRequest.PROCESS_WAIT_LOCK.GAID_FETCH_WAIT_LOCK);
        if (this.performCookieBasedStrongMatchingOnGAIDAvailable) {
            this.performCookieBasedStrongMatch();
            this.performCookieBasedStrongMatchingOnGAIDAvailable = false;
            return;
        }
        this.processNextQueueItem();
    }

    @Override
    public void onInstallReferrerEventsFinished() {
        this.requestQueue_.unlockProcessWait(ServerRequest.PROCESS_WAIT_LOCK.INSTALL_REFERRER_FETCH_WAIT_LOCK);
        this.processNextQueueItem();
    }

    public boolean reInitSession(Activity activity, BranchReferralInitListener branchReferralInitListener) {
        Uri uri;
        if (activity == null) {
            return false;
        }
        Intent intent = activity.getIntent();
        if (intent != null && (uri = intent.getData()) != null) {
            this.initState_ = SESSION_STATE.INITIALISING;
            this.setSessionReferredLink(uri.toString());
            this.prefHelper_.setAppLink(uri.toString());
            this.isInitReportedThroughCallBack = false;
            this.initializeSession(branchReferralInitListener);
            this.initSession(branchReferralInitListener, uri, activity);
        }
        return true;
    }

    public void redeemRewards(int n2) {
        this.redeemRewards(Defines.Jsonkey.DefaultBucket.getKey(), n2, null);
    }

    public void redeemRewards(int n2, BranchReferralStateChangedListener branchReferralStateChangedListener) {
        this.redeemRewards(Defines.Jsonkey.DefaultBucket.getKey(), n2, branchReferralStateChangedListener);
    }

    public void redeemRewards(String string2, int n2) {
        this.redeemRewards(string2, n2, null);
    }

    public void redeemRewards(String string2, int n2, BranchReferralStateChangedListener branchReferralStateChangedListener) {
        ServerRequestRedeemRewards serverRequestRedeemRewards = new ServerRequestRedeemRewards(this.context_, string2, n2, branchReferralStateChangedListener);
        if (!serverRequestRedeemRewards.constructError_ && !serverRequestRedeemRewards.handleErrors(this.context_)) {
            this.handleNewRequest((ServerRequest)serverRequestRedeemRewards);
        }
    }

    void registerAppReInit() {
        if (!this.trackingController.isTrackingDisabled()) {
            this.isGAParamsFetchInProgress_ = this.deviceInfo_.getSystemObserver().prefetchGAdsParams(this.context_, (SystemObserver.GAdsParamsFetchEvents)this);
        }
        if (this.networkCount_ != 0) {
            this.networkCount_ = 0;
            this.requestQueue_.clear();
        }
        ServerRequest serverRequest = this.getInstallOrOpenRequest(null);
        if (this.isGAParamsFetchInProgress_) {
            serverRequest.addProcessWaitLock(ServerRequest.PROCESS_WAIT_LOCK.GAID_FETCH_WAIT_LOCK);
        }
        this.registerInstallOrOpen(serverRequest, null);
    }

    public void registerView(BranchUniversalObject branchUniversalObject, BranchUniversalObject.RegisterViewStatusListener registerViewStatusListener) {
        if (this.context_ != null) {
            new BranchEvent(BRANCH_STANDARD_EVENT.VIEW_ITEM).addContentItems(new BranchUniversalObject[]{branchUniversalObject}).logEvent(this.context_);
        }
    }

    public void resetUserSession() {
        this.initState_ = SESSION_STATE.UNINITIALISED;
    }

    public void sendCommerceEvent(CommerceEvent commerceEvent) {
        this.sendCommerceEvent(commerceEvent, null, null);
    }

    public void sendCommerceEvent(CommerceEvent commerceEvent, JSONObject jSONObject, BranchViewHandler.IBranchViewEvents iBranchViewEvents) {
        ServerRequestRActionCompleted serverRequestRActionCompleted = new ServerRequestRActionCompleted(this.context_, commerceEvent, jSONObject, iBranchViewEvents);
        if (!serverRequestRActionCompleted.constructError_ && !serverRequestRActionCompleted.handleErrors(this.context_)) {
            this.handleNewRequest((ServerRequest)serverRequestRActionCompleted);
        }
    }

    public void setBranchRemoteInterface(BranchRemoteInterface branchRemoteInterface) {
        this.branchRemoteInterface_ = branchRemoteInterface;
    }

    public void setDebug() {
        Branch.enableDebugMode();
    }

    public void setDeepLinkDebugMode(JSONObject jSONObject) {
        this.deeplinkDebugParams_ = jSONObject;
    }

    public void setIdentity(String string2) {
        this.setIdentity(string2, null);
    }

    public void setIdentity(String string2, BranchReferralInitListener branchReferralInitListener) {
        ServerRequestIdentifyUserRequest serverRequestIdentifyUserRequest = new ServerRequestIdentifyUserRequest(this.context_, branchReferralInitListener, string2);
        if (!serverRequestIdentifyUserRequest.constructError_ && !serverRequestIdentifyUserRequest.handleErrors(this.context_)) {
            this.handleNewRequest((ServerRequest)serverRequestIdentifyUserRequest);
            return;
        }
        ServerRequestIdentifyUserRequest serverRequestIdentifyUserRequest2 = serverRequestIdentifyUserRequest;
        if (serverRequestIdentifyUserRequest2.isExistingID()) {
            serverRequestIdentifyUserRequest2.handleUserExist(branchReferral_);
        }
    }

    public void setLimitFacebookTracking(boolean bl) {
        this.prefHelper_.setLimitFacebookTracking(bl);
    }

    public void setNetworkTimeout(int n2) {
        PrefHelper prefHelper = this.prefHelper_;
        if (prefHelper != null && n2 > 0) {
            prefHelper.setTimeout(n2);
        }
    }

    public Branch setPreinstallCampaign(String string2) {
        this.addInstallMetadata(Defines.PreinstallKey.campaign.getKey(), string2);
        return this;
    }

    public Branch setPreinstallPartner(String string2) {
        this.addInstallMetadata(Defines.PreinstallKey.partner.getKey(), string2);
        return this;
    }

    public void setRequestMetadata(String string2, String string3) {
        this.prefHelper_.setRequestMetadata(string2, string3);
    }

    public void setRetryCount(int n2) {
        PrefHelper prefHelper = this.prefHelper_;
        if (prefHelper != null && n2 >= 0) {
            prefHelper.setRetryCount(n2);
        }
    }

    public void setRetryInterval(int n2) {
        PrefHelper prefHelper = this.prefHelper_;
        if (prefHelper != null && n2 > 0) {
            prefHelper.setRetryInterval(n2);
        }
    }

    public Branch setWhiteListedSchemes(List<String> list) {
        if (list != null) {
            UniversalResourceAnalyser.getInstance((Context)this.context_).addToAcceptURLFormats(list);
        }
        return this;
    }

    void updateSkipURLFormats() {
        UniversalResourceAnalyser.getInstance((Context)this.context_).checkAndUpdateSkipURLFormats(this.context_);
    }

    public void userCompletedAction(String string2) {
        this.userCompletedAction(string2, null, null);
    }

    public void userCompletedAction(String string2, BranchViewHandler.IBranchViewEvents iBranchViewEvents) {
        this.userCompletedAction(string2, null, iBranchViewEvents);
    }

    public void userCompletedAction(String string2, JSONObject jSONObject) {
        this.userCompletedAction(string2, jSONObject, null);
    }

    public void userCompletedAction(String string2, JSONObject jSONObject, BranchViewHandler.IBranchViewEvents iBranchViewEvents) {
        ServerRequestActionCompleted serverRequestActionCompleted = new ServerRequestActionCompleted(this.context_, string2, jSONObject, iBranchViewEvents);
        if (!serverRequestActionCompleted.constructError_ && !serverRequestActionCompleted.handleErrors(this.context_)) {
            this.handleNewRequest((ServerRequest)serverRequestActionCompleted);
        }
    }
}

