/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.ReactPackage
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.uimanager.ViewManager
 *  io.invertase.firebase.analytics.RNFirebaseAnalytics
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 */
package io.invertase.firebase.analytics;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import io.invertase.firebase.analytics.RNFirebaseAnalytics;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RNFirebaseAnalyticsPackage
implements ReactPackage {
    public List<NativeModule> createNativeModules(ReactApplicationContext reactApplicationContext) {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new RNFirebaseAnalytics(reactApplicationContext));
        return arrayList;
    }

    public List<ViewManager> createViewManagers(ReactApplicationContext reactApplicationContext) {
        return Collections.emptyList();
    }
}

